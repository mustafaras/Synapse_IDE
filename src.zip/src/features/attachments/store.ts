import { create } from 'zustand';
import type { AttachmentMeta } from './types';

export type AttachState = {
  list: AttachmentMeta[];
  addMany: (items: AttachmentMeta[]) => void;
  remove: (id: string) => void;
  clear: () => void;
};

export const useAttachStore = create<AttachState>()((set) => ({
  list: [],
  addMany: (items) => set(s => ({ list: [...items, ...s.list] })), // newest first
  remove: (id) => set(s => ({ list: s.list.filter(x => x.id !== id) })),
  clear: () => set({ list: [] }),
}));

export const useAttachments = () => useAttachStore(s => s.list);
