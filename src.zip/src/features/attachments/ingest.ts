import type { AttachKind } from './types';

export const MAX_TEXT_BYTES = 1_000_000;   // 1MB text extraction cap
export const MAX_FILE_BYTES = 10_000_000;  // 10MB overall cap (configurable)
const TEXT_MIMES = ['text/plain', 'text/markdown', 'application/json', 'application/xml', 'text/xml'];
const CODE_EXTS = ['.ts','.tsx','.js','.jsx','.py','.java','.cs','.cpp','.rs','.go','.php','.rb','.sql','.sh','.ps1','.html','.css','.json','.md','.yaml','.yml','.toml','.vue','.svelte','.c','.h','.hpp'];

export function sanitizeName(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]/g, '-').slice(0, 80);
}

export async function sha256(file: File): Promise<string> {
  const buf = await file.arrayBuffer();
  const dig = await crypto.subtle.digest('SHA-256', buf);
  return [...new Uint8Array(dig)].map(b => b.toString(16).padStart(2, '0')).join('');
}

export function sniffKind(name: string, mime: string): AttachKind {
  const low = name.toLowerCase();
  if (mime.startsWith('image/')) return 'image';
  if (mime === 'application/pdf' || low.endsWith('.pdf')) return 'pdf';
  if (TEXT_MIMES.includes(mime)) {
    if (CODE_EXTS.some(ext => low.endsWith(ext))) return 'code';
    if (low.endsWith('.csv')) return 'csv';
    if (mime === 'application/json') return 'json';
    return 'text';
  }
  if (CODE_EXTS.some(ext => low.endsWith(ext))) return 'code';
  return 'other';
}

export async function readTextSafely(file: File): Promise<string | undefined> {
  if (file.size > MAX_TEXT_BYTES) return undefined;
  const text = await file.text();
  // basic binary guard: if too many NULs/controls, drop
  // eslint-disable-next-line no-control-regex
  const ctrl = (text.match(/[\x00-\x08\x0E-\x1F]/g) || []).length;
  if (ctrl / Math.max(1, text.length) > 0.01) return undefined;
  return text;
}
