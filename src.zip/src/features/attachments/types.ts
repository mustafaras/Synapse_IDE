export type AttachKind = 'text' | 'code' | 'json' | 'csv' | 'image' | 'pdf' | 'other';

export interface AttachmentMeta {
  id: string;                // uuid
  name: string;              // sanitized file name
  ext: string;               // ".ts", ".txt", ".png", ...
  mime: string;              // browser-reported MIME
  size: number;              // bytes
  kind: AttachKind;          // coarse type bucket
  hash: string;              // sha256 hex for dedupe
  createdAt: number;
  previewUrl?: string | undefined;       // object URL for image/pdf
  textExcerpt?: string | undefined;      // small excerpt for UI
  textFull?: string | undefined;         // extracted text (guarded by size)
  parseWarnings?: string[] | undefined;  // non-fatal notes
}
