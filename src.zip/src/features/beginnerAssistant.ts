/**
 * Beginner Assistant feature flag & shared constants.
 *
 * Toggle BEGINNER_ASSISTANT_ENABLED to false to completely disable any newly
 * added Beginner Code Assistant UI / logic without touching existing IDE behavior.
 *
 * Integration rules:
 * - Add-only: never rename or remove existing components, stores, props, events.
 * - All new UI referencing this feature MUST be wrapped in a runtime check:
 *     if (!BEGINNER_ASSISTANT_ENABLED) return null;  (or conditional render)
 * - Keep theme (golden–black) and accessibility standards intact.
 * - Reuse existing preview & editor pipelines; no duplicate runners.
 */
export const BEGINNER_ASSISTANT_ENABLED = true; // Set to false for quick rollback / QA comparison

// Maximum number of primary actionable code blocks parsed from assistant output
export const CODE_BLOCK_MAX = 1;

// Throttle interval (ms) for streaming re-renders / preview auto-runs
export const STREAM_THROTTLE_MS = 250;

// (Optional) Helper for clarity in consuming components
export const isBeginnerAssistantEnabled = () => BEGINNER_ASSISTANT_ENABLED;
