import React, { createContext, useContext, useEffect, useState } from 'react';
import { ThemeProvider as StyledThemeProvider } from 'styled-components';
import { DESIGN_TOKENS } from '../constants/design';
import { type ActiveThemeName, type Theme, type ThemeName, themes } from '../styles/theme';

interface ThemeContextType {
  theme: Theme;
  themeName: ActiveThemeName;
  setTheme: (theme: ThemeName) => void;
  toggleTheme: () => void;
  designTokens: typeof DESIGN_TOKENS;
  applyThemeTransition: () => void; // New utility function
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: ThemeName;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({
  children,
  defaultTheme = 'dark', // 🚀 Changed to dark theme by default for pure black
}) => {
  const [themeName, setThemeName] = useState<ThemeName>(() => {
    const stored = localStorage.getItem('theme') as ThemeName;
    return stored && ['light', 'dark', 'neutral', 'auto'].includes(stored) ? stored : defaultTheme;
  });

  // Resolve auto theme to actual theme based on system preference
  const resolveTheme = (theme: ThemeName): ActiveThemeName => {
    if (theme === 'auto') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return theme as ActiveThemeName;
  };

  const activeThemeName = resolveTheme(themeName);
  const currentTheme = themes[activeThemeName];

  // Listen for system theme changes when 'auto' is selected
  useEffect(() => {
    if (themeName !== 'auto') return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => {
      // Force re-render by updating activeThemeName when system preference changes
      setThemeName('auto'); // This will trigger re-resolution
    };

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [themeName]);

  // Apply CSS variables for theme integration
  useEffect(() => {
    const root = document.documentElement;

    // === THEME-SPECIFIC VARIABLES ===
    // Apply all currentTheme properties with --theme-* prefix
    Object.entries(currentTheme).forEach(([key, value]) => {
      if (key === 'colors') {
        // Handle colors object separately
        Object.entries(value).forEach(([colorKey, colorValue]) => {
          root.style.setProperty(
            `--theme-${colorKey.replace(/([A-Z])/g, '-$1').toLowerCase()}`,
            String(colorValue)
          );
        });
      } else if (typeof value === 'string' || typeof value === 'number') {
        root.style.setProperty(
          `--theme-${key.replace(/([A-Z])/g, '-$1').toLowerCase()}`,
          String(value)
        );
      }
    });

    // === COLOR VARIABLES ===
    // Apply theme color variables with --color-* prefix for component compatibility
    Object.entries(currentTheme.colors).forEach(([key, value]) => {
      const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
      root.style.setProperty(`--color-${cssKey}`, value);
    });

    // === DESIGN TOKEN VARIABLES ===
    // Spacing system
    Object.entries(DESIGN_TOKENS.spacing).forEach(([key, value]) => {
      root.style.setProperty(`--spacing-${key}`, value);
    });

    // Border radius system
    Object.entries(DESIGN_TOKENS.borderRadius).forEach(([key, value]) => {
      root.style.setProperty(`--border-radius-${key}`, value);
    });

    // Shadow system
    Object.entries(DESIGN_TOKENS.shadows).forEach(([key, value]) => {
      root.style.setProperty(`--shadow-${key}`, value);
    });

    // Blur effects
    Object.entries(DESIGN_TOKENS.blur).forEach(([key, value]) => {
      root.style.setProperty(`--blur-${key}`, value);
    });

    // Transitions
    Object.entries(DESIGN_TOKENS.transitions).forEach(([key, value]) => {
      root.style.setProperty(`--transition-${key}`, value);
    });

    // Apply theme transition to document body
    document.body.style.transition = 'all 300ms ease-in-out';

    // Also apply theme transition to the root element
    root.style.transition = 'all 300ms ease-in-out';

    // Typography system
    Object.entries(DESIGN_TOKENS.typography.fontSize).forEach(([key, value]) => {
      root.style.setProperty(`--font-size-${key}`, value);
    });

    Object.entries(DESIGN_TOKENS.typography.fontWeight).forEach(([key, value]) => {
      root.style.setProperty(`--font-weight-${key}`, value.toString());
    });

    Object.entries(DESIGN_TOKENS.typography.lineHeight).forEach(([key, value]) => {
      root.style.setProperty(`--line-height-${key}`, value.toString());
    });

    // Font family
    Object.entries(DESIGN_TOKENS.typography.fontFamily).forEach(([key, value]) => {
      root.style.setProperty(`--font-family-${key}`, value);
    });

    // === GLASSMORPHISM VARIABLES ===
    Object.entries(DESIGN_TOKENS.glassmorphism.background).forEach(([key, value]) => {
      root.style.setProperty(`--glass-background-${key}`, value);
    });

    Object.entries(DESIGN_TOKENS.glassmorphism.border).forEach(([key, value]) => {
      root.style.setProperty(`--glass-border-${key}`, value);
    });

    Object.entries(DESIGN_TOKENS.glassmorphism.backdrop).forEach(([key, value]) => {
      root.style.setProperty(`--glass-backdrop-${key}`, value);
    });

    // === ANIMATION VARIABLES ===
    Object.entries(DESIGN_TOKENS.animation.duration).forEach(([key, value]) => {
      root.style.setProperty(`--duration-${key}`, value);
    });

    Object.entries(DESIGN_TOKENS.animation.easing).forEach(([key, value]) => {
      root.style.setProperty(`--easing-${key}`, value);
    });

    // === Z-INDEX VARIABLES ===
    Object.entries(DESIGN_TOKENS.zIndex).forEach(([key, value]) => {
      root.style.setProperty(`--z-${key}`, value.toString());
    });

    // === BREAKPOINTS ===
    Object.entries(DESIGN_TOKENS.breakpoints).forEach(([key, value]) => {
      root.style.setProperty(`--breakpoint-${key}`, value);
    });

    // === SPECIAL GLASS VARIABLES ===
    // Main glass effect variables for easy component access
    root.style.setProperty('--glass-background', currentTheme.colors.glass);
    root.style.setProperty('--glass-border', currentTheme.colors.glassBorder);
    root.style.setProperty('--glass-backdrop', DESIGN_TOKENS.glassmorphism.backdrop.glass);

    // Dynamic glass backdrop filter based on theme
    const glassBackdropFilter =
      activeThemeName === 'neutral'
        ? `${DESIGN_TOKENS.blur.glassDark} saturate(140%)`
        : activeThemeName === 'dark'
          ? `${DESIGN_TOKENS.blur.glass} saturate(180%)`
          : `${DESIGN_TOKENS.blur.glass} saturate(200%)`;
    root.style.setProperty('--glass-backdrop-filter', glassBackdropFilter);

    // === AI ASSISTANT VARIABLES ===
    // Theme-aware AI Assistant variables
    root.style.setProperty('--assistant-background', currentTheme.colors.aiBackground);
    root.style.setProperty('--assistant-bg', currentTheme.colors.aiBackground);
    root.style.setProperty('--assistant-glass', currentTheme.colors.glass);
    root.style.setProperty('--assistant-border', currentTheme.colors.glassBorder);
    root.style.setProperty('--assistant-text-primary', currentTheme.colors.text);
    root.style.setProperty('--assistant-text-secondary', currentTheme.colors.textSecondary);
    root.style.setProperty('--assistant-primary', currentTheme.colors.primary);
    root.style.setProperty('--assistant-accent', currentTheme.colors.accent);
    root.style.setProperty('--assistant-shadow', currentTheme.colors.shadowHover);
    root.style.setProperty('--assistant-shadow-hover', currentTheme.colors.shadowHover);

    // Enhanced hover and tag colors with theme adaptation
    root.style.setProperty('--tag-hover-accent', currentTheme.colors.accent);
    root.style.setProperty('--tag-glow-color', `${currentTheme.colors.accent}30`);
    root.style.setProperty('--tag-glow-strong', `${currentTheme.colors.accent}40`);
    root.style.setProperty('--tag-text-shadow', `0 0 8px ${currentTheme.colors.accent}60`);

    // Theme-specific tag hover behaviors
    const tagHoverGlow =
      activeThemeName === 'dark'
        ? `0 4px 12px ${currentTheme.colors.accent}40, 0 0 20px ${currentTheme.colors.accent}30`
        : activeThemeName === 'light'
          ? `0 4px 12px ${currentTheme.colors.accent}25, 0 0 15px ${currentTheme.colors.accent}20`
          : `0 4px 12px ${currentTheme.colors.accent}35, 0 0 18px ${currentTheme.colors.accent}25`;
    root.style.setProperty('--tag-hover-glow', tagHoverGlow);

    const tagActiveGlow =
      activeThemeName === 'dark'
        ? `0 6px 16px ${currentTheme.colors.accent}50, 0 0 30px ${currentTheme.colors.accent}40`
        : activeThemeName === 'light'
          ? `0 6px 16px ${currentTheme.colors.accent}30, 0 0 25px ${currentTheme.colors.accent}25`
          : `0 6px 16px ${currentTheme.colors.accent}40, 0 0 28px ${currentTheme.colors.accent}30`;
    root.style.setProperty('--tag-active-glow', tagActiveGlow);

    // App title color - high contrast for all themes
    const appTitleColor =
      activeThemeName === 'dark'
        ? '#FFFFFF' // Pure white for maximum contrast on dark themes
        : activeThemeName === 'light'
          ? '#1A1A1A' // Near black for maximum contrast on light themes
          : '#2D3748'; // Dark gray for neutral theme with good contrast
    root.style.setProperty('--app-title-color', appTitleColor);

    // Enhanced contrast variables for critical text elements
    const highContrastTextSecondary =
      activeThemeName === 'dark'
        ? '#d1d5db' // AA compliant light text for dark themes
        : activeThemeName === 'light'
          ? '#475569' // AA compliant dark text for light themes
          : '#d1d5db'; // AA compliant light text for neutral theme
    root.style.setProperty('--text-secondary-high-contrast', highContrastTextSecondary);

    // AA compliant minimum contrast ratios
    root.style.setProperty(
      '--text-contrast-aa',
      activeThemeName === 'dark' ? '#ffffff' : '#000000'
    );
    root.style.setProperty(
      '--text-contrast-aaa',
      activeThemeName === 'dark' ? '#ffffff' : '#1a1a1a'
    );

    // === COMPONENT-SPECIFIC VARIABLES ===
    // Button variables
    root.style.setProperty('--button-primary-bg', currentTheme.colors.primary);
    root.style.setProperty('--button-primary-hover', currentTheme.colors.primary);
    root.style.setProperty('--button-glass-bg', currentTheme.colors.glass);
    root.style.setProperty('--button-glass-border', currentTheme.colors.glassBorder);

    // Card variables with theme-based opacity
    root.style.setProperty('--card-background', currentTheme.colors.surface);
    root.style.setProperty('--card-border', currentTheme.colors.border);
    root.style.setProperty('--card-glass-bg', currentTheme.colors.glass);
    root.style.setProperty('--card-glass-border', currentTheme.colors.glassBorder);

    // Theme-based card opacity for different levels of transparency
    const cardOpacity =
      activeThemeName === 'dark'
        ? '0.95' // Slightly transparent on dark themes for better depth
        : activeThemeName === 'light'
          ? '0.98' // Nearly opaque on light themes
          : '0.92'; // More transparent on neutral theme for subtle appearance
    root.style.setProperty('--card-opacity', cardOpacity);

    // Input variables
    root.style.setProperty('--input-background', currentTheme.colors.surface);
    root.style.setProperty('--input-border', currentTheme.colors.border);
    root.style.setProperty('--input-focus', currentTheme.colors.primary);

    // Modal variables
    root.style.setProperty('--modal-background', currentTheme.colors.background);
    root.style.setProperty('--modal-glass-bg', currentTheme.colors.glass);
    root.style.setProperty('--modal-overlay', `${currentTheme.colors.glass}80`);

    // === THEME-SPECIFIC DYNAMIC VARIABLES ===
    // IDE/Editor variables
    root.style.setProperty('--editor-background', currentTheme.colors.background);
    root.style.setProperty('--editor-surface', currentTheme.colors.surface);
    root.style.setProperty('--editor-text', currentTheme.colors.text);
    root.style.setProperty('--editor-text-secondary', currentTheme.colors.textSecondary);

    // Sidebar variables
    root.style.setProperty('--sidebar-background', currentTheme.colors.glass);
    root.style.setProperty('--sidebar-border', currentTheme.colors.glassBorder);
    root.style.setProperty('--sidebar-backdrop', glassBackdropFilter);

    // Header/Toolbar variables
    root.style.setProperty('--header-background', currentTheme.colors.glass);
    root.style.setProperty('--header-border', currentTheme.colors.border);
    root.style.setProperty('--header-backdrop', glassBackdropFilter);

    // === ACCESSIBILITY & STATE VARIABLES ===
    // Focus states
    root.style.setProperty('--focus-ring', `0 0 0 2px ${currentTheme.colors.primary}40`);
    root.style.setProperty('--focus-ring-offset', '2px');

    // Hover states
    root.style.setProperty('--hover-background', `${currentTheme.colors.glass}80`);
    root.style.setProperty('--hover-border', currentTheme.colors.glassBorder);

    // Active states
    root.style.setProperty('--active-background', `${currentTheme.colors.primary}20`);
    root.style.setProperty('--active-border', currentTheme.colors.primary);

    // Disabled states
    root.style.setProperty('--disabled-background', `${currentTheme.colors.surface}60`);
    root.style.setProperty('--disabled-text', `${currentTheme.colors.textSecondary}60`);
    root.style.setProperty('--disabled-border', `${currentTheme.colors.border}40`);

    // === SEMANTIC COLOR VARIABLES ===
    root.style.setProperty('--success-color', currentTheme.colors.success);
    root.style.setProperty('--warning-color', currentTheme.colors.warning);
    root.style.setProperty('--error-color', currentTheme.colors.error);
    root.style.setProperty('--info-color', currentTheme.colors.info);

    // Semantic backgrounds
    root.style.setProperty('--success-background', `${currentTheme.colors.success}20`);
    root.style.setProperty('--warning-background', `${currentTheme.colors.warning}20`);
    root.style.setProperty('--error-background', `${currentTheme.colors.error}20`);
    root.style.setProperty('--info-background', `${currentTheme.colors.info}20`);

    // === LAYOUT & SPACING HELPERS ===
    // Container widths using breakpoints as base
    root.style.setProperty('--container-xs', DESIGN_TOKENS.breakpoints.xs);
    root.style.setProperty('--container-sm', DESIGN_TOKENS.breakpoints.sm);
    root.style.setProperty('--container-md', DESIGN_TOKENS.breakpoints.md);
    root.style.setProperty('--container-lg', DESIGN_TOKENS.breakpoints.lg);
    root.style.setProperty('--container-xl', DESIGN_TOKENS.breakpoints.xl);

    // === DOCUMENT UPDATES ===
    // Update document class for theme-specific styling
    document.documentElement.className = `theme-${activeThemeName}`;
    document.documentElement.setAttribute('data-theme', activeThemeName);

    // Add smooth transition effect for theme changes
    document.documentElement.style.transition = DESIGN_TOKENS.transitions.md;

    // Set body styles using CSS variables for consistency
    document.body.style.background = 'var(--color-background)';
    document.body.style.color = 'var(--color-text)';
    document.body.style.fontFamily = DESIGN_TOKENS.typography.fontFamily.primary;
    document.body.style.fontSize = DESIGN_TOKENS.typography.fontSize.md;
    document.body.style.lineHeight = DESIGN_TOKENS.typography.lineHeight.normal.toString();

    // Remove transition after animation completes to avoid affecting other animations
    setTimeout(() => {
      document.documentElement.style.transition = '';
    }, 300);
  }, [currentTheme, activeThemeName]);

  // Save theme preference
  useEffect(() => {
    localStorage.setItem('theme', themeName);
  }, [themeName]);

  const setTheme = React.useCallback((theme: ThemeName) => {
    if (Object.keys(themes).includes(theme)) {
      // Apply enhanced theme transition effects
      document.body.style.transition = 'all 300ms ease-in-out';
      document.documentElement.style.transition = 'all 300ms ease-in-out';

      // Add a subtle transition delay for smoother effect
      setTimeout(() => {
        setThemeName(theme);
      }, 10);

      // Reset transitions after theme change completes
      setTimeout(() => {
        document.body.style.transition = '';
        document.documentElement.style.transition = '';
      }, 350);
    }
  }, []);

  const toggleTheme = React.useCallback(() => {
    // Cycle through: Light → Dark → Neutral → Auto → Light
    const themeOrder: ThemeName[] = ['light', 'dark', 'neutral', 'auto'];
    const currentIndex = themeOrder.indexOf(themeName);
    const nextTheme = themeOrder[(currentIndex + 1) % themeOrder.length];
    setTheme(nextTheme);
  }, [themeName, setTheme]);

  // Utility function to apply theme transitions
  const applyThemeTransition = React.useCallback(() => {
    document.body.style.transition = 'all 300ms ease-in-out';
    document.documentElement.style.transition = 'all 300ms ease-in-out';

    // Reset after transition completes
    setTimeout(() => {
      document.body.style.transition = '';
      document.documentElement.style.transition = '';
    }, 350);
  }, []);

  const value = React.useMemo<ThemeContextType>(
    () => ({
      theme: currentTheme,
      themeName: activeThemeName,
      setTheme,
      toggleTheme,
      designTokens: DESIGN_TOKENS,
      applyThemeTransition,
    }),
    [currentTheme, activeThemeName, setTheme, toggleTheme, applyThemeTransition]
  );

  return (
    <ThemeContext.Provider value={value}>
      <StyledThemeProvider theme={currentTheme}>{children}</StyledThemeProvider>
    </ThemeContext.Provider>
  );
};
