import { type ChatMsg, loadDraft, loadHistory, migrateV1toV2, saveDraftDebounced, saveHistoryDebounced } from './chatPersistence';

export type ChatStateShape = {
  draft: string;
  messages: ChatMsg[];
};

export function initChatState(): ChatStateShape {
  try { migrateV1toV2(); } catch {}
  const d = loadDraft();
  const h = loadHistory();
  return {
    draft: d?.text ?? '',
    messages: h?.messages ?? [],
  };
}

export function onDraftChanged(next: string) {
  saveDraftDebounced(next);
}

export function onMessagesChanged(msgs: ChatMsg[]) {
  saveHistoryDebounced(msgs);
}
