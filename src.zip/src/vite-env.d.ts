/// <reference types="vite/client" />

// Theme type definitions for type safety
export type ThemeName = 'light' | 'dark' | 'neutral' | 'auto';

// Extract Theme type from themes object
export type Theme = typeof import('./styles/theme').themes.light;

// Theme context type definition
export interface ThemeContextType {
  theme: Theme;
  themeName: Exclude<ThemeName, 'auto'>;
  setTheme: (theme: ThemeName) => void;
  toggleTheme: () => void;
  designTokens: typeof import('./constants/design').DESIGN_TOKENS;
}

// Global CSS custom properties interface for better type safety
declare global {
  interface CSSStyleDeclaration {
    '--theme-glass': string;
    '--theme-primary': string;
    '--theme-shadow': string;
    '--glass-backdrop-filter': string;
    '--assistant-glow': string;
    '--assistant-bg': string;
    '--assistant-primary': string;
    '--assistant-shadow-hover': string;
    '--app-title-color': string;
  }
}
