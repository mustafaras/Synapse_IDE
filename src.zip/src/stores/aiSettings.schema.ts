import type { ProviderKey } from '@/utils/ai/models/registry';

export interface AiSettings {
  mode: 'beginner' | 'pro';
  provider: ProviderKey;
  model: string; // model id
  languageId: string; // e.g., 'typescript'
  temperature: number;
  maxTokens: number;
  stream: boolean;
  timeoutMs: number;
  safetyLevel?: 'standard' | 'strict' | 'off';
  keys?: Partial<Record<ProviderKey, string>>;
  activePresetId?: string;
  // Prompt 4: user-first toggles
  usePresets?: boolean; // default false
  useWorkspaceContext?: boolean; // default false
}

export interface AiPreset {
  id: string;
  label: string;
  values: Partial<AiSettings>;
}

export const BUILT_IN_PRESETS: AiPreset[] = [
  { id: 'BEGINNER_DEFAULT', label: 'Beginner — Single File', values: { mode: 'beginner', temperature: 0.3, stream: true } },
  { id: 'PRO_DEFAULT', label: 'Pro — Multi File', values: { mode: 'pro', temperature: 0.2, stream: true } },
];

// ==============
// Persistence (v2)
// ==============
export const AI_SETTINGS_V2_STORAGE_KEY = 'synapse.ai.settings.v2';

export const DEFAULT_AI_SETTINGS_V2: AiSettings = {
  mode: 'beginner',
  provider: 'openai',
  model: 'gpt-4o',
  languageId: 'typescript',
  temperature: 0.2,
  maxTokens: 2048,
  stream: true,
  timeoutMs: 30000,
  safetyLevel: 'standard',
  keys: { ollama: 'http://localhost:11434' },
  usePresets: false,
  useWorkspaceContext: false,
};

export type AiSettingsV2Listener = (s: AiSettings) => void;
const aiSettingsV2Listeners = new Set<AiSettingsV2Listener>();

export function loadAiSettingsV2(): AiSettings {
  try {
    const raw = localStorage.getItem(AI_SETTINGS_V2_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_AI_SETTINGS_V2 };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_AI_SETTINGS_V2, ...parsed } as AiSettings;
  } catch {
    return { ...DEFAULT_AI_SETTINGS_V2 };
  }
}

export function saveAiSettingsV2(s: AiSettings) {
  try {
    localStorage.setItem(AI_SETTINGS_V2_STORAGE_KEY, JSON.stringify(s));
  } finally {
    aiSettingsV2Listeners.forEach(fn => {
      try { fn(s); } catch { /* ignore */ }
    });
  }
}

export function subscribeAiSettingsV2(fn: AiSettingsV2Listener) {
  aiSettingsV2Listeners.add(fn);
  return () => aiSettingsV2Listeners.delete(fn);
}

export function mergeAiSettingsV2(base: AiSettings, patch: Partial<AiSettings>): AiSettings {
  const nextKeys: Partial<Record<ProviderKey, string>> = patch.keys ? { ...(base.keys || {}), ...patch.keys } : (base.keys || {});
  return { ...(base as AiSettings), ...(patch as AiSettings), keys: nextKeys } as AiSettings;
}
