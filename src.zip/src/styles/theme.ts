import { DESIGN_TOKENS, GLASSMORPHISM_PRESETS } from '../constants/design';

// Theme interface defining the structure of each theme
export interface ThemeColors {
  background: string;
  backgroundSecondary?: string;
  backgroundTertiary?: string;
  text: string;
  textPrimary?: string;
  textSecondary: string;
  textTertiary?: string;
  textDescription: string; // High-contrast color for description text (4.5:1 minimum)
  primary: string;
  primaryHover?: string;
  secondary?: string;
  accent: string;
  glass: string;
  glassBorder: string;
  aiBackground: string;
  shadowHover: string;
  surface: string;
  border: string;
  borderLight?: string;
  borderFocus?: string;
  success: string;
  warning: string;
  error: string;
  info: string;
}

export interface Theme {
  name: 'light' | 'dark' | 'neutral';
  colors: ThemeColors;
  shadows: typeof DESIGN_TOKENS.shadows;
  blur: typeof DESIGN_TOKENS.blur;
  spacing: typeof DESIGN_TOKENS.spacing;
  borderRadius: typeof DESIGN_TOKENS.borderRadius;
  transitions: typeof DESIGN_TOKENS.transitions;
  typography: typeof DESIGN_TOKENS.typography;
  glassmorphism: typeof DESIGN_TOKENS.glassmorphism;
}

// Light theme - Clean and professional
export const lightTheme: Theme = {
  name: 'light',
  colors: {
    background: '#ffffff', // Pure white
    backgroundSecondary: '#f8f9fa', // Light gray
    backgroundTertiary: '#f1f3f4', // Very light gray
    surface: 'rgba(255,255,255,0.6)', // Translucent white surface
    text: '#1f2937', // Dark gray (textPrimary)
    textPrimary: '#1f2937', // Dark gray - primary text
    textSecondary: '#6b7280', // Medium gray - secondary text
    textTertiary: '#9ca3af', // Light gray - tertiary text
    textDescription: '#1f2937', // WCAG AA compliant (4.5:1) description text
    border: '#e5e7eb', // Light border
    borderLight: '#f3f4f6', // Very light border
    borderFocus: '#3b82f6', // Blue focus border
    primary: '#0066cc', // Professional blue
    primaryHover: '#0052a3', // Darker blue hover
    secondary: '#7c3aed', // Purple secondary
    accent: '#0066cc', // Professional blue accent
    glass: 'rgba(255,255,255,0.6)', // Glass surface
    glassBorder: 'rgba(255,255,255,0.8)', // Glass border
    aiBackground: 'rgba(255,255,255,0.8)', // AI background
    shadowHover: '0 25px 50px -12px rgba(0, 0, 0, 0.25)', // Shadow hover
    success: '#10b981', // Green success
    warning: '#f59e0b', // Orange warning
    error: '#ef4444', // Red error
    info: '#3b82f6', // Blue info
  },
  shadows: DESIGN_TOKENS.shadows,
  blur: DESIGN_TOKENS.blur,
  spacing: DESIGN_TOKENS.spacing,
  borderRadius: DESIGN_TOKENS.borderRadius,
  transitions: DESIGN_TOKENS.transitions,
  typography: DESIGN_TOKENS.typography,
  glassmorphism: DESIGN_TOKENS.glassmorphism,
};

// Dark theme - Modern and elegant
export const darkTheme: Theme = {
  name: 'dark',
  colors: {
    background: '#0f0f0f', // Deep dark background
    surface: 'rgba(255,255,255,0.05)', // Minimal white surface overlay
    text: '#f9fafb', // Pure light text
    textDescription: '#D1D5DB', // WCAG AA compliant (4.5:1) description text on dark
    textSecondary: '#d1d5db', // Medium contrast secondary text
    border: '#1F2937', // Dark border
    primary: '#6366f1', // Indigo primary
    accent: '#6366f1', // Indigo accent
    glass: 'rgba(255,255,255,0.05)', // Minimal glass surface
    glassBorder: 'rgba(255,255,255,0.1)', // Subtle glass border
    aiBackground: 'rgba(255,255,255,0.08)', // AI background
    shadowHover: '0 8px 32px rgba(0, 0, 0, 0.37)', // Dark shadow hover
    success: DESIGN_TOKENS.colors.semantic.success, // Success color
    warning: DESIGN_TOKENS.colors.semantic.warning, // Warning color
    error: DESIGN_TOKENS.colors.semantic.error, // Error color
    info: DESIGN_TOKENS.colors.semantic.info, // Info color
  },
  shadows: DESIGN_TOKENS.shadows,
  blur: DESIGN_TOKENS.blur,
  spacing: DESIGN_TOKENS.spacing,
  borderRadius: DESIGN_TOKENS.borderRadius,
  transitions: DESIGN_TOKENS.transitions,
  typography: DESIGN_TOKENS.typography,
  glassmorphism: DESIGN_TOKENS.glassmorphism,
};

// Neutral theme - Warm and balanced
export const neutralTheme: Theme = {
  name: 'neutral',
  colors: {
    background: '#1e1e1e', // Warm dark background
    surface: 'rgba(250,250,250,0.03)', // Very subtle warm surface
    text: '#e5e7eb', // Warm light text
    textDescription: '#F3F4F6', // WCAG AA compliant (4.5:1) description text on neutral
    textSecondary: '#d1d5db', // Warm secondary text
    border: '#374151', // Warm dark border
    primary: '#FBBF24', // Amber primary
    accent: '#FBBF24', // Amber accent
    glass: 'rgba(250,250,250,0.03)', // Warm glass surface
    glassBorder: 'rgba(251,191,36,0.2)', // Amber-tinted glass border
    aiBackground: 'rgba(250,250,250,0.05)', // Warm AI background
    shadowHover: '0 8px 32px rgba(251,191,36,0.15)', // Amber-tinted shadow
    success: DESIGN_TOKENS.colors.semantic.success, // Success color
    warning: DESIGN_TOKENS.colors.semantic.warning, // Warning color
    error: DESIGN_TOKENS.colors.semantic.error, // Error color
    info: DESIGN_TOKENS.colors.semantic.info, // Info color
  },
  shadows: DESIGN_TOKENS.shadows,
  blur: DESIGN_TOKENS.blur,
  spacing: DESIGN_TOKENS.spacing,
  borderRadius: DESIGN_TOKENS.borderRadius,
  transitions: DESIGN_TOKENS.transitions,
  typography: DESIGN_TOKENS.typography,
  glassmorphism: DESIGN_TOKENS.glassmorphism,
};

// Theme registry for easy access
export const themes = {
  light: lightTheme,
  dark: darkTheme,
  neutral: neutralTheme,
} as const;

// Theme utilities
export const getTheme = (themeName: keyof typeof themes): Theme => {
  return themes[themeName];
};

// CSS custom properties generator using design tokens
export const createCSSVariables = (theme: Theme) => {
  return {
    // Core colors
    '--color-background': theme.colors.background,
    '--color-surface': theme.colors.surface,
    '--color-text': theme.colors.text,
    '--color-text-secondary': theme.colors.textSecondary,
    '--color-border': theme.colors.border,
    '--color-primary': theme.colors.primary,
    '--color-accent': theme.colors.accent,

    // Semantic colors
    '--color-success': theme.colors.success,
    '--color-warning': theme.colors.warning,
    '--color-error': theme.colors.error,
    '--color-info': theme.colors.info,

    // Glassmorphism
    '--glass-background': theme.colors.glass,
    '--glass-backdrop': DESIGN_TOKENS.glassmorphism.backdrop.glass,
    '--glass-border': theme.colors.glassBorder,
    '--glass-shadow': DESIGN_TOKENS.shadows.glass,
    '--ai-background': theme.colors.aiBackground,
    '--shadow-hover': theme.colors.shadowHover,

    // Typography - Enhanced font system
    '--font-family-primary': theme.typography.fontFamily.primary,
    '--font-family-brand': theme.typography.fontFamily.brand,
    '--font-family-mono': theme.typography.fontFamily.mono,
    '--font-size-xs': theme.typography.fontSize.xs,
    '--font-size-sm': theme.typography.fontSize.sm,
    '--font-size-md': theme.typography.fontSize.md,
    '--font-size-lg': theme.typography.fontSize.lg,
    '--font-size-xl': theme.typography.fontSize.xl,
    '--font-size-xxl': theme.typography.fontSize.xxl,
    '--font-size-xxxl': theme.typography.fontSize.xxxl,
    '--font-size-display': theme.typography.fontSize.display,
    '--font-size-hero': theme.typography.fontSize.hero,

    // Font weights - Enhanced system
    '--font-weight-thin': theme.typography.fontWeight.thin.toString(),
    '--font-weight-light': theme.typography.fontWeight.light.toString(),
    '--font-weight-normal': theme.typography.fontWeight.normal.toString(),
    '--font-weight-medium': theme.typography.fontWeight.medium.toString(),
    '--font-weight-semibold': theme.typography.fontWeight.semibold.toString(),
    '--font-weight-bold': theme.typography.fontWeight.bold.toString(),
    '--font-weight-extrabold': theme.typography.fontWeight.extrabold.toString(),
    '--font-weight-black': theme.typography.fontWeight.black.toString(),

    // Line heights - Enhanced system
    '--line-height-none': theme.typography.lineHeight.none.toString(),
    '--line-height-tight': theme.typography.lineHeight.tight.toString(),
    '--line-height-normal': theme.typography.lineHeight.normal.toString(),
    '--line-height-relaxed': theme.typography.lineHeight.relaxed.toString(),
    '--line-height-loose': theme.typography.lineHeight.loose.toString(),

    // Spacing using design tokens
    '--spacing-xs': theme.spacing.xs,
    '--spacing-sm': theme.spacing.sm,
    '--spacing-md': theme.spacing.md,
    '--spacing-lg': theme.spacing.lg,
    '--spacing-xl': theme.spacing.xl,
    '--spacing-xxl': theme.spacing.xxl,
    '--spacing-glass': theme.spacing.glass,
    '--spacing-hover': theme.spacing.hover,
    '--spacing-glass-dark': theme.spacing.glassDark,

    // Border radius using design tokens
    '--border-radius-xs': theme.borderRadius.xs,
    '--border-radius-sm': theme.borderRadius.sm,
    '--border-radius-md': theme.borderRadius.md,
    '--border-radius-lg': theme.borderRadius.lg,
    '--border-radius-xl': theme.borderRadius.xl,
    '--border-radius-glass': theme.borderRadius.glass,
    '--border-radius-hover': theme.borderRadius.hover,
    '--border-radius-glass-dark': theme.borderRadius.glassDark,
    '--border-radius-full': theme.borderRadius.full,
    '--border-radius-geometric': theme.borderRadius.geometric,

    // Shadows using design tokens
    '--shadow-xs': theme.shadows.xs,
    '--shadow-sm': theme.shadows.sm,
    '--shadow-md': theme.shadows.md,
    '--shadow-lg': theme.shadows.lg,
    '--shadow-xl': theme.shadows.xl,
    '--shadow-glass': theme.shadows.glass,
    '--shadow-glass-dark': theme.shadows.glassDark,
    '--shadow-inner': theme.shadows.inner,
    '--shadow-glow': theme.shadows.glow,
    '--shadow-premium': theme.shadows.premium,

    // Blur effects using design tokens
    '--blur-xs': theme.blur.xs,
    '--blur-sm': theme.blur.sm,
    '--blur-md': theme.blur.md,
    '--blur-lg': theme.blur.lg,
    '--blur-xl': theme.blur.xl,
    '--blur-glass': theme.blur.glass,
    '--blur-hover': theme.blur.hover,
    '--blur-glass-dark': theme.blur.glassDark,
    '--blur-premium': theme.blur.premium,
    '--blur-subtle': theme.blur.subtle,

    // Transitions using design tokens
    '--transition-xs': theme.transitions.xs,
    '--transition-sm': theme.transitions.sm,
    '--transition-md': theme.transitions.md,
    '--transition-lg': theme.transitions.lg,
    '--transition-xl': theme.transitions.xl,
    '--transition-glass': theme.transitions.glass,
    '--transition-hover': theme.transitions.hover,
    '--transition-glass-dark': theme.transitions.glassDark,
    '--transition-bounce': theme.transitions.bounce,
    '--transition-elastic': theme.transitions.elastic,
    '--transition-spring': theme.transitions.spring,

    // Animation durations and easing
    '--duration-fast': DESIGN_TOKENS.animation.duration.fast,
    '--duration-medium': DESIGN_TOKENS.animation.duration.medium,
    '--duration-slow': DESIGN_TOKENS.animation.duration.slow,
    '--duration-glass': DESIGN_TOKENS.animation.duration.glass,
    '--duration-hover': DESIGN_TOKENS.animation.duration.hover,
    '--duration-glass-dark': DESIGN_TOKENS.animation.duration.glassDark,

    '--easing-ease-out': DESIGN_TOKENS.animation.easing.easeOut,
    '--easing-ease-in': DESIGN_TOKENS.animation.easing.easeIn,
    '--easing-ease-in-out': DESIGN_TOKENS.animation.easing.easeInOut,
    '--easing-bounce': DESIGN_TOKENS.animation.easing.bounce,
    '--easing-glass': DESIGN_TOKENS.animation.easing.glass,
    '--easing-hover': DESIGN_TOKENS.animation.easing.hover,
    '--easing-glass-dark': DESIGN_TOKENS.animation.easing.glassDark,
    '--easing-elastic': DESIGN_TOKENS.animation.easing.elastic,

    // Z-index using design tokens
    '--z-hide': DESIGN_TOKENS.zIndex.hide.toString(),
    '--z-auto': DESIGN_TOKENS.zIndex.auto,
    '--z-base': DESIGN_TOKENS.zIndex.base.toString(),
    '--z-docked': DESIGN_TOKENS.zIndex.docked.toString(),
    '--z-dropdown': DESIGN_TOKENS.zIndex.dropdown.toString(),
    '--z-sticky': DESIGN_TOKENS.zIndex.sticky.toString(),
    '--z-fixed': DESIGN_TOKENS.zIndex.fixed.toString(),
    '--z-backdrop': DESIGN_TOKENS.zIndex.backdrop.toString(),
    '--z-modal': DESIGN_TOKENS.zIndex.modal.toString(),
    '--z-popover': DESIGN_TOKENS.zIndex.popover.toString(),
    '--z-tooltip': DESIGN_TOKENS.zIndex.tooltip.toString(),
    '--z-toast': DESIGN_TOKENS.zIndex.toast.toString(),
  };
};

// Glassmorphism preset utilities
export const getGlassmorphismPreset = (variant: keyof typeof GLASSMORPHISM_PRESETS) => {
  return GLASSMORPHISM_PRESETS[variant];
};

// Theme-aware glassmorphism helper
export const getThemeGlass = (theme: Theme) => {
  return {
    background: theme.colors.glass,
    backdropFilter: DESIGN_TOKENS.glassmorphism.backdrop.glass,
    border: `1px solid ${theme.colors.glassBorder}`,
    borderRadius: DESIGN_TOKENS.borderRadius.glass,
    boxShadow: DESIGN_TOKENS.shadows.glass,
    transition: DESIGN_TOKENS.transitions.glass,
  };
};

// Export theme types with auto detection support
export type ThemeName = 'light' | 'dark' | 'neutral' | 'auto';
export type ActiveThemeName = Exclude<ThemeName, 'auto'>;
export type ThemeType = (typeof themes)[ActiveThemeName];

// Backward compatibility exports for existing components
export const DURATION = DESIGN_TOKENS.animation.duration;
export const EASING = DESIGN_TOKENS.animation.easing;
