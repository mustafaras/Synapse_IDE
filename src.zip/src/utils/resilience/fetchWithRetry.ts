import { parseRetryAfter } from './policy';

export interface FetchRetryOpts {
  timeoutMs?: number;
  maxAttempts?: number; // inclusive of first try
  backoffMs?: (attempt: number) => number; // attempt starts at 0
}

export async function fetchWithRetry(url: string, init: RequestInit, opts: FetchRetryOpts): Promise<Response> {
  const maxAttempts = Math.max(1, opts.maxAttempts ?? 4);
  let attempt = 0;

  while (true) {
    const controller = new AbortController();
    const to = setTimeout(() => controller.abort(), opts.timeoutMs ?? 15000);
    try {
      const res = await fetch(url, { ...init, signal: controller.signal });
      clearTimeout(to);
      if (res.ok) return res;

      // Retry on 408/429/5xx with optional Retry-After
      if ([408, 429].includes(res.status) || (res.status >= 500 && res.status <= 599)) {
        if (attempt >= maxAttempts - 1) return res; // give up
        const retryAfter = parseRetryAfter(res.headers.get('retry-after'));
        const delay = retryAfter ?? (opts.backoffMs ? opts.backoffMs(attempt) : 1000);
        await new Promise(r => setTimeout(r, delay));
        attempt += 1;
        continue;
      }
      return res; // non-retryable
    } catch (e) {
      clearTimeout(to);
      // network/abort: retry if attempts left
      if (attempt >= maxAttempts - 1) throw e;
      const delay = opts.backoffMs ? opts.backoffMs(attempt) : 1000;
      await new Promise(r => setTimeout(r, delay));
      attempt += 1;
    }
  }
}
