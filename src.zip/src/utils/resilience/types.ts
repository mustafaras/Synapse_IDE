export type RetryKind = 'chat' | 'settings' | 'upload' | 'generic';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export interface RequestEnvelope<T = any> {
  id: string;                 // uuid
  kind: RetryKind;
  url: string;
  method: 'GET'|'POST'|'PUT'|'DELETE';
  headers?: Record<string,string>;
  body?: T;                   // JSON-serializable (no streams here)
  timeoutMs?: number;         // fall back to settings.timeoutMs
  fingerprint: string;        // dedupe key based on kind+essential fields
  createdAt: number;
}

export interface OutboxItem {
  env: RequestEnvelope;
  attempt: number;
  nextAt: number;             // epoch ms for next try
  status: 'queued'|'running'|'paused'|'done'|'failed';
  lastError?: string;
}
