/**
 * parseFenceInfo.ts
 * Fault-tolerant fence info parser: extracts lang and optional filename meta.
 */

export function parseFenceInfo(info: string | undefined): { lang: string; filename: string | null } {
  const raw = (info || '').trim();
  const lang = (raw.split(/\s+/)[0] || '').trim();
  const mFile = raw.match(/filename:([^\s]+)/i);
  const filename = mFile?.[1] ?? null;
  return { lang, filename };
}

export default parseFenceInfo;
