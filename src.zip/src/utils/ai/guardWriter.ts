import { showToast } from '@/ui/toast/api';

// Minimal shape shared with chat messages to avoid tight coupling
export type WriterSource = 'providerStream' | 'ui' | 'system';

export interface AssistantLike {
  type: 'user' | 'assistant' | 'system';
  content?: string;
  streamedContent?: string;
}

/**
 * Runtime guard: Only providerStream can increase assistant text.
 * - Allows reductions/no-op (e.g., clearing, finalizing, status updates)
 * - Blocks any growth of content/streamedContent from non-provider sources
 * - On violation: shows toast and throws to surface in error flows
 */
export function assertAssistantTextWrite(prev: AssistantLike, next: AssistantLike, source: WriterSource): void {
  if (!next || next.type !== 'assistant') return;
  const prevText = String((prev?.streamedContent ?? prev?.content ?? '') || '');
  const nextText = String((next?.streamedContent ?? next?.content ?? '') || '');
  const grew = nextText.length > prevText.length;
  if (grew && source !== 'providerStream') {
    // Single toast policy at call-sites; keep simple here
    try { showToast({ kind: 'warning', message: 'Blocked non-model content.', contextKey: 'guard:assistant-write' }); } catch {}
    const err = new Error('Blocked non-model content.');
    // Attach minimal context for debugging without leaking content
    (err as any).code = 'guard_violation';
    (err as any).source = source;
    throw err;
  }
}
