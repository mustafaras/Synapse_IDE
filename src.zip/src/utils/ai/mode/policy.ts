// Mode policy: centralizes Beginner vs Pro behavior flags in one place.
export type AiMode = 'beginner' | 'pro';

export interface ModePolicy {
  id: AiMode;
  // Beginner must be single-file only; Pro may create multiple files.
  singleFileOnly: boolean;
  // In Beginner, prefer inserting into the active editor; Pro prefers creating files.
  preferInsertIntoActive: boolean;
}

export const MODE_POLICIES: Record<AiMode, ModePolicy> = {
  beginner: {
    id: 'beginner',
    singleFileOnly: true,
    preferInsertIntoActive: true,
  },
  pro: {
    id: 'pro',
    singleFileOnly: false,
    preferInsertIntoActive: false,
  },
};

export function getModePolicy(mode: AiMode): ModePolicy {
  return MODE_POLICIES[mode] || MODE_POLICIES.beginner;
}
