let lastWarnTs = 0;

export function guardModeSwitch(isStreaming: boolean, onWarn: (msg: string) => void): boolean {
  if (!isStreaming) return true;
  const now = Date.now();
  // rate-limit warning to once every ~5s to avoid spam
  if (now - lastWarnTs > 5000) {
    lastWarnTs = now;
    onWarn('Mode switch will apply to the next request. Current response is using the previous mode.');
  }
  // still allow UI toggle, but communicate that it will apply to next request only
  return true;
}
