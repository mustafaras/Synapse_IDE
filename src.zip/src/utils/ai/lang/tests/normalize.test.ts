// Minimal tests for normalizeAssistantMessage and filename helpers
import { getLangSpec } from '../../lang/languageMap';
import { normalizeAssistantMessage } from '../../lang/normalizeOutput';
import { dedupeName, ensureExt, safeJoin, sanitizeBase } from '../../lang/filename';

function assert(cond: unknown, msg: string) { if (!cond) throw new Error(msg); }

// Beginner: prose + two fences → pick selected language fence
(() => {
  const fence = '```';
  const raw = `Hello\n\n${fence}ts\nconst x: number = 1\n${fence}\n\nSome text\n\n${fence}python\nprint('hi')\n${fence}`;
  const spec = getLangSpec('python')!;
  const { files } = normalizeAssistantMessage(raw, { selectedLang: spec, mode: 'beginner' });
  assert(files.length === 1, 'Beginner should return one file');
  assert(files[0].ext === '.py', 'File ext should be .py');
  assert(files[0].monaco === 'python', 'Monaco should be python');
})();

// Pro: multi fences without filenames → synthesize and dedupe
(() => {
  const fence = '```';
  const raw = `//// file: src/utils/foo.ts\n\n${fence}ts\nexport const a = 1\n${fence}\n\n${fence}ts\nexport const b = 2\n${fence}`;
  const spec = getLangSpec('typescript')!;
  const { files } = normalizeAssistantMessage(raw, { selectedLang: spec, mode: 'pro', defaultDir: 'src' });
  if (!(files.length >= 2)) throw new Error('Pro should return multiple files');
})();

// Filename utils
(() => {
  if (sanitizeBase('Hello world!.tsx') !== 'Hello-world-tsx') throw new Error('sanitizeBase should strip unsafe characters');
  if (ensureExt('App', '.tsx') !== 'App.tsx') throw new Error('ensureExt should append missing ext');
  if (safeJoin('../', 'App.tsx') !== 'App.tsx') throw new Error('safeJoin should strip unsafe dir');
  const existing = new Set(['App.tsx', 'App-2.tsx']);
  if (dedupeName(existing, 'App.tsx') !== 'App-3.tsx') throw new Error('dedupeName should bump suffix');
})();
