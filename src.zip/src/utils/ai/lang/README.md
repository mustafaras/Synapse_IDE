# Language normalization utilities

- languageMap.ts: single source of truth for language → monaco id, extension, fence, default filename
- filename.ts: safe filename/path helpers (sanitizeBase, ensureExt, safeJoin, dedupeName)
- detectLanguage.ts: lightweight heuristics for missing/unknown fence
- normalizeOutput.ts: parses code fences (and optional `//// file:` headers) and produces NormalizedFile[]

Notes:

- Side-effect free; actual writes/Monaco changes happen in the integration layer
- Beginner mode: returns exactly one coerced file using the selected language
- Pro mode: allows multiple files and multi-language bundles when reasonable
- Emits `[DEV][lang-normalize]` warnings for auto-corrections in dev builds
