// Minimal tests for buildApplyPlan & executeApplyPlan
// Note: This is a lightweight runtime check using basic assertions; adapt to your test harness if needed.

import { buildApplyPlan } from '../../apply/buildApplyPlan';
import { type EditorApi, executeApplyPlan } from '../../apply/executeApplyPlan';

const raw = `//// file: src/hello.ts\n\n\`\`\`ts\nexport const hi = 'there'\n\`\`\``;

function collect(_api?: Partial<EditorApi>) {
  const created: Array<{ path: string; content: string; lang: string }> = [];
  const replaced: Array<{ path: string; content: string; lang: string }> = [];
  const snapshots: Array<{ path: string; prev: string }> = [];
  const existing = new Map<string, string>();
  const impl: EditorApi = {
    fileExists: p => existing.has(p),
    readFile: p => existing.get(p) ?? null,
    createFile: (p, c, m) => { created.push({ path: p, content: c, lang: m }); existing.set(p, c); },
    replaceFile: (p, c, m) => { replaced.push({ path: p, content: c, lang: m }); existing.set(p, c); },
    pushUndoSnapshot: (p, prev) => { snapshots.push({ path: p, prev }); },
  };
  return { impl, created, replaced, snapshots, existing };
}

export async function testBuildAndExecute() {
  const plan = buildApplyPlan({ rawAssistantText: raw, selectedLanguageId: 'typescript', mode: 'beginner', defaultDir: 'src', existingPaths: new Set() });
  if (plan.items.length !== 1) throw new Error('expected one item');
  const box = collect({});
  executeApplyPlan(plan, box.impl, { preferInsertIntoActive: false });
  if (box.created.length !== 1) throw new Error('expected create');
}
