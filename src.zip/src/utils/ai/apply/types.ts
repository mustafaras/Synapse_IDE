// Apply pipeline types (additive, framework-agnostic)
// Keeps the Parse -> Plan -> Apply flow explicit and testable.

export type ApplyAction = 'create' | 'replace' | 'insert';

export interface ApplyItem {
  // Normalized relative path (no leading slash, no .. segments)
  path: string;
  // Decided action for this file
  action: ApplyAction;
  // Final code to write
  code: string;
  // Monaco language id (e.g., 'typescript', 'javascript', 'python')
  monaco: string;
  // File extension including dot (e.g., '.ts', '.py')
  ext: string;
  // Whether a file existed at the original path during planning
  exists: boolean;
}

export interface ApplyPlan {
  mode: 'beginner' | 'pro';
  items: ApplyItem[];
  // Non-fatal notes from normalization/collisions
  warnings: string[];
}
