/**
 * Context source collection for system prompt compilation.
 * Pure, deterministic helpers that transform provided inputs into ContextSlice entries.
 */
import { redactContext } from '@/utils/safety/redactor';

export interface ContextSlice {
  id: string; // e.g., 'active-file', 'selection', 'pinned-notes'
  title: string; // human-readable
  content: string; // plain text to inject
  importance?: number; // 0..1 (ranking weight)
  updatedAt?: number; // ms timestamp
}

export interface ContextInput {
  activeFilePath?: string;
  activeFileContent?: string;
  selectedText?: string;
  pinnedNotes?: string[];
  projectBrief?: string;
  quickPrompts?: string[];
  settings: {
    mode: 'beginner' | 'pro';
    languageId?: string;
    monacoLanguage?: string;
    model?: string;
    temperature?: number;
    maxTokens?: number;
  };
}

export interface CompiledContext {
  slices: ContextSlice[];
  summary: string; // short bulletized synthesis (≤ ~1200 chars)
  tokensEstimated: number;
}

const nowTs = () => Date.now();

// Attachments slice (Prompt 9)
// Static read from the attachments store; no subscriptions to avoid coupling
import { useAttachStore } from '@/features/attachments/store';

export function collectAttachmentsSlice(): ContextSlice | null {
  const list = useAttachStore.getState().list as Array<{ name: string; size: number; kind: string; textFull?: string }>;
  if (!list || list.length === 0) return null;

  const lines: string[] = [];
  for (const a of list) {
    if (a.textFull && a.textFull.length > 0) {
      lines.push(`// ${a.name} (${Math.round(a.size / 1024)} KB)`);
  // Redact attachment text excerpts to avoid leaking secrets
  const red = redactContext(a.textFull.slice(0, 2000));
  lines.push(red.clean);
    } else {
      lines.push(`// ${a.name} [${a.kind}]`);
    }
  }

  return {
    id: 'attachments',
    title: 'Attached files',
    content: lines.join('\n'),
    importance: 0.8,
    updatedAt: nowTs(),
  };
}

export function collectActiveFileSlice(input: ContextInput): ContextSlice | null {
  const { activeFilePath, activeFileContent } = input;
  if (!activeFileContent) return null;
  return {
    id: 'active-file',
    title: activeFilePath ? `Active File: ${activeFilePath}` : 'Active File',
    content: activeFileContent,
    importance: 0.9,
    updatedAt: nowTs(),
  };
}

export function collectSelectionSlice(input: ContextInput): ContextSlice | null {
  const { selectedText } = input;
  if (!selectedText || !selectedText.trim()) return null;
  return {
    id: 'selection',
    title: 'Selection',
    content: selectedText,
    importance: 1.0,
    updatedAt: nowTs(),
  };
}

export function collectPinnedNotesSlice(input: ContextInput): ContextSlice | null {
  const { pinnedNotes } = input;
  if (!pinnedNotes || pinnedNotes.length === 0) return null;
  return {
    id: 'pinned-notes',
    title: 'Pinned Notes',
    content: pinnedNotes.map(n => `- ${n}`).join('\n'),
    importance: 0.7,
    updatedAt: nowTs(),
  };
}

export function collectProjectBriefSlice(input: ContextInput): ContextSlice | null {
  const { projectBrief } = input;
  if (!projectBrief) return null;
  return {
    id: 'project-brief',
    title: 'Project Brief',
    content: projectBrief,
    importance: 0.6,
    updatedAt: nowTs(),
  };
}

export function collectQuickPromptsSlice(input: ContextInput): ContextSlice | null {
  const { quickPrompts } = input;
  if (!quickPrompts || quickPrompts.length === 0) return null;
  return {
    id: 'quick-prompts',
    title: 'Quick Prompts',
    content: quickPrompts.map(n => `- ${n}`).join('\n'),
    importance: 0.5,
    updatedAt: nowTs(),
  };
}

export function collectAllSlices(input: ContextInput): ContextSlice[] {
  return [
    collectSelectionSlice(input),
    collectActiveFileSlice(input),
  collectAttachmentsSlice(),
    collectPinnedNotesSlice(input),
    collectProjectBriefSlice(input),
    collectQuickPromptsSlice(input),
  ].filter(Boolean) as ContextSlice[];
}

export function rankByImportanceUpdated(a: ContextSlice, b: ContextSlice): number {
  const ia = a.importance ?? 0;
  const ib = b.importance ?? 0;
  if (ib !== ia) return ib - ia; // desc importance
  const ua = a.updatedAt ?? 0;
  const ub = b.updatedAt ?? 0;
  if (ub !== ua) return ub - ua; // desc updatedAt
  // tiebreaker: shorter content first to favor concise context
  return (a.content?.length ?? 0) - (b.content?.length ?? 0);
}
