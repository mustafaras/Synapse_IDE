import type { ContextSlice } from './contextSources';
import { estimateTokens } from '@/services/telemetry';

export interface BudgetPlan {
  systemMax: number; // tokens reserved for system prompt
  userMax?: number;
  perSliceMax?: Record<string, number>;
}

const CHARS_PER_TOKEN = 4; // fast heuristic

export function planBudget(mode: 'beginner' | 'pro'): BudgetPlan {
  const systemMax = mode === 'beginner' ? 1800 : 1400;
  const userMax = mode === 'beginner' ? 1200 : 1600;
  // percentage weights per slice id
  const perSliceMax: Record<string, number> = {
    selection: 0.4,
    'active-file': 0.3,
    'pinned-notes': 0.15,
    'project-brief': 0.15,
    'quick-prompts': 0.1, // fallback if present
  };
  return { systemMax, userMax, perSliceMax };
}

export function estimateTokensForSlices(slices: ContextSlice[]): number {
  return estimateTokens(slices.map(s => s.content).join('\n\n'));
}

/**
 * Truncate slice contents in ranking order to fit within systemMax tokens.
 * Higher-importance slices should be placed earlier in the array.
 */
export function fitToBudget(slices: ContextSlice[], systemMaxTokens: number): ContextSlice[] {
  const total = estimateTokensForSlices(slices);
  if (total <= systemMaxTokens) return slices;

  const totalCharsBudget = systemMaxTokens * CHARS_PER_TOKEN;
  const totalChars = slices.reduce((acc, s) => acc + s.content.length, 0);
  if (totalChars <= totalCharsBudget) return slices; // already fine by char-length

  // Distribute char budgets by per-slice max if provided, else proportional by rank
  const ranked = slices.slice();
  // Compute provisional caps (by weight or equal share)
  const weights = ranked.map(s => weightForSliceId(s.id));
  const weightSum = weights.reduce((a, b) => a + b, 0) || 1;

  const budgets = weights.map(w => Math.max(200, Math.floor((w / weightSum) * totalCharsBudget)));

  const truncated: ContextSlice[] = [];
  for (let i = 0; i < ranked.length; i++) {
    const s = ranked[i];
    const cap = budgets[i];
    if (s.content.length <= cap) {
      truncated.push(s);
    } else {
      const sliceAt = Math.max(0, cap - 14);
      truncated.push({ ...s, content: `${s.content.slice(0, sliceAt)}\n…[TRUNCATED]` });
    }
  }

  // Final guard: if still over token target, iteratively trim least important tail
  let guard = 8;
  while (guard-- > 0 && estimateTokensForSlices(truncated) > systemMaxTokens) {
    for (let i = truncated.length - 1; i >= 0; i--) {
      const s = truncated[i];
      if (s.content.length > 400) {
  truncated[i] = { ...s, content: `${s.content.slice(0, s.content.length - 200)}\n…[TRUNCATED]` };
        break;
      }
    }
  }

  return truncated;
}

function weightForSliceId(id: string): number {
  switch (id) {
    case 'selection':
      return 1.0;
    case 'active-file':
      return 0.9;
    case 'pinned-notes':
      return 0.7;
    case 'project-brief':
      return 0.6;
    case 'quick-prompts':
      return 0.5;
    default:
      return 0.5;
  }
}

export { estimateTokens };
