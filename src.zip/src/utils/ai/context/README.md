# Profile-aware System Prompt & Context Compiler

Modules

- contextSources.ts: defines ContextInput/ContextSlice and collectors for selection, active file, pinned notes, project brief, quick prompts
- sanitize.ts: redacts .env-like secrets, strips nested fences, normalizes text, marks injection phrases
- tokenBudget.ts: estimates tokens (~4 chars/token), plans budget per mode, and fits slices to a token cap with graceful truncation
- contextCompiler.ts: orchestrates collection → sanitization → ranking → budgeting → summary synthesis
- templates.ts: Beginner/Pro system templates that consume the compiled context

Notes

- All helpers are pure and accept ContextInput instead of reading stores directly
- No UI changes; existing buildSystemPrompt() continues to return a string for backward compatibility
- Use buildSystemPromptV2() if you want structured results like token estimates and the synthesized summary
