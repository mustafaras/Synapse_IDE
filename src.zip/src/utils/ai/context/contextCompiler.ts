import * as CS from './contextSources';
import { sanitizeSlices } from './sanitize';
import { estimateTokens, fitToBudget, planBudget } from './tokenBudget';
import { getActiveTraceId, spanEnd, spanStart } from '@/utils/obs/instrument';

function clip(text: string, max = 1200): string {
  return text.length > max ? `${text.slice(0, max - 14)}\n…[TRUNCATED]` : text;
}

function summarizeSlices(slices: CS.ContextSlice[]): string {
  const lines: string[] = [];
  const sel = slices.find(s => s.id === 'selection');
  const act = slices.find(s => s.id === 'active-file');
  const pin = slices.find(s => s.id === 'pinned-notes');
  const brf = slices.find(s => s.id === 'project-brief');

  if (sel) {
    const key = sel.content.split(/\r?\n/).filter(Boolean).slice(0, 2);
    if (key.length) lines.push(`• Selection: ${key.join(' / ')}`);
  }
  if (act) {
    const fileName = (act.title.replace(/^Active File:\s*/i, '') || '').trim();
    const firstLines = act.content.split(/\r?\n/).filter(Boolean).slice(0, 2);
    const hint = firstLines.join(' / ');
    lines.push(`• Active file: ${fileName}${hint ? ` — ${hint}` : ''}`);
  }
  if (pin) {
    const items = pin.content.split(/\r?\n/).filter(l => l.trim().startsWith('-')).slice(0, 2);
    if (items.length) lines.push(`• Pinned: ${items.map(s => s.replace(/^-\s*/, '')).join(' | ')}`);
  }
  if (brf) {
    const bullets = brf.content.split(/\r?\n/).filter(Boolean).slice(0, 2);
    if (bullets.length) lines.push(`• Brief: ${bullets.join(' / ')}`);
  }

  return clip(lines.join('\n'));
}

export function compileContext(input: CS.ContextInput): CS.CompiledContext {
  const raw = CS.collectAllSlices(input).filter(Boolean) as CS.ContextSlice[];
  try {
    const att = raw.find(s => s.id === 'attachments');
    if (att) {
      const tid = getActiveTraceId();
      if (tid) {
        const sp = spanStart(tid, 'attachments_digest', 'attachments digest', { attachmentsCount: (att.content.match(/^\/\//gm) || []).length });
        spanEnd(tid, sp, {});
      }
    }
  } catch {}
  const clean = sanitizeSlices(raw);
  clean.sort(CS.rankByImportanceUpdated);

  const plan = planBudget(input.settings.mode);
  const bounded = fitToBudget(clean, plan.systemMax);
  const summary = summarizeSlices(bounded);
  const tokensEstimated = estimateTokens(bounded.map(s => s.content).join('\n\n'));

  if (import.meta.env?.MODE === 'development') {
    // eslint-disable-next-line no-console
    console.debug('[ctx] slices', bounded.map(s => ({ id: s.id, len: s.content.length })));
    // eslint-disable-next-line no-console
    console.debug('[ctx] tokens≈', tokensEstimated);
  }

  return { slices: bounded, summary, tokensEstimated };
}
