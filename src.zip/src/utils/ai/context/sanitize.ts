/**
 * Sanitization utilities for context slices.
 * - Redact .env-like secrets (KEY=VALUE -> KEY=[REDACTED])
 * - Remove likely binary/gibberish lines
 * - Normalize whitespace and enforce UTF-8 safe characters
 * - Strip code fence openers to avoid nested fences
 * - Replace prompt-injection phrases with neutral markers (non-destructive)
 */

import type { ContextSlice } from './contextSources';
import { redactContext } from '@/utils/safety/redactor';

const ENV_LINE = /^(?:[A-Z0-9_]{2,})\s*=\s*.+$/;
const FENCE_START = /```+/g;
const INJECTION_PHRASES = /(ignore previous instructions|disregard earlier rules|forget all prior)/gi;

function sanitizeLine(line: string): string | null {
  // Remove binary-ish lines (very high non-printable ratio)
  // eslint-disable-next-line no-control-regex
  const nonPrintables = (line.match(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g) || []).length;
  if (nonPrintables > Math.max(8, Math.floor(line.length * 0.2))) return null;

  // Redact .env style
  if (ENV_LINE.test(line)) {
    const key = line.split('=')[0].trim();
    return `${key}=[REDACTED]`;
  }

  // Strip fence starters within context
  line = line.replace(FENCE_START, '');

  // Replace injection phrases
  line = line.replace(INJECTION_PHRASES, match => `⟪${match}⟫`);

  // Normalize whitespace
  return line.replace(/[\t\u00A0]+/g, ' ').replace(/\s+$/g, '');
}

export function sanitizeText(text: string, sliceMaxChars = 4000): string {
  const lines = text.split(/\r?\n/);
  const cleaned: string[] = [];
  for (const ln of lines) {
    const s = sanitizeLine(ln);
    if (s == null) continue;
    cleaned.push(s);
  }
  let out = cleaned.join('\n');
  // Apply extra safety redaction pass for auxiliary context (not user prompt)
  const red = redactContext(out);
  out = red.clean;
  if (out.length > sliceMaxChars) {
    out = `${out.slice(0, sliceMaxChars)}\n…[TRUNCATED]`;
  }
  return out;
}

export function sanitizeSlices(slices: ContextSlice[], sliceMaxChars = 4000): ContextSlice[] {
  return slices.map(s => ({
    ...s,
    content: sanitizeText(s.content, sliceMaxChars),
  }));
}
