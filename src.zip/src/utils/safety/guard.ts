import { scanAssistantText } from './scanner';
import { redactContext } from './redactor';
import { showToast } from '@/ui/toast/api';

export function redactContextSlice(content: string): { content: string } {
  const { clean, hits } = redactContext(content);
  if (hits.length && (process.env.NODE_ENV === 'development' || import.meta.env?.MODE === 'development')) {
    // eslint-disable-next-line no-console
    console.log('[DEV][safety] context redactions:', hits.slice(0, 10));
  }
  return { content: clean };
}

export function warnIfRiskyOutput(rawAssistantText: string, contextKey = 'safety:warn'): void {
  const report = scanAssistantText(rawAssistantText);
  if (!report.ok) {
    const msg = report.findings.slice(0, 3).map(f => f.detail).join(', ');
    showToast({ kind: 'warning', contextKey, title: 'Review recommended', message: msg || 'Potentially risky output' });
    if (process.env.NODE_ENV === 'development' || import.meta.env?.MODE === 'development') {
      console.warn('[DEV][safety] findings', report.findings);
    }
  }
}
