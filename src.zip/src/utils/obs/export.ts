import { selectTraces } from './store';

export function exportTraces() {
  try {
    const traces = selectTraces();
    const payload = JSON.stringify({ exportedAt: new Date().toISOString(), traces }, null, 2);
    const blob = new Blob([payload], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'assistant-traces.json';
    a.click();
    URL.revokeObjectURL(a.href);
  } catch {}
}
