export type CodeBlock = { language: string | undefined; code: string; index: number };

export function extractCodeBlocks(markdown: string): CodeBlock[] {
  // Support both backtick and tilde fences; capture optional info string
  const re = /(?:^|\n)(`{3,}|~{3,})([^\n]*)\n([\s\S]*?)\1/g;
  const blocks: CodeBlock[] = [];
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(markdown)) !== null) {
    const info = (m[2] || '').trim();
    const lang = (info.split(/\s+/)[0] || '').trim();
    blocks.push({ language: lang || undefined, code: (m[3] || '').replace(/\s+$/, ''), index: i++ });
  }
  return blocks;
}

export function guessByLanguage(lang?: string): { language: string; ext: string } {
  const l = (lang || '').toLowerCase();
  if (['ts', 'typescript'].includes(l)) return { language: 'typescript', ext: 'ts' };
  if (['tsx'].includes(l)) return { language: 'typescript', ext: 'tsx' };
  if (['js', 'javascript', 'jsx'].includes(l)) return { language: 'javascript', ext: 'js' };
  if (['json'].includes(l)) return { language: 'json', ext: 'json' };
  if (['python', 'py'].includes(l)) return { language: 'python', ext: 'py' };
  if (['html', 'htm'].includes(l)) return { language: 'html', ext: 'html' };
  if (['css'].includes(l)) return { language: 'css', ext: 'css' };
  if (['md', 'markdown'].includes(l)) return { language: 'markdown', ext: 'md' };
  if (['yaml', 'yml'].includes(l)) return { language: 'yaml', ext: 'yml' };
  if (['go', 'golang'].includes(l)) return { language: 'go', ext: 'go' };
  if (['java'].includes(l)) return { language: 'java', ext: 'java' };
  if (['c', 'h'].includes(l)) return { language: 'c', ext: 'c' };
  if (['cpp', 'hpp', 'cc', 'cxx', 'hh', 'hxx'].includes(l)) return { language: 'cpp', ext: 'cpp' };
  if (['sh', 'bash', 'shell'].includes(l)) return { language: 'shell', ext: 'sh' };
  return { language: 'plaintext', ext: 'txt' };
}

export function defaultFilename(base: string, n: number, ext: string) {
  return `${base}.${n}.${ext}`;
}
