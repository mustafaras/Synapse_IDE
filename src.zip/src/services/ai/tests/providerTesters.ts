import { requestJSON } from '@/services/ai/http';
import { reportError } from '@/lib/error-bus';

export type ProviderId = 'openai' | 'anthropic' | 'gemini';

type TestResult = { ok: true } | { ok: false; message: string };

const success = (): TestResult => ({ ok: true });
const fail = (message: string): TestResult => ({ ok: false, message });

/** Redact helper for optional UI messages (last 4 chars only). */
export function redactKey(key?: string): string {
  if (!key) return '(none)';
  const tail = key.slice(-4);
  return `${key.slice(0, 3)}…${tail}`;
}

export async function testOpenAI(openaiKey?: string): Promise<TestResult> {
  if (!openaiKey) return fail('OpenAI key is missing.');
  try {
    await requestJSON({
      url: 'https://api.openai.com/v1/models',
      method: 'GET',
      headers: { Authorization: `Bearer ${openaiKey}` },
      timeout: 15000,
    });
    return success();
  } catch (e: any) {
    const payload: Parameters<typeof reportError>[0] = { source: 'http', provider: 'openai', code: e?.code };
    if (typeof e?.status === 'number') (payload as any).status = e.status;
    const msg = e?.userMessage || e?.message; if (typeof msg === 'string') (payload as any).message = msg;
    reportError(payload);
    return fail('OpenAI test failed.');
  }
}

export async function testAnthropic(anthropicKey?: string): Promise<TestResult> {
  if (!anthropicKey) return fail('Anthropic key is missing.');
  try {
    await requestJSON({
      url: 'https://api.anthropic.com/v1/models',
      method: 'GET',
      headers: {
        'x-api-key': anthropicKey,
        'anthropic-version': '2023-06-01',
      },
      timeout: 15000,
    });
    return success();
  } catch (e: any) {
    const payload: Parameters<typeof reportError>[0] = { source: 'http', provider: 'anthropic', code: e?.code };
    if (typeof e?.status === 'number') (payload as any).status = e.status;
    const msg = e?.userMessage || e?.message; if (typeof msg === 'string') (payload as any).message = msg;
    reportError(payload);
    return fail('Anthropic test failed.');
  }
}

export async function testGemini(geminiKey?: string): Promise<TestResult> {
  if (!geminiKey) return fail('Gemini key is missing.');
  try {
    await requestJSON({
      url: `https://generativelanguage.googleapis.com/v1/models?key=${encodeURIComponent(geminiKey)}`,
      method: 'GET',
      timeout: 15000,
    });
    return success();
  } catch (e: any) {
    const payload: Parameters<typeof reportError>[0] = { source: 'http', provider: 'gemini', code: e?.code };
    if (typeof e?.status === 'number') (payload as any).status = e.status;
    const msg = e?.userMessage || e?.message; if (typeof msg === 'string') (payload as any).message = msg;
    reportError(payload);
    return fail('Gemini test failed.');
  }
}
