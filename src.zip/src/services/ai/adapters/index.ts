import type { Adapter, CompleteResult, FinishReason, Message, ProviderKey } from './types';
import { errorFromResponse, fromHttpError, makeError } from './errors';
import { requestJSON, requestSSE } from '@/services/ai/http';
import { fetchWithRetry } from '@/utils/resilience/fetchWithRetry';
import { flags } from '@/config/flags';
import { logger } from '@/lib/logger';
import type { EndpointId } from '@/utils/ai/models/schema';
// Export canonical endpoint ids for adapters (used by guards/docs)
export const ENDPOINTS: Record<'openai'|'anthropic'|'gemini'|'ollama', EndpointId> = {
  openai: 'openai_chat_completions',
  anthropic: 'anthropic_messages',
  gemini: 'gemini_generate',
  ollama: 'ollama_generate',
};

const textDecoder = () => new TextDecoder();

// Helpers
const pickBase = (explicit?: string, fallback?: string): string => explicit ?? (fallback ?? '');

function normalizeMessages(messages: Message[]): Array<{ role: 'system'|'user'|'assistant'; content: string }> {
  // Tool messages are not sent directly; they are used when emitting tool_result_request/tool_call
  return messages.filter(m => m.role !== 'tool').map(m => ({ role: m.role as 'system'|'user'|'assistant', content: m.content }));
}

function toUsage(prompt?: number, completion?: number) {
  return { prompt: prompt ?? 0, completion: completion ?? 0 };
}

// OpenAI
export function openaiAdapter(): Adapter {
  return {
    async stream({ requestId, signal, baseUrl, apiKey, options, messages, onEvent, timeoutMs }) {
  if (flags.aiTrace) logger.debug('[ADAPTER_ASSERT]', 'endpoint=', ENDPOINTS.openai);
  const isBrowser = typeof window !== 'undefined';
  const isDev = isBrowser && !!(import.meta as any)?.env?.DEV;
  const urlBase = isDev ? '/openai' : pickBase(baseUrl, 'https://api.openai.com');
  const url = `${urlBase}/v1/chat/completions`;
      onEvent({ type: 'start', requestId });
      if (flags.aiTrace) logger.info('[ADAPTER_REQUEST]', 'provider=openai', 'model=', options.model, 'stream=true');
      try {
        const body = {
          model: options.model,
          messages: normalizeMessages(messages),
          temperature: options.temperature,
          top_p: options.topP,
          max_tokens: options.maxTokens,
          stop: options.stop,
          stream: true,
        };
        let first = true;
        await new Promise<void>((resolve, reject) => {
          const headers: Record<string, string> = {};
          if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
          const sseOpts: any = {
            url,
            method: 'POST',
            headers,
            body,
            signal,
            onEvent: (evt: any) => {
              if (evt.type === 'open') { if (flags.aiTrace) logger.debug('[ADAPTER_CONNECTION_OPENED]'); return; }
              if (evt.type === 'error') { reject(fromHttpError(evt.error!, 'openai')); return; }
              if (evt.type === 'done') { onEvent({ type: 'done', requestId, finishReason: 'stop' }); if (flags.aiTrace) logger.info('[ADAPTER_STREAM_END]'); resolve(); return; }
              if (evt.type === 'message' && evt.data) {
                const payload = evt.data;
                if (payload === '[DONE]') { onEvent({ type: 'done', requestId, finishReason: 'stop' }); resolve(); return; }
                try {
                  const json = JSON.parse(payload);
                  const choice = json.choices?.[0];
                  const delta = choice?.delta?.content;
                  if (delta) {
                    if (first) { if (flags.aiTrace) logger.info('[ADAPTER_FIRST_CHUNK]'); first = false; }
                    if (flags.aiTrace) logger.debug('[ADAPTER_CHUNK]', 'size=', String(delta.length));
                    onEvent({ type: 'delta', requestId, text: delta });
                  }
                  if ((choice?.finish_reason)) onEvent({ type: 'done', requestId, finishReason: choice.finish_reason });
                  const usage = json.usage;
                  if (usage) onEvent({ type: 'usage', requestId, usage: toUsage(usage.prompt_tokens, usage.completion_tokens) });
                } catch {}
              }
            },
          };
          if (typeof timeoutMs === 'number') sseOpts.openTimeoutMs = timeoutMs;
          const { cancel } = requestSSE(sseOpts);
          signal.addEventListener('abort', () => cancel(), { once: true });
        });
      } catch (e: any) {
        if (flags.aiTrace) logger.error('[ADAPTER_STREAM_ERROR]', String(e?.message || e));
        throw e;
      }
    },
    async complete({ baseUrl, apiKey, options, messages, signal, timeoutMs }) {
  const isBrowser2 = typeof window !== 'undefined';
  const isDev2 = isBrowser2 && !!(import.meta as any)?.env?.DEV;
  const urlBase2 = isDev2 ? '/openai' : pickBase(baseUrl, 'https://api.openai.com');
  const url = `${urlBase2}/v1/chat/completions`;
      const headers: Record<string, string> = {};
      if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
      const jsonOpts: any = {
        url,
        method: 'POST',
        headers,
        body: {
          model: options.model,
          messages: normalizeMessages(messages),
          temperature: options.temperature,
          top_p: options.topP,
          max_tokens: options.maxTokens,
          stop: options.stop,
        },
      };
      if (signal) jsonOpts.signal = signal;
      if (typeof timeoutMs === 'number') jsonOpts.timeout = timeoutMs;
      const data = await requestJSON<any>(jsonOpts).catch((e) => { throw fromHttpError(e, 'openai'); });
      const choice = data.choices?.[0];
      const text: string = choice?.message?.content ?? '';
  const finishReason = choice?.finish_reason as FinishReason | undefined;
  const usageVal = data.usage ? toUsage(data.usage.prompt_tokens, data.usage.completion_tokens) : undefined;
  const result: CompleteResult = { text };
  if (finishReason !== undefined) result.finishReason = finishReason;
  if (usageVal) result.usage = usageVal;
      return result;
    },
  };
}

// Anthropic
export function anthropicAdapter(): Adapter {
  return {
    async stream({ requestId, signal, baseUrl, apiKey, options, messages, onEvent, timeoutMs }) {
  if (flags.aiTrace) logger.debug('[ADAPTER_ASSERT]', 'endpoint=', ENDPOINTS.anthropic);
      const url = `${pickBase(baseUrl, 'https://api.anthropic.com')}/v1/messages`;
      onEvent({ type: 'start', requestId });
      if (flags.aiTrace) logger.info('[ADAPTER_REQUEST]', 'provider=anthropic', 'model=', options.model, 'stream=true');
      const sys = messages.find(m => m.role === 'system')?.content || undefined;
      const userContent = messages.filter(m => m.role === 'user').map(m => m.content).join('\n\n');
      const body = { model: options.model, max_tokens: options.maxTokens ?? 2000, messages: [{ role: 'user', content: sys ? `${sys}\n\n${userContent}` : userContent }], temperature: options.temperature, top_p: options.topP, stream: true };
      try {
        let first = true;
        await new Promise<void>((resolve, reject) => {
          const headers: Record<string, string> = { 'anthropic-version': '2023-06-01' };
          if (apiKey) headers['x-api-key'] = apiKey;
          const sseOpts: any = {
            url,
            method: 'POST',
            headers,
            body,
            signal,
            onEvent: (evt: any) => {
              if (evt.type === 'open') { if (flags.aiTrace) logger.debug('[ADAPTER_CONNECTION_OPENED]'); return; }
              if (evt.type === 'error') { reject(fromHttpError(evt.error!, 'anthropic')); return; }
              if (evt.type === 'done') { onEvent({ type: 'done', requestId, finishReason: 'stop' }); if (flags.aiTrace) logger.info('[ADAPTER_STREAM_END]'); resolve(); return; }
              if (evt.type === 'message' && evt.data) {
                const payload = evt.data;
                if (payload === '[DONE]') { onEvent({ type: 'done', requestId, finishReason: 'stop' }); resolve(); return; }
                try {
                  const json = JSON.parse(payload);
                  const delta = json.delta?.text || json.content_block_delta?.text || '';
                  if (delta) {
                    if (first) { if (flags.aiTrace) logger.info('[ADAPTER_FIRST_CHUNK]'); first = false; }
                    if (flags.aiTrace) logger.debug('[ADAPTER_CHUNK]', 'size=', String(delta.length));
                    onEvent({ type: 'delta', requestId, text: delta });
                  }
                } catch {}
              }
            },
          };
          if (typeof timeoutMs === 'number') sseOpts.openTimeoutMs = timeoutMs;
          const { cancel } = requestSSE(sseOpts);
          signal.addEventListener('abort', () => cancel(), { once: true });
        });
      } catch (e: any) {
        if (flags.aiTrace) logger.error('[ADAPTER_STREAM_ERROR]', String(e?.message || e));
        throw e;
      }
    },
    async complete({ baseUrl, apiKey, options, messages, signal, timeoutMs }) {
      const url = `${pickBase(baseUrl, 'https://api.anthropic.com')}/v1/messages`;
      const sys = messages.find(m => m.role === 'system')?.content || undefined;
      const userContent = messages.filter(m => m.role === 'user').map(m => m.content).join('\n\n');
      const body = { model: options.model, max_tokens: options.maxTokens ?? 2000, messages: [{ role: 'user', content: sys ? `${sys}\n\n${userContent}` : userContent }], temperature: options.temperature, top_p: options.topP };
      const headers: Record<string, string> = { 'anthropic-version': '2023-06-01' };
      if (apiKey) headers['x-api-key'] = apiKey;
      const jsonOpts: any = { url, method: 'POST', headers, body };
      if (signal) jsonOpts.signal = signal;
      if (typeof timeoutMs === 'number') jsonOpts.timeout = timeoutMs;
      const data = await requestJSON<any>(jsonOpts).catch((e) => { throw fromHttpError(e, 'anthropic'); });
      const text: string = data.content?.[0]?.text || '';
  return { text, finishReason: 'stop' };
    },
  };
}

// Gemini (non-stream via simulated chunks)
export function geminiAdapter(): Adapter {
  return {
    async stream({ requestId, signal, baseUrl, apiKey, options, messages, onEvent, timeoutMs }) {
  if (flags.aiTrace) logger.debug('[ADAPTER_ASSERT]', 'endpoint=', ENDPOINTS.gemini);
      onEvent({ type: 'start', requestId });
      if (flags.aiTrace) logger.info('[ADAPTER_REQUEST]', 'provider=gemini', 'model=', options.model, 'stream=true');
      const sys = messages.find(m => m.role === 'system')?.content || undefined;
      const user = messages.filter(m => m.role === 'user').map(m => m.content).join('\n\n');
      const url = `${pickBase(baseUrl, 'https://generativelanguage.googleapis.com')}/v1beta/models/${options.model}:generateContent?key=${apiKey || ''}`;
      const body = { contents: [{ parts: [{ text: sys ? `${sys}\n\n${user}` : user }] }], generationConfig: { maxOutputTokens: options.maxTokens ?? 2000, temperature: options.temperature, topP: options.topP } };
      try {
        const jsonOpts: any = { url, method: 'POST', body };
        if (signal) jsonOpts.signal = signal;
        if (typeof timeoutMs === 'number') jsonOpts.timeout = timeoutMs;
        const data = await requestJSON<any>(jsonOpts).catch((e) => { throw fromHttpError(e, 'gemini'); });
        if (flags.aiTrace) logger.debug('[ADAPTER_CONNECTION_OPENED]');
        const full: string = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
        if (!full) { onEvent({ type: 'done', requestId, finishReason: 'stop' }); if (flags.aiTrace) logger.info('[ADAPTER_STREAM_END]'); return; }
        const chunks = full.match(/.{1,60}/g) || [full];
        let first = true;
        for (const c of chunks) {
          if (signal.aborted) break;
          if (first) { if (flags.aiTrace) logger.info('[ADAPTER_FIRST_CHUNK]'); first = false; }
          if (flags.aiTrace) logger.debug('[ADAPTER_CHUNK]', 'size=', String(c.length));
          onEvent({ type: 'delta', requestId, text: c });
          await new Promise(r => setTimeout(r, 16));
        }
        onEvent({ type: 'done', requestId, finishReason: 'stop' });
        if (flags.aiTrace) logger.info('[ADAPTER_STREAM_END]');
        if (signal.aborted && flags.aiTrace) logger.warn('[ADAPTER_STREAM_ABORTED]');
      } catch (e: any) {
        if (flags.aiTrace) logger.error('[ADAPTER_STREAM_ERROR]', String(e?.message || e));
        throw e;
      }
    },
    async complete({ baseUrl, apiKey, options, messages, signal, timeoutMs }) {
      const sys = messages.find(m => m.role === 'system')?.content || undefined;
      const user = messages.filter(m => m.role === 'user').map(m => m.content).join('\n\n');
      const url = `${pickBase(baseUrl, 'https://generativelanguage.googleapis.com')}/v1beta/models/${options.model}:generateContent?key=${apiKey || ''}`;
      const body = { contents: [{ parts: [{ text: sys ? `${sys}\n\n${user}` : user }] }], generationConfig: { maxOutputTokens: options.maxTokens ?? 2000, temperature: options.temperature, topP: options.topP } };
  const jsonOpts2: any = { url, method: 'POST', body };
      if (signal) jsonOpts2.signal = signal;
      if (typeof timeoutMs === 'number') jsonOpts2.timeout = timeoutMs;
  const data = await requestJSON<any>(jsonOpts2).catch((e) => { throw fromHttpError(e, 'gemini'); });
      const text: string = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
      return { text, finishReason: 'stop' };
    },
  };
}

// Ollama
export function ollamaAdapter(): Adapter {
  return {
    async stream({ requestId, signal, baseUrl, options, messages, onEvent, timeoutMs }) {
  if (flags.aiTrace) logger.debug('[ADAPTER_ASSERT]', 'endpoint=', ENDPOINTS.ollama);
      onEvent({ type: 'start', requestId });
      const sys = messages.find(m => m.role === 'system')?.content || undefined;
      const user = messages.filter(m => m.role === 'user').map(m => m.content).join('\n\n');
  const configured = pickBase(baseUrl, 'http://localhost:11434');
  const isLocalDefault = /localhost:11434\/?$/.test(configured);
      const base = isLocalDefault && typeof window !== 'undefined' ? '/ollama' : configured;
  const resp = await fetchWithRetry(`${base}/api/generate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model: options.model, prompt: sys ? `${sys}\n\n${user}` : user, stream: true }), signal }, timeoutMs !== undefined ? { timeoutMs } : {});
      if (!resp.ok) throw await errorFromResponse(resp, 'ollama', 'generate');
      const reader = resp.body?.getReader();
      if (!reader) throw makeError('Ollama: no stream', 'server', 'ollama');
      const dec = textDecoder();
      let leftover = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        if (!value) continue;
        leftover += dec.decode(value, { stream: true });
        const lines = leftover.split(/\n+/);
        leftover = lines.pop() || '';
        for (const line of lines) {
          const t = line.trim();
          if (!t) continue;
          try {
            const json = JSON.parse(t);
            const delta = json.response || '';
            if (delta) onEvent({ type: 'delta', requestId, text: delta });
            if (json.done) { onEvent({ type: 'done', requestId, finishReason: 'stop' }); }
          } catch {}
        }
      }
    },
    async complete({ baseUrl, options, messages, signal, timeoutMs }) {
      const sys = messages.find(m => m.role === 'system')?.content || undefined;
      const user = messages.filter(m => m.role === 'user').map(m => m.content).join('\n\n');
  const configured = pickBase(baseUrl, 'http://localhost:11434');
  const isLocalDefault = /localhost:11434\/?$/.test(configured);
      const base = isLocalDefault && typeof window !== 'undefined' ? '/ollama' : configured;
  const jsonOpts3: any = { url: `${base}/api/generate`, method: 'POST', body: { model: options.model, prompt: sys ? `${sys}\n\n${user}` : user, stream: false } };
      if (signal) jsonOpts3.signal = signal;
      if (typeof timeoutMs === 'number') jsonOpts3.timeout = timeoutMs;
  const data = await requestJSON<any>(jsonOpts3).catch((e) => { throw fromHttpError(e, 'ollama'); });
      const text: string = data.response || '';
      return { text, finishReason: 'stop' };
    },
  };
}

export function getAdapter(provider: ProviderKey): Adapter {
  if (provider === 'openai') return openaiAdapter();
  if (provider === 'anthropic') return anthropicAdapter();
  if (provider === 'gemini') return geminiAdapter();
  if (provider === 'ollama') return ollamaAdapter();
  throw makeError('Unknown provider', 'invalid_request');
}
