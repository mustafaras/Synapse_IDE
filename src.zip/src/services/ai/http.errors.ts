import type { UnifiedError } from './http.types';

export function isAbortError(e: unknown): boolean {
  // DOMException name can be 'AbortError' in browsers; node fetch throws AbortError as well
  return (
    (e instanceof DOMException && e.name === 'AbortError') ||
    (typeof e === 'object' && e !== null && 'name' in e && (e as any).name === 'AbortError')
  );
}

export function toUnifiedError(e: unknown, ctx?: { status?: number }): UnifiedError {
  if (isAbortError(e)) {
    return { code: 'aborted', retriable: false, userMessage: 'Request was canceled', detail: String(e) } as UnifiedError;
  }
  if (typeof ctx?.status === 'number') {
    const status = ctx.status;
    if (status >= 500) {
      return { code: 'http_5xx', status, retriable: true, userMessage: 'Server error. Please retry.', detail: String(e) } as UnifiedError;
    }
    if (status >= 400) {
      return { code: 'http_4xx', status, retriable: false, userMessage: 'Request error. Check your settings.', detail: String(e) } as UnifiedError;
    }
  }
  // Timeout marker
  if (typeof e === 'object' && e && (e as any).__timeout === true) {
    return { code: 'timeout', retriable: true, userMessage: 'Request timed out. Trying again may help.' } as UnifiedError;
  }
  // Network or unknown
  return { code: 'network', retriable: true, userMessage: 'Network error. Please check connection and retry.', detail: String(e) } as UnifiedError;
}
