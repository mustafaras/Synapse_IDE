import { isAbortError, toUnifiedError } from './http.errors';
import type { RequestJSONOptions, RequestSSEOptions, RequestSSEResult, RetryPolicy, UnifiedError } from './http.types';

// Lightweight aiTrace tap to avoid importing app-wide logger; guard by window.flags if present
function aiTrace(...args: any[]) {
  try {
    // @ts-ignore
    const enabled = typeof window !== 'undefined' && (window as any)?.flags?.aiTrace;
    if (enabled) console.log('[AI-TRACE]', ...args);
  } catch {}
}

const DEFAULT_RETRY: RetryPolicy = {
  retries: 2,
  baseDelayMs: 300,
  maxDelayMs: 2000,
  retryOn: (status?: number, _code?: string) => {
    if (status === undefined) return true; // network error
    if (status >= 500) return true;
    if (status === 429) return true;
    return false;
  },
};

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((res, rej) => {
    const t = setTimeout(res, ms);
    if (signal) {
      const onAbort = () => {
        clearTimeout(t);
        const err: any = new Error('Aborted');
        err.name = 'AbortError';
        rej(err);
      };
      if (signal.aborted) onAbort();
      signal.addEventListener('abort', onAbort, { once: true });
    }
  });
}

function jitteredBackoff(attempt: number, base: number, max: number) {
  const exp = Math.min(max, base * Math.pow(2, attempt));
  const jitter = Math.random() * 0.3 + 0.85; // 0.85x–1.15x
  return Math.min(max, Math.floor(exp * jitter));
}

export async function requestJSON<T = unknown>(opts: RequestJSONOptions): Promise<T> {
  const { url, method = 'POST', headers = {}, body, signal, timeout, retry } = opts;
  const rp: RetryPolicy = { ...DEFAULT_RETRY, ...retry };
  let attempt = 0;
  const controller = new AbortController();
  const signals: AbortSignal[] = [controller.signal];
  if (signal) signals.push(signal);
  const anyAborted = () => signals.some(s => (s as any).aborted);
  const onAbort = () => controller.abort();
  signals.forEach(s => s.addEventListener('abort', onAbort));

  try {
    while (true) {
      if (anyAborted()) throw new DOMException('Aborted', 'AbortError');
      const thisAttempt = attempt;
      let timeoutId: any;
      const reqController = new AbortController();
      const merged = new AbortController();
      const mergeAbort = () => merged.abort();
      reqController.signal.addEventListener('abort', mergeAbort);
      signals.forEach(s => s.addEventListener('abort', mergeAbort));

      const start = performance.now();
      aiTrace('[HTTP][INIT]', { url, method, attempt: thisAttempt });
      try {
        if (timeout && timeout > 0) {
          timeoutId = setTimeout(() => reqController.abort(), timeout);
        }
        const res = await fetch(url, {
          method,
          headers: { 'content-type': 'application/json', ...headers },
          body: body !== undefined ? JSON.stringify(body) : null,
          signal: merged.signal,
        });
        clearTimeout(timeoutId);
        const elapsed = Math.round(performance.now() - start);
        if (!res.ok) {
          aiTrace('[HTTP][ERROR_STATUS]', { status: res.status, elapsed, attempt: thisAttempt });
          const ue = toUnifiedError(new Error(`HTTP ${res.status}`), { status: res.status });
          if (rp.retryOn(res.status, ue.code) && attempt < rp.retries) {
            const delay = jitteredBackoff(attempt, rp.baseDelayMs, rp.maxDelayMs);
            aiTrace('[HTTP][RETRY]', { attempt: thisAttempt + 1, delay });
            attempt++;
            await sleep(delay, signal);
            continue;
          }
          throw ue;
        }
        const json = (await res.json()) as T;
        aiTrace('[HTTP][DONE]', { elapsed });
        return json;
      } catch (e) {
        clearTimeout(timeoutId);
        if (isAbortError(e)) throw e;
        const ue = toUnifiedError(e as any);
        if (rp.retryOn(undefined, ue.code) && attempt < rp.retries && ue.retriable) {
          const delay = jitteredBackoff(attempt, rp.baseDelayMs, rp.maxDelayMs);
          aiTrace('[HTTP][RETRY]', { attempt: thisAttempt + 1, delay, code: ue.code });
          attempt++;
          await sleep(delay, signal);
          continue;
        }
        aiTrace('[HTTP][FAIL]', { code: ue.code });
        throw ue;
      }
    }
  } finally {
    signals.forEach(s => s.removeEventListener('abort', onAbort));
  }
}

export function requestSSE(opts: RequestSSEOptions): RequestSSEResult {
  const { url, method = 'POST', headers = {}, body, signal, openTimeoutMs = 10_000, retry, onEvent } = opts;
  const rp: RetryPolicy = { ...DEFAULT_RETRY, ...retry };
  let attempt = 0;
  let closed = false;
  const controller = new AbortController();
  const userSignal = signal;

  const cancel = () => {
    closed = true;
    controller.abort();
  };

  function attachUserAbort() {
    if (!userSignal) return;
    const onAbort = () => cancel();
    if (userSignal.aborted) onAbort();
    userSignal.addEventListener('abort', onAbort, { once: true });
  }

  async function run() {
    attachUserAbort();
    while (!closed) {
      const thisAttempt = attempt;
      let openTimer: any;
      try {
        aiTrace('[SSE][INIT]', { url, attempt: thisAttempt });
        const res = await fetch(url, {
          method,
          headers: { 'content-type': 'application/json', accept: 'text/event-stream', ...headers },
          body: body !== undefined ? JSON.stringify(body) : null,
          signal: controller.signal,
        });
        if (!res.ok) {
          const ue = toUnifiedError(new Error(`HTTP ${res.status}`), { status: res.status });
          aiTrace('[SSE][ERROR_STATUS]', { status: res.status, attempt: thisAttempt });
          if (rp.retryOn(res.status, ue.code) && attempt < rp.retries) {
            const delay = jitteredBackoff(attempt, rp.baseDelayMs, rp.maxDelayMs);
            aiTrace('[SSE][RETRY]', { attempt: thisAttempt + 1, delay });
            attempt++;
            await sleep(delay, signal);
            continue;
          }
          onEvent({ type: 'error', error: ue });
          return;
        }

        const reader = res.body?.getReader();
        if (!reader) {
          // Fallback: some test environments (e.g., Playwright route.fulfill) may not provide a ReadableStream body.
          // Parse the entire response text as an SSE transcript and emit events sequentially.
          try {
            const full = await res.text();
            onEvent({ type: 'open' });
            let buffer = full || '';
            // Split into SSE frames by double newline
            const frames = buffer.split(/\n\n+/);
            for (const raw of frames) {
              if (!raw) continue;
              for (const line of raw.split('\n')) {
                if (line.startsWith('data:')) {
                  const data = line.slice(5).trimStart();
                  onEvent({ type: 'message', data });
                }
              }
            }
            onEvent({ type: 'done' });
            return;
          } catch (_e) {
            const ue: UnifiedError = { code: 'parse', retriable: true, userMessage: 'No stream', detail: 'Missing body reader' };
            onEvent({ type: 'error', error: ue });
            return;
          }
        }

        let opened = false;
        openTimer = setTimeout(() => {
          if (!opened) {
            const ue: UnifiedError = { code: 'timeout', retriable: true, userMessage: 'Stream open timed out.' };
            aiTrace('[SSE][OPEN_TIMEOUT]');
            try { reader.cancel(); } catch {}
            onEvent({ type: 'error', error: ue });
            cancel();
          }
        }, openTimeoutMs);

        const decoder = new TextDecoder();
        let buffer = '';
        onEvent({ type: 'open' });
        opened = true;
        aiTrace('[SSE][OPEN]');
        while (!closed) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          buffer += chunk;
          let idx: number;
          while ((idx = buffer.indexOf('\n\n')) !== -1) {
            const raw = buffer.slice(0, idx);
            buffer = buffer.slice(idx + 2);
            // Basic SSE line parse: look for `data:`
            const lines = raw.split('\n');
            for (const line of lines) {
              if (line.startsWith('data:')) {
                const data = line.slice(5).trimStart();
                onEvent({ type: 'message', data });
              }
            }
          }
        }
        clearTimeout(openTimer);
        onEvent({ type: 'done' });
        aiTrace('[SSE][DONE]');
        return;
      } catch (e) {
        clearTimeout(openTimer);
        if (isAbortError(e) || closed) {
          onEvent({ type: 'error', error: { code: 'aborted', retriable: false, userMessage: 'Request was canceled' } });
          return;
        }
        const ue = toUnifiedError(e as any);
        if (rp.retryOn(undefined, ue.code) && attempt < rp.retries && ue.retriable) {
          const delay = jitteredBackoff(attempt, rp.baseDelayMs, rp.maxDelayMs);
          aiTrace('[SSE][RETRY]', { attempt: thisAttempt + 1, delay, code: ue.code });
          attempt++;
          await sleep(delay, signal);
          continue;
        }
        onEvent({ type: 'error', error: ue });
        return;
      }
    }
  }

  // kick
  run();
  return { cancel };
}
export async function fetchWithAbort(input: RequestInfo, init?: RequestInit & { signal?: AbortSignal }) {
  return fetch(input as any, init as any);
}
