// Tiny DOM event bus so UI components can talk to the Editor host without tight coupling.
export type BridgeEvent =
  | { type: 'editor:openTab'; payload: { filename: string; code: string; language?: string } }
  | { type: 'editor:insertAtCursor'; payload: { code: string } }
  | { type: 'editor:replaceActive'; payload: { code: string } };

const BUS = '___editor_bridge___';

function emit(e: BridgeEvent) {
  window.dispatchEvent(new CustomEvent(BUS, { detail: e }));
}

// Public API
export type OpenTabPayload = { filename: string; code: string; language?: string };
export type InsertAtCursorPayload = { code: string };
export type ReplaceActivePayload = { code: string };

export const editorBridge = {
  openNewTab(args: OpenTabPayload) {
    emit({ type: 'editor:openTab', payload: args });
  },
  insertAtCursor(args: InsertAtCursorPayload) {
    emit({ type: 'editor:insertAtCursor', payload: args });
  },
  replaceActive(args: ReplaceActivePayload) {
    emit({ type: 'editor:replaceActive', payload: args });
  },
  // helper
  sizeGuard(code: string, max = 500 * 1024) {
    return code.length <= max;
  },
};

export type EditorBridgeHandler = (e: BridgeEvent) => void;

export function subscribeEditorBridge(handler: EditorBridgeHandler) {
  const on = (evt: Event) => {
    const ce = evt as CustomEvent<BridgeEvent>;
    handler(ce.detail);
  };
  window.addEventListener(BUS, on);
  return () => window.removeEventListener(BUS, on);
}
