// tasksAdapter.ts
// Auto-initialize a tasks handler for the tasksBridge when available.
// - In VS Code webviews, use acquireVsCodeApi to post messages to the extension host.
// - In local dev, allow a global function window.__runTask(kind) to be used.

import { setTasksHandler } from './tasksBridge';
import { terminalError, terminalInfo } from '@/components/terminal/terminalLogBus';

declare global {
  interface Window {
    acquireVsCodeApi?: () => { postMessage: (msg: any) => void };
    __runTask?: (kind: 'run' | 'build') => void;
  }
}

(() => {
  try {
    if (typeof window !== 'undefined') {
      if (typeof window.acquireVsCodeApi === 'function') {
        const vscode = window.acquireVsCodeApi!();
        setTasksHandler(kind => {
          vscode.postMessage({ type: 'synapse:task', kind });
          terminalInfo(`Requested VS Code task: ${kind}`, 'build');
        });
        // Optional: handle messages from extension host to surface logs
        window.addEventListener('message', (event: MessageEvent) => {
          const data = event.data;
          if (!data || typeof data !== 'object') return;
          if (data.type === 'synapse:task:log' && typeof data.message === 'string') {
            terminalInfo(data.message, data.channel || 'build');
          }
          if (data.type === 'synapse:task:error' && typeof data.message === 'string') {
            terminalError(data.message, data.channel || 'build');
          }
        });
        return;
      }
      if (typeof window.__runTask === 'function') {
        setTasksHandler(kind => {
          try {
            window.__runTask!(kind);
          } catch {}
        });
        
      }
    }
  } catch {
    // ignore
  }
  // If no adapters available, keep default simulated handler in tasksBridge
})();

export {};
