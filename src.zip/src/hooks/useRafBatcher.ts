import { useCallback, useRef } from 'react';

export function useRafBatcher<T>(flush: (items: T[]) => void) {
  const q = useRef<T[]>([]);
  const scheduled = useRef(false);

  const schedule = () => {
    if (scheduled.current) return;
    scheduled.current = true;
    requestAnimationFrame(() => {
      scheduled.current = false;
      const items = q.current;
      q.current = [];
      if (items.length) flush(items);
    });
  };

  return useCallback((item: T) => {
    q.current.push(item);
    schedule();
  }, []);
}

export default useRafBatcher;