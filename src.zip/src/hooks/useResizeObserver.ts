import { useEffect, useRef } from 'react';

export function useResizeObserver(onSize: (h: number) => void) {
  const ref = useRef<HTMLElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let last = 0;
    const ro = new ResizeObserver((entries) => {
      const h = Math.ceil(entries[0].contentRect.height);
      if (h !== last) { last = h; onSize(h); }
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [onSize]);

  return ref as React.RefObject<HTMLElement>;
}

export default useResizeObserver;