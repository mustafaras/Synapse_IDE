import { useCallback, useEffect, useMemo, useRef } from 'react';

// Debounce hook
export const useDebounce = <T extends (...args: any[]) => any>(callback: T, delay: number): T => {
  const timeoutRef = useRef<NodeJS.Timeout | undefined>(undefined);

  return useCallback(
    ((...args: Parameters<T>) => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }

      timeoutRef.current = setTimeout(() => {
        callback(...args);
      }, delay);
    }) as T,
    [callback, delay]
  );
};

// Throttle hook
export const useThrottle = <T extends (...args: any[]) => any>(callback: T, delay: number): T => {
  const lastCallRef = useRef<number>(0);
  const timeoutRef = useRef<NodeJS.Timeout | undefined>(undefined);

  return useCallback(
    ((...args: Parameters<T>) => {
      const now = Date.now();

      if (now - lastCallRef.current >= delay) {
        lastCallRef.current = now;
        callback(...args);
      } else {
        if (timeoutRef.current) {
          clearTimeout(timeoutRef.current);
        }

        timeoutRef.current = setTimeout(
          () => {
            lastCallRef.current = Date.now();
            callback(...args);
          },
          delay - (now - lastCallRef.current)
        );
      }
    }) as T,
    [callback, delay]
  );
};

// Memoized value with deep comparison
export const useDeepMemo = <T>(factory: () => T, deps: any[]): T => {
  const ref = useRef<{ deps: any[]; value: T } | undefined>(undefined);

  if (!ref.current || !deepEqual(ref.current.deps, deps)) {
    ref.current = {
      deps,
      value: factory(),
    };
  }

  return ref.current.value;
};

// Deep equality check
const deepEqual = (a: any, b: any): boolean => {
  if (a === b) return true;

  if (a instanceof Date && b instanceof Date) {
    return a.getTime() === b.getTime();
  }

  if (!a || !b || (typeof a !== 'object' && typeof b !== 'object')) {
    return a === b;
  }

  if (a === null || a === undefined || b === null || b === undefined) {
    return false;
  }

  if (a.prototype !== b.prototype) return false;

  const keys = Object.keys(a);
  if (keys.length !== Object.keys(b).length) {
    return false;
  }

  return keys.every(k => deepEqual(a[k], b[k]));
};

// Optimized event callback that prevents unnecessary re-renders
export const useStableCallback = <T extends (...args: any[]) => any>(callback: T): T => {
  const callbackRef = useRef(callback);

  useEffect(() => {
    callbackRef.current = callback;
  });

  return useCallback(
    ((...args: Parameters<T>) => {
      return callbackRef.current(...args);
    }) as T,
    []
  );
};

// Intersection Observer hook for virtual scrolling
export const useIntersectionObserver = (options: IntersectionObserverInit = {}) => {
  const ref = useRef<HTMLElement | null>(null);
  const callbackRef = useRef<((entries: IntersectionObserverEntry[]) => void) | null>(null);

  const setCallback = useCallback((callback: (entries: IntersectionObserverEntry[]) => void) => {
    callbackRef.current = callback;
  }, []);

  useEffect(() => {
    if (!ref.current || !callbackRef.current) return;

    const observer = new IntersectionObserver(entries => {
      if (callbackRef.current) {
        callbackRef.current(entries);
      }
    }, options);

    observer.observe(ref.current);

    return () => observer.disconnect();
  }, [options]);

  return { ref, setCallback };
};

// Performance monitoring hook
export const usePerformanceMonitor = (name: string) => {
  const startTimeRef = useRef<number | undefined>(undefined);

  const start = useCallback(() => {
    startTimeRef.current = performance.now();
  }, []);

  const end = useCallback(() => {
    if (startTimeRef.current) {
      const duration = performance.now() - startTimeRef.current;
      console.log(`[Performance] ${name}: ${duration.toFixed(2)}ms`);
      startTimeRef.current = undefined;
      return duration;
    }
    return 0;
  }, [name]);

  const measure = useCallback(
    (fn: () => any) => {
      start();
      const result = fn();
      end();
      return result;
    },
    [start, end]
  );

  return { start, end, measure };
};

// Virtual list hook for large datasets
export const useVirtualList = <T>(
  items: T[],
  itemHeight: number,
  containerHeight: number,
  overscan: number = 5
) => {
  const scrollTopRef = useRef(0);

  const visibleRange = useMemo(() => {
    const start = Math.floor(scrollTopRef.current / itemHeight);
    const end = Math.min(start + Math.ceil(containerHeight / itemHeight), items.length - 1);

    return {
      start: Math.max(start - overscan, 0),
      end: Math.min(end + overscan, items.length - 1),
    };
  }, [items.length, itemHeight, containerHeight, overscan]);

  const visibleItems = useMemo(() => {
    return items.slice(visibleRange.start, visibleRange.end + 1).map((item, index) => ({
      item,
      index: visibleRange.start + index,
    }));
  }, [items, visibleRange]);

  const totalHeight = items.length * itemHeight;

  const onScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    scrollTopRef.current = e.currentTarget.scrollTop;
  }, []);

  return {
    visibleItems,
    totalHeight,
    onScroll,
    startOffset: visibleRange.start * itemHeight,
  };
};

// Memory usage monitor
export const useMemoryMonitor = () => {
  const getMemoryUsage = useCallback(() => {
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      return {
        used: Math.round(memory.usedJSHeapSize / 1048576), // MB
        total: Math.round(memory.totalJSHeapSize / 1048576), // MB
        limit: Math.round(memory.jsHeapSizeLimit / 1048576), // MB
      };
    }
    return null;
  }, []);

  const logMemoryUsage = useCallback(
    (label: string = 'Memory Usage') => {
      const usage = getMemoryUsage();
      if (usage) {
        console.log(
          `[${label}] Used: ${usage.used}MB, Total: ${usage.total}MB, Limit: ${usage.limit}MB`
        );
      }
    },
    [getMemoryUsage]
  );

  return { getMemoryUsage, logMemoryUsage };
};

// Optimized resize observer
export const useResizeObserver = (
  callback: (entry: ResizeObserverEntry) => void,
  throttleDelay: number = 16
) => {
  const ref = useRef<HTMLElement | null>(null);
  const throttledCallback = useThrottle(callback, throttleDelay);

  useEffect(() => {
    if (!ref.current) return;

    const observer = new ResizeObserver(entries => {
      if (entries[0]) {
        throttledCallback(entries[0]);
      }
    });

    observer.observe(ref.current);

    return () => observer.disconnect();
  }, [throttledCallback]);

  return ref;
};
