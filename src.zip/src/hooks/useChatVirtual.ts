import { useCallback, useEffect, useRef, useState } from 'react';

type Layout = {
  totalHeight: number;
  offsets: number[];
};

export function useChatVirtual(opts: {
  count: number;
  estimateItemHeight?: number;
  overscan?: number;
  scrollEl: React.RefObject<HTMLElement>;
}) {
  const { count, estimateItemHeight = 92, overscan = 6, scrollEl } = opts;
  const heights = useRef<number[]>([]);
  const [layout, setLayout] = useState<Layout>(() => ({
    totalHeight: count * estimateItemHeight,
    offsets: Array.from({ length: count + 1 }, (_, i) => i * estimateItemHeight),
  }));

  const recompute = useCallback(() => {
    const off = new Array(count + 1);
    let y = 0;
    for (let i = 0; i < count; i++) {
      off[i] = y;
      y += heights.current[i] || estimateItemHeight;
    }
    off[count] = y;
    setLayout({ totalHeight: y, offsets: off });
  }, [count, estimateItemHeight]);

  const setItemHeight = useCallback((index: number, h: number) => {
    if (heights.current[index] === h) return;
    heights.current[index] = h;
    Promise.resolve().then(recompute);
  }, [recompute]);

  const findIndexAt = useCallback((y: number, off: number[]) => {
    let lo = 0, hi = off.length - 1;
    while (lo < hi) {
      const mid = ((lo + hi) / 2) | 0;
      if (off[mid + 1] <= y) lo = mid + 1;
      else hi = mid;
    }
    return lo;
  }, []);

  const [range, setRange] = useState({ start: 0, end: Math.max(0, Math.min(count - 1, 20)) });

  useEffect(() => {
    const el = scrollEl.current;
    if (!el) return;
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        const { scrollTop, clientHeight } = el;
        const off = layout.offsets;
        const start = Math.max(0, findIndexAt(scrollTop, off) - overscan);
        const end = Math.min(count - 1, findIndexAt(scrollTop + clientHeight, off) + overscan);
        setRange({ start, end });
      });
    };
    onScroll();
    el.addEventListener('scroll', onScroll, { passive: true } as any);
    return () => el.removeEventListener('scroll', onScroll);
  }, [count, overscan, scrollEl, layout.offsets, findIndexAt]);

  const getItemStyle = useCallback((index: number) => {
    const top = layout.offsets[index] ?? index * estimateItemHeight;
    const h = (heights.current[index] ?? estimateItemHeight);
    return { position: 'absolute' as const, top: `${top}px`, left: 0, right: 0, height: `${h}px`, willChange: 'transform' };
  }, [layout.offsets, estimateItemHeight]);

  const isAtBottom = useCallback((thresholdPx = 24) => {
    const el = scrollEl.current; if (!el) return true;
    const dist = (layout.totalHeight - el.clientHeight) - el.scrollTop;
    return dist <= thresholdPx;
  }, [scrollEl, layout.totalHeight]);

  const scrollToBottom = useCallback(() => {
    const el = scrollEl.current; if (!el) return;
    el.scrollTop = layout.totalHeight - el.clientHeight;
  }, [scrollEl, layout.totalHeight]);

  return { range, layout, setItemHeight, getItemStyle, isAtBottom, scrollToBottom };
}

export default useChatVirtual;