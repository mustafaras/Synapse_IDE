import { useCallback, useEffect, useRef, useState } from 'react';
// Switch to unified adapters resolver
import { getAdapter } from '@/services/ai/adapters';
import type { Adapter, StreamEvent } from '@/services/ai/adapters/types';
// Observability
import { beginTrace, endTraceError, endTraceOk, getActiveTraceId, setUsageAndMaybeCost, spanEnd, spanStart } from '@/utils/obs/instrument';
import { flags } from '@/config/flags';
import { logger } from '@/lib/logger';
import { timeouts } from '@/config/timeouts';

export type AiProvider = 'openai' | 'anthropic' | 'google' | 'ollama';

// --- Streaming race guards and controllers ---
export interface StartStreamOptions {
  signal?: AbortSignal;              // optional external signal
  opToken?: string;                  // optional caller-provided token
  groupKey?: string;                 // default: 'assistant'
  autoAbortOnVisibilityChange?: boolean; // optional: abort when tab hidden
}

type InflightCtx = {
  token: string;
  groupKey: string;
  abortController: AbortController;
  aborted: boolean;
  onVis?: () => void;
};

const inflightByGroup = new Map<string, InflightCtx>();
const genOpToken = () => `op_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;

interface StartParams {
  provider: AiProvider;
  modelId: string;
  prompt: string;
  systemPrompt?: string | undefined; // optional higher-level instruction (e.g., Beginner Mode)
  temperature?: number | undefined;
  topP?: number | undefined;
  seed?: number | undefined | null;
  onDelta?: (chunk: string) => void;
  onComplete?: (full: string) => void;
  onError?: (err: unknown) => void;
  // New: notify caller when provider acknowledges the stream and provide requestId for provenance
  onStart?: (meta: { requestId: string }) => void;
}

interface UseAiStreamingOptions {
  openai?: string;
  anthropic?: string;
  google?: string;
  ollama?: string; // base url
  throttleMs?: number;
}

interface StreamState {
  isStreaming: boolean;
  activeJobId: string | null;
  queuedJobs: number;
  abortReason: string | null;
}

interface QueueJob extends StartParams {
  id: string;
}

export const useAiStreaming = (opts: UseAiStreamingOptions) => {
  const [streamState, setStreamState] = useState<StreamState>({
    isStreaming: false,
    activeJobId: null,
    queuedJobs: 0,
    abortReason: null,
  });
  const isStreamingRef = useRef<boolean>(false);
  const isMountedRef = useRef<boolean>(true);
  const isDev = (typeof process !== 'undefined' && process.env && process.env.NODE_ENV === 'development') || (typeof import.meta !== 'undefined' && (import.meta as unknown as { env?: { DEV?: boolean } }).env?.DEV === true);
  const isDevRef = useRef<boolean>(isDev);
  // helper to update stream state with shallow-equality guard to avoid redundant renders
  const updateStreamState = useCallback((updater: (prev: StreamState) => StreamState) => {
    if (!isMountedRef.current) return;
    setStreamState(prev => {
      const next = updater(prev);
      if (
        prev.isStreaming === next.isStreaming &&
        prev.activeJobId === next.activeJobId &&
        prev.queuedJobs === next.queuedJobs &&
        prev.abortReason === next.abortReason
      ) {
        return prev;
      }
      isStreamingRef.current = next.isStreaming;
      return next;
    });
  }, []);
  // Track mount state to avoid updates after unmount
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
      try { abortRef.current?.abort(); } catch {}
    };
  }, []);
  const queueRef = useRef<QueueJob[]>([]);
  const abortRef = useRef<AbortController | null>(null);
  const activeGroupRef = useRef<string>('assistant');
  const activeTokenRef = useRef<string | null>(null);

  // Unified request versioning
  const requestSeqRef = useRef<number>(0);
  const activeRequestIdRef = useRef<string | null>(null);
  const doneRef = useRef<boolean>(false);
  const devCountersRef = useRef<{ flushes: number; dropped: number; aborts: number; chars: number }>({ flushes: 0, dropped: 0, aborts: 0, chars: 0 });

  // Buffered streaming (RAF-based flush)
  const bufferRef = useRef<string[]>([]);
  const rafIdRef = useRef<number | null>(null);
  const flushTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flushScheduledRef = useRef<boolean>(false);
  const isSettledRef = useRef<boolean>(false);
  const accumRef = useRef<string>('');
  const lastFlushAtRef = useRef<number>(0);
  // Observability span ids
  const streamSpanIdRef = useRef<string | null>(null);
  const connectSpanIdRef = useRef<string | null>(null);

  const runNext = useCallback(() => {
    if (isStreamingRef.current) return; // shouldn't happen
    const next = queueRef.current.shift();
    updateStreamState(s => ({ ...s, queuedJobs: queueRef.current.length }));
    if (next) {
      _execute(next);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // RAF-based flush to avoid per-token re-renders
  const scheduleFlush = useCallback((onDelta?: (chunk: string) => void) => {
    if (isSettledRef.current) return; // don't schedule after finish
    if (rafIdRef.current !== null || flushScheduledRef.current) return;
    flushScheduledRef.current = true;
    const cb = () => {
      rafIdRef.current = null;
      flushScheduledRef.current = false;
      if (bufferRef.current.length === 0) return;
      const chunk = bufferRef.current.join('');
      bufferRef.current.length = 0;
      accumRef.current += chunk;
      const ctx = inflightByGroup.get(activeGroupRef.current);
      if (ctx && activeTokenRef.current && ctx.token === activeTokenRef.current && !ctx.aborted) {
        onDelta?.(chunk);
      }
      lastFlushAtRef.current = Date.now();
      if (isDevRef.current) { try { devCountersRef.current.flushes += 1; } catch {} }
    };
    if (typeof requestAnimationFrame !== 'undefined') {
      rafIdRef.current = requestAnimationFrame(cb);
    } else {
      flushTimeoutRef.current = setTimeout(cb, 16);
    }
  }, []);

  const cancelPendingFlushes = useCallback(() => {
    try {
      if (rafIdRef.current !== null) {
        if (typeof cancelAnimationFrame !== 'undefined') cancelAnimationFrame(rafIdRef.current);
        else clearTimeout(rafIdRef.current as unknown as number);
      }
    } catch {}
    rafIdRef.current = null;
    if (flushTimeoutRef.current) { try { clearTimeout(flushTimeoutRef.current); } catch {} }
    flushTimeoutRef.current = null;
    flushScheduledRef.current = false;
  }, []);

  const hasPendingBufferedDeltas = useCallback(() => bufferRef.current.length > 0, []);

  const flushAllNow = useCallback((onDelta?: (chunk: string) => void) => {
    if (bufferRef.current.length === 0) return;
    const chunk = bufferRef.current.join('');
    bufferRef.current.length = 0;
    accumRef.current += chunk;
    const ctx = inflightByGroup.get(activeGroupRef.current);
    if (ctx && activeTokenRef.current && ctx.token === activeTokenRef.current && !ctx.aborted) {
      onDelta?.(chunk);
    }
    lastFlushAtRef.current = Date.now();
    if (isDevRef.current) { try { devCountersRef.current.flushes += 1; } catch {} }
  }, []);

  const safeAppend = useCallback((text: string, onDelta?: (chunk: string) => void) => {
    if (!text) return;
    if (isSettledRef.current) return; // drop late deltas after finish
    bufferRef.current.push(text);
    scheduleFlush(onDelta);
  }, [scheduleFlush]);

  // Note: OpenAI model fallback logic removed here; adapters take the model id as-is.

  // Provider adapters map
  const resolveProvider = useCallback((provider: AiProvider) => {
    if (provider === 'openai') return 'openai' as const;
    if (provider === 'anthropic') return 'anthropic' as const;
    if (provider === 'google') return 'gemini' as const;
    if (provider === 'ollama') return 'ollama' as const;
    throw new Error(`Unknown provider: ${String(provider)}`);
  }, []);

  // Map OpenAI model fallbacks (kept)

  // Execute a job via adapter
  const executeViaAdapter = useCallback(async (job: QueueJob, requestId: string) => {
  const providerKey = resolveProvider(job.provider);
  const adapter = getAdapter(providerKey);
    // Build messages with strict role normalization and no default canned system text
  const messages: { role: 'system'|'user'|'assistant'; content: string }[] = [];
    if (job.systemPrompt && job.systemPrompt.trim().length > 0) {
      messages.push({ role: 'system', content: job.systemPrompt });
    }
    messages.push({ role: 'user', content: job.prompt });
  const onEvent = (ev: StreamEvent) => {
      if (ev.requestId !== activeRequestIdRef.current) {
        if (isDevRef.current) { try { devCountersRef.current.dropped += 1; } catch {} }
        if (flags.aiTrace) { try { logger.warn('[IGNORED_DELTA]', 'out_of_date', 'rid=', String(ev.requestId), 'active=', String(activeRequestIdRef.current)); } catch {} }
        return;
      }
      // mark connect span on adapter start
      if (ev.type === 'start') {
        // Expose requestId upstream so UI can attach model provenance to the assistant message
        try { job.onStart?.({ requestId: ev.requestId }); } catch {}
        try {
          const tid = getActiveTraceId();
          if (tid && connectSpanIdRef.current == null) {
            connectSpanIdRef.current = spanStart(tid, 'network_connect', 'connect');
          }
        } catch {}
      }
      if (ev.type === 'delta' && ev.text) {
        if (isSettledRef.current) return; // ignore late tokens
        safeAppend(ev.text, job.onDelta);
        if (isDevRef.current) { try { devCountersRef.current.chars += ev.text.length; } catch {} }
        // mark stream started span on first delta
        try {
          const tid = getActiveTraceId();
          if (tid && streamSpanIdRef.current == null) {
            streamSpanIdRef.current = spanStart(tid, 'stream', job.modelId, { adapter: providerKey });
          }
          if (tid && connectSpanIdRef.current) {
            spanEnd(tid, connectSpanIdRef.current, {});
            connectSpanIdRef.current = null;
          }
        } catch {}
      } else if (ev.type === 'done') {
        doneRef.current = true;
        try {
          const tid = getActiveTraceId();
          if (tid && streamSpanIdRef.current) spanEnd(tid, streamSpanIdRef.current, { finish: ev.finishReason });
          if (tid && connectSpanIdRef.current) { spanEnd(tid, connectSpanIdRef.current, {}); connectSpanIdRef.current = null; }
        } catch {}
      } else if (ev.type === 'usage') {
        try {
          const tid = getActiveTraceId();
          if (tid) setUsageAndMaybeCost(tid, providerKey, job.modelId, ev.usage);
        } catch {}
      } else if (ev.type === 'error') {
        job.onError?.(ev.error);
        try {
          const tid = getActiveTraceId();
          if (tid) {
            const errObj: { code: string; message?: string; status?: number } = { code: String(ev.error.code), message: ev.error.message };
            if (typeof ev.error.status === 'number') errObj.status = ev.error.status;
            endTraceError(tid, errObj);
          }
          if (tid && connectSpanIdRef.current) { spanEnd(tid, connectSpanIdRef.current, {}); connectSpanIdRef.current = null; }
        } catch {}
      }
    };
    const options = { model: job.modelId } as { model: string; temperature?: number; topP?: number };
    if (typeof job.temperature === 'number') options.temperature = job.temperature;
    if (typeof job.topP === 'number') options.topP = job.topP;
    type StreamArgs = Parameters<Adapter['stream']>[0];
    const args: StreamArgs = {
      requestId,
      signal: abortRef.current!.signal,
      options,
      messages,
      onEvent,
    };
    if (providerKey === 'ollama') {
      args.baseUrl = opts.ollama || 'http://localhost:11434';
    }
    if (providerKey === 'openai' && opts.openai) args.apiKey = opts.openai;
    if (providerKey === 'anthropic' && opts.anthropic) args.apiKey = opts.anthropic;
    if (providerKey === 'gemini' && opts.google) args.apiKey = opts.google;
  // Use centralized open-timeout to make SSE connection snappy under e2e
  (args as any).timeoutMs = timeouts.sseOpenMs;
  await adapter.stream(args);
  }, [resolveProvider, opts.openai, opts.anthropic, opts.google, opts.ollama, safeAppend]);

  const _execute = useCallback(async (job: QueueJob) => {
  if (!abortRef.current) abortRef.current = new AbortController();
    // start new request id/version
    const requestId = `r${++requestSeqRef.current}`;
    activeRequestIdRef.current = requestId;
    doneRef.current = false;
    isSettledRef.current = false;
  if (isDevRef.current) { devCountersRef.current = { flushes: 0, dropped: 0, aborts: 0, chars: 0 }; }
    bufferRef.current.length = 0;
    accumRef.current = '';
    if (rafIdRef.current !== null) {
      if (typeof cancelAnimationFrame !== 'undefined') {
        cancelAnimationFrame(rafIdRef.current);
      } else {
        clearTimeout(rafIdRef.current as unknown as number);
      }
      rafIdRef.current = null;
    }
    updateStreamState(s => ({ ...s, isStreaming: true, activeJobId: job.id, abortReason: null }));
    // Observability: begin trace and build_prompt span
    let traceId: string | null = null;
    let buildSpan: string | null = null;
    try {
      const pk = resolveProvider(job.provider);
      traceId = beginTrace({ requestId, provider: pk, model: job.modelId, userTextBytes: (job.prompt?.length || 0) });
      buildSpan = spanStart(traceId, 'build_prompt', 'system+context');
    } catch {}
    try {
      await executeViaAdapter(job, requestId);
      // Final synchronous flush before completing
      isSettledRef.current = true;
      cancelPendingFlushes();
      if (hasPendingBufferedDeltas()) flushAllNow(job.onDelta);
      if (activeRequestIdRef.current === requestId) {
        job.onComplete?.(accumRef.current);
      }
      try { if (traceId) endTraceOk(traceId); } catch {}
    } catch (err: unknown) {
      const e = err as { name?: string } | undefined;
      if (e && e.name === 'AbortError') {
        // On abort, ensure we render last buffered chunk once
        isSettledRef.current = true;
        cancelPendingFlushes();
        if (hasPendingBufferedDeltas()) flushAllNow(job.onDelta);
        updateStreamState(s => ({ ...s, abortReason: s.abortReason || 'aborted' }));
  try { if (traceId) endTraceError(traceId, { code: 'cancelled', message: 'aborted' }); } catch {}
      } else {
        // On error, also render last buffered chunk once
        isSettledRef.current = true;
        cancelPendingFlushes();
        if (hasPendingBufferedDeltas()) flushAllNow(job.onDelta);
        const ctx = inflightByGroup.get(activeGroupRef.current);
        if (ctx && activeTokenRef.current && ctx.token === activeTokenRef.current && !ctx.aborted) {
          job.onError?.(err);
        }
      }
      try {
        if (traceId) {
          const msg = err instanceof Error ? err.message : String(err ?? '');
          endTraceError(traceId, { code: 'unknown', message: msg });
        }
      } catch {}
    } finally {
      try { if (traceId && buildSpan) spanEnd(traceId, buildSpan, {}); } catch {}
      streamSpanIdRef.current = null;
      connectSpanIdRef.current = null;
      updateStreamState(s => ({ ...s, isStreaming: false, activeJobId: null }));
      const ctx = inflightByGroup.get(activeGroupRef.current);
      if (ctx && activeTokenRef.current && ctx.token === activeTokenRef.current) {
        if (ctx.onVis) try { document.removeEventListener('visibilitychange', ctx.onVis); } catch {}
        inflightByGroup.delete(activeGroupRef.current);
        activeTokenRef.current = null;
      }
      abortRef.current = null;
      // Cancel any pending animation/timeouts for flush and clear flags
      cancelPendingFlushes();
      bufferRef.current.length = 0;
      if (isDevRef.current) { try { console.warn('[DEV][stream] summary', { requestId, ...devCountersRef.current }); } catch {} }
      runNext();
    }
  }, [executeViaAdapter, scheduleFlush, updateStreamState, runNext, resolveProvider]);

  const startStreaming = useCallback(
    (params: StartParams, options?: StartStreamOptions) => {
      const groupKey = options?.groupKey ?? 'assistant';
      const token = options?.opToken ?? genOpToken();
      // Abort any in-flight in this group (single-flight)
      const prior = inflightByGroup.get(groupKey);
      if (prior && !prior.aborted) {
        try { prior.abortController.abort(); prior.aborted = true; } catch {}
        inflightByGroup.delete(groupKey);
      }
      // Create internal controller and bridge external signal
      const ctrl = new AbortController();
      if (options?.signal) {
        if (options.signal.aborted) ctrl.abort();
        else options.signal.addEventListener('abort', () => ctrl.abort(), { once: true });
      }
      // Optional visibility-based abort
  let onVis: (() => void) | undefined;
      if (options?.autoAbortOnVisibilityChange) {
        onVis = () => { if (document.hidden) ctrl.abort(); };
        document.addEventListener('visibilitychange', onVis);
      }
  const ctx: InflightCtx = { token, groupKey, abortController: ctrl, aborted: false } as InflightCtx;
  if (onVis) ctx.onVis = onVis;
      // track aborted flag on controller
      try { ctrl.signal.addEventListener('abort', () => { ctx.aborted = true; }, { once: true }); } catch {}
      inflightByGroup.set(groupKey, ctx);
      activeGroupRef.current = groupKey;
      activeTokenRef.current = token;
  abortRef.current = ctrl;

  const job: QueueJob = {
        ...params,
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      };
      if (streamState.isStreaming || queueRef.current.length > 0) {
        queueRef.current.push(job);
        updateStreamState(s => ({ ...s, queuedJobs: queueRef.current.length }));
      } else {
        _execute(job);
      }
  if (isDev) console.warn('[DEV][stream] start', { groupKey, token, provider: params.provider, modelId: params.modelId, queued: queueRef.current.length });
  return {
        opToken: token,
        abort: () => { try { ctx.aborted = true; ctrl.abort(); } catch {} },
        groupKey,
      };
       
    },
  [streamState.isStreaming, _execute, updateStreamState, isDev]
  );

  const abortStreaming = useCallback(
    (reason: string = 'user_cancel') => {
      // Always set abort reason so UI can surface feedback immediately
      updateStreamState(s => ({ ...s, abortReason: reason, isStreaming: false, activeJobId: null }));
      // If a request has been started (abortRef set), abort the controller as well
      if (abortRef.current) {
        try { abortRef.current.abort(); } catch {}
        if (isDevRef.current) { try { devCountersRef.current.aborts += 1; } catch {} }
      }
    },
  [updateStreamState]
  );

  return { startStreaming, abortStreaming, streamState } as const;
};

// Optional: out-of-hook cancel by group
export const cancelStream = (groupKey: string = 'assistant') => {
  const ctx = inflightByGroup.get(groupKey);
  if (!ctx || ctx.aborted) return;
  try { ctx.abortController.abort(); } catch {}
  inflightByGroup.delete(groupKey);
};
