import React, { useEffect, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import { Copy, FilePlus, PlusSquare, Replace, Rocket } from 'lucide-react';
import { inferLanguageFromFence } from '@/services/editorBridge';
import { editorBridge as domEditorBridge } from '@/services/editor/bridge';
import { BEGINNER_ASSISTANT_ENABLED } from '@/features/beginnerAssistant';
import { showToast } from '@/ui/toast/api';

export interface CodeBlockWithActionsProps {
  code: string;
  language?: string;
  // Primary == show full toolbar. Secondary blocks should be compact.
  primary?: boolean;
  // Back-compat: some callers may still pass `limited`; we will honor it if provided.
  limited?: boolean;
  // Callbacks receive snippet and language for convenience; returning void or Promise<void>.
  onCopy?: (code: string) => void | Promise<void>;
  onInsert?: (code: string, lang?: string) => void | Promise<void>;
  onPreview?: (code: string, lang?: string) => void | Promise<void>;
  onNewTab?: (code: string, lang?: string) => void | Promise<void>;
  onReplace?: (code: string, lang?: string) => void | Promise<void>;
}

// Accessible button component styled via global classes
const ActionBtn: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement>> = ({
  children,
  className = '',
  ...rest
}) => (
  <button {...rest} className={`ai-code-action ${className}`}>
    {children}
  </button>
);

export const CodeBlockWithActions: React.FC<CodeBlockWithActionsProps> = ({
  code,
  language,
  onCopy,
  onInsert,
  onPreview,
  onNewTab,
  onReplace,
  primary,
  limited,
}) => {
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const lang = inferLanguageFromFence(language, code);
  const codeRef = useRef<HTMLPreElement | null>(null);
  const previewSupported = /^(html?|css|javascript)$/.test((lang || '').toLowerCase());
  const isShellLike = useMemo(() => /^(sh|bash|shell|zsh|powershell|ps1|cmd)$/i.test(lang || ''), [lang]);
  const isDiffLike = useMemo(() => /^(diff|patch)$/i.test(lang || ''), [lang]);
  const oversized = useMemo(() => code.length > 200_000 || code.split(/\r?\n/).length > 2000, [code]);

  useEffect(() => {
    if (!copied) return;
    const t = setTimeout(() => setCopied(false), 1600);
    return () => clearTimeout(t);
  }, [copied]);

  if (!BEGINNER_ASSISTANT_ENABLED) {
    return (
      <pre className="ai-code-pre" tabIndex={0} aria-label={`${lang} code`}>
        <code>{code}</code>
      </pre>
    );
  }

  const handleCopy = () => {
    onCopy?.(code);
    setCopied(true);
  };

  // Quick secret scrub check before destructive operations
  const SECRET_REGEX = /(sk-[a-z0-9]{20,}|AIza[0-9A-Za-z_\-]{10,}|ghp_[0-9A-Za-z]{30,})/i;
  const containsSecrets = (s: string) => SECRET_REGEX.test(s);

  const handleToolbarKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Escape') {
      e.stopPropagation();
      codeRef.current?.focus();
    }
  };

  // Determine compact vs full toolbar.
  const isLimited = primary === undefined ? !!limited : !primary;

  return (
    <div
      className="ai-code-wrapper"
      data-language={lang}
      data-limited={isLimited ? 'true' : 'false'}
    >
      <div
        className="ai-code-toolbar"
        role="toolbar"
        aria-label={`Code actions for ${lang} block`}
        onKeyDown={handleToolbarKey}
      >
        <ActionBtn aria-label="Copy code" title="Copy code" onClick={handleCopy}>
          {copied ? '✔' : <Copy size={16} />}
        </ActionBtn>
        <ActionBtn
          aria-label="Open in new tab"
          title="Open in new tab"
          disabled={busy}
          onClick={async () => {
            if (oversized) {
              const proceed = window.confirm('This snippet is quite large. Open in a new tab anyway?');
              if (!proceed) return;
            }
            try {
              setBusy(true);
              if (onNewTab) {
                await onNewTab(code, lang);
              } else {
                const fname = `snippet-${Date.now()}.${(lang||'txt')}`;
                if (!domEditorBridge.sizeGuard(code)) {
                  showToast({ kind: 'warning', message: 'Large snippet. Opened in new tab.', contextKey: 'editor:guard' });
                }
                domEditorBridge.openNewTab({ filename: fname, code, language: lang });
              }
              showToast({ kind: 'success', message: 'Opened in new tab' });
            }
            catch { showToast({ kind: 'error', message: 'Failed to open in new tab' }); }
            finally { setBusy(false); }
          }}
        >
          <FilePlus size={16} />
        </ActionBtn>
        {!isLimited && (
          <>
            <ActionBtn
              aria-label="Insert into active tab"
              title="Insert into active tab"
              disabled={busy}
              onClick={async () => {
                if (oversized) {
                  const proceed = window.confirm('This snippet is very large. Insert into the active editor?');
                  if (!proceed) return;
                }
                if (isShellLike) {
                  showToast({ kind: 'warning', message: 'Shell code detected. Review before running.' });
                }
                if (containsSecrets(code) && !window.confirm('This block looks like it may contain secrets (API keys). Insert anyway?')) return;
                try {
                  setBusy(true);
                  if (onInsert) {
                    await onInsert(code, lang);
                  } else {
                    if (!domEditorBridge.sizeGuard(code)) {
                      showToast({ kind: 'warning', message: 'Large snippet. Opened in new tab.', contextKey: 'editor:guard' });
                      domEditorBridge.openNewTab({ filename: `snippet-${Date.now()}.txt`, code, language: lang });
                    } else {
                      domEditorBridge.insertAtCursor({ code });
                    }
                  }
                  showToast({ kind: 'success', message: 'Inserted snippet', contextKey: 'editor:insert' });
                }
                catch { showToast({ kind: 'error', message: 'Insert failed' }); }
                finally { setBusy(false); }
              }}
              data-full-only="true"
            >
              <PlusSquare size={16} />
            </ActionBtn>
            <ActionBtn
              aria-label="Replace editor content"
              title="Replace editor content"
              disabled={busy || isDiffLike}
              onClick={async () => {
                if (isDiffLike) return; // hidden/disabled for diff/patch
                if (oversized) {
                  const proceed = window.confirm('This will replace selection with a very large snippet. Continue?');
                  if (!proceed) return;
                }
                if (isShellLike) {
                  showToast({ kind: 'warning', message: 'Shell code detected. Review before running.' });
                }
                if (containsSecrets(code) && !window.confirm('This block looks like it may contain secrets (API keys). Replace anyway?')) return;
                try {
                  setBusy(true);
                  if (onReplace) {
                    await onReplace(code, lang);
                  } else {
                    if (!domEditorBridge.sizeGuard(code)) {
                      showToast({ kind: 'warning', message: 'Large snippet. Opened in new tab.', contextKey: 'editor:guard' });
                      domEditorBridge.openNewTab({ filename: `snippet-${Date.now()}.txt`, code, language: lang });
                    } else {
                      domEditorBridge.replaceActive({ code });
                    }
                  }
                  showToast({ kind: 'success', message: 'Replaced selection', contextKey: 'editor:replace' });
                }
                catch { showToast({ kind: 'error', message: 'Replace failed' }); }
                finally { setBusy(false); }
              }}
              data-full-only="true"
            >
              <Replace size={16} />
            </ActionBtn>
            <ActionBtn
              aria-label="Preview (HTML/CSS/JS)"
              title="Preview (HTML/CSS/JS)"
              onClick={async () => {
                if (!previewSupported) return;
                try { setBusy(true); await onPreview?.(code, lang); }
                catch { showToast({ kind: 'error', message: 'Preview failed' }); }
                finally { setBusy(false); }
              }}
              disabled={!previewSupported || busy}
              data-full-only="true"
            >
              <Rocket size={16} />
            </ActionBtn>
          </>
        )}
      </div>
      <div className="ai-code-lang">{language || lang}</div>
      {isShellLike ? <div className="ai-code-note" role="note" aria-label="shell warning" style={{ fontSize: 11, opacity: 0.8, padding: '2px 12px' }}>
          Shell-like snippet. Review before running.
        </div> : null}
      <pre
        ref={codeRef}
        className="ai-code-pre"
        tabIndex={0}
        aria-label={`${lang} code (press Tab to reach actions, Esc to return)`}
      >
        <code>{code}</code>
      </pre>
    </div>
  );
};

// Inline style objects removed in favor of themed classes defined in AiAssistantStyles.ts (STEP 5)

export default CodeBlockWithActions;
