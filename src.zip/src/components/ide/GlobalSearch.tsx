import React, { useEffect, useMemo, useState } from 'react';
import { Modal } from '../molecules/Modal';
import { SYNAPSE_COLORS, SYNAPSE_TYPO, withAlpha } from '../../ui/theme/synapseTheme';
import { useEditorStore, useTabActions } from '../../stores/editorStore';
import { indexDocs, queryDocs } from '../../services/search';
import { useFileExplorerStore } from '../../stores/fileExplorerStore';

export const GlobalSearch: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  const tabs = useEditorStore(s => s.tabs);
  const files = useFileExplorerStore(s => s.files);
  const { setActiveTab, openTab } = useTabActions();
  const [q, setQ] = useState('');
  useEffect(() => {
    if (!isOpen) setQ('');
  }, [isOpen]);
  const [results, setResults] = useState<
    {
      tabId: string;
      tabName: string;
      line: number;
      preview: string;
      matchIndex?: number;
      matchLength?: number;
    }[]
  >([]);

  // Index open tabs whenever modal opens or tabs change
  useEffect(() => {
    if (!isOpen) return;
    // Flatten files in explorer
    const flatten = (nodes: any[]): any[] => {
      const out: any[] = [];
      nodes.forEach(n => {
        if (n.type === 'file') out.push(n);
        if (n.children) out.push(...flatten(n.children));
      });
      return out;
    };
    const explorerFiles = flatten(files);
    // Merge unique by path/name: prefer open tab content if present
    const openByPath = new Map<string, any>();
    tabs.forEach(t => openByPath.set(t.path, { id: t.id, name: t.name, content: t.content || '' }));
    const docs = explorerFiles.map(
      f => openByPath.get(f.path) || { id: f.id, name: f.name, content: f.content || '' }
    );
    indexDocs(docs);
  }, [isOpen, tabs, files]);

  useEffect(() => {
    if (!isOpen) {
      setResults([]);
      return;
    }
    const v = q.trim();
    if (!v) {
      setResults([]);
      return;
    }
    let cancelled = false;
    queryDocs(v, 300).then(list => {
      if (cancelled) return;
      const mapped = list.map((r: any) => ({
        tabId: r.docId,
        tabName: r.docName,
        line: r.line,
        preview: r.preview,
        matchIndex: r.matchIndex,
        matchLength: r.matchLength,
      }));
      setResults(mapped);
    });
    return () => {
      cancelled = true;
    };
  }, [q, isOpen]);

  const highlight = useMemo(() => {
    const v = q.trim();
    return (text: string, idx?: number, len?: number) => {
      if (!v) return text;
      const i = typeof idx === 'number' ? idx : text.toLowerCase().indexOf(v.toLowerCase());
      const l = typeof len === 'number' ? len : v.length;
      if (i < 0) return text;
      return (
        <>
          {text.slice(0, i)}
          <mark style={{ background: 'rgba(194,167,110,0.25)', color: SYNAPSE_COLORS.textPrimary }}>
            {text.slice(i, i + l)}
          </mark>
          {text.slice(i + l)}
        </>
      );
    };
  }, [q]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Global Search" size="lg">
      <div>
        <input
          autoFocus
          placeholder="Search across open tabs…"
          value={q}
          onChange={e => setQ(e.target.value)}
          style={{
            width: '100%',
            padding: '10px 12px',
            borderRadius: 10,
            border: `1px solid ${SYNAPSE_COLORS.border}`,
            background: withAlpha('#fff', 0.04),
            color: SYNAPSE_COLORS.textPrimary,
            fontFamily: SYNAPSE_TYPO.fontFamily,
          }}
        />
        <div
          style={{ marginTop: 10, display: 'grid', gap: 6, maxHeight: '60vh', overflow: 'auto' }}
        >
          {results.map((r, i) => (
            <button
              key={i}
              onClick={() => {
                const exists = tabs.find(t => t.id === r.tabId || t.name === r.tabName);
                if (exists) setActiveTab(exists.id);
                else {
                  // Try open by file explorer path/name
                  // naive search by name fallback
                  const flatten = (nodes: any[]): any[] =>
                    nodes.flatMap((n: any) =>
                      n.type === 'file' ? [n] : n.children ? flatten(n.children) : []
                    );
                  const explorerFiles = flatten(files);
                  const match = explorerFiles.find((f: any) => f.name === r.tabName);
                  if (match) openTab(match);
                }
                // jump to the matched line once mounted
                setTimeout(() => {
                  const target = tabs.find(t => t.id === r.tabId || t.name === r.tabName);
                  const targetId = target?.id || r.tabId;
                  window.dispatchEvent(
                    new CustomEvent('synapse.editor.reveal', {
                      detail: { tabId: targetId, line: r.line, column: 1 },
                    })
                  );
                }, 60);
                onClose();
              }}
              style={{
                padding: '8px 10px',
                borderRadius: 8,
                border: `1px solid ${withAlpha('#fff', 0.08)}`,
                background: 'transparent',
                color: SYNAPSE_COLORS.textPrimary,
                fontFamily: SYNAPSE_TYPO.fontFamily,
                textAlign: 'left',
              }}
            >
              <div style={{ fontSize: 12, color: SYNAPSE_COLORS.textSecondary }}>
                Tab: {r.tabName} • Line {r.line}
              </div>
              <div style={{ whiteSpace: 'pre-wrap', marginTop: 4 }}>
                {highlight(r.preview, r.matchIndex, r.matchLength)}
              </div>
            </button>
          ))}
          {results.length === 0 && (
            <div style={{ color: SYNAPSE_COLORS.textSecondary, fontSize: 12 }}>
              Type to search open tabs
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
};

export default GlobalSearch;
