import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Modal } from '../molecules/Modal';
import { SYNAPSE_COLORS, SYNAPSE_TYPO, withAlpha } from '../../ui/theme/synapseTheme';
import { type Command as Cmd, fuzzyFilter, listCommands } from '../../services/commandRegistry';
import { useFileExplorerStore } from '../../stores/fileExplorerStore';
import { useEditorStore, useTabActions } from '../../stores/editorStore';
import type { FileNode } from '../../types/state';

type Mode = 'files' | 'tabs' | 'symbols' | 'commands';

// Lightweight MRU/favorites persistence
const MRU_KEY = 'synapse.palette.mru.v1';
function useMRU() {
  const [mru, setMru] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(MRU_KEY) || '[]');
    } catch {
      return [];
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(MRU_KEY, JSON.stringify(mru.slice(0, 30)));
    } catch {}
  }, [mru]);
  const touch = (id: string) => setMru(prev => [id, ...prev.filter(x => x !== id)].slice(0, 30));
  return { mru, touch };
}

function flattenFiles(nodes: FileNode[]): FileNode[] {
  const out: FileNode[] = [];
  const walk = (list: FileNode[]) => {
    for (const n of list) {
      if (n.type === 'file') out.push(n);
      if (n.children && n.children.length) walk(n.children);
    }
  };
  walk(nodes);
  return out;
}

function highlight(text: string, query: string) {
  if (!query) return text;
  const i = text.toLowerCase().indexOf(query.toLowerCase());
  if (i === -1) return text;
  const before = text.slice(0, i);
  const mid = text.slice(i, i + query.length);
  const after = text.slice(i + query.length);
  return (
    <>
      {before}
      <mark style={{ background: withAlpha('#C2A76E', 0.25), color: SYNAPSE_COLORS.textPrimary }}>
        {mid}
      </mark>
      {after}
    </>
  );
}

function extractSymbols(content: string, language?: string) {
  const syms: { name: string; kind: string }[] = [];
  try {
    const lines = content.split(/\r?\n/);
    const push = (n: string, k: string) => {
      if (n.trim()) syms.push({ name: n.trim(), kind: k });
    };
    if ((language || '').includes('ts') || (language || '').includes('js')) {
      const reFn = /function\s+([a-zA-Z0-9_]+)/;
      const reCls = /class\s+([A-Za-z0-9_]+)/;
      const reConstFn = /const\s+([A-Za-z0-9_]+)\s*=\s*\(/;
      for (const ln of lines) {
        const m1 = ln.match(reFn);
        if (m1) push(m1[1], 'function');
        const m2 = ln.match(reCls);
        if (m2) push(m2[1], 'class');
        const m3 = ln.match(reConstFn);
        if (m3) push(m3[1], 'function');
      }
    } else if ((language || '').includes('md')) {
      const reH = /^(#+)\s+(.*)$/;
      for (const ln of lines) {
        const m = ln.match(reH);
        if (m) push(m[2], `h${m[1].length}`);
      }
    }
  } catch {}
  return syms;
}

export const CommandPalette: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  commands?: Cmd[];
}> = ({ isOpen, onClose, commands }) => {
  const [q, setQ] = useState('');
  const [mode, setMode] = useState<Mode>('files');
  const listRef = useRef<HTMLDivElement | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const { mru, touch } = useMRU();
  const files = useFileExplorerStore(s => s.files);
  const tabs = useEditorStore(s => s.tabs);
  const { openTab, setActiveTab } = useTabActions();

  // Reset input when closing
  useEffect(() => {
    if (!isOpen) {
      setQ('');
      setMode('files');
      setActiveIndex(0);
    }
  }, [isOpen]);

  // Mode parsing via prefixes
  useEffect(() => {
    if (!q) return;
    if (q.startsWith('>')) setMode('commands');
    else if (q.startsWith('@')) setMode('symbols');
    else if (q.startsWith('#')) setMode('tabs');
    else setMode('files');
  }, [q]);

  const filesFlat = useMemo(() => flattenFiles(files), [files]);
  const allCmds = useMemo(() => commands ?? listCommands(), [commands, isOpen]);
  const qStripped = useMemo(
    () => (q.startsWith('>') || q.startsWith('@') || q.startsWith('#') ? q.slice(1) : q),
    [q]
  );

  const fileResults = useMemo(() => {
    const v = qStripped.trim().toLowerCase();
    const base = !v
      ? filesFlat.slice(0, 200)
      : filesFlat.filter(f => f.name.toLowerCase().includes(v) || f.path.toLowerCase().includes(v));
    // Prioritize MRU hits by moving them to top in order
    const byId = new Map(base.map(f => [f.id, f] as const));
    const prioritized: typeof base = [] as any;
    mru.forEach(id => {
      const f = byId.get(id);
      if (f) {
        prioritized.push(f);
        byId.delete(id);
      }
    });
    const rest = Array.from(byId.values());
    return [...prioritized, ...rest].slice(0, 50);
  }, [filesFlat, qStripped]);

  const tabResults = useMemo(() => {
    const v = qStripped.trim().toLowerCase();
    const base = !v ? tabs : tabs.filter(t => t.name.toLowerCase().includes(v));
    const byId = new Map(base.map(t => [t.id, t] as const));
    const prioritized: typeof base = [] as any;
    mru.forEach(id => {
      const t = byId.get(id);
      if (t) {
        prioritized.push(t);
        byId.delete(id);
      }
    });
    return [...prioritized, ...Array.from(byId.values())];
  }, [tabs, qStripped]);

  const symbolResults = useMemo(() => {
    const v = qStripped.trim().toLowerCase();
    const list: Array<{
      tabId: string;
      tabName: string;
      symbol: string;
      kind: string;
      line: number;
    }> = [];
    tabs.forEach(t => {
      const syms = extractSymbols(t.content || '', t.language);
      const lines = (t.content || '').split(/\r?\n/);
      syms.forEach(s => {
        // best-effort line lookup
        const idx = Math.max(
          0,
          lines.findIndex(l => l.includes(s.name))
        );
        list.push({
          tabId: t.id,
          tabName: t.name,
          symbol: s.name,
          kind: s.kind,
          line: (idx || 0) + 1,
        });
      });
    });
    if (!v) return list.slice(0, 100);
    return list.filter(s => s.symbol.toLowerCase().includes(v)).slice(0, 100);
  }, [tabs, qStripped]);

  const commandResults = useMemo(() => fuzzyFilter(qStripped, allCmds), [qStripped, allCmds]);

  const placeholder = useMemo(() => {
    switch (mode) {
      case 'commands':
        return 'Run a command… (prefix with >)';
      case 'symbols':
        return 'Search symbols in open files… (prefix with @)';
      case 'tabs':
        return 'Switch to tab… (prefix with #)';
      default:
        return 'Search files…';
    }
  }, [mode]);

  // Keyboard navigation for list
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
        return;
      }
      if (e.key === 'Tab') {
        e.preventDefault();
        const order: Mode[] = ['files', 'tabs', 'symbols', 'commands'];
        const idx = order.indexOf(mode);
        setMode(order[(idx + (e.shiftKey ? order.length - 1 : 1)) % order.length]);
        setActiveIndex(0);
        return;
      }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const len =
          mode === 'files'
            ? fileResults.length
            : mode === 'tabs'
              ? tabResults.length
              : mode === 'symbols'
                ? symbolResults.length
                : commandResults.length;
        if (len === 0) return;
        setActiveIndex(i => {
          const delta = e.key === 'ArrowDown' ? 1 : -1;
          const next = (i + delta + len) % len;
          // ensure scroll into view
          const container = listRef.current;
          if (!container) return next;
          const item = container.querySelector(`[data-idx="${next}"]`) as HTMLElement | null;
          item?.scrollIntoView({ block: 'nearest' });
          return next;
        });
      }
      if (e.key === 'Enter') {
        e.preventDefault();
        const runPick = (fn: (() => void) | null) => {
          if (fn) fn();
        };
        if (mode === 'files') {
          const f = fileResults[activeIndex];
          if (!f) return;
          touch(f.id);
          const t = tabs.find(t => t.fileId === f.id);
          runPick(() => {
            t ? setActiveTab(t.id) : openTab(f);
            onClose();
          });
        } else if (mode === 'tabs') {
          const t = tabResults[activeIndex];
          if (!t) return;
          touch(t.id);
          runPick(() => {
            setActiveTab(t.id);
            onClose();
          });
        } else if (mode === 'symbols') {
          const s = symbolResults[activeIndex];
          if (!s) return;
          touch(`sym:${s.tabId}:${s.symbol}`);
          runPick(() => {
            setActiveTab(s.tabId);
            // reveal after next tick to ensure tab mounted
            setTimeout(() => {
              window.dispatchEvent(
                new CustomEvent('synapse.editor.reveal', {
                  detail: { tabId: s.tabId, line: s.line, column: 1 },
                })
              );
            }, 50);
            onClose();
          });
        } else {
          const c = commandResults[activeIndex];
          if (!c) return;
          touch(`cmd:${c.id}`);
          runPick(() => {
            c.run();
            onClose();
          });
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [
    isOpen,
    mode,
    activeIndex,
    fileResults,
    tabResults,
    symbolResults,
    commandResults,
    onClose,
    openTab,
    setActiveTab,
    tabs,
    touch,
  ]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Command Palette" size="lg">
      <div>
        {/* Mode chips */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
          {(
            [
              { key: 'files', label: 'Files' },
              { key: 'tabs', label: 'Tabs' },
              { key: 'symbols', label: 'Symbols' },
              { key: 'commands', label: 'Commands' },
            ] as Array<{ key: Mode; label: string }>
          ).map(m => (
            <button
              key={m.key}
              onClick={() => setMode(m.key)}
              style={{
                padding: '4px 8px',
                borderRadius: 6,
                border: `1px solid ${mode === m.key ? withAlpha(SYNAPSE_COLORS.goldPrimary, 0.5) : SYNAPSE_COLORS.border}`,
                background:
                  mode === m.key ? withAlpha(SYNAPSE_COLORS.goldPrimary, 0.12) : 'transparent',
                color: mode === m.key ? SYNAPSE_COLORS.textAccent : SYNAPSE_COLORS.textSecondary,
                fontSize: 12,
              }}
            >
              {m.label}
            </button>
          ))}
        </div>

        <input
          autoFocus
          placeholder={placeholder}
          value={q}
          onChange={e => setQ(e.target.value)}
          style={{
            width: '100%',
            padding: '10px 12px',
            borderRadius: 10,
            border: `1px solid ${SYNAPSE_COLORS.border}`,
            background: withAlpha('#fff', 0.04),
            color: SYNAPSE_COLORS.textPrimary,
            fontFamily: SYNAPSE_TYPO.fontFamily,
          }}
        />

        {/* Hints */}
        <div
          style={{
            display: 'flex',
            gap: 12,
            color: SYNAPSE_COLORS.textSecondary,
            fontSize: 11,
            marginTop: 6,
          }}
        >
          <span>Tip: &gt; Commands, @ Symbols, # Tabs</span>
        </div>

        <div
          ref={listRef}
          style={{ marginTop: 10, display: 'grid', gap: 6, maxHeight: '60vh', overflow: 'auto' }}
        >
          {mode === 'files' &&
            fileResults.map((f, i) => (
              <button
                key={f.id}
                data-idx={i}
                aria-selected={activeIndex === i}
                onClick={() => {
                  // open or focus
                  const t = tabs.find(t => t.fileId === f.id);
                  touch(f.id);
                  if (t) setActiveTab(t.id);
                  else openTab(f);
                  onClose();
                }}
                style={{
                  textAlign: 'left',
                  padding: '10px 12px',
                  borderRadius: 8,
                  border: `1px solid ${withAlpha('#fff', 0.08)}`,
                  background:
                    activeIndex === i ? withAlpha(SYNAPSE_COLORS.goldPrimary, 0.1) : 'transparent',
                  color: SYNAPSE_COLORS.textPrimary,
                  display: 'grid',
                  gap: 4,
                }}
              >
                <span style={{ fontWeight: 600 }}>{highlight(f.name, qStripped)}</span>
                <small style={{ color: SYNAPSE_COLORS.textSecondary }}>
                  {highlight(f.path, qStripped)}
                </small>
              </button>
            ))}

          {mode === 'tabs' &&
            tabResults.map((t, i) => (
              <button
                key={t.id}
                data-idx={i}
                aria-selected={activeIndex === i}
                onClick={() => {
                  touch(t.id);
                  setActiveTab(t.id);
                  onClose();
                }}
                style={{
                  textAlign: 'left',
                  padding: '10px 12px',
                  borderRadius: 8,
                  border: `1px solid ${withAlpha('#fff', 0.08)}`,
                  background:
                    activeIndex === i ? withAlpha(SYNAPSE_COLORS.goldPrimary, 0.1) : 'transparent',
                  color: SYNAPSE_COLORS.textPrimary,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <span>{highlight(t.name, qStripped)}</span>
                {t.isDirty ? <small style={{ color: SYNAPSE_COLORS.textSecondary }}>• unsaved</small> : null}
              </button>
            ))}

          {mode === 'symbols' &&
            symbolResults.map((s, i) => (
              <button
                key={`${s.tabId}-${i}`}
                data-idx={i}
                aria-selected={activeIndex === i}
                onClick={() => {
                  touch(`sym:${s.tabId}:${s.symbol}`);
                  setActiveTab(s.tabId);
                  setTimeout(() => {
                    window.dispatchEvent(
                      new CustomEvent('synapse.editor.reveal', {
                        detail: { tabId: s.tabId, line: s.line, column: 1 },
                      })
                    );
                  }, 50);
                  onClose();
                }}
                style={{
                  textAlign: 'left',
                  padding: '10px 12px',
                  borderRadius: 8,
                  border: `1px solid ${withAlpha('#fff', 0.08)}`,
                  background:
                    activeIndex === i ? withAlpha(SYNAPSE_COLORS.goldPrimary, 0.1) : 'transparent',
                  color: SYNAPSE_COLORS.textPrimary,
                  display: 'grid',
                  gap: 4,
                }}
              >
                <span style={{ fontWeight: 600 }}>{highlight(s.symbol, qStripped)}</span>
                <small style={{ color: SYNAPSE_COLORS.textSecondary }}>
                  {s.kind} — {s.tabName} (Ln {s.line})
                </small>
              </button>
            ))}

          {mode === 'commands' &&
            commandResults.map((cmd, i) => (
              <button
                key={cmd.id}
                data-idx={i}
                aria-selected={activeIndex === i}
                onClick={() => {
                  touch(`cmd:${cmd.id}`);
                  cmd.run();
                  onClose();
                }}
                style={{
                  textAlign: 'left',
                  padding: '10px 12px',
                  borderRadius: 8,
                  border: `1px solid ${withAlpha('#fff', 0.08)}`,
                  background:
                    activeIndex === i ? withAlpha(SYNAPSE_COLORS.goldPrimary, 0.1) : 'transparent',
                  color: SYNAPSE_COLORS.textPrimary,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <span>{highlight(cmd.label, qStripped)}</span>
                {cmd.shortcut ? <small style={{ color: SYNAPSE_COLORS.textSecondary }}>{cmd.shortcut}</small> : null}
              </button>
            ))}

          {(mode === 'files' && fileResults.length === 0) ||
          (mode === 'tabs' && tabResults.length === 0) ||
          (mode === 'symbols' && symbolResults.length === 0) ||
          (mode === 'commands' && commandResults.length === 0) ? (
            <div style={{ color: SYNAPSE_COLORS.textSecondary, fontSize: 12 }}>No results</div>
          ) : null}
        </div>
      </div>
    </Modal>
  );
};

export default CommandPalette;
