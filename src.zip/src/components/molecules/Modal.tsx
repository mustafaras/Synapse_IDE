import type { FC, ReactNode } from 'react';
import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import styled, { css, keyframes } from 'styled-components';
import { X } from 'lucide-react';
import { Button } from '@/components/atoms';
import { useKeyPress, useOnClickOutside } from '@/hooks';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  closeOnOverlayClick?: boolean;
  closeOnEscape?: boolean;
  showCloseButton?: boolean;
  preventBodyScroll?: boolean;
  className?: string;
}

const fadeIn = keyframes`
  from { opacity: 0; }
  to { opacity: 1; }
`;

const slideUp = keyframes`
  from { 
    opacity: 0;
    transform: translateY(20px) scale(0.95);
  }
  to { 
    opacity: 1;
    transform: translateY(0) scale(1);
  }
`;

const Overlay = styled.div<{ isOpen: boolean }>`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: var(--glass-background);
  backdrop-filter: var(--glass-backdrop);
  z-index: var(--z-modal);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--spacing-md);

  animation: ${fadeIn} var(--duration-medium) var(--easing-ease-out);

  ${props =>
    !props.isOpen &&
    css`
      display: none;
    `}
`;

const ModalContainer = styled.div<{ size: string }>`
  background: var(--color-surface);
  border: 1px solid var(--glass-border);
  border-radius: var(--border-radius-lg);
  box-shadow: var(--shadow-glass-xl);
  backdrop-filter: var(--glass-backdrop);
  max-height: 90vh;
  overflow-y: auto;
  animation: ${slideUp} var(--duration-medium) var(--easing-ease-out);

  ${props => {
    switch (props.size) {
      case 'sm':
        return css`
          width: 100%;
          max-width: 400px;
        `;
      case 'md':
        return css`
          width: 100%;
          max-width: 600px;
        `;
      case 'lg':
        return css`
          width: 100%;
          max-width: 800px;
        `;
      case 'xl':
        return css`
          width: 100%;
          max-width: 1200px;
        `;
      case 'full':
        return css`
          width: 100%;
          height: 100%;
          max-width: none;
          max-height: none;
          border-radius: 0;
        `;
      default:
        return css`
          width: 100%;
          max-width: 600px;
        `;
    }
  }}
`;

const ModalHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--spacing-lg);
  border-bottom: 1px solid var(--color-border);
`;

const ModalTitle = styled.h2`
  margin: 0;
  font-size: var(--font-size-lg);
  font-weight: var(--font-weight-semibold);
  color: var(--color-text);
`;

const ModalContent = styled.div`
  padding: var(--spacing-lg);
`;

export const Modal: FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  size = 'md',
  closeOnOverlayClick = true,
  closeOnEscape = true,
  showCloseButton = true,
  preventBodyScroll = true,
  className,
}) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const escapePressed = useKeyPress('Escape');
  // Handle click outside
  useOnClickOutside(modalRef as React.RefObject<HTMLElement>, () => {
    if (closeOnOverlayClick) {
      onClose();
    }
  });

  // Handle escape key
  useEffect(() => {
    if (escapePressed && closeOnEscape && isOpen) {
      onClose();
    }
  }, [escapePressed, closeOnEscape, isOpen, onClose]);

  // Handle body scroll
  useEffect(() => {
    if (preventBodyScroll && isOpen) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = 'unset';
      };
    }
    return undefined;
  }, [preventBodyScroll, isOpen]);

  // Focus management
  useEffect(() => {
    if (isOpen && modalRef.current) {
      const focusableElements = modalRef.current.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      const firstElement = focusableElements[0] as HTMLElement;
      if (firstElement) {
        firstElement.focus();
      }
    }
  }, [isOpen]);

  if (!isOpen) {
    return null;
  }

  const modalContent = (
    <Overlay isOpen={isOpen}>
      <ModalContainer
        ref={modalRef}
        size={size}
        className={className}
        role="dialog"
        aria-modal="true"
        aria-labelledby={title ? 'modal-title' : undefined}
      >
        {(title || showCloseButton) ? <ModalHeader>
            {title ? <ModalTitle id="modal-title">{title}</ModalTitle> : null}
            {showCloseButton ? <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                icon={<X size={16} />}
                aria-label="Close modal"
              /> : null}
          </ModalHeader> : null}

        <ModalContent>{children}</ModalContent>
      </ModalContainer>
    </Overlay>
  );

  return createPortal(modalContent, document.body);
};

export default Modal;
