# Status Bar Wiring (non-breaking)

Quick one-liners for other teams to publish real-time data to the local status
bus. Import from the StatusBar folder and call these anywhere appropriate. All
are safe and non-breaking.

## Monaco Editor (inside your existing editor setup)

```ts
import { mergeEmit, emit } from '../StatusBar/statusBus';

// Cursor position
editor.onDidChangeCursorPosition(({ position }) =>
  emit({ cursor: { line: position.lineNumber, column: position.column } })
);

// Content-derived counts
editor.onDidChangeModelContent(() => {
  const model = editor.getModel();
  const content = model?.getValue() || '';
  emit({
    counts: {
      lines: model?.getLineCount() || 0,
      words: (content.match(/\S+/g) || []).length,
      chars: content.length,
    },
  });
});

// Indentation and tab size
editor.onDidChangeModelOptions(() => {
  const opts = editor.getOptions ? editor.getOptions() : null;
  emit({
    tabSize: opts?.get(2),
    indentation: opts?.get(4) ? 'tabs' : 'spaces',
  } as any);
});

// Diagnostics (if you keep a linter elsewhere), publish aggregates:
// mergeEmit('diagnostics', { errors, warnings, infos });
```

## File Explorer (when active/renamed/moved)

```ts
import { emit } from '../StatusBar/statusBus';

emit({ filePath, fileName, ext, dirty });
```

## Git service (after fetch/status)

```ts
import { mergeEmit } from '../StatusBar/statusBus';

mergeEmit('git', { branch, ahead, behind, changed, stashed });
```

## Live server

```ts
import { mergeEmit } from '../StatusBar/statusBus';

mergeEmit('liveServer', { on: true, port: 3000 });
```

Notes:

- Use `emit({ ... })` for whole-snapshot updates; use
  `mergeEmit('key', partial)` to update a nested group.
- The Status Bar prefers bus values but gracefully falls back to props, so these
  calls won’t break existing flows.
