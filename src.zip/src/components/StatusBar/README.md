# SynapseIDE Status Bar (gold-dominant, fully wired)

Self-contained Status Bar module with a tiny local bus, theme tokens, and a
bridge for one-liner integration.

- Palette: see `statusTheme.ts` (soft gold on golden-black; no hard-coded hex in
  the bar).
- Bus: `statusBus.ts` exposes `emit`, `mergeEmit`, `subscribe`, and
  `useStatus()`.
- Types: `statusTypes.ts` defines `StatusSnapshot`.
- Bridge: `statusBridge.ts` provides small helper functions for other modules.
- Component: `StatusBar.tsx` prefers bus values over props; props remain safe
  fallbacks.

## Quick start (rendering)

```tsx
import StatusBar from '@/components/StatusBar/StatusBar';

// Render once (commonly in IDE view)
<StatusBar
  language="javascript"
  content="// initial content"
  cursorPosition={{ line: 1, column: 1 }}
  encoding="UTF-8"
  lineEnding="LF"
  tabSize={2}
  indentation="spaces"
  errors={0}
  warnings={0}
  isLiveServer={false}
  gitBranch="main"
  isModified={false}
/>;
```

## Publish real data (use the Bridge)

Import helpers from `statusBridge.ts` and call them anywhere (Editor, Explorer,
Git, Live Server, AI, etc.).

```ts
import {
  setCursor,
  setContentCounts,
  setIndentation,
  setDiagnostics,
  setFileInfo,
  setGitStatus,
  setLiveServer,
  setLanguage,
  setEncoding,
  setEol,
  setOnline,
  setSystem,
  ai,
} from '@/components/StatusBar/statusBridge';

// Editor
setCursor({ line: 12, column: 7 });
setContentCounts(model.getValue()); // lines/words/chars/size auto-derived
setIndentation('spaces', 2);
setDiagnostics(1, 3, 0);
setLanguage('typescript');
setEncoding('UTF-8');
setEol('LF');

// Explorer
setFileInfo({
  filePath: '/src/app.tsx',
  fileName: 'app.tsx',
  ext: 'tsx',
  dirty: true,
});

// Git
setGitStatus({
  branch: 'feature/x',
  ahead: 1,
  behind: 0,
  changed: 3,
  stashed: 0,
});

// Live server
setLiveServer(true, 3000);

// System
setOnline(navigator.onLine);
setSystem({ cpu: 23, mem: 48 });

// AI
ai.start('Explain selection', 'ai:explain-selection');
// ...later, when finished
ai.responded(1234); // or ai.error();
```

Notes

- `emit({ ... })` replaces fields; `mergeEmit('key', partial)` merges nested
  groups. The Bridge chooses the right one for you.
- Bus values override props automatically; existing props keep behavior for
  non-publishing flows.
- Accessibility: chips are keyboardable with tooltips; reduced motion honored.
