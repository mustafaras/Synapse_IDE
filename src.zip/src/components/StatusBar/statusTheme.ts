export const SB_COLORS = {
  // Dominant palette tuned for a solid soft-gold status bar
  bgPrimary: '#C2A76E', // soft gold base
  bgSecondary: '#B7985F', // slightly deeper gold if ever needed
  bgOverlay: 'rgba(0,0,0,0.04)',
  textPrimary: '#14120B', // deep near-black for strong contrast on gold
  textSecondary: '#2E2B22', // muted dark for secondary text
  textAccent: '#14120B', // keep accents dark on gold
  goldSoft: '#C2A76E',
  goldMuted: '#A58B5F',
  grayBlue: '#6B7280', // toned down to harmonize with warm palette
  borderSoft: 'rgba(0,0,0,0.35)', // dark border on gold
  success: '#2E7D32',
  warning: '#B58900',
  error: '#B00020',
  softShadow: 'rgba(0,0,0,0.18)',
  borderHighlight: 'rgba(0,0,0,0.5)',
  glowSubtle: '0 0 0 rgba(0,0,0,0)',
} as const;

export const sbFont = 'JetBrains Mono, Fira Code, SF Mono, Consolas, monospace';
export const alpha = (hex: string, a: number) => {
  if (!hex || !hex.startsWith('#')) return hex;
  const h = hex.replace('#', '');
  const to255 = (str: string) => parseInt(str, 16);
  let r = 0,
    g = 0,
    b = 0;
  if (h.length === 3) {
    r = to255(h[0] + h[0]);
    g = to255(h[1] + h[1]);
    b = to255(h[2] + h[2]);
  } else if (h.length === 6) {
    r = to255(h.substring(0, 2));
    g = to255(h.substring(2, 4));
    b = to255(h.substring(4, 6));
  }
  const alphaClamped = Math.max(0, Math.min(1, a));
  return `rgba(${r}, ${g}, ${b}, ${alphaClamped})`;
};
