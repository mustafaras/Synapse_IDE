export type StatusSnapshot = {
  // File/Editor
  filePath?: string;
  fileName?: string;
  ext?: string;
  formatLabel?: string;
  language?: string;
  eol?: 'LF' | 'CRLF';
  encoding?: string;
  tabSize?: number;
  indentation?: 'spaces' | 'tabs';
  cursor?: { line: number; column: number };
  selection?: { chars: number; lines: number };
  counts?: { lines: number; words: number; chars: number; sizeBytes?: number };
  diagnostics?: { errors: number; warnings: number; infos: number };
  dirty?: boolean;
  // Git
  git?: { branch?: string; ahead?: number; behind?: number; changed?: number; stashed?: number };
  // Runtime / Preview
  liveServer?: { on: boolean; port?: number };
  // System
  online?: boolean;
  cpu?: number;
  mem?: number;
  // AI assistant
  ai?: {
    state: 'idle' | 'thinking' | 'responded' | 'error';
    lastAction?: string;
    latencyMs?: number;
  };
  // Timestamps
  now?: number;
};
