import React, { useEffect, useRef } from 'react';
import { Check, Copy, Rocket } from 'lucide-react';
import type { TerminalCommand } from '../types/shellTypes';

interface TerminalOutputProps {
  commands: TerminalCommand[];
  className?: string;
  autoScroll?: boolean;
}

export const TerminalOutput: React.FC<TerminalOutputProps> = ({
  commands,
  className = '',
  autoScroll = true,
}) => {
  const outputRef = useRef<HTMLDivElement>(null);
  const [copiedIndex, setCopiedIndex] = React.useState<number | null>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (autoScroll && outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [commands, autoScroll]);

  const handleCopy = async (text: string, index: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    } catch (error) {
      console.error('Failed to copy text:', error);
    }
  };

  const formatTimestamp = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const renderCommandLine = (cmd: TerminalCommand, index: number) => {
    const commandText = `${cmd.command}${cmd.args.length > 0 ? ` ${  cmd.args.join(' ')}` : ''}`;

    return (
      <div key={index} style={{ marginBottom: '12px' }}>
        {/* Command Input Line */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            marginBottom: '4px',
            fontFamily: 'JetBrains Mono, Fira Code, Consolas, Monaco, monospace',
            fontSize: '13px',
          }}
        >
          {/* Timestamp */}
          <span
            style={{
              color: '#A0A0A0', // textSecondary
              fontSize: '11px',
              minWidth: '60px',
              opacity: 0.7,
            }}
          >
            {formatTimestamp(cmd.timestamp)}
          </span>

          {/* Command */}
          <span
            style={{
              color: '#C2A76E', // textAccent
              fontWeight: '600',
            }}
          >
            $
          </span>

          <span
            style={{
              color: '#E0E0E0', // textPrimary
              flex: 1,
            }}
          >
            {commandText}
          </span>

          {/* Copy Button */}
          <button
            onClick={() => handleCopy(commandText, index)}
            style={{
              background: 'transparent',
              border: 'none',
              color: copiedIndex === index ? '#2ECC71' : '#A0A0A0', // success or textSecondary
              cursor: 'pointer',
              padding: '2px',
              borderRadius: '4px',
              display: 'flex',
              alignItems: 'center',
              opacity: 0.6,
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={e => {
              e.currentTarget.style.opacity = '1';
              e.currentTarget.style.background = 'rgba(194, 167, 110, 0.1)'; // hover bg using goldSoft
            }}
            onMouseLeave={e => {
              e.currentTarget.style.opacity = '0.6';
              e.currentTarget.style.background = 'transparent';
            }}
            title="Copy command"
          >
            {copiedIndex === index ? <Check size={12} /> : <Copy size={12} />}
          </button>
        </div>

        {/* Command Output */}
        {cmd.output ? <div
            style={{
              color: '#E0E0E0', // textPrimary
              fontFamily: 'JetBrains Mono, Fira Code, Consolas, Monaco, monospace',
              fontSize: '12px',
              lineHeight: '1.4',
              marginLeft: '76px', // Align with command text
              marginBottom: '8px',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
            }}
          >
            {cmd.output}
          </div> : null}

        {/* Command Error */}
        {cmd.error ? <div
            style={{
              color: '#E74C3C', // error
              fontFamily: 'JetBrains Mono, Fira Code, Consolas, Monaco, monospace',
              fontSize: '12px',
              lineHeight: '1.4',
              marginLeft: '76px',
              marginBottom: '8px',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
              background: 'rgba(255, 255, 255, 0.04)', // bgOverlay
              padding: '8px',
              borderRadius: '4px',
              border: '1px solid #FFFFFF10', // borderSoft
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                marginBottom: '4px',
                fontSize: '11px',
                fontWeight: '600',
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
              }}
            >
              ⚠️ Error
              {cmd.exitCode !== undefined && (
                <span style={{ opacity: 0.7 }}>(Exit Code: {cmd.exitCode})</span>
              )}
            </div>
            {cmd.error}
          </div> : null}

        {/* Success indicator for exit code 0 */}
        {cmd.exitCode === 0 && !cmd.error && cmd.output ? <div
            style={{
              marginLeft: '76px',
              fontSize: '11px',
              color: '#2ECC71', // success
              opacity: 0.7,
              fontStyle: 'italic',
            }}
          >
            ✓ Command completed successfully
          </div> : null}
      </div>
    );
  };

  return (
    <div
      ref={outputRef}
      className={className}
      style={{
        flex: 1,
        overflowY: 'auto',
        padding: '16px',
        fontFamily: 'JetBrains Mono, Fira Code, Consolas, Monaco, monospace',
        fontSize: '13px',
        lineHeight: '1.4',
        background: '#121212', // bgPrimary
        // Custom scrollbar
        scrollbarWidth: 'thin',
        scrollbarColor: '#C2A76E transparent', // goldSoft fallback for Firefox
      }}
    >
      {commands.length === 0 ? (
        <div
          style={{
            color: '#A0A0A0', // textSecondary
            fontStyle: 'italic',
            textAlign: 'center',
            padding: '0px 20px', // Padding'i sıfırla
            fontSize: '13px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center', // Dikey ortalama
            alignItems: 'center', // Yatay ortalama
            height: '100%', // Tam yükseklik kullan
            minHeight: '100px', // Minimum yükseklik (120px → 100px)
            maxHeight: 'calc(100vh - 150px)', // Maksimum yükseklik sınırı
          }}
        >
          <div
            style={{
              fontSize: '18px', // 20px → 18px (daha küçük)
              marginBottom: '6px', // 8px → 6px
              opacity: 0.6,
              color: '#C2A76E', // goldSoft
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <Rocket size={18} /> {/* 20 → 18 */}
          </div>
          <div
            style={{
              marginBottom: '4px', // 6px → 4px
              lineHeight: '1.3', // Satır yüksekliği ayarı
            }}
          >
            Terminal ready. Type a command to get started.
          </div>
          <div
            style={{
              fontSize: '10px', // 11px → 10px
              marginTop: '2px', // 4px → 2px
              opacity: 0.8,
              lineHeight: '1.2', // Satır yüksekliği
            }}
          >
            Try: <span style={{ color: '#C2A76E' }}>help</span>,{' '}
            <span style={{ color: '#C2A76E' }}>ls</span>, or{' '}
            <span style={{ color: '#C2A76E' }}>dir</span>
          </div>
        </div>
      ) : (
        commands.map((cmd, index) => renderCommandLine(cmd, index))
      )}

      {/* Scroll indicator */}
      <div style={{ height: '1px' }} />
    </div>
  );
};
