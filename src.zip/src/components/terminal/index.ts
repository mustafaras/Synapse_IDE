export { Terminal } from './components/Terminal';
export { TerminalInput } from './components/TerminalInput';
export { TerminalOutput } from './components/TerminalOutput';
export { useTerminalHistory } from './hooks/useTerminalHistory';
export type { ShellType, TerminalCommand, ShellConfig } from './types/shellTypes';
