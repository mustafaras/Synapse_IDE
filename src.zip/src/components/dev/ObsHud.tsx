import React from 'react';
import { useObs } from '@/utils/obs/store';
import { SYNAPSE_ELEVATION, SYNAPSE_LAYOUT } from '@/ui/theme/synapseTheme';

export const ObsHud: React.FC = () => {
  const traces = useObs((s) => s.traces);
  if (process.env.NODE_ENV !== 'development') return null;
  return (
    <div
      style={{
        position: 'fixed',
        right: 12,
        top: 12,
        width: 380,
        maxHeight: '70vh',
        overflow: 'auto',
        background: SYNAPSE_ELEVATION.surface,
        border: `1px solid ${SYNAPSE_ELEVATION.border}`,
        borderRadius: SYNAPSE_LAYOUT.radiusMd,
        padding: SYNAPSE_LAYOUT.padMd,
        zIndex: 9999,
      }}
    >
      <strong>Observability (DEV)</strong>
      {traces.map((t) => (
        <div key={t.id} style={{ marginTop: 8, paddingTop: 8, borderTop: `1px dashed ${SYNAPSE_ELEVATION.border}` }}>
          <div>
            {t.provider} · {t.model} · {t.mode} · {t.status}
          </div>
          <div>
            req: {t.requestId.slice(0, 8)}… · {t.usage ? `${t.usage.prompt}/${t.usage.completion} tok` : '—'} {t.cost ? `· $${t.cost.total}` : ''}
          </div>
          {t.error && typeof t.error.code === 'string' ? (
            <div style={{ color: 'tomato' }}>
              {`${t.error.code}`}{typeof t.error.status === 'number' ? ` (${t.error.status})` : ''}
            </div>
          ) : null}
          {t.spans.slice(0, 4).map((sp) => (
            <div key={sp.id} style={{ opacity: 0.8, fontSize: 12 }}>
              • {sp.type} {sp.end ? `${Math.round((sp.end - sp.start))}ms` : '(running)'}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

export default ObsHud;
