import React from 'react';
import styled, { css } from 'styled-components';
import { SYNAPSE_ACCENT, SYNAPSE_ANIM, SYNAPSE_COLORS, SYNAPSE_ELEVATION, SYNAPSE_FOCUS, SYNAPSE_LAYOUT, withAlpha } from '@/ui/theme/synapseTheme';

interface CardProps {
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  variant?: 'default' | 'elevated' | 'outlined' | 'glass' | 'premium';
  size?: 'small' | 'medium' | 'large' | 'golden';
  hover?: 'none' | 'lift' | 'scale' | 'glow' | 'premium';
  padding?: 'none' | 'small' | 'medium' | 'large' | 'md' | 'lg' | 'modular';
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
  loading?: boolean;
  interactive?: boolean;
  icon?: React.ReactNode;
  actions?: React.ReactNode;
  footer?: React.ReactNode;
  image?: string;
  imageAlt?: string;
  style?: React.CSSProperties;
}

const CardVariants = {
  default: css`
    background: ${SYNAPSE_ELEVATION.surface};
    backdrop-filter: blur(8px);
    border: 1px solid ${SYNAPSE_ELEVATION.border};
    box-shadow:
      ${SYNAPSE_ELEVATION.shadowSm},
      inset 0 1px 0 ${withAlpha('#FFFFFF', 0.08)};
  `,
  elevated: css`
    background: ${SYNAPSE_ELEVATION.surface};
    backdrop-filter: blur(8px);
    border: 1px solid ${SYNAPSE_ELEVATION.border};
    box-shadow:
      ${SYNAPSE_ELEVATION.shadowMd},
      inset 0 1px 0 ${withAlpha('#FFFFFF', 0.10)};
  `,
  outlined: css`
    background: transparent;
    border: 2px solid ${SYNAPSE_ELEVATION.border};
    box-shadow: none;
    backdrop-filter: none;
  `,
  glass: css`
    background: ${SYNAPSE_ELEVATION.surface};
    backdrop-filter: blur(8px);
    border: 1px solid ${SYNAPSE_ELEVATION.border};
    box-shadow:
      ${SYNAPSE_ELEVATION.shadowSm},
      inset 0 1px 0 ${withAlpha('#FFFFFF', 0.10)};
  `,
  premium: css`
    background: ${SYNAPSE_ELEVATION.surface};
    backdrop-filter: blur(8px);
    border: 1px solid ${SYNAPSE_ELEVATION.border};
    box-shadow:
      ${SYNAPSE_ELEVATION.shadowMd},
      0 0 20px ${withAlpha(SYNAPSE_ACCENT.gold, 0.33)},
      inset 0 1px 0 ${withAlpha('#FFFFFF', 0.10)};

    /* Premium border enhancement */
    position: relative;

    &::before {
      content: '';
      position: absolute;
      inset: -1px;
      padding: 1px;
      background: linear-gradient(135deg, ${withAlpha(SYNAPSE_ACCENT.gold, 0.6)}, transparent, ${withAlpha(
        SYNAPSE_ACCENT.gold,
        0.4
      )});
      border-radius: inherit;
      mask:
        linear-gradient(#fff 0 0) content-box,
        linear-gradient(#fff 0 0);
      mask-composite: xor;
      -webkit-mask-composite: xor;
    }
  `,
};

const CardSizes = {
  small: css`
  padding: ${SYNAPSE_LAYOUT.padSm};
  border-radius: ${SYNAPSE_LAYOUT.radiusSm};
  `,
  medium: css`
  padding: ${SYNAPSE_LAYOUT.padMd};
  border-radius: ${SYNAPSE_LAYOUT.radiusMd};
  `,
  large: css`
  padding: ${SYNAPSE_LAYOUT.padLg};
  border-radius: ${SYNAPSE_LAYOUT.radiusLg};
  `,
  golden: css`
  padding: calc(${SYNAPSE_LAYOUT.padMd} * 1.618);
  border-radius: ${SYNAPSE_LAYOUT.radiusLg};
  `,
  md: css`
  padding: ${SYNAPSE_LAYOUT.padMd};
  border-radius: ${SYNAPSE_LAYOUT.radiusMd};
  `,
  lg: css`
  padding: ${SYNAPSE_LAYOUT.padLg};
  border-radius: ${SYNAPSE_LAYOUT.radiusLg};
  `,
  modular: css`
  padding: calc(${SYNAPSE_LAYOUT.padMd} * 1.272);
  border-radius: ${SYNAPSE_LAYOUT.radiusMd};
  `,
};

const CardHoverEffects = {
  none: css``,
  lift: css`
    transition: all ${SYNAPSE_ANIM.base};
    &:hover {
      transform: translateY(-4px);
      box-shadow: ${SYNAPSE_ELEVATION.shadowMd}, 0 0 30px ${withAlpha(SYNAPSE_ACCENT.gold, 0.4)};
    }
  `,
  scale: css`
    transition: all ${SYNAPSE_ANIM.base};
    &:hover {
      transform: scale(1.02);
      box-shadow: ${SYNAPSE_ELEVATION.shadowMd}, 0 0 30px ${withAlpha(SYNAPSE_ACCENT.gold, 0.4)};
    }
  `,
  glow: css`
    transition: all ${SYNAPSE_ANIM.base};
    &:hover {
      box-shadow: ${SYNAPSE_ELEVATION.shadowMd}, 0 0 30px ${withAlpha(SYNAPSE_ACCENT.gold, 0.6)},
        inset 0 1px 0 ${withAlpha('#FFFFFF', 0.2)};
      border-color: ${SYNAPSE_ACCENT.gold};
      background: ${SYNAPSE_ELEVATION.surfaceHover};
    }
  `,
  premium: css`
    transition: all ${SYNAPSE_ANIM.base};
    &:hover {
      transform: translateY(-2px) scale(1.01);
      box-shadow: ${SYNAPSE_ELEVATION.shadowLg}, 0 0 40px ${withAlpha(SYNAPSE_ACCENT.gold, 0.7)},
        inset 0 1px 0 ${withAlpha('#FFFFFF', 0.25)};
      border-color: ${SYNAPSE_ACCENT.gold};
      background: ${SYNAPSE_ELEVATION.surfaceHover};
    }
  `,
};

const StyledCard = styled.div<{
  variant: CardProps['variant'];
  size: CardProps['size'];
  hover: CardProps['hover'];
  interactive: boolean;
  disabled: boolean;
}>`
  position: relative;
  overflow: hidden;
  transition: all ${SYNAPSE_ANIM.base};
  cursor: ${({ interactive, disabled }) =>
    disabled ? 'not-allowed' : interactive ? 'pointer' : 'default'};

  /* Theme-based opacity adjustments */
  opacity: var(--card-opacity, 1);

  ${({ variant = 'default' }) => CardVariants[variant]}
  ${({ size = 'medium' }) => CardSizes[size]}
  ${({ hover = 'none', disabled }) => !disabled && CardHoverEffects[hover]}

  ${({ disabled }) =>
    disabled &&
    css`
      opacity: 0.4;
      pointer-events: none;
      filter: grayscale(0.5);
    `}

  &:focus-visible {
    outline: none;
    box-shadow:
      0 0 0 ${SYNAPSE_FOCUS.width} ${withAlpha(SYNAPSE_FOCUS.ring, 1)},
      0 0 0 calc(${SYNAPSE_FOCUS.width} * 2) ${withAlpha(SYNAPSE_FOCUS.ringOffset, 0.9)};
    border-radius: ${SYNAPSE_FOCUS.radius};
  }

  /* Enhanced glassmorphism effect on hover */
  &:hover:not([disabled]) {
    backdrop-filter: blur(8px);
    border-color: ${SYNAPSE_ELEVATION.borderStrong};
    animation: cardGlow ${SYNAPSE_ANIM.fast.replace(' cubic-bezier(.2,.8,.2,1)', '')} ease-out;
  }

  /* Keyframes for glow animation */
  @keyframes cardGlow {
    0% { box-shadow: ${SYNAPSE_ELEVATION.shadowSm}; }
    50% {
      box-shadow: ${SYNAPSE_ELEVATION.shadowMd}, 0 0 25px ${withAlpha(SYNAPSE_ACCENT.gold, 0.5)};
    }
    100% {
      box-shadow: ${SYNAPSE_ELEVATION.shadowMd}, 0 0 20px ${withAlpha(SYNAPSE_ACCENT.gold, 0.4)};
    }
  }
`;

const CardHeader = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: ${SYNAPSE_LAYOUT.gapMd};
`;

const CardTitleSection = styled.div`
  display: flex;
  align-items: center;
  gap: ${SYNAPSE_LAYOUT.gapSm};
  flex: 1;
`;

const CardTitle = styled.h3`
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: ${SYNAPSE_COLORS.textPrimary};
  line-height: 1.2;
`;

const CardSubtitle = styled.p`
  margin: ${SYNAPSE_LAYOUT.gapSm} 0 0 0;
  font-size: 12px;
  color: ${SYNAPSE_COLORS.textSecondary};
  line-height: 1.4;
`;

const CardContent = styled.div`
  color: ${SYNAPSE_COLORS.textPrimary};
  line-height: 1.6;

  /* Ensure proper spacing between content and actions */
  &:not(:last-child) {
    margin-bottom: ${SYNAPSE_LAYOUT.gapMd};
  }
`;

const CardActions = styled.div`
  display: flex;
  align-items: center;
  gap: ${SYNAPSE_LAYOUT.gapSm};
  margin-top: ${SYNAPSE_LAYOUT.gapMd};
  justify-content: flex-end;

  /* Ensure proper spacing from content */
  &:not(:first-child) {
    border-top: 1px solid ${SYNAPSE_ELEVATION.border};
    padding-top: ${SYNAPSE_LAYOUT.padSm};
  }
`;

const CardFooter = styled.div`
  margin-top: ${SYNAPSE_LAYOUT.gapMd};
  padding-top: ${SYNAPSE_LAYOUT.padSm};
  border-top: 1px solid ${SYNAPSE_ELEVATION.border};
  color: ${SYNAPSE_COLORS.textSecondary};
  font-size: 12px;
`;

const CardImage = styled.img`
  width: 100%;
  height: 200px;
  object-fit: cover;
  border-radius: ${SYNAPSE_LAYOUT.radiusSm};
  margin-bottom: ${SYNAPSE_LAYOUT.padSm};
`;

const LoadingSpinner = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 24px;
  height: 24px;
  border: 2px solid transparent;
  border-top: 2px solid ${SYNAPSE_ACCENT.gold};
  border-radius: 50%;
  animation: spin 1s linear infinite;
  z-index: 10;

  @keyframes spin {
    to {
      transform: translate(-50%, -50%) rotate(360deg);
    }
  }
`;

export const Card: React.FC<CardProps> = ({
  title,
  subtitle,
  children,
  variant = 'default',
  size = 'medium',
  hover = 'none',
  padding,
  className,
  onClick,
  disabled = false,
  loading = false,
  interactive = false,
  icon,
  actions,
  footer,
  image,
  imageAlt,
  style,
  ...props
}) => {
  // Override size if padding is explicitly set
  const finalSize = padding ? (padding as CardProps['size']) : size;

  return (
    <StyledCard
      variant={variant}
      size={finalSize}
      hover={hover}
      interactive={interactive || !!onClick}
      disabled={disabled}
      className={className}
      onClick={disabled ? undefined : onClick}
      style={style}
      tabIndex={interactive || onClick ? 0 : undefined}
      role={onClick ? 'button' : undefined}
      {...props}
    >
      {loading ? <LoadingSpinner /> : null}

      {image ? <CardImage src={image} alt={imageAlt || 'Card image'} /> : null}

      {(title || subtitle || icon || actions) ? <CardHeader>
          <CardTitleSection>
            {icon ? <span>{icon}</span> : null}
            <div>
              {title ? <CardTitle>{title}</CardTitle> : null}
              {subtitle ? <CardSubtitle>{subtitle}</CardSubtitle> : null}
            </div>
          </CardTitleSection>
          {actions ? <CardActions>{actions}</CardActions> : null}
        </CardHeader> : null}

      <CardContent>{children}</CardContent>

      {/* Separate actions section if no header actions */}
      {actions && !title && !subtitle && !icon ? <CardActions>{actions}</CardActions> : null}

      {footer ? <CardFooter>{footer}</CardFooter> : null}
    </StyledCard>
  );
};
