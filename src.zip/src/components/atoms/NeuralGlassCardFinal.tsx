import React, { useEffect, useState } from 'react';
import styled, { css, keyframes } from 'styled-components';
import { motion } from 'framer-motion';
import { useTheme } from '../../contexts/ThemeContext';

// Theme-specific glitch keyframes
const glitchLight = keyframes`
  0%, 100% {
    transform: translate(0);
    border-color: rgba(59, 130, 246, 0.2);
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.1), 0 0 20px rgba(59, 130, 246, 0.05);
  }
  10% {
    transform: translate(-1px, 0.5px);
    border-color: rgba(59, 130, 246, 0.4);
  }
  20% {
    transform: translate(-0.5px, -0.5px);
    border-color: rgba(96, 165, 250, 0.3);
  }
  30% {
    transform: translate(0.5px, 1px);
    border-color: rgba(139, 92, 246, 0.3);
  }
  40% {
    transform: translate(1px, -0.5px);
    border-color: rgba(59, 130, 246, 0.3);
  }
  50% {
    transform: translate(-0.5px, 0.5px);
    border-color: rgba(96, 165, 250, 0.4);
  }
  60% {
    transform: translate(0.5px, 0.5px);
    border-color: rgba(59, 130, 246, 0.3);
  }
  70% {
    transform: translate(-1px, 0.5px);
    border-color: rgba(139, 92, 246, 0.3);
  }
  80% {
    transform: translate(1px, -1px);
    border-color: rgba(59, 130, 246, 0.4);
  }
  90% {
    transform: translate(0.5px, -0.5px);
    border-color: rgba(96, 165, 250, 0.3);
  }
`;

const glitchDark = keyframes`
  0%, 100% {
    transform: translate(0);
    border-color: rgba(99, 102, 241, 0.2);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3), 0 0 20px rgba(99, 102, 241, 0.1);
  }
  10% {
    transform: translate(-1px, 0.5px);
    border-color: rgba(99, 102, 241, 0.4);
  }
  20% {
    transform: translate(-0.5px, -0.5px);
    border-color: rgba(139, 92, 246, 0.3);
  }
  30% {
    transform: translate(0.5px, 1px);
    border-color: rgba(168, 85, 247, 0.3);
  }
  40% {
    transform: translate(1px, -0.5px);
    border-color: rgba(99, 102, 241, 0.3);
  }
  50% {
    transform: translate(-0.5px, 0.5px);
    border-color: rgba(139, 92, 246, 0.4);
  }
  60% {
    transform: translate(0.5px, 0.5px);
    border-color: rgba(99, 102, 241, 0.3);
  }
  70% {
    transform: translate(-1px, 0.5px);
    border-color: rgba(168, 85, 247, 0.3);
  }
  80% {
    transform: translate(1px, -1px);
    border-color: rgba(99, 102, 241, 0.4);
  }
  90% {
    transform: translate(0.5px, -0.5px);
    border-color: rgba(139, 92, 246, 0.3);
  }
`;

const glitchNeutral = keyframes`
  0%, 100% {
    transform: translate(0);
    border-color: rgba(251, 191, 36, 0.2);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15), 0 0 20px rgba(251, 191, 36, 0.1);
  }
  10% {
    transform: translate(-1px, 0.5px);
    border-color: rgba(251, 191, 36, 0.4);
  }
  20% {
    transform: translate(-0.5px, -0.5px);
    border-color: rgba(245, 158, 11, 0.3);
  }
  30% {
    transform: translate(0.5px, 1px);
    border-color: rgba(249, 115, 22, 0.3);
  }
  40% {
    transform: translate(1px, -0.5px);
    border-color: rgba(251, 191, 36, 0.3);
  }
  50% {
    transform: translate(-0.5px, 0.5px);
    border-color: rgba(245, 158, 11, 0.4);
  }
  60% {
    transform: translate(0.5px, 0.5px);
    border-color: rgba(251, 191, 36, 0.3);
  }
  70% {
    transform: translate(-1px, 0.5px);
    border-color: rgba(249, 115, 22, 0.3);
  }
  80% {
    transform: translate(1px, -1px);
    border-color: rgba(251, 191, 36, 0.4);
  }
  90% {
    transform: translate(0.5px, -0.5px);
    border-color: rgba(245, 158, 11, 0.3);
  }
`;

// Simple text component with fade-in animation
interface SimpleTextProps {
  children: string;
  delay?: number;
}

const FadeText = styled(motion.span)`
  display: inline-block;
  font-family:
    'Fira Code', 'JetBrains Mono', 'Monaco', 'Cascadia Code', 'Roboto Mono', 'Source Code Pro',
    Consolas, 'Courier New', monospace;
`;

const SimpleText: React.FC<SimpleTextProps> = ({ children, delay = 0 }) => {
  return (
    <FadeText
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{
        duration: 0.6,
        delay: delay / 1000, // Convert ms to seconds
        ease: 'easeOut',
      }}
    >
      {children}
    </FadeText>
  );
};

interface NeuralGlassCardProps {
  title: string;
  description: string;
  onClick?: () => void;
  className?: string;
  cardIndex?: number; // Kart değişiminde glitch için
}

// Theme-aware style function with colors matching each theme's primary/accent
const getThemeStyles = (theme: string) => {
  switch (theme) {
    case 'light':
      return {
        iconColor: '#3B82F6', // Blue primary color from light theme
        iconBackground: 'rgba(59, 130, 246, 0.15)',
        titleColor: '#3B82F6', // Same blue for title
        descriptionColor: '#334155', // Dark gray for excellent readability
      };
    case 'dark':
      return {
        iconColor: '#6366f1', // Indigo primary color from dark theme
        iconBackground: 'rgba(99, 102, 241, 0.2)',
        titleColor: '#6366f1', // Same indigo for title
        descriptionColor: '#CBD5E1', // Light gray for good contrast
      };
    case 'neutral':
      return {
        iconColor: '#FBBF24', // Amber primary color from neutral theme
        iconBackground: 'rgba(251, 191, 36, 0.2)',
        titleColor: '#FBBF24', // Same amber/yellow for title
        descriptionColor: '#F8FAFC', // Very light gray, almost white for readability
      };
    default:
      return {
        iconColor: '#3B82F6', // Default to light theme blue
        iconBackground: 'rgba(59, 130, 246, 0.15)',
        titleColor: '#3B82F6', // Same blue for title
        descriptionColor: '#334155',
      };
  }
};

// Styled CardContainer with glassmorphic design and glitch effects (NO HOVER)
const CardContainer = styled(motion.div)<{ $themeName: string; $isGlitching: boolean }>`
  position: relative;
  /* Glassmorphic background - tema sensitive */
  background: ${({ $themeName }) => {
    switch ($themeName) {
      case 'light':
        return 'rgba(255, 255, 255, 0.1)';
      case 'dark':
        return 'rgba(0, 0, 0, 0.2)';
      case 'neutral':
        return 'rgba(248, 250, 252, 0.15)';
      default:
        return 'rgba(255, 255, 255, 0.1)';
    }
  }};

  /* Glassmorphic blur ve border */
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-radius: 20px;
  border: 2.5px solid
    ${({ $themeName }) => {
      switch ($themeName) {
        case 'light':
          return 'rgba(59, 130, 246, 0.45)';
        case 'dark':
          return 'rgba(99, 102, 241, 0.55)';
        case 'neutral':
          return 'rgba(251, 191, 36, 0.55)';
        default:
          return 'rgba(59, 130, 246, 0.45)';
      }
    }};

  /* Stronger glassmorphic shadow - tema sensitive */
  box-shadow: ${({ $themeName }) => {
    switch ($themeName) {
      case 'light':
        return '0 8px 32px 0 rgba(31, 38, 135, 0.18), 0 0 32px 4px rgba(59, 130, 246, 0.18), 0 0 0 4px rgba(59,130,246,0.10)';
      case 'dark':
        return '0 8px 32px 0 rgba(0, 0, 0, 0.45), 0 0 32px 4px rgba(99, 102, 241, 0.22), 0 0 0 4px rgba(99,102,241,0.13)';
      case 'neutral':
        return '0 8px 32px 0 rgba(0, 0, 0, 0.22), 0 0 32px 4px rgba(251, 191, 36, 0.18), 0 0 0 4px rgba(251,191,36,0.10)';
      default:
        return '0 8px 32px 0 rgba(31, 38, 135, 0.18), 0 0 32px 4px rgba(59, 130, 246, 0.18)';
    }
  }};

  /* Double border/glow using pseudo-element */
  &::before {
    content: '';
    position: absolute;
    inset: -5px;
    border-radius: 24px;
    pointer-events: none;
    z-index: 2;
    border: 2.5px solid transparent;
    box-shadow: ${({ $themeName }) => {
      switch ($themeName) {
        case 'light':
          return '0 0 12px 6px rgba(59,130,246,0.12), 0 0 0 2px rgba(59,130,246,0.18)';
        case 'dark':
          return '0 0 12px 6px rgba(99,102,241,0.12), 0 0 0 2px rgba(99,102,241,0.18)';
        case 'neutral':
          return '0 0 12px 6px rgba(251,191,36,0.12), 0 0 0 2px rgba(251,191,36,0.13)';
        default:
          return '0 0 12px 6px rgba(59,130,246,0.12)';
      }
    }};
    background: ${({ $themeName }) => {
      switch ($themeName) {
        case 'light':
          return 'linear-gradient(120deg, rgba(59,130,246,0.12) 0%, rgba(255,255,255,0.08) 100%)';
        case 'dark':
          return 'linear-gradient(120deg, rgba(99,102,241,0.18) 0%, rgba(0,0,0,0.10) 100%)';
        case 'neutral':
          return 'linear-gradient(120deg, rgba(251,191,36,0.13) 0%, rgba(255,255,255,0.08) 100%)';
        default:
          return 'linear-gradient(120deg, rgba(59,130,246,0.12) 0%, rgba(255,255,255,0.08) 100%)';
      }
    }};
    opacity: 0.95;
    transition:
      box-shadow 0.4s,
      background 0.4s;
  }

  /* Layout constraints */
  display: flex;
  flex-direction: column;
  gap: 1rem;
  min-width: 0;
  max-width: 990px;
  width: 100%;
  min-height: 110px;
  padding: 1rem;
  margin: 2rem 0 2rem 2rem;
  align-self: flex-start;

  /* Interactive states */
  cursor: pointer;

  /* Coder font for all text */
  font-family:
    'Fira Code', 'JetBrains Mono', 'Monaco', 'Cascadia Code', 'Roboto Mono', 'Source Code Pro',
    Consolas, 'Courier New', monospace;

  /* Scroll snap */
  scroll-snap-align: start;
  flex-shrink: 0;

  /* Glitch animasyonu - tema sensitive */
  ${({ $isGlitching, $themeName }) =>
    $isGlitching &&
    css`
      animation: ${$themeName === 'light'
          ? glitchLight
          : $themeName === 'dark'
            ? glitchDark
            : $themeName === 'neutral'
              ? glitchNeutral
              : glitchLight}
        0.5s ease-in-out;
    `}

  /* Smooth transitions */
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  /* HİÇBİR HOVER EFEKTİ YOK */
  &:hover {
    /* Hiçbir değişiklik yok */
  }

  &:active {
    /* Hiçbir değişiklik yok */
  }

  &:focus,
  &:focus-visible,
  &:focus-within {
    outline: none;
  }

  /* Kart değişim animasyonlarını kaldır (sadece tema glitch aktif) */
  /* Framer Motion animasyonlarını kaldırmak için CardContainer kullanımında initial, animate, exit ve transition prop'larını kaldırmalısın. */

  /* Responsive paddings for mobile - updated widths */
  @media (max-width: 768px) {
    min-width: 0;
    max-width: 95vw;
    width: 100%;
    padding: 0.75rem;
    min-height: 110px;
    margin: 1rem 0 1rem 1rem;
    align-self: flex-start;
  }

  @media (max-width: 640px) {
    min-width: 0;
    max-width: 98vw;
    width: 100%;
    padding: 0.5rem;
    min-height: 100px;
    margin: 0.5rem 0 0.5rem 0.5rem;
    align-self: flex-start;
  }

  @media (max-width: 480px) {
    min-width: 0;
    max-width: 99vw;
    width: 100%;
    padding: 0.4rem;
    min-height: 90px;
    margin: 0.25rem 0 0.25rem 0.25rem;
    align-self: flex-start;
  }

  @media (max-width: 360px) {
    min-width: 0;
    max-width: 100vw;
    width: 100%;
    padding: 0.3rem;
    min-height: 80px;
    margin: 0.1rem 0 0.1rem 0.1rem;
    align-self: flex-start;
  }
`;

const Title = styled.h3<{ $themeName: string; $isGlitching?: boolean }>`
  /* Coder font for title */
  font-family:
    'Fira Code', 'JetBrains Mono', 'Monaco', 'Cascadia Code', 'Roboto Mono', 'Source Code Pro',
    Consolas, 'Courier New', monospace;
  font-size: 1.125rem;
  font-weight: 600;
  line-height: 1.4;
  color: ${({ $themeName }) => getThemeStyles($themeName).titleColor};
  margin: 0;

  /* REMOVE ALL BORDERS AND OUTLINES */
  border: none !important;
  outline: none !important;

  /* Text alignment - left aligned */
  text-align: left;
  word-wrap: break-word;
  overflow-wrap: break-word;

  /* Ensure text doesn't overflow */
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;

  transition: color 0.3s ease;
  ${({ $isGlitching, $themeName }) =>
    $isGlitching &&
    css`
      animation: ${$themeName === 'light'
          ? glitchLight
          : $themeName === 'dark'
            ? glitchDark
            : $themeName === 'neutral'
              ? glitchNeutral
              : glitchLight}
        0.5s ease-in-out;
    `}
`;

const Description = styled.p<{ $themeName: string; $isGlitching?: boolean }>`
  /* Coder font for description */
  font-family:
    'Fira Code', 'JetBrains Mono', 'Monaco', 'Cascadia Code', 'Roboto Mono', 'Source Code Pro',
    Consolas, 'Courier New', monospace;
  font-size: 0.875rem;
  font-weight: 400;
  line-height: 1.5;
  color: ${({ $themeName }) => getThemeStyles($themeName).descriptionColor};
  margin: 0;
  flex-grow: 1;

  /* REMOVE ALL BORDERS AND OUTLINES */
  border: none !important;
  outline: none !important;

  /* Text alignment - justified with hyphenation */
  text-align: justify;
  word-wrap: break-word;
  overflow-wrap: break-word;
  hyphens: auto;
  -webkit-hyphens: auto;
  -moz-hyphens: auto;
  -ms-hyphens: auto;

  /* Ensure text doesn't overflow */
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 5; /* increased from 3 to show more text */
  -webkit-box-orient: vertical;

  transition: color 0.3s ease;
  ${({ $isGlitching, $themeName }) =>
    $isGlitching &&
    css`
      animation: ${$themeName === 'light'
          ? glitchLight
          : $themeName === 'dark'
            ? glitchDark
            : $themeName === 'neutral'
              ? glitchNeutral
              : glitchLight}
        0.5s ease-in-out;
    `}
`;

const NeuralGlassCard: React.FC<NeuralGlassCardProps> = ({
  title,
  description,
  onClick,
  className,
  cardIndex,
}) => {
  const { themeName } = useTheme();
  const [isGlitching, setIsGlitching] = useState(false);

  // Tema veya kart değişiminde glitch efekti
  useEffect(() => {
    setIsGlitching(true);
    const timeout = setTimeout(() => setIsGlitching(false), 300);
    return () => clearTimeout(timeout);
  }, [themeName, cardIndex]);

  return (
    <CardContainer
      $themeName={themeName}
      $isGlitching={isGlitching}
      onClick={onClick}
      className={`neural-glass-card-final ${className || ''}`}
      data-component="neural-glass-card-final"
    >
      <div>
        <Title $themeName={themeName} $isGlitching={isGlitching}>
          <SimpleText delay={50}>{title}</SimpleText>
        </Title>
        <Description $themeName={themeName} $isGlitching={isGlitching}>
          <SimpleText delay={100}>{description}</SimpleText>
        </Description>
      </div>
    </CardContainer>
  );
};

export default NeuralGlassCard;
