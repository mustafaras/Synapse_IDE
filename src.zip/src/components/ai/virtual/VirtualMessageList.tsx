/* eslint-disable */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { VLIST_MEASURE_DEBOUNCE_MS, VLIST_OVERSCAN_PX, rafThrottle } from '@/components/ai/AiAssistantConfig';

type RowMeasure = { height: number, top: number, bottom: number };

function useRowMeasure(onSizeChange: () => void) {
  const map = useRef<Map<string | number, RowMeasure>>(new Map()).current;
  const observers = useRef<Map<string | number, ResizeObserver>>(new Map()).current;
  const nodes = useRef<Map<string | number, HTMLElement>>(new Map()).current;
  const set = (id: string | number, el: HTMLElement | null) => {
    const prevNode = nodes.get(id);
    const prevObs = observers.get(id);
    if (!el || (prevNode && prevNode !== el)) {
      if (prevObs) {
        try { prevObs.disconnect(); } catch {}
        observers.delete(id);
      }
      if (!el) nodes.delete(id);
    }
    if (!el) return;
    let ro = observers.get(id);
    if (!ro) {
      ro = new ResizeObserver(() => {
        const rect = el.getBoundingClientRect();
        const height = (el as any).offsetHeight || rect.height || 0;
        const prev = map.get(id) || { height: 0, top: 0, bottom: 0 };
        if (prev.height !== height) {
          map.set(id, { ...prev, height });
          onSizeChange();
        }
      });
      observers.set(id, ro);
    }
    try { ro.observe(el); } catch {}
    nodes.set(id, el);
  };
  const cleanupAll = () => {
    observers.forEach(ro => { try { ro.disconnect(); } catch {} });
    observers.clear();
    nodes.clear();
  };
  return { measures: map, setRef: set, cleanupAll };
}

export interface VListProps<T> {
  items: readonly T[];
  keyOf: (x: T) => string | number;
  estimatedRowHeight?: number;
  overscanPx?: number;
  renderRow: (x: T, index: number) => React.ReactElement;
  containerRef?: React.RefObject<HTMLDivElement | null>;
  storageKey?: string; // for scroll restoration
}

export const VirtualizedMessageList = <T,>({
  items,
  keyOf,
  estimatedRowHeight = 120,
  overscanPx = VLIST_OVERSCAN_PX,
  renderRow,
  containerRef: externalContainerRef,
  storageKey,
}: VListProps<T>) => {
  const internalContainerRef = useRef<HTMLDivElement | null>(null);
  const containerRef: React.RefObject<HTMLDivElement | null> = (externalContainerRef as React.RefObject<HTMLDivElement | null>) ?? internalContainerRef;
  const spacerTopRef = useRef<HTMLDivElement | null>(null);
  const spacerBottomRef = useRef<HTMLDivElement | null>(null);
  const debouncedRecalcRef = useRef<number | null>(null);
  const scheduleRecalc = () => {
  if (debouncedRecalcRef.current) (window as any).cancelIdleCallback?.(debouncedRecalcRef.current as unknown as number);
  debouncedRecalcRef.current = ((window as any).requestIdleCallback?.(() => recalc()) as unknown as number) || (setTimeout(recalc, VLIST_MEASURE_DEBOUNCE_MS) as unknown as number);
  };

  const { measures, setRef, cleanupAll } = useRowMeasure(scheduleRecalc);
  const atBottomRef = useRef(true);
  const [showJump, setShowJump] = useState(false);
  const prevBottomRef = useRef<boolean>(true);
  const [range, setRange] = useState({ start: 0, end: Math.min(items.length, 20) });
  const [totalHeight, setTotalHeight] = useState(estimatedRowHeight * items.length);

  const recalc = useMemo(
    () => rafThrottle(() => {
      const view = containerRef.current;
      if (!view) return;
      let y = 0;
      const tops: number[] = new Array(items.length);
      const bottoms: number[] = new Array(items.length);
      for (let i = 0; i < items.length; i++) {
        const id = keyOf(items[i]);
        const h = measures.get(id)?.height ?? estimatedRowHeight;
        tops[i] = y;
        y += h;
        bottoms[i] = y;
      }
      setTotalHeight(y);

      const scrollTop = view.scrollTop;
      const viewH = view.clientHeight;
      const minY = Math.max(0, scrollTop - overscanPx);
      const maxY = Math.min(y, scrollTop + viewH + overscanPx);

  const tolerance = 24;
      const isBottom = (y - (scrollTop + viewH)) <= tolerance;
      atBottomRef.current = isBottom;
      if (prevBottomRef.current !== isBottom) {
        prevBottomRef.current = isBottom;
        setShowJump(!isBottom);
      }

      let s = 0, e = items.length;
      while (s < e) { const m = (s + e) >> 1; if (bottoms[m] < minY) s = m + 1; else e = m; }
      const start = s;
      s = start; e = items.length;
      while (s < e) { const m = (s + e) >> 1; if (tops[m] <= maxY) s = m + 1; else e = m; }
      const end = Math.min(items.length, s);

      setRange({ start, end });

      if (spacerTopRef.current) spacerTopRef.current.style.height = `${tops[start] || 0}px`;
      if (spacerBottomRef.current) spacerBottomRef.current.style.height = `${y - (bottoms[end - 1] || 0)}px`;

      if (atBottomRef.current) {
        requestAnimationFrame(() => {
          const v = containerRef.current;
          if (v) v.scrollTop = v.scrollHeight;
        });
      }
    }),
  [items.length, measures, overscanPx, estimatedRowHeight, keyOf, containerRef]
  );

  useEffect(() => {
    const view = containerRef.current;
    if (!view) return;
    const onScroll = recalc;
    const save = rafThrottle(() => {
      if (!storageKey) return;
      try { sessionStorage.setItem(storageKey, String(view.scrollTop)); } catch {}
    });
    const onScrollPersist = () => { save(); };
  view.addEventListener('scroll', onScroll as EventListener, { passive: true } as AddEventListenerOptions);
  view.addEventListener('scroll', onScrollPersist as EventListener, { passive: true } as AddEventListenerOptions);
  window.addEventListener('resize', onScroll as EventListener);
    recalc();
    try {
      if (storageKey) {
        const saved = sessionStorage.getItem(storageKey);
        if (saved && !Number.isNaN(Number(saved))) {
          view.scrollTop = Number(saved);
          recalc();
        }
      }
    } catch {}
    function cleanup(): void {
      if (view) {
        view.removeEventListener('scroll', onScroll as EventListener);
        view.removeEventListener('scroll', onScrollPersist as EventListener);
      }
      window.removeEventListener('resize', onScroll as EventListener);
    }
    return cleanup;
  }, [recalc, storageKey, containerRef]);

  useEffect(() => () => {
    cleanupAll();
    if (debouncedRecalcRef.current) (window as any).cancelIdleCallback?.(debouncedRecalcRef.current as unknown as number);
  }, [cleanupAll]);

  useEffect(() => { scheduleRecalc(); }, [items.length, scheduleRecalc]);

  useEffect(() => {
    if (!containerRef.current) return;
    if (!atBottomRef.current) return;
    requestAnimationFrame(() => {
      const v = containerRef.current;
      if (v) v.scrollTop = v.scrollHeight;
    });
  }, [items.length, containerRef]);

  const rows: React.ReactElement[] = [];
  for (let i = range.start; i < range.end; i++) {
    const item = items[i];
    const key = keyOf(item);
    const row = renderRow(item, i);
    rows.push(
  <div key={String(key)} ref={(el: HTMLDivElement | null) => { setRef(key, el as unknown as HTMLElement | null); }}>
        {row}
      </div>
    );
  }

  if (externalContainerRef) {
    return (
      <>
        <div ref={spacerTopRef} style={{ height: 0 }} />
        {rows}
        <div ref={spacerBottomRef} style={{ height: Math.max(0, totalHeight - (measures.size ? 0 : items.length * estimatedRowHeight)) }} />
        {!atBottomRef.current && showJump && (
          <div style={{ position: 'sticky', bottom: 12, display: 'flex', justifyContent: 'flex-end', pointerEvents: 'none' }}>
            <button
              onClick={() => {
                const v = containerRef.current;
                if (v) v.scrollTop = v.scrollHeight;
              }}
              style={{
                pointerEvents: 'auto',
                padding: '6px 10px',
                borderRadius: 8,
                background: 'rgba(0,0,0,0.6)',
                border: '1px solid #FFFFFF25',
                color: '#C2A76E',
                fontSize: 11,
                cursor: 'pointer',
                marginRight: 8,
              }}
              title="Jump to latest"
            >
              Jump to latest
            </button>
          </div>
        )}
      </>
    );
  }

  // Fallback: own container if none provided
  return (
    <div ref={containerRef} style={{ overflow: 'auto', height: '100%' }}>
      <div ref={spacerTopRef} style={{ height: 0 }} />
      {rows}
      <div ref={spacerBottomRef} style={{ height: Math.max(0, totalHeight - (measures.size ? 0 : items.length * estimatedRowHeight)) }} />
    </div>
  );
};

export default VirtualizedMessageList;
