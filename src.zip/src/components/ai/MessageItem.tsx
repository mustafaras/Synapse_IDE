import React from 'react';

export const MessageItem = React.memo(({
  index,
  msg,
}: {
  index: number;
  msg: { id: string; role: 'user'|'assistant'|'system'; content: string; ts: number };
}) => {
  return (
    <article aria-label={`${msg.role === 'assistant' ? 'Assistant' : msg.role === 'user' ? 'User' : 'System'} message #${index + 1}`}>
      <div data-role={msg.role}>{msg.content}</div>
    </article>
  );
}, (prev, next) => (
  prev.msg.id === next.msg.id &&
  prev.msg.content === next.msg.content &&
  prev.msg.role === next.msg.role
));

export default MessageItem;