import React from 'react';
import { Modal } from '@/components/molecules/Modal';
import * as Theme from '@/ui/theme/synapseTheme';
import type { AttachmentMeta } from '@/features/attachments/types';

type Props = {
  open: boolean;
  item: AttachmentMeta | undefined;
  onClose: () => void;
};

const labelStyle: React.CSSProperties = {
  fontSize: 12,
  color: Theme.SYNAPSE_COLORS.textTertiary,
};

const valueStyle: React.CSSProperties = {
  fontSize: 12,
  color: Theme.SYNAPSE_COLORS.textSecondary,
};

const boxStyle: React.CSSProperties = {
  border: `1px solid ${Theme.SYNAPSE_COLORS.borderSubtle}`,
  borderRadius: 8,
  padding: 12,
  background: Theme.SYNAPSE_ELEVATION.surface,
};

export const AttachmentPreview: React.FC<Props> = ({ open, item, onClose }) => {
  const title = item ? `Preview • ${item.name}` : 'Preview';

  return (
    <Modal isOpen={open} onClose={onClose} title={title} size="xl" closeOnOverlayClick closeOnEscape>
      {!item ? (
        <div style={valueStyle}>Attachment not available.</div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 12 }}>
          {/* Meta */}
          <div style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
            <div><span style={labelStyle}>Type:</span> <span style={valueStyle}>{item.kind.toUpperCase()} ({item.mime})</span></div>
            <div><span style={labelStyle}>Size:</span> <span style={valueStyle}>{(item.size/1024).toFixed(1)} KB</span></div>
            <div><span style={labelStyle}>Added:</span> <span style={valueStyle}>{new Date(item.createdAt).toLocaleString()}</span></div>
          </div>

          {/* Preview body */}
          <div style={boxStyle}>
            {(() => {
              switch (item.kind) {
                case 'image':
                  if (item.previewUrl) {
                    return (
                      <img
                        src={item.previewUrl}
                        alt={item.name}
                        style={{ maxWidth: '100%', maxHeight: '70vh', display: 'block', margin: '0 auto', borderRadius: 6 }}
                      />
                    );
                  }
                  return <div style={valueStyle}>No image preview available.</div>;
                case 'pdf':
                  if (item.previewUrl) {
                    return (
                      <iframe
                        title={`PDF ${item.name}`}
                        src={item.previewUrl}
                        style={{ width: '100%', height: '70vh', border: 'none', borderRadius: 6, background: '#fff' }}
                      />
                    );
                  }
                  return <div style={valueStyle}>No PDF preview available.</div>;
                case 'text':
                case 'code':
                case 'json':
                case 'csv':
                  return (
                    <pre
                      aria-label="Text preview"
                      style={{
                        margin: 0,
                        maxHeight: '70vh',
                        overflow: 'auto',
                        background: Theme.SYNAPSE_ELEVATION.surface,
                        color: Theme.SYNAPSE_COLORS.textPrimary,
                        borderRadius: 6,
                        padding: 12,
            fontFamily: Theme.SYNAPSE_TYPO.fontFamily,
                        fontSize: 12,
                        lineHeight: 1.5,
                      }}
                    >{item.textFull ?? item.textExcerpt ?? 'No text available.'}</pre>
                  );
                default:
                  return <div style={valueStyle}>No preview for this file type.</div>;
              }
            })()}
          </div>

          <div style={{ fontSize: 12, color: Theme.SYNAPSE_COLORS.textTertiary }}>
            Tip: Press Escape to close. Focus will return to the triggering control.
          </div>
        </div>
      )}
    </Modal>
  );
};

export default AttachmentPreview;
