/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
import React, { useCallback, useRef, useState } from 'react';
import { Eye, X } from 'lucide-react';
import * as Theme from '@/ui/theme/synapseTheme';
import { showToast } from '@/ui/toast/api';
import { useAttachStore } from '@/features/attachments/store';
import type { AttachmentMeta } from '@/features/attachments/types';
import { MAX_FILE_BYTES, readTextSafely, sanitizeName, sha256, sniffKind } from '@/features/attachments/ingest';
import './attachBar.css';
import AttachmentPreview from './AttachmentPreview';
import { uuid } from '@/utils/uuid';

const bytes = (n: number) => `${(n/1024).toFixed(1)} KB`;

export const AttachBar: React.FC = () => {
  const addMany = useAttachStore(s => s.addMany);
  const remove = useAttachStore(s => s.remove);
  const list = useAttachStore(s => s.list);
  const [isDragging, setDragging] = useState(false);
  const [previewId, setPreviewId] = useState<string | null>(null);
  const lastTriggerRef = useRef<HTMLElement | null>(null);

  const onFiles = useCallback(async (files: FileList | File[]) => {
    const batch: AttachmentMeta[] = [];
    const existingHashes = new Set(useAttachStore.getState().list.map(a => a.hash));
    for (const file of Array.from(files)) {
      try {
        if (file.size > MAX_FILE_BYTES) {
          showToast({ kind: 'warning', contextKey: 'attach:too-big', title: 'File too large', message: file.name });
          continue;
        }
  const id = uuid();
        const name = sanitizeName(file.name);
        const ext = name.includes('.') ? name.slice(name.lastIndexOf('.')) : '';
        const mime = file.type || 'application/octet-stream';
        const kind = sniffKind(name, mime);
        const hash = await sha256(file);
        if (existingHashes.has(hash)) {
          showToast({ kind: 'info', contextKey: 'attach:dup', title: 'Already attached', message: name });
          continue;
        }
        const meta: AttachmentMeta = {
          id, name, ext, mime, size: file.size, kind, hash,
          createdAt: Date.now(),
          previewUrl: kind === 'image' || kind === 'pdf' ? URL.createObjectURL(file) : undefined,
        };
        if (kind === 'text' || kind === 'code' || kind === 'json' || kind === 'csv') {
          meta.textFull = await readTextSafely(file);
          meta.textExcerpt = meta.textFull?.slice(0, 500);
        }
        batch.push(meta);
      } catch (err) {
        showToast({ kind: 'error', contextKey: 'attach:error', title: 'Attach failed', message: (err as Error)?.message || 'Unknown error' });
      }
    }
    if (batch.length) {
      addMany(batch);
      showToast({ kind: 'success', contextKey: 'attach:added', title: 'Files attached', message: `${batch.length} file(s)` });
    }
  }, [addMany]);

  const onDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; }, []);
  const onDragEnter = useCallback((e: React.DragEvent) => { e.preventDefault(); setDragging(true); }, []);
  const onDragLeave = useCallback((e: React.DragEvent) => { e.preventDefault(); setDragging(false); }, []);
  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); setDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length) {
      onFiles(e.dataTransfer.files);
    }
  }, [onFiles]);

  const removeItem = useCallback((id: string) => {
    const item = useAttachStore.getState().list.find(a => a.id === id);
    if (item?.previewUrl) URL.revokeObjectURL(item.previewUrl);
    remove(id);
    showToast({ kind: 'info', contextKey: 'attach:removed', title: 'Removed', message: item?.name || 'Attachment' });
  }, [remove]);

  const onRemoveClick = useCallback((e: React.MouseEvent<HTMLButtonElement>) => {
    const id = (e.currentTarget as HTMLButtonElement).dataset.id;
    if (id) removeItem(id);
  }, [removeItem]);

  const onPreviewClick = useCallback((e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    const id = (e.currentTarget as HTMLButtonElement).dataset.id;
    if (id) {
      lastTriggerRef.current = e.currentTarget as HTMLButtonElement;
      setPreviewId(id);
    }
  }, []);

  const openPreviewFromChip = useCallback((id: string, el: HTMLElement) => {
    lastTriggerRef.current = el;
    setPreviewId(id);
  }, []);

  const closePreview = useCallback(() => {
    setPreviewId(null);
    // restore focus to last trigger for a11y
    setTimeout(() => lastTriggerRef.current?.focus(), 0);
  }, []);

  const overlay = isDragging ? (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.25)', backdropFilter: 'blur(2px)', border: `2px dashed ${Theme.SYNAPSE_COLORS.goldPrimary}`, pointerEvents: 'none', zIndex: 9999 }} />
  ) : null;

  // no keyboard listeners on container to avoid nested interactive issues

  return (
    <div role="region" aria-label="Attachments dropzone" onDragOver={onDragOver} onDragEnter={onDragEnter} onDragLeave={onDragLeave} onDrop={onDrop} style={{ position: 'relative' }}>
      {overlay}
  <div style={{ display: 'flex', alignItems: 'center', gap: Theme.SYNAPSE_LAYOUT.gapSm }}>
        {/* Chips list (non-intrusive) */}
        <div className="attachbar-chips" style={{ display:'flex', flexWrap:'nowrap', gap: Theme.SYNAPSE_LAYOUT.gapSm }}>
          {list.map(item => (
            <div
              key={item.id}
              className="attachbar-chip"
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Delete' || e.key === 'Backspace') {
                  e.preventDefault();
                  removeItem(item.id);
                } else if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  openPreviewFromChip(item.id, e.currentTarget as HTMLElement);
                }
              }}
              title={`${item.name} • ${bytes(item.size)}`}
              style={{ display:'inline-flex', alignItems:'center', gap:6, padding:'6px 8px', border:`1px solid ${Theme.SYNAPSE_COLORS.borderSubtle}`, background:Theme.SYNAPSE_ELEVATION.surface, color:Theme.SYNAPSE_COLORS.textSecondary, borderRadius:8, boxShadow:Theme.elevate(0), fontFamily:Theme.SYNAPSE_TYPO.fontFamily, fontSize:12 }}
            >
              <span style={{ color: Theme.SYNAPSE_COLORS.textAccent }}>{item.kind}</span>
              <span style={{ maxWidth:200, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{item.name}</span>
              <button aria-label={`Preview ${item.name}`} title="Preview" data-id={item.id} onClick={onPreviewClick} style={{ background:'transparent', border:'none', color:Theme.SYNAPSE_COLORS.blueGray, cursor:'pointer' }}>
                <Eye size={14} />
              </button>
              <button aria-label={`Remove ${item.name}`} title="Remove" data-id={item.id} onClick={onRemoveClick} style={{ background:'transparent', border:'none', color:Theme.SYNAPSE_COLORS.textSecondary, cursor:'pointer' }}>
                <X size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Preview Modal */}
      <AttachmentPreview
        open={!!previewId}
        item={previewId ? list.find(x => x.id === previewId) : undefined}
        onClose={closePreview}
      />
    </div>
  );
};

export default AttachBar;
