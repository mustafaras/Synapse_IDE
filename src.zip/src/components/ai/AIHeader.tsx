import React, { useEffect, useRef, useState } from 'react';
import {
  Bot,
  Check,
  ChevronDown,
  Maximize2,
  Minimize2,
  Settings,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { type AiSettings, loadAiSettings, MODEL_OPTIONS, saveAiSettings, subscribeAiSettings } from './AiAssistantConfig';

interface AIHeaderProps {
  onClose?: () => void;
  onMinimize?: () => void;
  onToggleExpand?: () => void;
  onSettings?: () => void;
  isExpanded?: boolean;
  title?: string;
  className?: string;
  // Optional external change handlers for new controls
  onBeginnerModeChange?: (value: boolean) => void;
  onPresetSelect?: (presetKey: string) => void;
  beginnerMode?: boolean;
  activePreset?: string | null;
}

const AIHeader: React.FC<AIHeaderProps> = ({
  onClose,
  onMinimize,
  onToggleExpand,
  onSettings,
  isExpanded = false,
  title = 'AI Assistant',
  className,
  onBeginnerModeChange,
  onPresetSelect,
  beginnerMode,
  activePreset,
}) => {
  // Local persisted state (fallback if parent not controlling)
  const [internalBeginner, setInternalBeginner] = useState<boolean>(() => {
    try {
      return localStorage.getItem('synapse.ai.beginner') === 'true';
    } catch {
      return false;
    }
  });
  const [preset, setPreset] = useState<string | null>(() => {
    try {
      return localStorage.getItem('synapse.ai.lastPreset') || null;
    } catch {
      return null;
    }
  });
  const [showPresetMenu, setShowPresetMenu] = useState(false);
  // Popover state for AI Settings
  const [open, setOpen] = useState(false);
  const [settings, setSettings] = useState<AiSettings>(() => loadAiSettings());
  const popRef = useRef<HTMLDivElement | null>(null);
  const btnRef = useRef<HTMLButtonElement | null>(null);

  const effectiveBeginner = typeof beginnerMode === 'boolean' ? beginnerMode : internalBeginner;
  const effectivePreset = activePreset ?? preset;

  const toggleBeginner = () => {
    const next = !effectiveBeginner;
    if (onBeginnerModeChange) onBeginnerModeChange(next);
    else setInternalBeginner(next);
    try {
      localStorage.setItem('synapse.ai.beginner', String(next));
    } catch {}
  };

  const handleSelectPreset = (key: string) => {
    if (onPresetSelect) onPresetSelect(key);
    else setPreset(key);
    try {
      localStorage.setItem('synapse.ai.lastPreset', key);
    } catch {}
    setShowPresetMenu(false);
  };

  // Close preset menu on outside click
  useEffect(() => {
    if (!showPresetMenu) return;
    const handler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('[data-presets-dropdown]')) setShowPresetMenu(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [showPresetMenu]);

  // Sync settings via pub/sub with shallow guard to avoid redundant renders
  useEffect(() => {
    const isDev = (() => {
      try {
        const meta = (import.meta as unknown) as { env?: { DEV?: boolean } };
        if (typeof import.meta !== 'undefined' && meta.env?.DEV) return true;
      } catch {}
      try { if (typeof process !== 'undefined' && process.env && process.env.NODE_ENV === 'development') return true; } catch {}
      return false;
    })();
    let updates = 0;
    const handler = (s: AiSettings) => {
      setSettings(prev => {
        if (
          prev.mode === s.mode &&
          prev.modelId === s.modelId &&
          prev.defaultInsert === s.defaultInsert &&
          prev.autoPreview === s.autoPreview
        ) {
          return prev;
        }
        if (isDev) console.warn('[DEV][store] aiSettings update (AIHeader)', ++updates);
        return s;
      });
    };
    const unsub = subscribeAiSettings(handler);
    return () => {
      try {
        unsub();
      } catch {}
    };
  }, []);
  // Close popover on outside click
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      if (
        popRef.current &&
        !popRef.current.contains(t) &&
        btnRef.current &&
        !btnRef.current.contains(t)
      ) {
        setOpen(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      if (el && (el.tagName === 'TEXTAREA' || el?.closest?.('[data-chat-input]'))) return;
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    window.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const updateSettings = <K extends keyof AiSettings>(key: K, value: AiSettings[K]) => {
    const next = { ...settings, [key]: value } as AiSettings;
    setSettings(next);
    saveAiSettings(next);
  };

  return (
    <div
      className={className}
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        height: '60px', // Match EnhancedIDE header height
        padding: '0 var(--spacing-lg)', // horizontal padding only
        background: '#1A1A1A',
        border: '1px solid #FFFFFF10',
        borderTopLeftRadius: 'var(--radius-lg)',
        borderTopRightRadius: 'var(--radius-lg)',
        borderBottom: 'none',
        position: 'sticky',
        top: 0,
        zIndex: 10,
        backdropFilter: 'var(--assistant-blur)',
        WebkitBackdropFilter: 'var(--assistant-blur)',
        boxSizing: 'border-box',
      }}
    >
      {/* Soft gold top line (2px) */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '2px',
          background: 'linear-gradient(90deg,#C2A76E,#A58B5F,#C2A76E)',
          borderTopLeftRadius: 'var(--radius-lg)',
          borderTopRightRadius: 'var(--radius-lg)',
          pointerEvents: 'none',
          opacity: 0.95,
        }}
      />
      {/* Left side: AI Assistant title */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-sm)' }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '32px',
            height: '32px',
            borderRadius: 'var(--radius-md)',
            background: 'linear-gradient(135deg, #C2A76E, #A58B5F)',
            color: '#121212',
          }}
        >
          <Bot size={18} />
        </div>

        <h2
          style={{
            margin: 0,
            fontSize: '1rem',
            fontWeight: '600',
            color: '#E8E8E8',
            lineHeight: '1.2',
            /* Explicitly remove any shadows */
            textShadow: 'none',
            boxShadow: 'none',
            filter: 'none',
            fontFamily: '"JetBrains Mono", "Fira Code", "SF Mono", monospace',
          }}
        >
          {title}
        </h2>
      </div>

      {/* Right side: Beginner Mode + Presets + Action buttons */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        {/* Beginner Mode Toggle */}
        <button
          onClick={toggleBeginner}
          aria-pressed={effectiveBeginner}
          aria-label="Toggle Beginner Mode"
          title="Produce single-file, commented, beginner-friendly code."
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '6px 10px',
            fontSize: '11px',
            fontWeight: 600,
            cursor: 'pointer',
            borderRadius: '6px',
            border: '1px solid',
            borderColor: effectiveBeginner ? '#C2A76E66' : '#FFFFFF10',
            background: effectiveBeginner
              ? 'linear-gradient(135deg,#C2A76E33,#A58B5F22)'
              : 'rgba(26,26,26,0.4)',
            color: '#E8E8E8',
            transition: 'all .25s ease',
          }}
          onMouseEnter={e => {
            e.currentTarget.style.borderColor = '#C2A76E99';
            if (effectiveBeginner)
              e.currentTarget.style.background = 'linear-gradient(135deg,#C2A76E55,#A58B5F33)';
          }}
          onMouseLeave={e => {
            e.currentTarget.style.borderColor = effectiveBeginner ? '#C2A76E66' : '#FFFFFF10';
            e.currentTarget.style.background = effectiveBeginner
              ? 'linear-gradient(135deg,#C2A76E33,#A58B5F22)'
              : 'rgba(26,26,26,0.4)';
          }}
        >
          <span
            style={{
              display: 'inline-block',
              width: '14px',
              height: '14px',
              borderRadius: '50%',
              background: effectiveBeginner
                ? 'linear-gradient(135deg,#C2A76E,#A58B5F)'
                : 'transparent',
              boxShadow: effectiveBeginner ? '0 0 0 1px #C2A76EAA inset' : '0 0 0 1px #555 inset',
              transition: 'all .3s ease',
            }}
          />
          Beginner
        </button>

        {/* Presets Dropdown */}
        <div style={{ position: 'relative' }} data-presets-dropdown>
          <button
            onClick={() => setShowPresetMenu(v => !v)}
            aria-haspopup="listbox"
            aria-expanded={showPresetMenu}
            aria-label="Select Beginner Preset"
            disabled={!effectiveBeginner}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '6px 10px',
              fontSize: '11px',
              fontWeight: 600,
              cursor: effectiveBeginner ? 'pointer' : 'not-allowed',
              borderRadius: '6px',
              border: '1px solid #FFFFFF10',
              background: effectiveBeginner ? 'rgba(26,26,26,0.4)' : 'rgba(26,26,26,0.2)',
              color: '#E8E8E8',
              opacity: effectiveBeginner ? 1 : 0.45,
              transition: 'all .25s ease',
            }}
            title={
              effectiveBeginner
                ? 'Select a starter preset prompt'
                : 'Enable Beginner Mode to use presets'
            }
          >
            {effectivePreset
              ? effectivePreset.charAt(0).toUpperCase() + effectivePreset.slice(1)
              : 'Presets'}
            <ChevronDown size={14} />
          </button>
          {showPresetMenu ? <div
              role="listbox"
              style={{
                position: 'absolute',
                top: '110%',
                right: 0,
                minWidth: '160px',
                background: '#121212',
                border: '1px solid #FFFFFF10',
                borderRadius: '8px',
                boxShadow: '0 8px 24px rgba(0,0,0,0.5)',
                padding: '6px',
                zIndex: 20,
              }}
            >
              {['calculator', 'landing', 'portfolio', 'todo'].map(key => (
                <button
                  key={key}
                  role="option"
                  aria-selected={effectivePreset === key}
                  onClick={() => handleSelectPreset(key)}
                  style={{
                    width: '100%',
                    textAlign: 'left',
                    background:
                      effectivePreset === key
                        ? 'linear-gradient(135deg,#C2A76E22,#A58B5F22)'
                        : 'transparent',
                    border: 'none',
                    color: '#E8E8E8',
                    padding: '8px 10px',
                    borderRadius: '6px',
                    fontSize: '12px',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                  }}
                  onMouseEnter={e => {
                    if (effectivePreset !== key)
                      e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                  }}
                  onMouseLeave={e => {
                    if (effectivePreset !== key) e.currentTarget.style.background = 'transparent';
                  }}
                >
                  {effectivePreset === key && <Check size={14} color="#C2A76E" />}
                  <span style={{ flex: 1, textTransform: 'capitalize' }}>{key}</span>
                </button>
              ))}
            </div> : null}
        </div>

        {/* AI Settings Popover Trigger */}
        <div style={{ position: 'relative' }}>
          <button
            ref={btnRef}
            onClick={() => setOpen(v => !v)}
            aria-haspopup="dialog"
            aria-expanded={open}
            aria-label="AI Settings"
            title="AI Settings"
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '28px',
              height: '28px',
              border: 'none',
              borderRadius: 'var(--radius-sm)',
              background: 'transparent',
              color: '#AAB2BD',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={e => {
              e.currentTarget.style.background = 'rgba(255,255,255,0.04)';
              e.currentTarget.style.color = '#E8E8E8';
            }}
            onMouseLeave={e => {
              e.currentTarget.style.background = 'transparent';
              e.currentTarget.style.color = '#AAB2BD';
            }}
          >
            <SlidersHorizontal size={16} />
          </button>

          {open ? <div
              ref={popRef}
              role="dialog"
              aria-label="AI Settings"
              style={{
                position: 'absolute',
                top: '110%',
                right: 0,
                minWidth: 260,
                background: '#121212',
                border: '1px solid #FFFFFF10',
                borderRadius: 10,
                boxShadow: '0 12px 32px rgba(0,0,0,0.55)',
                padding: 10,
                zIndex: 20,
              }}
            >
              {/* Mode segmented */}
              <div style={{ display: 'grid', gap: 6, marginBottom: 10 }}>
                <label style={{ color: '#AAB2BD', fontSize: 11, fontWeight: 600 }}>Mode</label>
                <div style={{ display: 'flex', gap: 6 }} role="group" aria-label="AI Mode">
                  {(['beginner', 'pro'] as const).map(m => (
                    <button
                      key={m}
                      onClick={() => updateSettings('mode', m)}
                      aria-pressed={settings.mode === m}
                      style={{
                        flex: 1,
                        padding: '6px 8px',
                        borderRadius: 6,
                        border: `1px solid ${settings.mode === m ? '#C2A76E66' : '#FFFFFF10'}`,
                        background:
                          settings.mode === m
                            ? 'linear-gradient(135deg,#C2A76E33,#A58B5F22)'
                            : 'rgba(26,26,26,0.4)',
                        color: '#E8E8E8',
                        fontSize: 12,
                        fontWeight: 600,
                        cursor: 'pointer',
                      }}
                    >
                      {m === 'beginner' ? 'Beginner' : 'Pro'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Model dropdown */}
              <div style={{ display: 'grid', gap: 6, marginBottom: 10 }}>
                <label style={{ color: '#AAB2BD', fontSize: 11, fontWeight: 600 }}>Model</label>
                <select
                  aria-label="Model"
                  value={settings.modelId ?? ''}
                  onChange={e => updateSettings('modelId', e.target.value || null)}
                  style={{
                    width: '100%',
                    padding: '8px 10px',
                    borderRadius: 8,
                    border: '1px solid #FFFFFF10',
                    background: 'rgba(26,26,26,0.4)',
                    color: '#E8E8E8',
                    fontSize: 12,
                  }}
                >
                  <option value="">Default (per Assistant)</option>
                  {MODEL_OPTIONS.filter(m => !m.hidden && !m.deprecated).map(opt => (
                    <option key={opt.id} value={opt.id}>
                      {opt.id}
                    </option>
                  ))}
                </select>
              </div>

              {/* Default Insert Behavior */}
              <div style={{ display: 'grid', gap: 6, marginBottom: 10 }}>
                <label style={{ color: '#AAB2BD', fontSize: 11, fontWeight: 600 }}>
                  Default Insert
                </label>
                <div
                  role="radiogroup"
                  aria-label="Default Insert Behavior"
                  style={{ display: 'grid', gap: 6 }}
                >
                  {[
                    { key: 'insert', label: 'Insert at cursor' },
                    { key: 'replace', label: 'Replace selection' },
                    { key: 'new-tab', label: 'Open in new tab' },
                  ].map(r => (
                    <label
                      key={r.key}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 8,
                        color: '#E8E8E8',
                        fontSize: 12,
                      }}
                    >
                      <input
                        type="radio"
                        name="ai-insert"
                        checked={settings.defaultInsert === (r.key as any)}
                        onChange={() => updateSettings('defaultInsert', r.key as any)}
                        aria-label={r.label}
                      />
                      <span>{r.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Auto-Preview */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <input
                  id="ai-auto-preview"
                  type="checkbox"
                  checked={!!settings.autoPreview}
                  onChange={() => updateSettings('autoPreview', !settings.autoPreview)}
                  aria-label="Auto-Preview HTML/CSS/JS"
                />
                <label htmlFor="ai-auto-preview" style={{ color: '#E8E8E8', fontSize: 12 }}>
                  Run Preview automatically for HTML/CSS/JS snippets
                </label>
              </div>
            </div> : null}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-xs)' }}>
          {onSettings ? <button
              onClick={onSettings}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: '28px',
                height: '28px',
                border: 'none',
                borderRadius: 'var(--radius-sm)',
                background: 'transparent',
                color: '#AAB2BD',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = 'rgba(255,255,255,0.04)';
                e.currentTarget.style.color = '#E8E8E8';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#AAB2BD';
              }}
              title="Settings"
            >
              <Settings size={16} />
            </button> : null}

          {onMinimize ? <button
              onClick={onMinimize}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: '28px',
                height: '28px',
                border: 'none',
                borderRadius: 'var(--radius-sm)',
                background: 'transparent',
                color: '#AAB2BD',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = 'rgba(255,255,255,0.04)';
                e.currentTarget.style.color = '#E8E8E8';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#AAB2BD';
              }}
              title="Minimize"
            >
              <Minimize2 size={16} />
            </button> : null}

          {onToggleExpand ? <button
              onClick={onToggleExpand}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: '28px',
                height: '28px',
                border: 'none',
                borderRadius: 'var(--radius-sm)',
                background: 'transparent',
                color: '#AAB2BD',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = 'rgba(255,255,255,0.04)';
                e.currentTarget.style.color = '#E8E8E8';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#AAB2BD';
              }}
              title={isExpanded ? 'Restore' : 'Maximize'}
            >
              <Maximize2 size={16} />
            </button> : null}

          {onClose ? <button
              onClick={onClose}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: '28px',
                height: '28px',
                border: 'none',
                borderRadius: 'var(--radius-sm)',
                background: 'transparent',
                color: '#AAB2BD',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = 'rgba(231,76,60,0.15)';
                e.currentTarget.style.color = '#E74C3C';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#AAB2BD';
              }}
              title="Close AI Assistant"
            >
              <X size={16} />
            </button> : null}
        </div>
      </div>
    </div>
  );
};

export { AIHeader };
