import AttachBar from '@/components/ai/attachments/AttachBar';
import { useAttachStore } from '@/features/attachments/store';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { uuid as safeUuid } from '@/utils/uuid';
import { showToast } from '@/ui/toast/api';
import { reportError } from '@/lib/error-bus';
import { useKeyScope } from '@/ui/keys/useKeyScope';
import { toChord } from '@/ui/keys/router';
import styled from 'styled-components';
// Using alias path per project config for consistent resolution
import { useAiStreaming } from '@/hooks/useAiStreaming';
import {
  Activity,
  AlertCircle,
  Bot,
  Brain,
  Check,
  ChevronDown,
  ChevronUp,
  Clock,
  Code,
  Copy,
  Download,
  Lightbulb,
  Paperclip,
  Pin,
  PinOff,
  RotateCcw,
  Search,
  Send,
  Trash2,
  Wifi,
  WifiOff,
  X,
} from 'lucide-react';
import {
  // titleStyles (unused after header redesign),
  buttonStyles,
  globalStyles,
  inputContainerStyles,
  messagesStyles,
  createInputStyles,
  createMessageStyles,
  getCharacterCountColor,
} from '@/components/ai/AiAssistantStyles';
import {
  BEGINNER_PRESETS,
  MODEL_OPTIONS,
  PRO_PRESETS,
  aiModels,
  appendToThread,
  buildSummaryRequestPayload,
  buildSystemPrompt,
  classifyProviderError,
  findPresetById,
  getActiveProjectId,
  
  languages,
  loadAiSettings,
  loadPinnedContext,
  
  loadThread,
  modelOptionMap,
  parseFenceInfo,
  quickPrompts,
  replaceThread,
  saveAiSettings,
  
  selectFallbackModel,
  subscribeAiSettings,
  // Prompt 6 helpers
  buildSelectionUserPrompt,
  detectLangFromFilename,
  type AiSelectionAction,
  // Prompt 8 perf helpers
  VLIST_OVERSCAN_PX,
  // Prompt 3 helpers
  isOnline,
  pickEffectiveModel,
  // Dev-only telemetry helpers
  recordTelemetry,
  tStart,
  tEnd,
  flushTelemetryBuffer,
  estimateTokens,
  redactOutbound,
  type AiSettings,
  // constants referenced in this file
  ALLOW_MODEL_FALLBACK,
  CONTEXT_BUDGET_TOKENS,
  // Prompt 8 reliability helpers
  classifyError,
  userFacingMessage,
  emitTelemetry,
} from '@/components/ai/AiAssistantConfig';
import { timeouts } from '@/config/timeouts';
import AiSettingsModalPro from '@/components/ai/settings/AiSettingsModalPro';
import { type AiSettings as AiSettingsV2, loadAiSettingsV2, mergeAiSettingsV2, saveAiSettingsV2 } from '@/stores/aiSettings.schema';
import { MAX_FILE_BYTES, readTextSafely, sanitizeName, sha256, sniffKind } from '@/features/attachments/ingest';
import type { AttachmentMeta } from '@/features/attachments/types';
import { timeAndLog } from '@/services/telemetry';
import { useEditorStore } from '@/stores/editorStore';
import CodeBlockWithActions from '@/components/assistant/CodeBlockWithActions';
import { openNewTab as editorOpenNewTab, inferLanguageFromFence as inferFenceLang, insertIntoActive, replaceSelection } from '@/services/editorBridge';
import { defaultFilename, extractCodeBlocks, guessByLanguage } from '@/utils/markdown/extractCodeBlocks';
import { editorBridge as domEditorBridge } from '@/services/editor/bridge';
// (Apply pipeline now wired in EnhancedIDE command; no direct usage here.)
import { runPreview as previewRun } from '@/services/previewBridge';
import VirtualizedMessageList from '@/components/ai/virtual/VirtualMessageList';
import { chatScrollbarCss } from '@/components/ai/AiAssistantStyles';
import ChatMessage from '@/components/ai/ChatMessage';
import '@/components/ai/chatMessage.css';
import '@/components/ai/composer.css';
// a11y removed
import { useRafBatcher } from '@/hooks/useRafBatcher';
import { guardModeSwitch } from '@/utils/ai/mode/switchGuard';
// import { useResilience } from '@/utils/resilience/store';
import { SYNAPSE_COLORS, SYNAPSE_ELEVATION, withAlpha } from '@/ui/theme/synapseTheme';
import { flags } from '@/config/flags';
import { logger } from '@/lib/logger';
import { validateSelection } from '@/utils/ai/models/validator';
// Chat persistence wiring (Prompt 10)
import { type DraftV2, type HistoryV2, subscribeStorage } from '@/state/chatPersistence';
import { initChatState, onDraftChanged, onMessagesChanged } from '@/state/chatStore';

// Styled components (no visual change; replace repeated inline styles)
const Container = styled.div<{ $w: number; $isMobile: boolean }>`
  width: ${p => `${p.$w}px`};
  height: 100vh;
  margin-top: 0px;
  margin-bottom: 0px;
  display: flex;
  flex-direction: column;
  background: ${withAlpha(SYNAPSE_COLORS.bgSecondary, 0.4)};
  border: 1px solid ${SYNAPSE_COLORS.borderSubtle};
  border-radius: 0px;
  overflow: hidden;
  position: relative;
  z-index: 1000;
  box-shadow: ${p => p.$isMobile ? SYNAPSE_ELEVATION.shadowMd : SYNAPSE_ELEVATION.shadowLg};
  backdrop-filter: blur(20px) saturate(1.8);
  color: ${SYNAPSE_COLORS.textPrimary};
  font-family: "JetBrains Mono", "Fira Code", "SF Mono", monospace;
  padding-bottom: 28px;

`;

const Header = styled.div<{ $isMobile: boolean }>`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: ${p => (p.$isMobile ? '16px 20px' : '20px 24px')};
  min-height: 108px;
  border-bottom: 1px solid ${SYNAPSE_COLORS.borderSubtle};
  background: ${withAlpha(SYNAPSE_COLORS.bgSecondary, 0.6)};
  position: sticky;
  top: 0;
  z-index: 1002;
  backdrop-filter: blur(16px) saturate(1.5);
  box-shadow: ${SYNAPSE_ELEVATION.shadowMd};
  border-radius: 0 0 0px 0px;
  font-family: "JetBrains Mono", "Fira Code", "SF Mono", monospace;
`;

const BeginnerDot = styled.span<{ $active?: boolean }>`
  display: inline-block;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: ${p => (p.$active ? `linear-gradient(135deg,${SYNAPSE_COLORS.goldPrimary},${SYNAPSE_COLORS.goldSecondary})` : 'transparent')};
  box-shadow: 0 0 0 1px ${p => (p.$active ? withAlpha(SYNAPSE_COLORS.goldPrimary, 0.67) : SYNAPSE_COLORS.textTertiary)} inset;
  transition: background 0.2s ease, box-shadow 0.2s ease;
`;

const QueuePill = styled.span`
  background: ${SYNAPSE_COLORS.warning};
  color: ${SYNAPSE_COLORS.bgDark};
  padding: 0 6px;
  border-radius: 10px;
  font-size: 10px;
  font-weight: 700;
`;

const DelayLetter = styled.span<{ $dl?: string }>`
  --dl: ${p => p.$dl ?? '0.02s'};
`;

// Minimal text flow wrapper for inline highlighted segments
const TextFlow = styled.div`
  font-family: inherit;
  font-size: 13px;
  line-height: 1.6;
  color: ${SYNAPSE_COLORS.textPrimary};
`;

// Placeholder box for streaming code fences
const CodePlaceholderWrapper = styled.div`
  position: relative;
  background: linear-gradient(145deg, ${SYNAPSE_COLORS.bgDark}, ${SYNAPSE_COLORS.bgSecondary});
  border: 1px dashed ${withAlpha(SYNAPSE_COLORS.goldPrimary, 0.35)};
  border-radius: 12px;
  margin: 12px 0;
  padding: 12px 14px;
  color: ${SYNAPSE_COLORS.goldPrimary};
  font-size: 12px;
  font-family: 'JetBrains Mono', monospace;
`;

const InlineRow = styled.span`
  display: flex;
  align-items: center;
  gap: 8px;
`;

const SpinnerDot = styled.span`
  width: 14px;
  height: 14px;
  border: 2px solid ${withAlpha(SYNAPSE_COLORS.goldPrimary, 0.4)};
  border-top-color: ${SYNAPSE_COLORS.goldPrimary};
  border-radius: 50%;
  animation: spin 0.9s linear infinite;
  display: inline-block;

  @keyframes spin {
    to { transform: rotate(360deg); }
  }
`;

// (removed unused FlexOne)

// Types
interface Message {
  id: string;
  type: 'user' | 'ai' | 'system';
  content: string;
  timestamp: Date;
  language?: string;
  model?: string;
  mode?: 'beginner' | 'pro';
  threadId?: string; // Message threading support
  parentId?: string; // For reply chains
  isThreadStart?: boolean; // Mark thread start
  // STEP 4 streaming enhancements
  isStreaming?: boolean;             // whether message still receiving tokens
  streamedContent?: string;          // incremental buffer
  openFence?: {                      // if currently inside a fenced code block
    langHint?: string;
    code: string;                    // accumulated code inside fence
    startIndex: number;              // index in streamedContent where fence began
  token?: string;                  // token used for the fence (``` or ~~~)
  } | null;
}
// Use shared SSR-safe uuid helper
const uuid = safeUuid;

// Prompt 3: Small factories for consistent message shapes
function makeSystemMessage(text: string): Message {
  return {
  id: uuid(),
    type: 'system',
    content: text,
    timestamp: new Date(),
  } as Message;
}

function makeUserMessage(text: string, modelId: string | null, language?: string): Message {
  return {
  id: uuid(),
    type: 'user',
    content: text,
    timestamp: new Date(),
    model: modelId || undefined,
    language,
  } as Message;
}

function makeAiPlaceholder(modelId: string | null, language?: string, mode?: 'beginner' | 'pro', id?: string): Message {
  return {
  id: id || uuid(),
    type: 'ai',
    content: '',
    streamedContent: '',
    isStreaming: true,
    openFence: null,
    timestamp: new Date(),
    model: modelId || undefined,
    language,
    mode,
  } as Message;
}

// Provider keys are read from advanced settings (advSettings.keys)

interface AiAssistantProps {
  width?: number;
  onClose?: () => void;
}

const AiAssistant: React.FC<AiAssistantProps> = ({
  width = 400,
  onClose
}) => {
  // State
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: 'Hello! I\'m your AI coding assistant. I can help you with code generation, debugging, explanations, and architectural guidance. What would you like to work on today?',
      timestamp: new Date()
    }
  ]);
  /**
   * Safe, deferred, idempotent message updates
   * - Prevents render→state→render loops by deferring state writes to microtasks
   * - Dedupe by message id
   * - Guards against updates after unmount
   */
  const isMountedRef = React.useRef(true);
  React.useEffect(() => {
    return () => { isMountedRef.current = false; };
  }, []);

  // Safe microtask polyfill (queueMicrotask fallback)
  const runMicrotask = React.useCallback((fn: () => void) => {
    try { queueMicrotask(fn); } catch { Promise.resolve().then(fn); }
  }, []);

  // Defers a messages state update to the next microtask
  const deferMessagesUpdate = React.useCallback((updater: (prev: Message[]) => Message[]) => {
    runMicrotask(() => {
      if (!isMountedRef.current) return;
      setMessages(prev => updater(prev));
    });
  }, [runMicrotask]);

  // Append messages (idempotent by id)
  const appendMessagesDeferred = React.useCallback((items: Message[]) => {
    deferMessagesUpdate(prev => {
      if (!items.length) return prev;
      const seen = new Set(prev.map(m => m.id));
      const next = [...prev];
      for (const m of items) {
  if (!seen.has(m.id)) { next.push(m); seen.add(m.id); }
      }
      return next;
    });
  }, [deferMessagesUpdate]);

  // Replace/update a single message by id (deferred)
  const replaceMessageDeferred = React.useCallback((id: string, replacer: (m: Message) => Message) => {
    deferMessagesUpdate(prev => {
      const idx = prev.findIndex(m => m.id === id);
      if (idx === -1) return prev;
      const next = [...prev];
      next[idx] = replacer(next[idx]);
      return next;
    });
  }, [deferMessagesUpdate]);

  // Safe wrapper: if message missing, create a minimal assistant skeleton then apply update
  const safeReplaceMessage = React.useCallback((id: string, replacer: (m: Message) => Message, seed?: Partial<Message>) => {
    setMessages(prev => {
      let idx = prev.findIndex(m => m.id === id);
      let next = prev;
      if (idx === -1) {
        const skeleton: Message = {
          id,
          type: 'ai',
          content: '',
          streamedContent: '',
          isStreaming: true,
          openFence: null,
          timestamp: new Date(),
          ...(seed as any),
        } as Message;
        next = [...prev, skeleton];
        idx = next.length - 1;
      } else {
        next = [...prev];
      }
      next[idx] = replacer(next[idx]);
      return next;
    });
  }, []);

  // State
  const [input, setInput] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('javascript');
  const [selectedModel, setSelectedModel] = useState(() => {
    try { return localStorage.getItem('synapse.ai.model') || 'gpt-4-turbo'; } catch { return 'gpt-4-turbo'; }
  });
  const [isTyping, setIsTyping] = useState(false);
  // Persistence bootstrap + multi-tab coherence
  const lastDraftAtRef = useRef(0);
  const lastHistoryAtRef = useRef(0);
  // Break storage↔state echo loops
  const applyingExternalDraftRef = useRef(false);
  const applyingExternalHistoryRef = useRef(false);
  useEffect(() => {
    // Cold start load (once)
    try {
      const boot = initChatState();
      if (!input && boot.draft) {
        applyingExternalDraftRef.current = true;
        setInput(boot.draft);
        runMicrotask(() => { applyingExternalDraftRef.current = false; });
      }
      if (boot.messages && boot.messages.length) {
        // Map ChatMsg -> local Message shape, omit undefined optionals
        const mapped: Message[] = boot.messages.map(m => {
          const base: any = {
            id: m.id,
            type: m.role === 'assistant' ? 'ai' : (m.role as any),
            content: m.content,
            timestamp: new Date(m.ts),
          };
          if (m.model) base.model = m.model;
          return base as Message;
        });
        applyingExternalHistoryRef.current = true;
        setMessages(mapped);
        runMicrotask(() => { applyingExternalHistoryRef.current = false; });
      }
    } catch {}
    // Multi-tab coherence: subscribe to external updates
    const unsub = subscribeStorage(
      (d: DraftV2) => {
        try {
          if (d.updatedAt > lastDraftAtRef.current) {
            lastDraftAtRef.current = d.updatedAt;
            applyingExternalDraftRef.current = true;
            setInput(d.text);
            runMicrotask(() => { applyingExternalDraftRef.current = false; });
          }
        } catch {}
      },
      (h: HistoryV2) => {
        try {
          if (h.updatedAt > lastHistoryAtRef.current) {
            lastHistoryAtRef.current = h.updatedAt;
            const mapped: Message[] = h.messages.map((m) => {
              const base: any = { id: m.id, type: m.role === 'assistant' ? 'ai' : (m.role as any), content: m.content, timestamp: new Date(m.ts) };
              if (m.model) base.model = m.model;
              return base as Message;
            });
            applyingExternalHistoryRef.current = true;
            setMessages(mapped);
            runMicrotask(() => { applyingExternalHistoryRef.current = false; });
          }
        } catch {}
      }
    );
    return () => unsub();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [settingsOpen, setSettingsOpen] = useState(false);

  useEffect(() => {
    // Prevent echo-loop: when messages were applied from external storage, skip notifying store
    if (applyingExternalHistoryRef.current) return;
    const msgs = messages.map(m => ({ id: m.id, role: (m.type === 'ai' ? 'assistant' : (m.type as any)), content: m.content, ts: m.timestamp?.getTime?.() ?? Date.now(), model: m.model }));
    onMessagesChanged(msgs as any);
  }, [messages]);
  // Keep draft (input) in sync with v2 storage; skip writes when applying external updates
  useEffect(() => {
    if (applyingExternalDraftRef.current) return;
    try { onDraftChanged(input); } catch {}
  }, [input]);
  // Removed local isResizing state (external panel handle controls width)
  // Width now fully controlled by parent (EnhancedIDE)
  const currentWidth = width;
  // Inline API settings removed; settings live in modal
  
  // Thread tools moved into AI Settings modal (Thread & Context tab)
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [languageCategory, setLanguageCategory] = useState<string>('all');
  const [modelProvider, setModelProvider] = useState<string>('all');
  // Experimental models toggle (UI) – persists to localStorage 'synapse.ai.experimentalModels' ('1' | '0')
  // experimental models toggle removed from this scope to reduce unused state
  const [ollama, setOllamaModels] = useState<string[]>([]);
  // Local UI states needed before settings subscription
  const [autoPreview, setAutoPreview] = useState<boolean>(() => {
    try { return localStorage.getItem('synapse.ai.autoPreview') === 'false' ? false : true; } catch { return true; }
  });
  const [insertBehavior, setInsertBehavior] = useState<'cursor'|'newTab'>(() => {
    try { const v = localStorage.getItem('synapse.ai.insertBehavior'); if (v === 'cursor' || v === 'newTab') return v as any; } catch {}
    return 'cursor';
  });
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  // STEP 7 mode/settings from central AI settings
  const [aiSettings, setAiSettings] = useState(() => {
    try { return loadAiSettings(); } catch { return { mode: 'beginner', modelId: null, defaultInsert: 'insert', autoPreview: true } as any; }
  });
  const [beginnerMode, setBeginnerMode] = useState<boolean>(aiSettings.mode === 'beginner');
  useEffect(() => { setBeginnerMode(aiSettings.mode === 'beginner'); }, [aiSettings.mode]);
  useEffect(() => {
    const isDev = (() => {
      try { if (typeof import.meta !== 'undefined' && (import.meta as any).env?.DEV) return true; } catch {}
      try { if (typeof process !== 'undefined' && process.env?.NODE_ENV === 'development') return true; } catch {}
      return false;
    })();
    let updates = 0;
    const unsub = subscribeAiSettings((s) => {
      // Shallow guard for settings object
      setAiSettings((prev: AiSettings) => {
        if (
          prev.mode === s.mode &&
          prev.modelId === s.modelId &&
          prev.defaultInsert === s.defaultInsert &&
          prev.autoPreview === s.autoPreview
        ) return prev;
        if (isDev) console.warn('[DEV][store] aiSettings update (Assistant)', ++updates);
        return s;
      });
      // Apply derived local states only if changed
      if (s.modelId && s.modelId !== selectedModel) setSelectedModel(s.modelId);
      const nextInsert = s.defaultInsert === 'new-tab' ? 'newTab' : 'cursor';
      if (autoPreview !== !!s.autoPreview) setAutoPreview(!!s.autoPreview);
      if (insertBehavior !== nextInsert) setInsertBehavior(nextInsert);
      // Mirror to localStorage (idempotent)
      try { localStorage.setItem('synapse.ai.autoPreview', String(!!s.autoPreview)); } catch {}
      try { localStorage.setItem('synapse.ai.insertBehavior', nextInsert); } catch {}
    });
    return () => { try { unsub(); } catch { /* ignore */ } };
  }, [selectedModel, autoPreview, insertBehavior]);
  // expose setter for dev toggling (debug only)
  if (typeof window !== 'undefined') {
    (window as any).__setSynapseBeginner = (v: boolean) => {
      const next = { ...aiSettings, mode: v ? 'beginner' : 'pro' } as any;
      setAiSettings(next);
      saveAiSettings(next);
    };
  }

  // Pinned presets (mode-specific)
  const [pinnedBeginner, setPinnedBeginner] = useState<string[]>(() => {
  try { return JSON.parse(localStorage.getItem('synapse.ai.pinned.beginner')||'[]'); } catch { return []; }
  });
  const [pinnedPro, setPinnedPro] = useState<string[]>(() => {
  try { return JSON.parse(localStorage.getItem('synapse.ai.pinned.pro')||'[]'); } catch { return []; }
  });
  const pinnedForMode = aiSettings.mode === 'beginner' ? pinnedBeginner : pinnedPro;
  const setPinnedForMode = (ids: string[]) => {
    if (aiSettings.mode === 'beginner') {
      setPinnedBeginner(ids);
  try { localStorage.setItem('synapse.ai.pinned.beginner', JSON.stringify(ids)); } catch { /* ignore */ }
    } else {
      setPinnedPro(ids);
  try { localStorage.setItem('synapse.ai.pinned.pro', JSON.stringify(ids)); } catch { /* ignore */ }
    }
  };
  const togglePin = (id: string) => {
    const set = new Set(pinnedForMode);
    if (set.has(id)) set.delete(id); else set.add(id);
    setPinnedForMode(Array.from(set));
  };
  const [activePreset, setActivePreset] = useState<string | null>(() => {
  try { return localStorage.getItem('synapse.ai.lastPreset'); } catch { return null; }
  });
  // Debug expose (non-production suggestion)
  if (typeof window !== 'undefined') {
    (window as any).__synapseBeginner = beginnerMode;
  }

  // Notifications are centralized via Toaster; keep local API for compatibility
  // Test button state
  // Removed dev-only test and self-check controls to reduce confusion
  const [connectionStatus, setConnectionStatus] = useState<{
    [key: string]: 'connected' | 'disconnected' | 'testing' | 'error';
  }>({});
  const [apiResponseTimes, setApiResponseTimes] = useState<{
    [key: string]: number;
  }>({});

  // Recreated refs lost during refactor
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const messageListRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  // IME/Send control refs (Prompt 5)
  const composingRef = useRef<boolean>(false);
  const pendingEnterRef = useRef<boolean>(false);
  const lastSendAtRef = useRef<number>(0);
  const projectIdRef = useRef<string>('default');
  // Per-thread mapping for the active assistant message id (guards overlapping streams)
  const activeMsgByThreadRef = useRef<Map<string, string>>(new Map());
  
  // Local pinned/summary controls managed in AI Settings modal
  const idleTimerRef = useRef<ReturnType<typeof window.setTimeout> | null>(null);
  const hardTimerRef = useRef<ReturnType<typeof window.setTimeout> | null>(null);
  const streamedCharsRef = useRef<number>(0);
  // Track current streaming message id
  const currentStreamingMsgIdRef = useRef<string | null>(null);
  // Track last aborted message (for Continue)
  const lastAbortedMsgIdRef = useRef<string | null>(null);
  // Stream coalescing buffer (Prompt 8)
  const streamBufferRef = useRef<string>('');      // accumulates raw delta
  const flushTimerRef = useRef<ReturnType<typeof window.setTimeout> | null>(null);
  const lastFlushAtRef = useRef<number>(0);
  // Track last abort toast to avoid spamming
  const lastAbortToastAtRef = useRef<number>(0);
  // Stream buffer config (Prompt 2)
  // Streaming buffer cap kept by rAF batching; old constant retained for docs but unused
  // const MAX_BUFFER_CHARS_BETWEEN_FLUSH = 800;
  // Sanitize timeouts and keep a ref so helper timers can read the latest
  type TimeoutCfg = { idleMs?: number; hardMs?: number; retryBackoffMs?: number };
  const sanitizeTimeouts = (t: TimeoutCfg) => {
    const idle = Number.isFinite(t?.idleMs) && (t!.idleMs as number) >= 10000 ? (t!.idleMs as number) : 45000;
    const hardRaw = Number.isFinite(t?.hardMs) && (t!.hardMs as number) >= 60000 ? (t!.hardMs as number) : 180000;
    const hard = Math.max(hardRaw, idle + 30000);
    const backoff = Number.isFinite(t?.retryBackoffMs) && (t!.retryBackoffMs as number) >= 250 ? (t!.retryBackoffMs as number) : 1500;
    return { idleMs: idle, hardMs: hard, retryBackoffMs: backoff };
  };
  const sanitizedTimeoutsRef = useRef(sanitizeTimeouts(timeouts as any));

  // Race-safe clear helper: only clears the active stream id if it matches the provided id
  const clearActiveStreamIfMatches = useCallback((id: string | null) => {
    if (!id) return;
    if (currentStreamingMsgIdRef.current === id) {
      currentStreamingMsgIdRef.current = null;
    }
  }, []);

  // Idle timeout for lack of flush activity
  // const MAX_BUFFER_CHARS_BETWEEN_FLUSH = 800; // no longer used with rAF batching
  const idleFlushTimerRef = useRef<ReturnType<typeof window.setTimeout> | null>(null);
  const armIdleTimeout = useCallback(() => {
    if (idleFlushTimerRef.current) clearTimeout(idleFlushTimerRef.current);
    // Do not arm if not currently streaming
    if (!streamState.isStreaming) return;
    const idleBudget = sanitizedTimeoutsRef.current?.idleMs ?? (typeof (timeouts as any)?.idleMs === 'number' ? (timeouts as any).idleMs : 25000);
    idleFlushTimerRef.current = window.setTimeout(() => {
      try {
        const last = lastFlushAtRef.current || 0;
        const ago = Date.now() - last;
        if (ago >= idleBudget) {
          // Centralize abort handling; abort underlying stream then finalize UI
          try { abortStreaming('idle_timeout'); } catch {}
          try { /* finalize in abort effect or per-request handlers */ } catch {}
        }
      } catch { /* no-op */ }
    }, idleBudget + 200) as unknown as ReturnType<typeof window.setTimeout>;
  }, []);
  const clearIdleTimeout = useCallback(() => {
    if (idleFlushTimerRef.current) {
      window.clearTimeout(idleFlushTimerRef.current);
      idleFlushTimerRef.current = null;
    }
  }, []);

  // Ensure chat view jumps to the latest message reliably
  const scrollToBottom = useCallback(() => {
    try {
      requestAnimationFrame(() => {
        const v = messageListRef.current as any;
        if (v?.scrollToBottom) v.scrollToBottom();
        else {
          const el = v as HTMLDivElement | null;
          if (el) el.scrollTop = el.scrollHeight;
          messagesEndRef.current?.scrollIntoView?.({ behavior: 'smooth' });
        }
      });
    } catch {}
  }, []);

  // Advanced Settings (v2)
  const [advSettings, setAdvSettings] = useState<AiSettingsV2>(() => {
    try { return loadAiSettingsV2(); } catch { return loadAiSettingsV2(); }
  });

  // One-time auto-config: if OpenAI key is missing, read from env and persist (no logs, no echo)
  useEffect(() => {
    try {
      const hasKey = !!advSettings?.keys?.openai;
      if (hasKey) return;
      const envKey: string | undefined = (() => {
        try { return (import.meta as any)?.env?.VITE_OPENAI_API_KEY as string | undefined; } catch { return undefined; }
      })() || ((): string | undefined => {
        try { return (window as any)?.__OPENAI_API_KEY as string | undefined; } catch { return undefined; }
      })();
      if (envKey && typeof envKey === 'string') {
        setAdvSettings(prev => {
          const next = mergeAiSettingsV2(prev as any, { keys: { openai: envKey } } as any) as AiSettingsV2;
          try { saveAiSettingsV2(next as any); } catch { /* ignore */ }
          return next;
        });
      }
    } catch { /* ignore */ }
   
  }, [advSettings?.keys?.openai]);
  const syncLegacyFromV2 = useCallback((patch: Partial<AiSettingsV2>) => {
    const legacy = loadAiSettings();
    let changed = false;
    const next = { ...legacy } as AiSettings;
    if (typeof patch.mode !== 'undefined' && (legacy as any).mode !== patch.mode) { (next as any).mode = patch.mode as any; changed = true; }
    if (typeof patch.model !== 'undefined') {
      const modelId = (patch.model ?? null) as any;
      if ((legacy as any).modelId !== modelId) { (next as any).modelId = modelId; changed = true; }
    }
    if (changed) saveAiSettings(next);
  }, []);
  const handleAdvChange = useCallback((nextPartial: Partial<AiSettingsV2>) => {
    setAdvSettings(prev => {
      const merged = mergeAiSettingsV2(prev as any, nextPartial as any) as any as AiSettingsV2;
      saveAiSettingsV2(merged as any);
      syncLegacyFromV2(nextPartial);
      return merged;
    });
  }, [syncLegacyFromV2]);
  const handleAdvSave = useCallback(() => {
    try { saveAiSettingsV2(advSettings as any); showToast({ kind: 'success', contextKey: 'settings:v2:save', title: 'Settings saved', message: 'Your preferences are up to date.' }); } catch {
      showToast({ kind: 'error', contextKey: 'settings:v2:save', title: 'Save failed', message: 'Could not persist settings.' });
    }
  }, [advSettings]);
  const handleAdvExport = useCallback((includeKeys: boolean) => {
    try {
      const data = { ...advSettings, keys: includeKeys ? (advSettings.keys || {}) : {} } as AiSettingsV2;
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const ts = new Date();
      const name = `ai-settings-${ts.getFullYear()}${String(ts.getMonth()+1).padStart(2,'0')}${String(ts.getDate()).padStart(2,'0')}.json`;
      a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  showToast({ kind: 'success', contextKey: 'settings:v2:export', title: 'Exported settings JSON', message: 'Download started.' });
    } catch {
  showToast({ kind: 'error', contextKey: 'settings:v2:export', title: 'Export failed', message: 'Could not create file.' });
    }
  }, [advSettings]);
  const handleAdvImport = useCallback(async (file: File, overwriteKeys: boolean) => {
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as Partial<AiSettingsV2>;
      if (!parsed || typeof parsed !== 'object') throw new Error('Invalid file');
      const nextPatch: Partial<AiSettingsV2> = { ...parsed };
      if (!overwriteKeys) delete (nextPatch as any).keys;
      setAdvSettings(prev => {
        const merged = mergeAiSettingsV2(prev as any, nextPatch as any) as any as AiSettingsV2;
        saveAiSettingsV2(merged as any);
        syncLegacyFromV2(nextPatch);
        return merged;
      });
  showToast({ kind: 'success', contextKey: 'settings:v2:import', title: 'Imported settings', message: 'Profile applied.' });
    } catch (e) {
  showToast({ kind: 'error', contextKey: 'settings:v2:import', title: 'Import failed', message: 'Invalid or unreadable file.' });
    }
  }, [syncLegacyFromV2]);

  // (applyChunkToLastAssistantMessage) inlined into flushStreamBuffer for single-update flushes

  function flushStreamBuffer() {
    const pending = streamBufferRef.current;
    const msgId = currentStreamingMsgIdRef.current;
    if (!pending || !msgId) return;
    // Clear buffer first to avoid re-entrancy
    streamBufferRef.current = '';
    lastFlushAtRef.current = Date.now();
  safeReplaceMessage(msgId, (m: any) => {
      if (!m) return m as any;
      const prev = (m.streamedContent || m.content || '') as string;
      const aggregated = prev + pending;
      // Optional: lightweight fence tracking (keep cheap)
      let openFence = m.openFence || null;
      try {
        // Track the last unmatched opening fence. Support backtick and tilde.
        const fenceOpenRe = /(?:^|\n)(`{3,}|~{3,})([^\n]*)\n/g;
        const fenceClose = (token: string) => new RegExp(`(?:^|\n)${token}(?:\n|$)`);
        if (!openFence) {
          // Find all openings, pick the last one that is not yet closed
          let match: RegExpExecArray | null;
          let lastStart = -1;
          let lastLang: string | undefined = undefined;
          let lastToken = '```';
          while ((match = fenceOpenRe.exec(aggregated)) !== null) {
            const token = match[1];
            const start = match.index + match[0].length;
            const langHint = (match[2] || '').trim() || undefined;
            // Check if there is a matching closer after this start
            const closeRe = fenceClose(token);
            closeRe.lastIndex = start;
            const closeFound = closeRe.test(aggregated.slice(start));
            if (!closeFound) {
              lastStart = start; lastLang = langHint; lastToken = token;
            }
          }
          if (lastStart !== -1) {
            openFence = { langHint: lastLang, code: aggregated.slice(lastStart), startIndex: lastStart, token: lastToken } as any;
          }
        } else {
          const codePortion = aggregated.slice(openFence.startIndex);
          const closer = (openFence as any).token || '```';
          const closeRe = new RegExp(`(?:^|\n)${closer}(?:\n|$)`);
          const closeIdx = codePortion.search(closeRe);
          openFence = closeIdx === -1 ? { ...openFence, code: codePortion } : null;
        }
      } catch { /* ignore fence errors during stream */ }
      return { ...m, streamedContent: aggregated, content: aggregated, openFence } as Message;
    });
  // After applying the streamed delta, ensure the view stays pinned to the latest content
  try { scrollToBottom(); } catch {}
    // Re-arm idle timeout after a successful flush
    armIdleTimeout();
    // Telemetry for flushes
    try {
      flushCountRef.current = (flushCountRef.current || 0) + 1;
      emitTelemetry('delta_flush', { n: flushCountRef.current });
    } catch {}
  }

  // armFlushTimer no longer used with rAF batching
  function clearFlushTimer() {
    if (flushTimerRef.current) {
  window.clearTimeout(flushTimerRef.current);
      flushTimerRef.current = null;
    }
  }
  useEffect(() => () => { clearFlushTimer(); /* keep symbol referenced */ void flushStreamBuffer; }, []);

  // Unified cleanup across exits
  const cleanupStreamingState = useCallback(() => {
    try { clearFlushTimer(); } catch {}
    try { clearIdleTimeout(); } catch {}
    try {
      if (idleTimerRef.current) { clearTimeout(idleTimerRef.current); idleTimerRef.current = null; }
      if (hardTimerRef.current) { clearTimeout(hardTimerRef.current); hardTimerRef.current = null; }
    } catch {}
    currentStreamingMsgIdRef.current = null;
    setIsTyping(false);
  }, [clearIdleTimeout]);
  useEffect(() => () => { cleanupStreamingState(); }, [cleanupStreamingState]);

  // Abort any in-flight stream when component unmounts
  useEffect(() => {
    return () => {
      try { abortStreaming('unmount'); } catch {}
      // Revoke any object URLs created for attachments
      try {
        const list = useAttachStore.getState().list;
        list.forEach(a => { if (a.previewUrl) URL.revokeObjectURL(a.previewUrl); });
      } catch {}
    };
  }, []);

  // UX Enhancement States
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [lastAbortReason, setLastAbortReason] = useState<string | null>(null); // displayed in notification when updated
  // Feature flag: show a tiny inline hint while streaming (opt-in via localStorage 'synapse.ai.showCancelHint' = 'true')
  const [showCancelHint, setShowCancelHint] = useState<boolean>(false);
  // Inline presets dropdown state (moved from removed AIHeader)
  const [showPresetMenuInline, setShowPresetMenuInline] = useState(false);
  // Keyboard overlay + search
  const [showKeysOverlay, setShowKeysOverlay] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const searchInputRef = useRef<HTMLInputElement | null>(null);
  const providerKeys = useMemo(() => ({
    openai: advSettings.keys?.openai || '',
    anthropic: advSettings.keys?.anthropic || '',
    google: advSettings.keys?.google || '',
    ollama: advSettings.keys?.ollama || 'http://localhost:11434',
  }), [advSettings.keys]);

  const guardModelAndKeys = useCallback(
    (modelMeta: { provider: 'openai' | 'anthropic' | 'google' | 'ollama' } | null, effectiveModelId: string | null) => {
      if (!effectiveModelId) {
        return 'No model is selected. Please choose a model in AI Settings and resend.';
      }
      if (!modelMeta) {
        return 'Selected model is not available. Please choose another model in AI Settings.';
      }
      if (modelMeta.provider === 'openai' && !providerKeys.openai) {
        return 'Missing OpenAI API key. Open AI Settings → API Keys, add the key, then resend.';
      }
      if (modelMeta.provider === 'anthropic' && !providerKeys.anthropic) {
        return 'Missing Anthropic API key. Open AI Settings → API Keys, add the key, then resend.';
      }
      if (modelMeta.provider === 'google' && !providerKeys.google) {
        return 'Missing Google API key. Open AI Settings → API Keys, add the key, then resend.';
      }
      return null; // ollama için key gerekmiyor
    },
    [providerKeys.openai, providerKeys.anthropic, providerKeys.google]
  );
  const { startStreaming, abortStreaming, streamState } = useAiStreaming(providerKeys);
  // Dev-only telemetry refs
  const telReqT0Ref = useRef<number>(0);
  const telCharsRef = useRef<number>(0);
  const telRetryRef = useRef<number>(0);
  const telFallbackModelRef = useRef<string | null>(null);
  const telSummT0Ref = useRef<number>(0);
  const telSummElapsedRef = useRef<number>(0);
  const handleSendMessageRef = useRef<null | (() => Promise<void>)>(null);
  const [errorState, setErrorState] = useState<{
    hasError: boolean;
    errorType: 'network' | 'auth' | 'rate_limit' | 'server' | 'unknown';
    message: string;
    retryable: boolean;
  }>({
    hasError: false,
    errorType: 'unknown',
    message: '',
    retryable: false
  });

  // Prompt 8 — reliability: last system note for SR, flush counter, and debug toggle
  const [lastSystemNote, setLastSystemNote] = useState<string>('');
  const flushCountRef = useRef<number>(0);
  const debugOn = typeof window !== 'undefined' && (localStorage.getItem('synapse.ai.debug') === '1');
  // a11y announcements removed
  // Streaming delta processor bound per request
  const processDeltaRef = useRef<(chunk: string) => void>(() => {});
  const enqueueDelta = useRafBatcher<string>((chunks) => {
    const merged = chunks.join('');
    processDeltaRef.current(merged);
  });

  // Hydrate misc flags on mount
  useEffect(() => {
    try { setShowCancelHint(localStorage.getItem('synapse.ai.showCancelHint') === 'true'); } catch {}
  }, []);

  // Resolve active project id at mount
  useEffect(() => {
    try { projectIdRef.current = getActiveProjectId(); } catch { projectIdRef.current = 'default'; }
  }, []);
  // Pinned context handled in AI Settings modal

  // Respect user-selected model; do not auto-downgrade. Fallbacks are handled later when errors occur.
  // (Removed legacy auto-remap to gpt-4o to allow GPT-5 family and others.)

  // Responsive Design States
  const [isMobile, setIsMobile] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
  // Local UI states
  const [showQuickPrompts, setShowQuickPrompts] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<'all'|string>('all');
  const [initialSettingsTab, setInitialSettingsTab] = useState<string | undefined>(undefined);

  // Message Threading States (For future use)
  // const [currentThreadId, setCurrentThreadId] = useState<string | null>(null);
  // const [threadMessages, setThreadMessages] = useState<{ [threadId: string]: Message[] }>({});
  // const [showThreadView, setShowThreadView] = useState(false);

  // Effect: track abort reason from hook (friendly toasts)
  useEffect(() => {
    if (!streamState.abortReason) return;
    if (lastAbortReason === streamState.abortReason) return; // coalesce same reason back-to-back
    setLastAbortReason(streamState.abortReason);
    const r = streamState.abortReason;
  if (flags.aiTrace) logger.info('[STREAM_ABORT]', 'reason=', r);
  // Deterministic cleanup
  try { setIsTyping(false); } catch {}
  try { cleanupStreamingState(); } catch {}
  // Ensure any active assistant bubble is marked as not streaming
  try {
    const activeId = currentStreamingMsgIdRef.current;
  if (activeId) safeReplaceMessage(activeId, (m) => ({ ...m, isStreaming: false } as Message));
  } catch {}
    // Throttle abort toasts to avoid spam
    try {
      const now = Date.now();
      if (!lastAbortToastAtRef.current || now - lastAbortToastAtRef.current > 10000) {
        const toast =
          r === 'user_cancel' || r === 'user_escape' ? ['info', 'Generation cancelled.'] :
          r === 'new_request' ? ['info', 'Cancelled previous request'] :
          r === 'idle_timeout' ? ['warning', 'Connection stalled; request aborted.'] :
          r === 'request_timeout' ? ['warning', 'Request timed out.'] :
          ['info', 'Stream aborted'];
        addNotification(toast[0] as any, toast[1] as string);
        lastAbortToastAtRef.current = now;
      }
    } catch {}
  // a11y removed
  try { emitTelemetry('send_abort', { reason: r }); } catch {}
  // Also surface via unified error bus to ensure single toast policy
  try {
    const code = r === 'user_escape' || r === 'user_cancel' ? 'aborted' : (r?.includes('timeout') ? 'timeout' : 'unknown');
    reportError({ source: 'fsm', code });
  } catch {}
  }, [streamState.abortReason, lastAbortReason]);

  // Defensive guard: if engine reports not streaming, ensure UI bubble exits streaming
  useEffect(() => {
    if (streamState.isStreaming) return;
    try {
      const activeId = currentStreamingMsgIdRef.current;
  if (activeId) safeReplaceMessage(activeId, (m) => ({ ...m, isStreaming: false } as Message));
    } catch {}
    // Additionally, finalize any lingering AI messages that may still be flagged as streaming
    try {
      setMessages(prev => prev.map(m => (m.type === 'ai' && (m as any).isStreaming) ? ({ ...m, isStreaming: false } as Message) : m));
    } catch {}
    try { clearIdleTimeout(); } catch {}
    if (isMountedRef.current) setIsTyping(false);
  }, [streamState.isStreaming, clearIdleTimeout, replaceMessageDeferred]);
  // Close inline preset menu on outside click
  useEffect(() => {
    if (!showPresetMenuInline) return;
    const handler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('[data-presets-inline]')) setShowPresetMenuInline(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [showPresetMenuInline]);
  
  // Optional: ESC to cancel active generation (no UI change)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      if (el && (el.tagName === 'TEXTAREA' || el?.closest?.('[data-chat-input]'))) return;
      if (e.key === 'Escape') {
  // Mark the currently streaming message as aborted for Continue control
  try { lastAbortedMsgIdRef.current = currentStreamingMsgIdRef.current; } catch {}
  // a11y removed
        abortStreaming('user_escape');
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [abortStreaming]);
  // Alt+S to send (accessible shortcut)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const active = document.activeElement as HTMLElement | null;
      const target = (e.target as HTMLElement | null);
      const inChat = !!(
        (active && (active.tagName === 'TEXTAREA' || active.closest('[data-chat-input]') || active.closest('[data-component="ai-assistant"]')))
        || (target && (target.closest('[data-chat-input]') || target.closest('[data-component="ai-assistant"]')))
      );
      if (!inChat) return;
      if (e.altKey && (e.key?.toLowerCase?.() === 's' || (e as any).code === 'KeyS')) {
        e.preventDefault(); e.stopPropagation();
        if (!streamState.isStreaming) {
          // a11y removed
          const fn = (handleSendMessageRef.current);
          if (fn) void fn();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [streamState.isStreaming]);
  // Close settings on outside click
  useEffect(() => {
    if (!settingsOpen) return;
    const handler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('[data-ai-settings]') && !target.closest('[data-ai-settings-trigger]')) setSettingsOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [settingsOpen]);
  // ESC key to close settings
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = document.activeElement as HTMLElement | null;
      if (el && (el.tagName === 'TEXTAREA' || el?.closest?.('[data-chat-input]'))) return;
      if (e.key === 'Escape') setSettingsOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Global guard (bubble-phase): avoid interfering with chat input; only block necessary shortcuts globally
  useEffect(() => {
    const guard = (e: KeyboardEvent) => {
      const active = document.activeElement as HTMLElement | null;
      const target = e.target as HTMLElement | null;
      const inChat = !!(
        (active && (active.tagName === 'TEXTAREA' || active.closest('[data-chat-input]') || active.closest('[data-component="ai-assistant"]')))
        || (target && (target.closest('[data-chat-input]') || target.closest('[data-component="ai-assistant"]')))
      );
      if (inChat) return; // don't touch events inside chat input/components
      // Only handle truly global shortcuts here; do not touch Enter/ESC
      // Example: prevent browser find when overlay panes use their own search (Ctrl/Cmd+F)
      const isMac = navigator.platform.toLowerCase().includes('mac');
      const meta = isMac ? e.metaKey : e.ctrlKey;
      if (meta && (e.key?.toLowerCase?.() === 'f' || (e as any).code === 'KeyF')) {
        e.preventDefault();
      }
    };
    window.addEventListener('keydown', guard, false);
    window.addEventListener('keyup', guard, false);
    return () => {
      window.removeEventListener('keydown', guard, false);
      window.removeEventListener('keyup', guard, false);
    };
  }, []);
  // Persist settings
  useEffect(() => { try { localStorage.setItem('synapse.ai.insertBehavior', insertBehavior); } catch { /* ignore */ } }, [insertBehavior]);
  useEffect(() => { try { localStorage.setItem('synapse.ai.autoPreview', String(autoPreview)); } catch { /* ignore */ } }, [autoPreview]);
  useEffect(() => { try { localStorage.setItem('synapse.ai.model', selectedModel); } catch { /* ignore */ } }, [selectedModel]);
  // Telemetry for abort reasons
  useEffect(() => {
    if (lastAbortReason) {
      try { emitTelemetry('send_abort', { reason: lastAbortReason }); } catch {}
    }
  }, [lastAbortReason]);

  // Helpers (reintroduced)
  const highlightInline = (content: string) => {
    return content
      .replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>')
  // anti-linkify: wrap URLs to avoid auto-link conflicts in some UI kits
  .replace(/\bhttps?:\/\/[^\s]+/g, '<span class="url">$&</span>')
      .replace(/\b(\w+)\s*\(/g, '<span class="function-name">$1</span>(')
      .replace(/\b(function|const|let|var|if|else|for|while|return|import|export|class|interface|type)\b/g, '<span class="keyword">$1</span>')
      .replace(/"([^"]+)"/g, '<span class="string">"$1"</span>')
      .replace(/'([^']+)'/g, '<span class="string">\'$1\'</span>')
      .replace(/\b(\d+)\b/g, '<span class="number">$1</span>')
      .replace(/\/\/(.+)/g, '<span class="comment">//$1</span>')
      .replace(/\/\*([\s\S]*?)\*\//g, '<span class="comment">/*$1*/</span>');
  };
  const escapeHtml = (text: string) => { const div = document.createElement('div'); div.textContent = text; return div.innerHTML; };
  const escapeRegExp = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const applySearchHighlight = (html: string) => {
    const q = searchQuery.trim();
    if (!q) return html;
    try {
      const re = new RegExp(`(${escapeRegExp(q)})`, 'gi');
      // Split by <code ...>...</code> while keeping tags
      const parts: string[] = [];
      const codeRe = /<code\b[^>]*>[\s\S]*?<\/code>/gi;
      let lastIndex = 0; let m: RegExpExecArray | null;
      while ((m = codeRe.exec(html)) !== null) {
        const before = html.slice(lastIndex, m.index);
        if (before) parts.push(before.replace(re, '<mark class="chat-search-hit">$1</mark>'));
        parts.push(m[0]);
        lastIndex = m.index + m[0].length;
      }
      const tail = html.slice(lastIndex);
      if (tail) parts.push(tail.replace(re, '<mark class="chat-search-hit">$1</mark>'));
      return parts.join('');
    } catch { return html; }
  };

  // Error handling helpers (restored)
  const handleError = (error: any) => {
    let errorType: 'network' | 'auth' | 'rate_limit' | 'server' | 'unknown' = 'unknown';
    let message = 'Unknown error occurred';
    let retryable = false;
    if (error instanceof Error) {
      if (/(401|403)/.test(error.message)) { errorType='auth'; message='Invalid API key'; }
      else if (/429/.test(error.message)) { errorType='rate_limit'; message='Rate limit exceeded'; retryable=true; }
      else if (/(500|502|503)/.test(error.message)) { errorType='server'; message='Server error'; retryable=true; }
      else if (/network|fetch/i.test(error.message)) { errorType='network'; message='Network error'; retryable=true; }
      else { message = error.message; retryable = true; }
    }
    setErrorState({ hasError: true, errorType, message, retryable });
    return { errorType, message, retryable };
  };
  const clearError = () => setErrorState({ hasError:false, errorType:'unknown', message:'', retryable:false });

  // Offline queue helpers
  const overrideContentRef = useRef<string | null>(null);
  const suppressNextUserAppendRef = useRef<boolean>(false);
  const OFFLINE_QUEUE_KEY = 'synapse.chat.queue';
  const enqueueOffline = useCallback((payload: { content: string; lang?: string; model?: string; ts?: number; }) => {
    try {
      const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
      const arr: any[] = raw ? JSON.parse(raw) : [];
      arr.push({ ...payload, ts: payload.ts || Date.now() });
      localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(arr));
    } catch {}
  }, []);
  const flushOfflineQueue = useCallback(async () => {
    try {
      const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
      const arr: Array<{ content: string; lang?: string; model?: string; ts?: number; }> = raw ? JSON.parse(raw) : [];
      if (!arr.length) return;
      // Send sequentially without re-adding user bubbles
      while (arr.length) {
        const item = arr.shift()!;
        overrideContentRef.current = item.content;
        suppressNextUserAppendRef.current = true;
        // If a model was captured offline, temporarily select it for this replay
        if (item.model && item.model !== selectedModel) {
          setSelectedModel(item.model);
        }
         
        await handleSendMessage();
      }
      localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify([]));
      addNotification('success', 'Sent queued messages');
    } catch {}
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    const onOnline = () => { void flushOfflineQueue(); };
    window.addEventListener('online', onOnline);
    return () => window.removeEventListener('online', onOnline);
  }, [flushOfflineQueue]);

  // Structured renderer injecting CodeBlockWithActions for fenced code blocks
  const renderMessageContent = (content: string, message?: Message) => {
    // If streaming and there is an open fence, show placeholder reserve
    if (message?.isStreaming && message.openFence) {
      const before = content.slice(0, message.openFence.startIndex);
      const highlightedBefore = highlightInline(escapeHtml(before));
      return (
        <TextFlow>
          {before ? <div dangerouslySetInnerHTML={{ __html: highlightedBefore }} /> : null}
          <CodePlaceholderWrapper>
            <InlineRow>
              <SpinnerDot className="spinner" />
              Generating {message.openFence.langHint || 'code'}…
            </InlineRow>
          </CodePlaceholderWrapper>
        </TextFlow>
      );
    }
  // Support both backtick and tilde fences with matching closer (via backreference)
  const regex = /(?:^|\n)(`{3,}|~{3,})([^\n]*)\n([\s\S]*?)\1/g; // 1=fence token, 2=info line, 3=code
    let lastIndex = 0;
    const parts: React.ReactNode[] = [];
    let match: RegExpExecArray | null;
    let blockCount = 0;
    let keySeq = 0;

    // While streaming, avoid heavy parsing/Suspense; render as highlighted text only
    if ((message as any).isStreaming) {
      const highlighted = applySearchHighlight(highlightInline(escapeHtml(content)));
      return <div><TextFlow dangerouslySetInnerHTML={{ __html: highlighted }} /></div>;
    }
    while ((match = regex.exec(content)) !== null) {
      const [full, _fence, info, codeRaw] = match as any;
      const textBefore = content.slice(lastIndex, match.index);
      if (textBefore) {
        const highlighted = applySearchHighlight(highlightInline(escapeHtml(textBefore)));
        parts.push(
          <TextFlow key={`t-${blockCount}-seg-${keySeq++}`} dangerouslySetInnerHTML={{ __html: highlighted }} />
        );
      }
      blockCount += 1;
  const code = codeRaw.replace(/\s+$/,'');
  const { lang: parsedLang, filename: fenceFilename } = parseFenceInfo(info);
  const lang = parsedLang;
      const isPrimary = blockCount === 1; // first fence full toolbar
      parts.push(
        <React.Suspense fallback={<pre>Loading...</pre>}>
          <CodeBlockWithActions
            code={code}
            language={lang}
            primary={isPrimary}
            onCopy={async () => { try { emitTelemetry('apply_copy', { lang: lang || null }); await navigator.clipboard.writeText(code); addNotification('success','Copied to clipboard',1200); } catch {} }}
  onInsert={async () => {
              try {
        emitTelemetry('apply_insert', { lang: lang || null });
                const promptContext = code + (lang ? (`\nLANG:${lang}`) : '');
                const tokensApprox = estimateTokens(promptContext);
                await timeAndLog({ action: 'insert', model: selectedModel, tokensApprox, exec: async () => {
                  // Normalize using selected language & mode
                  const { normalizeAssistantMessage } = await import('@/utils/ai/lang/normalizeOutput');
                  const { getLangSpec } = await import('@/utils/ai/lang/languageMap');
                  const selectedSpec = getLangSpec(selectedLanguage) || getLangSpec('javascript')!;
                  const { files, warnings } = normalizeAssistantMessage(
                    `\n\n\u002F\u002F\u002F\u002F file: ${fenceFilename || ''}\n\n\u0060\u0060\u0060${lang || ''}\n${code}\n\u0060\u0060\u0060`,
                    { selectedLang: selectedSpec, mode: (message?.mode as any) || (aiSettings.mode as any) || 'beginner' }
                  );
                  if (warnings.length && (process.env.NODE_ENV !== 'production')) {
                    console.debug('[DEV][lang-normalize]', warnings);
                  }
                  // Beginner: single file expected; Pro: may have many
                  const toApply = files.length ? files : [{ path: fenceFilename || `snippet-${Date.now()}.${(lang||'txt')}`, code, monaco: selectedSpec.monaco, ext: selectedSpec.ext, fence: selectedSpec.fence }];
                  const first = toApply[0];
                  const langInf = inferFenceLang(first.fence, first.code);
                  let tabId: string;
                  if (insertBehavior === 'newTab') {
                    const res = await editorOpenNewTab({ filename: first.path, code: first.code, language: langInf });
                    tabId = res.tabId;
                  } else {
                    const res = await insertIntoActive({ code: first.code, language: langInf });
                    tabId = res.tabId;
                  }
                  if (autoPreview && lang && /^(html?|css|javascript)$/.test(lang.toLowerCase())) {
                    const previewTokens = estimateTokens(code);
                    await timeAndLog({ action: 'preview', model: selectedModel, tokensApprox: previewTokens, exec: async () => await previewRun(tabId) });
                  }
                }});
                addNotification('success','Inserted snippet',1500);
              } catch (e:any) {
                addNotification('error','Insert failed – Retry?',4000);
              }
            }}
  onNewTab={async () => {
      emitTelemetry('apply_newtab', { lang: lang || null });
              const { normalizeAssistantMessage } = await import('@/utils/ai/lang/normalizeOutput');
              const { getLangSpec } = await import('@/utils/ai/lang/languageMap');
              const selectedSpec = getLangSpec(selectedLanguage) || getLangSpec('javascript')!;
              const { files } = normalizeAssistantMessage(
                `\n\n\u002F\u002F\u002F\u002F file: ${fenceFilename || ''}\n\n\u0060\u0060\u0060${lang || ''}\n${code}\n\u0060\u0060\u0060`,
                { selectedLang: selectedSpec, mode: (message?.mode as any) || (aiSettings.mode as any) || 'beginner' }
              );
              const f = files[0] || { path: fenceFilename || `snippet-${Date.now()}.${(lang||'txt')}`, code, fence: lang } as any;
              await editorOpenNewTab({ filename: f.path, code: f.code, language: inferFenceLang(f.fence, f.code) });
            }}
            onReplace={async () => {
              try {
                emitTelemetry('apply_replace', { lang: lang || null });
                const promptContext = code + (lang ? (`\nLANG:${lang}`) : '');
                const tokensApprox = estimateTokens(promptContext);
                await timeAndLog({ action: 'insert', model: selectedModel, tokensApprox, exec: async () => {
                  const { normalizeAssistantMessage } = await import('@/utils/ai/lang/normalizeOutput');
                  const { getLangSpec } = await import('@/utils/ai/lang/languageMap');
                  const selectedSpec = getLangSpec(selectedLanguage) || getLangSpec('javascript')!;
                  const { files } = normalizeAssistantMessage(
                    `\n\n\u002F\u002F\u002F\u002F file: ${fenceFilename || ''}\n\n\u0060\u0060\u0060${lang || ''}\n${code}\n\u0060\u0060\u0060`,
                    { selectedLang: selectedSpec, mode: (message?.mode as any) || (aiSettings.mode as any) || 'beginner' }
                  );
                  const f = files[0] || { code, fence: lang } as any;
                  const { tabId } = await replaceSelection({ code: f.code, language: inferFenceLang(f.fence, f.code) });
                  if (autoPreview && lang && /^(html?|css|javascript)$/.test(lang.toLowerCase())) {
                    const previewTokens = estimateTokens(code);
                    await timeAndLog({ action: 'preview', model: selectedModel, tokensApprox: previewTokens, exec: async () => await previewRun(tabId) });
                  }
                }});
                addNotification('success','Replaced selection',1500);
              } catch { addNotification('error','Replace failed – Retry?',4000); }
            }}
            onPreview={async () => {
              try {
                emitTelemetry('apply_preview', { lang: lang || null });
                const previewTokens = estimateTokens(code);
                await timeAndLog({ action: 'preview', model: selectedModel, tokensApprox: previewTokens, exec: async () => {
      const { normalizeAssistantMessage } = await import('@/utils/ai/lang/normalizeOutput');
      const { getLangSpec } = await import('@/utils/ai/lang/languageMap');
      const selectedSpec = getLangSpec(selectedLanguage) || getLangSpec('javascript')!;
    const { files } = normalizeAssistantMessage(
        `\n\n\u002F\u002F\u002F\u002F file: ${fenceFilename || ''}\n\n\u0060\u0060\u0060${lang || ''}\n${code}\n\u0060\u0060\u0060`,
  { selectedLang: selectedSpec, mode: (message?.mode as any) || (aiSettings.mode as any) || 'beginner' }
      );
      const f = files[0] || { path: fenceFilename || `snippet-${Date.now()}.${(lang||'txt')}`, code, fence: lang } as any;
      const { tabId } = await editorOpenNewTab({ filename: f.path, code: f.code, language: inferFenceLang(f.fence, f.code) });
                  await previewRun(tabId);
                }});
              } catch { addNotification('error','Preview failed – Retry?',4000); }
            }}
          />
        </React.Suspense>
      );
      lastIndex = match.index + full.length;
    }
    const remaining = content.slice(lastIndex);
    if (remaining) {
  const highlighted = applySearchHighlight(highlightInline(escapeHtml(remaining)));
      parts.push(<TextFlow key="t-end" dangerouslySetInnerHTML={{ __html: highlighted }} />);
    }
    if (parts.length === 0) {
  const highlighted = applySearchHighlight(highlightInline(escapeHtml(content)));
  return <TextFlow dangerouslySetInnerHTML={{ __html: highlighted }} />;
    }
    return <div>{parts}</div>;
  };

  // Copy All Messages Function
  const copyAllMessages = async () => {
    const allText = messages
      .map(msg => `${msg.type.toUpperCase()}: ${msg.content}`)
      .join('\n\n');
    
    try {
      await navigator.clipboard.writeText(allText);
      addNotification('success', 'All messages copied to clipboard!');
    } catch (error) {
      addNotification('error', 'Cannot access clipboard. Use HTTPS or allow clipboard permissions.');
    }
  };

  // Prompt 6 — Apply handler exists in EnhancedIDE command wiring.

  const addNotification = (type: 'success' | 'error' | 'warning' | 'info', message: string, duration = 3000) => {
    try { showToast({ kind: type, message, duration, contextKey: `ai:${type}:${message}` }); } catch {}
  };

  // removeNotification helper removed (inline closures handle dismissal)

  // Connection Status Management
  const updateConnectionStatus = (provider: string, status: 'connected' | 'disconnected' | 'testing' | 'error') => {
    setConnectionStatus(prev => ({ ...prev, [provider]: status }));
  };

  // API Response Time Tracking
  const trackApiResponseTime = (provider: string, startTime: number) => {
    const responseTime = Date.now() - startTime;
    setApiResponseTimes(prev => ({ ...prev, [provider]: responseTime }));
    return responseTime;
  };

  // Activity Tracking
  const updateActivity = () => {
    // Activity tracking logic can be added here if needed
  };

  // Prompt 6 — helper to extract first fenced code block
  function extractFirstFencedBlock(text: string) {
    const re = /(?:^|\n)(`{3,}|~{3,})([\w+-]*)[^\n]*\n([\s\S]*?)\1/m;
    const m = re.exec(text);
    return {
      languageFromFence: (m?.[2] || '').trim() || null,
      codeBlock: m?.[3] || null,
    } as { languageFromFence: string | null; codeBlock: string | null };
  }

  // Prompt 8 — small retry helper with jitter for transient errors
  const withRetries = useCallback((fn: () => Promise<unknown>, canRetry: (e:any)=>boolean, max=2): Promise<unknown> => {
    const run = async () => {
      let attempt = 0;
      for (;;) {
        try { return await fn(); }
        catch (e) {
          attempt++;
          if (attempt > max || !canRetry(e)) throw e;
          const base = 500 * Math.pow(2, attempt - 1);
          const jitter = Math.floor(Math.random() * 250);
          await new Promise(r => setTimeout(r, base + jitter));
        }
      }
    };
    return run();
  }, []);
  const isTransient = useCallback((e:any) => {
    try { const k = classifyError(e); return k==='rate'||k==='timeout'||k==='server'||k==='network'; }
    catch { return false; }
  }, []);

  // =========================
  // Prompt 6 — Selection actions runner
  // =========================
  function getActiveEditorLike() {
    const store = useEditorStore.getState();
    const tab = store.tabs.find((t: any) => t.id === store.activeTabId) || null;
    if (!tab) return null;
    return {
      filename: tab.name,
      language: tab.language,
      getValue: () => tab.content || '',
      getSelectionText: () => {
        // current store doesn’t persist granular selections; fallback to full file
        return '';
      },
      replaceSelection: async (text: string) => {
        await replaceSelection({ code: text, language: inferFenceLang(tab.language, text) });
      },
    };
  }

  async function runAiOnSelection(action: AiSelectionAction) {
    const active = getActiveEditorLike();
    if (!active) {
      addNotification('warning', 'No active editor.');
      return;
    }
    const filename = active.filename || 'untitled';
    const fullContent = active.getValue();
    const sel = active.getSelectionText();
    const hasSel = !!sel && sel.trim().length > 0;
    if (!hasSel && (action === 'improve' || action === 'commentize')) {
      addNotification('warning', 'Select some code first.');
      return;
    }
    const code = hasSel ? sel : fullContent;
    const lang = detectLangFromFilename(filename) || active.language || '';
    const settings = aiSettings; // already synced with center store
  const system = buildSystemPrompt({ mode: settings.mode as any, preset: null, pinnedContext: loadPinnedContext() });
  const user = buildSelectionUserPrompt({ action: action as any, code, lang, mode: settings.mode });

    // Use streaming pipeline but buffer result; preserves resilience
    const selectedModelData = aiModels.find(m => m.id === (settings.modelId || selectedModel)) || aiModels.find(m => m.id === selectedModel) || aiModels[0];
    if (!selectedModelData) {
      addNotification('error', 'No model selected.');
      return;
    }
  let output = '';
  let streamed = 0;
  // Telemetry locals for selection action
  let selRetryCount = 0;
  let selFallbackModel: string | null = null;
  const selT0 = tStart();
    const provider = selectedModelData.provider as 'openai' | 'anthropic' | 'google' | 'ollama';
    const modelId = selectedModelData.id;
  addNotification('info', `AI ${action === 'improve' ? 'refactor' : action === 'commentize' ? 'comments' : 'explain'}…`);

  const doOnce = async (mid: string) =>
      await new Promise<void>((resolve, reject) => {
        let idleTimer: any = null;
        const hardTimer = setTimeout(() => {
          abortStreaming('request_timeout');
        }, timeouts.hardMs);
        const armIdle = () => {
          if (idleTimer) clearTimeout(idleTimer);
          idleTimer = setTimeout(() => abortStreaming('idle_timeout'), timeouts.idleMs);
        };
        armIdle();
  startStreaming({
          provider,
          modelId: mid,
          systemPrompt: system,
          prompt: redactOutbound(user),
          onDelta: chunk => {
            streamed += chunk.length;
            output += chunk;
            armIdle();
          },
          onComplete: () => {
            clearTimeout(hardTimer);
            if (idleTimer) clearTimeout(idleTimer);
            resolve();
          },
          onError: err => {
            clearTimeout(hardTimer);
            if (idleTimer) clearTimeout(idleTimer);
            reject(err);
          }
  }, { groupKey: 'assistant', autoAbortOnVisibilityChange: false });
      });

  try {
    // start telemetry event
    recordTelemetry({ phase: 'selection_action', ts: Date.now(), modelId, mode: aiSettings.mode, action, ok: true });
    await doOnce(modelId);
    } catch (e: any) {
      const info = classifyProviderError(e);
      const canTryFallback = ALLOW_MODEL_FALLBACK && streamed === 0 && (info.type === 'not_found' || info.type === 'bad_request');
      if (canTryFallback) {
        const fb = selectFallbackModel(modelId, provider);
        if (fb) {
          selFallbackModel = fb;
          await doOnce(fb);
        } else {
          throw e;
        }
      } else if (streamed === 0 && info.retryable) {
  await new Promise(r => setTimeout(r, timeouts.retryBackoffMs));
        try {
          selRetryCount += 1;
          await doOnce(modelId);
        } catch (e2: any) {
          if (ALLOW_MODEL_FALLBACK && streamed === 0) {
            const fb = selectFallbackModel(modelId, provider);
            if (fb) {
              selFallbackModel = fb;
              await doOnce(fb);
            } else throw e2;
          } else throw e2;
        }
      } else {
        throw e;
      }
    }

    const result = output.trim();
    // Emit telemetry completion for selection action
    try {
      const elapsed = tEnd(selT0);
      const estTok = estimateTokens(output || '');
      const tps = estTok > 0 ? (estTok / (elapsed / 1000)) : 0;
      recordTelemetry({
        phase: 'selection_action', ts: Date.now(), modelId, mode: aiSettings.mode, action,
        elapsedMs: elapsed, streamedChars: streamed, estTokens: estTok, tokensPerSec: Math.round(tps * 10) / 10,
        retryCount: selRetryCount, fallbackModelId: selFallbackModel, ok: true,
      });
    } catch {}

    if (action === 'explain') {
      await editorOpenNewTab({ filename: `[AI] Explain — ${filename}.md`, code: result, language: 'markdown' as any });
      addNotification('success', 'Explanation generated.');
      return;
    }
    const { codeBlock, languageFromFence } = extractFirstFencedBlock(result);
    const improved = (codeBlock || result || '').trim();
    if (!improved) {
      addNotification('error', 'AI returned no code.');
      return;
    }
    const langToUse = languageFromFence || lang;
    const pref = settings.defaultInsert;
    if (pref === 'new-tab') {
      await editorOpenNewTab({ filename: `[AI] ${action === 'improve' ? 'Improved' : 'Commented'} — ${filename}`, code: improved, language: inferFenceLang(langToUse, improved) });
      addNotification('success', 'Opened AI suggestion in a new tab.');
    } else if (pref === 'replace') {
      await replaceSelection({ code: improved, language: inferFenceLang(langToUse, improved) });
      addNotification('success', 'Selection replaced. (Undo available)');
    } else {
      await insertIntoActive({ code: improved, language: inferFenceLang(langToUse, improved) });
      addNotification('success', 'Inserted AI suggestion. (Undo available)');
    }
  }

  // Expose for palette
  useEffect(() => {
    (window as any).synapseRunAiOnSelection = runAiOnSelection;
    return () => {
      try {
        delete (window as any).synapseRunAiOnSelection;
      } catch {}
    };
  }, [aiSettings, selectedModel, providerKeys]);

  // Check if API key is available for selected model
  const isModelAvailable = (model: typeof aiModels[0]) => {
  switch (model.provider) {
      case 'openai':
    return !!providerKeys.openai;
      case 'anthropic':
    return !!providerKeys.anthropic;
      case 'google':
    return !!providerKeys.google;
      case 'ollama':
    return !!providerKeys.ollama;
      default:
        return false;
    }
  };

  // Compute Ollama base URL (proxy when using localhost)
  const getOllamaBase = () => {
  const configured = providerKeys.ollama || 'http://localhost:11434';
  // If user accidentally set a generic /api base, prefer the dedicated /ollama proxy
  if (/^\/api(\/|$)/.test(configured)) return '/ollama';
  const isLocalDefault = /localhost:11434\/?$/.test(configured);
  return isLocalDefault && typeof window !== 'undefined' ? '/ollama' : configured;
  };

  // One-shot summarization (non-UI, best-effort). Runs without blocking main send.
  const summarizeThread = async (provider: string, modelId: string, payload: { system: string; user: string; keepTailFromIndex: number; }): Promise<string> => {
    try {
      // Use a separate AbortController so this never gets canceled by chat aborts
      const ac = new AbortController();
      const signal = ac.signal;
      // Hard cap for summary only
  const t = setTimeout(() => ac.abort(), timeouts.hardMs);
    // Redact outbound system/user content
    const sys = redactOutbound(payload.system);
    const usr = redactOutbound(payload.user);

      if (provider === 'openai') {
  const apiKey = providerKeys.openai; if (!apiKey) return '';
        // Send the selected model id as-is; rely on runtime fallback for unsupported models
        const effective = modelId;
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({ model: effective, messages: [ { role: 'system', content: sys }, { role: 'user', content: usr } ], temperature: 0.2, stream: false }),
          signal
        });
  if (!res.ok) { clearTimeout(t); return ''; }
        const data = await res.json();
  clearTimeout(t);
        return data.choices?.[0]?.message?.content || '';
      }
      if (provider === 'anthropic') {
  const apiKey = providerKeys.anthropic; if (!apiKey) return '';
        const userPrompt = `${sys}\n\n${usr}`;
        const res = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({ model: modelId, max_tokens: 800, messages: [{ role: 'user', content: userPrompt }] }),
          signal
        });
  if (!res.ok) { clearTimeout(t); return ''; }
        const data = await res.json();
  clearTimeout(t);
        return data.content?.[0]?.text || '';
      }
      if (provider === 'google') {
  const apiKey = providerKeys.google; if (!apiKey) return '';
        const userPrompt = `${sys}\n\n${usr}`;
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent?key=${apiKey}`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ parts: [{ text: userPrompt }] }], generationConfig: { maxOutputTokens: 900, temperature: 0.2 } }),
          signal
        });
  if (!res.ok) { clearTimeout(t); return ''; }
        const data = await res.json();
  clearTimeout(t);
        return data.candidates?.[0]?.content?.parts?.[0]?.text || '';
      }
      if (provider === 'ollama') {
        const base = getOllamaBase();
        const userPrompt = `${sys}\n\n${usr}`;
        const res = await fetch(`${base}/api/generate`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model: modelId, prompt: userPrompt, stream: false }), signal });
        if (!res.ok) { clearTimeout(t); return ''; }
        const data = await res.json();
        clearTimeout(t);
        return data.response || '';
      }
      clearTimeout(t);
      return '';
    } catch { return ''; }
  };

  // --- Thread summary scheduler (debounced, cancelable, race-safe) ---
  type SummaryRunResult = { text: string; keepTailFromIndex?: number };
  const summaryTimers = useRef(new Map<string, ReturnType<typeof setTimeout>>());
  const summaryVersionRef = useRef(new Map<string, number>());

  const cancelThreadSummary = useCallback((threadId: string) => {
    const h = summaryTimers.current.get(threadId);
    if (h) {
      try { clearTimeout(h); } catch {}
      summaryTimers.current.delete(threadId);
    }
    // keep version; last-writer-wins via bumping on next schedule
  }, []);

  const scheduleThreadSummary = useCallback((opts: {
    threadId: string;
    getState: () => { messages: any[] } | any;
    runSummary: () => Promise<SummaryRunResult>;
    delayMs?: number;
  }) => {
    const { threadId, getState, runSummary } = opts;
    const delayMs = Math.max(250, opts.delayMs ?? 1500);

    // bump version
    const currentVer = summaryVersionRef.current.get(threadId) ?? 0;
    const nextVersion = currentVer + 1;
    summaryVersionRef.current.set(threadId, nextVersion);

    // clear pending debounce
    const prev = summaryTimers.current.get(threadId);
    if (prev) {
      try { clearTimeout(prev); } catch {}
      summaryTimers.current.delete(threadId);
    }

    const handle = setTimeout(async () => {
      try {
        // only latest scheduled run proceeds
        if (summaryVersionRef.current.get(threadId) !== nextVersion) return;

        const state = getState?.() ?? {};
        const messages: any[] = Array.isArray(state?.messages) ? state.messages : [];
        if (!messages.length) return;

        // Optional gate: last assistant reply must be non-trivial
        const last = messages[messages.length - 1];
        const lastText: string = (last && typeof last.content === 'string') ? last.content : '';
        if (lastText.length < 40) return;

        // run summary (non-blocking to chat UI)
        const t0 = Date.now();
        const { text, keepTailFromIndex } = await runSummary();
        const nextSummary = (text || '').trim();
        if (!nextSummary) return;

        // Write back safely; preserve rest of thread shape
        replaceThread(threadId, (t) => ({
          ...t,
          summary: (((t as any).summary ? String((t as any).summary) + '\n\n' : '') + nextSummary).trim(),
          ...(typeof keepTailFromIndex === 'number' ? { messages: (t as any).messages?.slice(keepTailFromIndex) } : {}),
        }));
        try { recordTelemetry?.({ phase: 'summary_run', ts: Date.now(), elapsedMs: Date.now() - t0, ok: true }); } catch {}
      } catch (err) {
        try { console.warn('[summary] failed:', err); } catch {}
        try { recordTelemetry?.({ phase: 'summary_error', ts: Date.now(), ok: false, note: 'silent summary failed' }); } catch {}
      } finally {
        summaryTimers.current.delete(threadId);
      }
    }, delayMs);

    summaryTimers.current.set(threadId, handle);
  }, []);

  // Fetch available Ollama models with status tracking
  const fetchOllamaModels = async () => {
    if (!providerKeys.ollama) return;
    const base = getOllamaBase();
    updateConnectionStatus('ollama', 'testing');
    const t0 = Date.now();
    try {
      const response = await fetch(`${base}/api/tags`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      const modelNames = data.models?.map((m: any) => m.name) || [];
      setOllamaModels(modelNames);
      const ms = trackApiResponseTime('ollama', t0);
      updateConnectionStatus('ollama', 'connected');
      addNotification('success', `Ollama connected (${ms}ms)`, 2000);
    } catch (e: any) {
      updateConnectionStatus('ollama', 'error');
      addNotification('error', `Ollama models fetch failed: ${e?.message || 'Unknown error'}`, 4000);
    }
  };

  // Provider Health Check (lightweight connectivity checks)
  /* const runHealthCheck = async () => {
    const checks: Promise<void>[] = [];

    // OpenAI
  if (providerKeys.openai) {
      updateConnectionStatus('openai', 'testing');
      const t0 = Date.now();
      checks.push((async () => {
        try {
          const res = await fetch('https://api.openai.com/v1/models?limit=1', {
            headers: { Authorization: `Bearer ${providerKeys.openai}` }
          });
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const ms = trackApiResponseTime('openai', t0);
          updateConnectionStatus('openai', 'connected');
          addNotification('success', `OpenAI reachable (${ms}ms)`, 2000);
        } catch (e: any) {
          updateConnectionStatus('openai', 'error');
          addNotification('error', `OpenAI check failed: ${e?.message || 'Unknown error'}`, 4000);
        }
      })());
    }

    // Anthropic (best-effort)
  if (providerKeys.anthropic) {
      updateConnectionStatus('anthropic', 'testing');
      const t0 = Date.now();
      checks.push((async () => {
        try {
          const res = await fetch('https://api.anthropic.com/v1/models', {
            headers: {
              'x-api-key': providerKeys.anthropic,
              'anthropic-version': '2023-06-01'
            }
          });
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const ms = trackApiResponseTime('anthropic', t0);
          updateConnectionStatus('anthropic', 'connected');
          addNotification('success', `Anthropic reachable (${ms}ms)`, 2000);
        } catch (e: any) {
          updateConnectionStatus('anthropic', 'error');
          addNotification('error', `Anthropic check failed: ${e?.message || 'Unknown error'}`, 4000);
        }
      })());
    }

    // Google (Gemini) best-effort
  if (providerKeys.google) {
      updateConnectionStatus('google', 'testing');
      const t0 = Date.now();
      checks.push((async () => {
        try {
          const res = await fetch(`https://generativelanguage.googleapis.com/v1/models?key=${encodeURIComponent(providerKeys.google)}`);
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const ms = trackApiResponseTime('google', t0);
          updateConnectionStatus('google', 'connected');
          addNotification('success', `Google reachable (${ms}ms)`, 2000);
        } catch (e: any) {
          updateConnectionStatus('google', 'error');
          addNotification('error', `Google check failed: ${e?.message || 'Unknown error'}`, 4000);
        }
      })());
    }

    // Ollama
  if (providerKeys.ollama) {
      const base = getOllamaBase();
      updateConnectionStatus('ollama', 'testing');
      const t0 = Date.now();
      checks.push((async () => {
        try {
          const ping = await fetch(`${base}/api/version`);
          if (!ping.ok) throw new Error(`HTTP ${ping.status}`);
          await fetchOllamaModels();
          const ms = trackApiResponseTime('ollama', t0);
          updateConnectionStatus('ollama', 'connected');
          addNotification('success', `Ollama connected (${ms}ms)`, 2000);
        } catch (e: any) {
          updateConnectionStatus('ollama', 'error');
          addNotification('error', `Ollama check failed: ${e?.message || 'Unknown error'}`, 4000);
        }
      })());
    }

    if (checks.length === 0) {
      addNotification('info', 'No providers configured. Add API keys or Ollama URL first.', 3000);
      return;
    }
    await Promise.all(checks);
  }; */

  // Get filtered languages by category
  const getFilteredLanguages = () => {
    if (languageCategory === 'all') return languages;
    return languages.filter(lang => lang.category === languageCategory);
  };

  // Get filtered models by provider and availability
  const getFilteredModels = () => {
  let filtered = [...aiModels];
    
    // Add dynamically fetched Ollama models
    if (ollama.length > 0) {
      const dynamicOllamaModels = ollama.map(modelName => ({
        id: modelName,
        name: modelName,
        provider: 'ollama' as const,
        description: `Local Ollama model: ${modelName}`,
        contextLength: 'Variable',
        strengths: ['Local', 'Privacy', 'No API costs', 'Fast']
      }));
      
      // Remove static Ollama models that aren't actually installed
      filtered = filtered.filter(model => 
        model.provider !== 'ollama' || ollama.includes(model.id)
      );
      
      // Add dynamic Ollama models that aren't already in the static list
      dynamicOllamaModels.forEach(dynamicModel => {
        if (!filtered.find(model => model.id === dynamicModel.id)) {
          filtered.push(dynamicModel);
        }
      });
    } else {
      // If no Ollama models fetched yet, keep curated static Ollama entries visible
      // so the user knows local options exist and can trigger a refresh.
    }
    
    if (modelProvider !== 'all') {
  // Always allow ollama dynamic models to show when provider=ollama OR when provider filter mismatched but user selected an ollama model
  filtered = filtered.filter(model => model.provider === modelProvider || (model.provider === 'ollama' && selectedModel === model.id));
    }

    // STEP 6: apply MODEL_OPTIONS filtering (hide hidden unless selected)
    const visibleIds = new Set(
      MODEL_OPTIONS.filter(opt => !opt.hidden || selectedModel === opt.id).map(o => o.id)
    );
  // Keep dynamic/local Ollama models even if not declared in MODEL_OPTIONS (they're discovered at runtime)
  filtered = filtered.filter(m => visibleIds.has(m.id) || m.provider === 'ollama');

    return filtered;
  };

  // Group models by provider with badges (using MODEL_OPTIONS metadata)
  const getGroupedModels = () => {
    const byProvider: Record<string, ReturnType<typeof getFilteredModels>> = {} as any;
    getFilteredModels().forEach(m => {
      if (!byProvider[m.provider]) byProvider[m.provider] = [] as any;
      byProvider[m.provider].push(m);
    });
    return byProvider;
  };

  // Get available providers based on API keys
  const getAvailableProviders = () => {
    const providers = ['all'];
  if (providerKeys.openai) providers.push('openai');
  if (providerKeys.anthropic) providers.push('anthropic');
  if (providerKeys.google) providers.push('google');
  if (providerKeys.ollama) providers.push('ollama'); // show provider always if endpoint configured
    return providers;
  };

  // provider API calls centralized in useAiStreaming hook

  // (legacy provider functions removed after central streaming hook introduction)

  // Naive language intent detector from prompt text (fences, keywords, extensions)
  const detectLanguageIntent = (text: string): string | null => {
    try {
      // code fence language
      const fence = text.match(/```\s*([a-zA-Z0-9#+-]+)/);
      if (fence && fence[1]) return fence[1].toLowerCase();
      const lower = text.toLowerCase();
      const table: Record<string, string[]> = {
        javascript: ['javascript', 'js', '.js', 'node.js', 'nodejs'],
        typescript: ['typescript', 'ts', '.ts'],
        python: ['python', 'py', '.py'],
        java: ['java', '.java'],
        csharp: ['c#', 'csharp', '.cs'],
        cpp: ['c++', 'cpp', '.cpp', '.cc', '.cxx'],
        c: ['c ', ' c\n', '.c'],
        go: ['golang', 'go ', ' go\n', '.go'],
        rust: ['rust', '.rs'],
        php: ['php', '.php'],
        ruby: ['ruby', '.rb'],
        swift: ['swift', '.swift'],
        kotlin: ['kotlin', '.kt'],
        scala: ['scala', '.scala'],
      };
      for (const [lang, keys] of Object.entries(table)) {
        if (keys.some(k => lower.includes(k))) return lang;
      }
      return null;
    } catch { return null; }
  };

  const handleSendMessage = async () => {
    // Reentrancy guard: ignore while typing or streaming
    if (isTyping || streamState.isStreaming) return;
  if (flags.aiTrace) logger.info('[SEND_CLICK]', 'isTyping=', String(isTyping), 'isStreaming=', String(streamState.isStreaming));
    const source = (overrideContentRef.current ?? input);
    const raw = source.replace(/[ \t]+$/gm, '').trim();
    if (!raw || isTyping) return;

    // Resolve effective model (do not mutate yet)
    const effectiveModelId = pickEffectiveModel(selectedModel, aiSettings);

    // Parse optional inline preset directive
    let finalContent = raw;
    let directivePresetId: string | null = null;
    const dirMatch = finalContent.match(/^\s*preset:([a-zA-Z0-9-_]+)\s*/i);
    if (dirMatch) {
      directivePresetId = dirMatch[1];
      finalContent = finalContent.slice(dirMatch[0].length);
    }

    // Validate model/provider compatibility and keys before doing anything visible
    try {
      const selectedForValidation = getFilteredModels().find(m => m.id === (effectiveModelId || selectedModel));
      const provider = (selectedForValidation?.provider || (advSettings as any)?.provider) as any;
      if (provider) {
        const v = validateSelection(provider, effectiveModelId || selectedModel, 'chat_stream');
        if (!v.ok) {
          const alt = (v.alternatives || []).map(a => a.label).slice(0, 3).join(', ');
          const msg = v.reason + (alt ? ` Try: ${alt}` : '');
          showToast({
            kind: 'warning',
            contextKey: 'model-compat',
            title: 'Model seçimi bu işlemle uyumlu değil',
            message: msg || 'Seçilen model bu akışta desteklenmiyor. Ayarlar → Model seçin veya önerilenlerden birini kullanın.'
          });
          return;
        }
      }
    } catch {}

    // (A) Append user bubble immediately (unless suppressed for queued sends)
    if (!suppressNextUserAppendRef.current) {
      const userMessage = makeUserMessage(finalContent, effectiveModelId, selectedLanguage);
      appendMessagesDeferred([userMessage]);
      if (flags.aiTrace) logger.debug('[USER_BUBBLE_APPENDED]', 'len=', String(finalContent.length));
      scrollToBottom();
  setInput('');
  scheduleAdjustTextarea();
    }
    // Reset overrides after we've captured content
    overrideContentRef.current = null;
    suppressNextUserAppendRef.current = false;

  // (B) Abort previous stream if any
  if (streamState.isStreaming) {
      if (flags.aiTrace) logger.warn('[ABORT_PREVIOUS_STREAM]', 'reason=new_request');
    // Capture the current streaming message id to finalize its state after abort
  const prevActiveId = currentStreamingMsgIdRef.current;
    try { await abortStreaming('new_request'); } catch {}
      // Centralized UI finalization
      try {
  if (prevActiveId) safeReplaceMessage(prevActiveId, (m) => ({ ...m, isStreaming: false } as Message));
        if (currentStreamingMsgIdRef.current === prevActiveId) currentStreamingMsgIdRef.current = null;
  try { activeMsgByThreadRef.current.delete(projectIdRef.current || 'default'); } catch {}
        clearFlushTimer();
        flushStreamBuffer();
        clearIdleTimeout();
        if (isMountedRef.current) setIsTyping(false);
      } catch {}
      addNotification('info', 'Canceled previous response');
  try { emitTelemetry('send_abort', { reason: 'new_request' }); } catch {}
  await new Promise(r => setTimeout(r, 80));
    }

  updateActivity();
  const selectedModelData = getFilteredModels().find(m => m.id === (effectiveModelId || selectedModel));
  const modelMeta = selectedModelData ? { id: selectedModelData.id, name: selectedModelData.name, provider: selectedModelData.provider } : null;

    // Warn if prompt language intent mismatches selected language (non-blocking)
    try {
      const intent = detectLanguageIntent(finalContent);
      if (intent && selectedLanguage && intent !== selectedLanguage.toLowerCase()) {
        appendMessagesDeferred([makeSystemMessage(`The requested language (${intent}) doesn\'t match the selected language (${selectedLanguage}). I\'ll answer in ${selectedLanguage}.`)]);
        addNotification('warning', "Prompt language doesn't match the selected language; the response will use the selected language.", 3500);
      }
    } catch {}
    const currentInput = finalContent;
    // If we used a preset, clear it for subsequent messages (user can reselect)
    if (activePreset) {
      // activePreset preserved; no removal from localStorage for usability
    }
    // (C) Validate environment for streaming
    if (!isOnline()) {
      const note = 'You appear to be offline. Your message was queued and will send when you reconnect.';
      appendMessagesDeferred([makeSystemMessage(note)]);
      setLastSystemNote(note);
      // Queue the content for later
  enqueueOffline({ content: finalContent, lang: selectedLanguage, ...(effectiveModelId ? { model: effectiveModelId } : {}) });
      scrollToBottom();
      return;
    }

    // Centralized model/key guard
    {
      const guardMsg = guardModelAndKeys(
        modelMeta ? ({ provider: modelMeta.provider } as any) : null,
        effectiveModelId
      );
      if (guardMsg) {
        appendMessagesDeferred([makeSystemMessage(guardMsg)]);
        setLastSystemNote(guardMsg);
        scrollToBottom();
        return;
      }
    }

  // modelMeta is guaranteed from here on; use a narrowed alias to avoid non-null assertions
  const assuredModel = modelMeta as { id: string; name: string; provider: typeof modelMeta extends infer T ? T extends { provider: infer P } ? P : any : any };

  setIsTyping(true);
  // a11y removed

  // Track API call start time
  const startTime = Date.now();
  // selectedModelData is defined by validation above
  updateConnectionStatus(assuredModel.provider as any, 'testing');

  try {
  if (flags.aiTrace) logger.info('[REQUEST_INIT]', 'provider=', String(assuredModel.provider), 'model=', String(assuredModel.id));
      // Preflight: if provider is ollama, check endpoint and suggest pulling models when needed
  if (assuredModel.provider === 'ollama') {
        const configured = providerKeys.ollama || 'http://localhost:11434';
        const isLocalDefault = /localhost:11434\/?$/.test(configured);
        const base = isLocalDefault && typeof window !== 'undefined' ? '/ollama' : configured;
        try {
          const ping = await fetch(`${base}/api/version`, { method: 'GET' });
          if (!ping.ok) throw new Error(`HTTP ${ping.status}`);
        } catch (e) {
          addNotification('error', 'Ollama is not reachable at the configured URL. Ensure Ollama is running (default http://localhost:11434).', 5000);
          throw e;
        }
      }
  const responseTime = trackApiResponseTime(assuredModel.provider, startTime);
  updateConnectionStatus(assuredModel.provider, 'connected');
  const newMsgId = uuid();
  // Conversation continuity: load thread (summarization is deferred to post-success)
      const projectId = projectIdRef.current || 'default';
      let thread = loadThread(projectId);
  // Cancel any pending summary for this thread while a new stream begins
  try { cancelThreadSummary(projectId); } catch {}
    // Freeze mode at send time (per-request) and append user to thread
    const frozenMode: 'beginner' | 'pro' = (aiSettings.mode as any) || (beginnerMode ? 'beginner' : 'pro');
    thread = appendToThread(projectId, { role: 'user', content: currentInput, ts: Date.now(), modelId: aiSettings.modelId || selectedModel, mode: frozenMode });
  let aggregated = '';
  currentStreamingMsgIdRef.current = newMsgId;
      // Map active message for this thread to guard overlapping streams
      activeMsgByThreadRef.current.set(projectId, newMsgId);
  appendMessagesDeferred([makeAiPlaceholder(effectiveModelId, selectedLanguage, frozenMode, newMsgId)]);
      scrollToBottom();
      // Start idle timeout monitoring for streaming
      armIdleTimeout();
  addNotification('success', `Streaming from ${assuredModel.name} (${responseTime}ms)` ,1500);
      // Compose system prompt using mode + preset + summary + pinned context
  const inlinePreset = directivePresetId ? findPresetById(aiSettings.mode, directivePresetId) : null;
      const resolvedPreset = inlinePreset ?? findPresetById(aiSettings.mode, activePreset);
      const pinned = loadPinnedContext();
    let systemPrompt = buildSystemPrompt({ mode: frozenMode, preset: resolvedPreset ?? null, pinnedContext: [] });
      // Enforce target language and output style for pro behavior
      if (selectedLanguage) {
        const fenceLang = selectedLanguage.toLowerCase();
        systemPrompt += `\n\nOutput requirements:\n- Target programming language: ${selectedLanguage}.\n- When the user requests code or when code is the best answer, respond primarily with a single fenced code block using \`\`\`${fenceLang}\`\`\`.\n- Keep explanations minimal unless explicitly requested; prioritize complete, runnable code.\n- If the user asks a different language, still prefer ${selectedLanguage} unless explicitly told otherwise.`;
      }
      if (thread.summary) {
        systemPrompt += `\n\nConversation summary:\n${thread.summary}`;
      }
      if (pinned.length) {
        systemPrompt += `\n\nPinned context:\n- ${pinned.join('\n- ')}`;
      }

      // Soft-limit warning on prompt size (~75% of context)
      try {
        const approx = estimateTokens(`${systemPrompt  }\n\n${  finalContent}`);
        if (approx > Math.floor(CONTEXT_BUDGET_TOKENS * 0.75)) {
          // Show non-blocking toast; require user to click Continue
          let proceed = false;
          await new Promise<void>((resolve) => {
            showToast({
              kind: 'warning',
              title: 'Large prompt',
              message: `~${approx} tokens. Continue?`,
              duration: -1,
              contextKey: 'prompt:large',
              action: { label: 'Continue', onClick: () => { proceed = true; resolve(); } }
            });
          });
          if (!proceed) {
            const msg = 'Canceled by user due to large prompt.';
            appendMessagesDeferred([makeSystemMessage(msg)]);
            setLastSystemNote(msg);
            // Ensure any pre-appended assistant placeholder exits streaming state
            try { safeReplaceMessage(newMsgId, (m) => ({ ...m, isStreaming: false } as Message)); } catch {}
            try { clearActiveStreamIfMatches(newMsgId); } catch {}
            try { clearIdleTimeout(); } catch {}
            try { clearFlushTimer(); } catch {}
            setIsTyping(false);
            return;
          }
        }
      } catch {}

  const buildPrompt = () => {
        try {
          const margin = 1500; // leave space for response
          const reversed = [...thread.messages].reverse();
          const acc: { role: string; content: string }[] = [];
          let used = estimateTokens(systemPrompt);
          for (const m of reversed) {
            const safe = (m.role === 'user' || m.role === 'assistant') ? redactOutbound(m.content) : m.content;
            const line = `[${m.role}] ${safe}\n`;
            const cost = estimateTokens(line);
            if (used + cost > (CONTEXT_BUDGET_TOKENS - margin)) break;
            acc.push({ role: m.role, content: safe });
            used += cost;
          }
          acc.reverse();
          const historyBlob = acc.map(m => `[${m.role}] ${m.content}`).join('\n');
          return (historyBlob ? `${historyBlob  }\n\n` : '') + redactOutbound(currentInput);
        } catch { return currentInput; }
      };

  const clearTimers = () => {
        if (idleTimerRef.current) { clearTimeout(idleTimerRef.current); idleTimerRef.current = null; }
        if (hardTimerRef.current) { clearTimeout(hardTimerRef.current); hardTimerRef.current = null; }
      };
      // Normalize timeouts for this request
      const normalized = sanitizeTimeouts(timeouts as any);
      sanitizedTimeoutsRef.current = normalized;
      const armIdle = () => {
        if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
        if (!streamState.isStreaming) return;
        idleTimerRef.current = window.setTimeout(() => {
          try { abortStreaming('idle_timeout'); } finally { /* UI finalization centralized */ }
        }, normalized.idleMs) as unknown as ReturnType<typeof window.setTimeout>;
      };
      const armHard = () => {
        if (hardTimerRef.current) clearTimeout(hardTimerRef.current);
        if (!streamState.isStreaming) return;
        hardTimerRef.current = window.setTimeout(() => {
          try { abortStreaming('request_timeout'); } finally { /* UI finalization centralized */ }
        }, normalized.hardMs) as unknown as ReturnType<typeof window.setTimeout>;
      };
      const wait = (ms: number) => new Promise(res => setTimeout(res, ms));

  // Telemetry start of main request
  telReqT0Ref.current = tStart();
      telCharsRef.current = 0;
      telRetryRef.current = 0;
      telFallbackModelRef.current = null;
  flushCountRef.current = 0;
  emitTelemetry('send_start', { model: assuredModel.id });
      recordTelemetry({
        phase: 'chat_start', ts: Date.now(), modelId: aiSettings.modelId || null, mode: aiSettings.mode,
        action: (directivePresetId ? `preset:${directivePresetId}` : (activePreset ? `preset:${activePreset}` : 'chat')),
        summarization: telSummElapsedRef.current
          ? { triggered: true, elapsedMs: telSummElapsedRef.current }
          : { triggered: false },
      });

  let firstTokenAt: number | null = null;
  const sendOnce = (modelIdToUse: string) => new Promise<string>((resolve, reject) => {
        let settled = false;
  streamedCharsRef.current = 0;
  aggregated = '';
        const to = sanitizedTimeoutsRef.current;
        // Unified abort finalizer used by all paths
        const finalizeAbort = (reason: 'idle_timeout' | 'request_timeout' | 'user_abort' | 'network_error') => {
          try { clearTimers(); } catch {}
          try { clearFlushTimer(); } catch {}
          try { flushStreamBuffer(); } catch {}
          try { clearIdleTimeout(); } catch {}
          if (isMountedRef.current) setIsTyping(false);
          try { safeReplaceMessage(newMsgId, (m) => ({ ...m, isStreaming: false } as Message)); } catch {}
          try { if (currentStreamingMsgIdRef.current === newMsgId) currentStreamingMsgIdRef.current = null; } catch {}
          // Ensure no pending summary runs for non-success reasons
          try { cancelThreadSummary(projectId); } catch {}
          // Toast throttling
          try {
            const now = Date.now();
            if (!lastAbortToastAtRef.current || now - lastAbortToastAtRef.current > 10000) {
              const text = reason === 'idle_timeout'
                ? 'Connection stalled; request aborted (idle timeout).'
                : reason === 'request_timeout'
                ? 'Request took too long and was aborted.'
                : reason === 'user_abort'
                ? 'Generation stopped.'
                : 'Network error; generation aborted.';
              addNotification(reason === 'idle_timeout' || reason === 'request_timeout' ? 'warning' : 'info', text);
              lastAbortToastAtRef.current = now;
            }
          } catch {}
          try { emitTelemetry('send_abort', { reason, idleMs: to.idleMs, hardMs: to.hardMs }); } catch {}
        };
  // openFence tracking handled within applyChunkToLastAssistantMessage during streaming
  // reset message content for retry or fallback
  safeReplaceMessage(newMsgId, (m) => ({
    ...m,
  content: (frozenMode === 'beginner') ? "(Beginner Mode Enabled)\n" : '',
  streamedContent: (frozenMode === 'beginner') ? "(Beginner Mode Enabled)\n" : '',
    openFence: null,
    model: modelIdToUse
  } as Message));
        armIdle(); armHard();
        // Bind per-frame delta processor now that scoped vars are ready
        processDeltaRef.current = (chunk: string) => {
          if (!chunk) return;
          if (firstTokenAt === null) {
            try { firstTokenAt = performance.now(); } catch { firstTokenAt = 0; }
            if (flags.aiTrace) logger.info('[FIRST_DELTA]');
          }
          if (flags.aiTrace) logger.debug('[DELTA]', 'n=', String(chunk.length));
          // a11y removed: no announce
          streamedCharsRef.current += chunk.length;
          telCharsRef.current += chunk.length;
          aggregated += chunk;
          // Append to buffer and schedule rAF flush
          streamBufferRef.current += chunk;
          flushStreamBuffer();
        };
  startStreaming({
          provider: assuredModel.provider as any,
          modelId: modelIdToUse,
          prompt: buildPrompt(),
          systemPrompt,
          temperature: typeof aiSettings.temperature === 'number' ? aiSettings.temperature : undefined,
          topP: typeof aiSettings.topP === 'number' ? aiSettings.topP : undefined,
          seed: typeof aiSettings.seed !== 'undefined' ? aiSettings.seed as any : undefined,
          onDelta: (delta) => { enqueueDelta(delta || ''); },
          onComplete: (full) => {
            if (settled) return; settled = true;
            clearTimers();
            clearFlushTimer();
            flushStreamBuffer();
            clearIdleTimeout();
            if (isMountedRef.current) setIsTyping(false);
            // Mark the assistant message as finished streaming
            // Only finalize if this id is still the active one for this thread
            if (activeMsgByThreadRef.current.get(projectId) === newMsgId) {
              safeReplaceMessage(newMsgId, (m) => ({ ...m, isStreaming: false }));
            }
            // Clear active streaming id on successful completion
            try { clearActiveStreamIfMatches(newMsgId); } catch {}
            try { activeMsgByThreadRef.current.delete(projectId); } catch {}
            // Schedule a debounced background thread summary (success only)
            try {
              const threadId = projectId;
              scheduleThreadSummary({
                threadId,
                getState: () => ({ messages: loadThread(threadId)?.messages || [] }),
                runSummary: async () => {
                  const th = loadThread(threadId);
                  if (!th) return { text: '' };
                  const payload = buildSummaryRequestPayload(th);
                  telSummT0Ref.current = tStart();
                  const text = await summarizeThread(assuredModel.provider as any, assuredModel.id, payload);
                  telSummElapsedRef.current = tEnd(telSummT0Ref.current);
                  return { text, keepTailFromIndex: payload.keepTailFromIndex };
                },
                delayMs: 1500,
              });
            } catch {}
            // a11y removed
            if (flags.aiTrace) logger.info('[STREAM_DONE]');
            try { emitTelemetry('send_complete', { chars: (aggregated || '').length, flushes: flushCountRef.current || 0 }); } catch {}
            try {
              const elapsed = tEnd(telReqT0Ref.current);
              const estTok = estimateTokens(aggregated || '');
              const tps = estTok > 0 ? (estTok / (elapsed / 1000)) : 0;
              recordTelemetry({
                phase: 'chat_complete', ts: Date.now(), modelId: aiSettings.modelId || null, mode: aiSettings.mode,
                action: (directivePresetId ? `preset:${directivePresetId}` : (activePreset ? `preset:${activePreset}` : 'chat')),
                elapsedMs: elapsed, streamedChars: telCharsRef.current, estTokens: estTok,
                tokensPerSec: Math.round(tps * 10) / 10, retryCount: telRetryRef.current,
                fallbackModelId: telFallbackModelRef.current,
                summarization: telSummElapsedRef.current
                  ? { triggered: true, elapsedMs: telSummElapsedRef.current }
                  : { triggered: false },
                ok: true,
              });
              if ((localStorage.getItem('synapse.ai.telemetry') || '') === 'verbose') {
                console.table(flushTelemetryBuffer());
              }
            } catch {}
            resolve(full);
          },
          onError: (err) => {
            if (settled) return; settled = true;
            finalizeAbort('network_error');
            // If we error while streaming, offer Continue for this message id
            try { lastAbortedMsgIdRef.current = newMsgId; } catch {}
            try { const kind = classifyError(err); emitTelemetry('send_error', { kind }); const msg = userFacingMessage(kind); appendMessagesDeferred([ makeSystemMessage(msg) ]); setLastSystemNote(msg); } catch {}
            // a11y removed block
            try {
              const code = (err && typeof err === 'object' && 'code' in (err as any)) ? String((err as any).code) : 'unknown';
              const payload: Parameters<typeof reportError>[0] = { source: 'adapter', code, provider: assuredModel.provider as any, model: modelIdToUse };
              const s = (err && typeof err === 'object' && 'status' in (err as any)) ? Number((err as any).status) : null;
              if (s !== null) (payload as any).status = s;
              const m = (err as any)?.message; if (typeof m === 'string') (payload as any).message = m;
              reportError(payload);
            } catch {}
            try {
              recordTelemetry({
                phase: 'chat_error', ts: Date.now(), modelId: aiSettings.modelId || null, mode: aiSettings.mode,
                action: (directivePresetId ? `preset:${directivePresetId}` : (activePreset ? `preset:${activePreset}` : 'chat')),
                elapsedMs: tEnd(telReqT0Ref.current), streamedChars: telCharsRef.current,
                retryCount: telRetryRef.current, fallbackModelId: telFallbackModelRef.current, ok: false, note: 'stream failed'
              });
              if ((localStorage.getItem('synapse.ai.telemetry') || '') === 'verbose') {
                console.table(flushTelemetryBuffer());
              }
            } catch {}
            if (flags.aiTrace) logger.error('[STREAM_ERROR]', String((err as any)?.message || err));
            reject(err);
          }
  }, { groupKey: 'assistant', autoAbortOnVisibilityChange: false });
      });

      try {
        await withRetries(
          () => sendOnce(assuredModel.id),
          isTransient,
          2
        );
        addNotification('success', 'Response complete', 1500);
  } catch (err1: any) {
        const info1 = classifyProviderError(err1);
        // If the selected model is unsupported/invalid, try an immediate fallback before retrying
        if (ALLOW_MODEL_FALLBACK && streamedCharsRef.current === 0 && (info1.type === 'not_found' || info1.type === 'bad_request')) {
          const fb = selectFallbackModel(assuredModel.id, assuredModel.provider as any);
          if (fb) {
            addNotification('info', `Selected model unavailable. Falling back to ${fb}…`, 2000);
            telFallbackModelRef.current = fb;
            try {
              await sendOnce(fb);
              addNotification('success', `Response from fallback ${fb}`, 1500);
              recordTelemetry({ phase: 'fallback_used', ts: Date.now(), modelId: aiSettings.modelId || null, mode: aiSettings.mode, action: (directivePresetId ? `preset:${directivePresetId}` : (activePreset ? `preset:${activePreset}` : 'chat')), fallbackModelId: fb, ok: true });
              return;
            } catch (errFb: any) {
              // continue into regular error flow below
            }
          }
        }
        if (info1.retryable && streamedCharsRef.current === 0) {
          addNotification('warning', 'Transient error – retrying…', 1800);
          await wait(timeouts.retryBackoffMs);
          telRetryRef.current += 1;
          try {
            await sendOnce(assuredModel.id);
            addNotification('success', 'Response complete', 1500);
          } catch (err2: any) {
            classifyProviderError(err2);
            if (ALLOW_MODEL_FALLBACK && streamedCharsRef.current === 0) {
              const fb = selectFallbackModel(assuredModel.id, assuredModel.provider as any);
              if (fb) {
                addNotification('info', `Falling back to ${fb}…`, 1800);
                telFallbackModelRef.current = fb;
                try {
                  await sendOnce(fb);
                  addNotification('success', `Response from fallback ${fb}`, 1800);
                  recordTelemetry({ phase: 'fallback_used', ts: Date.now(), modelId: aiSettings.modelId || null, mode: aiSettings.mode, action: (directivePresetId ? `preset:${directivePresetId}` : (activePreset ? `preset:${activePreset}` : 'chat')), fallbackModelId: fb, ok: true });
                  
                } catch (err3: any) {
                  const det = handleError(err3);
                  updateConnectionStatus(assuredModel.provider as any, 'error');
                  const hint = (assuredModel.provider === 'ollama')
                    ? '\nHint: Ollama çalışıyor ve model yüklü olmalı:\n   1) Ollama’yı başlatın\n   2) Terminal:  ollama pull <model>\n   3) Ayarlar → Providers → Ollama URL kontrol edin'
                    : '';
                  const errorMessage: Message = { id: (Date.now() + 2).toString(), type: 'system', content: `❌ Error: ${det.message}${hint}`, timestamp: new Date() };
                  appendMessagesDeferred([errorMessage]);
                  setLastSystemNote(det.message);
                  setIsTyping(false);
                  if (flags.aiTrace) logger.error('[STREAM_ERROR]', String((err3 as any)?.message || err3));
                }
              } else {
                const det = handleError(err2);
                updateConnectionStatus(assuredModel.provider as any, 'error');
                const hint = (assuredModel.provider === 'ollama')
                  ? '\nHint: Ollama çalışıyor ve model yüklü olmalı:\n   1) Ollama’yı başlatın\n   2) Terminal:  ollama pull <model>\n   3) Ayarlar → Providers → Ollama URL kontrol edin'
                  : '';
                const errorMessage: Message = { id: (Date.now() + 2).toString(), type: 'system', content: `❌ Error: ${det.message}${hint}`, timestamp: new Date() };
                appendMessagesDeferred([errorMessage]);
                setLastSystemNote(det.message);
                setIsTyping(false);
                if (flags.aiTrace) logger.error('[STREAM_ERROR]', String((err2 as any)?.message || err2));
              }
            } else {
              const det = handleError(err2);
              updateConnectionStatus(assuredModel.provider as any, 'error');
              const hint = (assuredModel.provider === 'ollama')
                ? '\nHint: Ollama çalışıyor ve model yüklü olmalı:\n   1) Ollama’yı başlatın\n   2) Terminal:  ollama pull <model>\n   3) Ayarlar → Providers → Ollama URL kontrol edin'
                : '';
              const errorMessage: Message = { id: (Date.now() + 2).toString(), type: 'system', content: `❌ Error: ${det.message}${hint}`, timestamp: new Date() };
              appendMessagesDeferred([errorMessage]);
              setLastSystemNote(det.message);
              setIsTyping(false);
              if (flags.aiTrace) logger.error('[STREAM_ERROR]', String((err2 as any)?.message || err2));
            }
          }
        } else {
          const det = handleError(err1);
          updateConnectionStatus(assuredModel.provider as any, 'error');
          const hint = (assuredModel.provider === 'ollama')
            ? '\nHint: Ollama çalışıyor ve model yüklü olmalı:\n   1) Ollama’yı başlatın\n   2) Terminal:  ollama pull <model>\n   3) Ayarlar → Providers → Ollama URL kontrol edin'
            : '';
          const errorMessage: Message = { id: (Date.now() + 2).toString(), type: 'system', content: `❌ Error: ${det.message}${hint}`, timestamp: new Date() };
          appendMessagesDeferred([errorMessage]);
          setLastSystemNote(det.message);
          setIsTyping(false);
          if (flags.aiTrace) logger.error('[STREAM_ERROR]', String((err1 as any)?.message || err1));
        }
      }
      
    } catch (error) {
      console.error('API call failed:', error);
  updateConnectionStatus(assuredModel.provider as any, 'error');
      
      const errorDetails = handleError(error);
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'system',
  content: `❌ Error calling ${assuredModel.provider} API: ${errorDetails.message}`,
        timestamp: new Date()
      };
      appendMessagesDeferred([errorMessage]);
  setLastSystemNote(errorDetails.message);
  addNotification(errorDetails.errorType === 'auth' ? 'warning' : 'error', `${assuredModel.name}: ${errorDetails.message}`, 5000);
  if (flags.aiTrace) logger.error('[STREAM_ERROR]', String((error as any)?.message || error));
      
    } finally {
      setIsTyping(false);
    }
  };

  // Keep a ref to the latest send function for keyboard handlers
  useEffect(() => {
    handleSendMessageRef.current = handleSendMessage;
    return () => { handleSendMessageRef.current = null; };
  }, [handleSendMessage]);

  // Helper: set preset as current input + flag then reuse handleSendMessage
  const sendPresetMessage = (presetKey: string, presetPrompt: string) => {
    if (isTyping) return;
    try { localStorage.setItem('synapse.ai.lastPreset', presetKey); } catch {}
    setActivePreset(presetKey);
    setInput(presetPrompt);
  scheduleAdjustTextarea();
    if (beginnerMode) {
      setTimeout(() => { handleSendMessage(); }, 0);
    }
  };

  const handleQuickPrompt = (prompt: string) => {
    setInput(prompt);
    inputRef.current?.focus();
  scheduleAdjustTextarea();
  };

  const copyToClipboard = async (content: string, messageId: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedMessageId(messageId);
      addNotification('success', 'Message copied to clipboard!', 1500);
      setTimeout(() => setCopiedMessageId(null), 2000);
    } catch (err) {
  console.error('Failed to copy:', err);
  addNotification('error', 'Clipboard blocked. Use HTTPS or grant permission.', 2000);
    }
  };

  const clearMessages = () => {
    try { abortStreaming('user_clear'); } catch {}
    deferMessagesUpdate(() => ([
      {
        id: safeUuid(),
        type: 'ai',
        content: 'Chat cleared! How can I assist you today?',
        timestamp: new Date()
      }
    ] as Message[]));
    try {
      // persist cleared history immediately (no debounce race)
      onMessagesChanged([
        { id: `${Date.now()}`, role: 'assistant', content: 'Chat cleared! How can I assist you today?', ts: Date.now() }
      ] as any);
    } catch {}
    addNotification('info', 'Chat history cleared', 1500);
    // Clear attachments and revoke any preview URLs
    try {
      const list = useAttachStore.getState().list;
      list.forEach(a => { if (a.previewUrl) URL.revokeObjectURL(a.previewUrl); });
      useAttachStore.getState().clear();
    } catch {}
    updateActivity();
    try { scrollToBottom(); } catch {}
  };

  // Quick Attach: file picker + ingest (same logic as AttachBar)
  const quickAttachInputRef = useRef<HTMLInputElement | null>(null);
  const attachAddMany = useAttachStore(s => s.addMany);
  const openQuickAttachPicker = useCallback(() => quickAttachInputRef.current?.click(), []);
  const [qaDragging, setQaDragging] = useState(false);
  const quickAttachOnFiles = useCallback(async (files: FileList | File[]) => {
    const batch: AttachmentMeta[] = [];
    const existingHashes = new Set(useAttachStore.getState().list.map(a => a.hash));
    for (const file of Array.from(files)) {
      try {
        if (file.size > MAX_FILE_BYTES) {
          showToast({ kind: 'warning', contextKey: 'attach:too-big', title: 'File too large', message: file.name });
          continue;
        }
  const id = uuid();
        const name = sanitizeName(file.name);
        const ext = name.includes('.') ? name.slice(name.lastIndexOf('.')) : '';
        const mime = file.type || 'application/octet-stream';
        const kind = sniffKind(name, mime);
        const hash = await sha256(file);
        if (existingHashes.has(hash)) {
          showToast({ kind: 'info', contextKey: 'attach:dup', title: 'Already attached', message: name });
          continue;
        }
        const meta: AttachmentMeta = {
          id, name, ext, mime, size: file.size, kind, hash,
          createdAt: Date.now(),
          previewUrl: kind === 'image' || kind === 'pdf' ? URL.createObjectURL(file) : undefined,
        };
        if (kind === 'text' || kind === 'code' || kind === 'json' || kind === 'csv') {
          meta.textFull = await readTextSafely(file);
          meta.textExcerpt = meta.textFull?.slice(0, 500);
        }
        batch.push(meta);
      } catch (err) {
        showToast({ kind: 'error', contextKey: 'attach:error', title: 'Attach failed', message: (err as Error)?.message || 'Unknown error' });
      }
    }
    if (batch.length) {
      attachAddMany(batch);
      showToast({ kind: 'success', contextKey: 'attach:added', title: 'Files attached', message: `${batch.length} file(s)` });
    }
  }, [attachAddMany]);
  const quickAttachOnChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) quickAttachOnFiles(e.target.files);
    e.target.value = '';
  scheduleAdjustTextarea();
  }, [quickAttachOnFiles]);
  const qaOnDragOver = useCallback((e: React.DragEvent) => { e.preventDefault(); e.dataTransfer.dropEffect='copy'; setQaDragging(true); }, []);
  const qaOnDragLeave = useCallback((e: React.DragEvent) => { e.preventDefault(); setQaDragging(false); }, []);
  const qaOnDrop = useCallback((e: React.DragEvent) => { e.preventDefault(); setQaDragging(false); if (e.dataTransfer.files?.length) quickAttachOnFiles(e.dataTransfer.files); }, [quickAttachOnFiles]);

  // Quick Actions Data
  const quickActions = [
    { id: 'attach', icon: Paperclip, label: 'Attach', action: openQuickAttachPicker },
    { id: 'clear', icon: Trash2, label: 'Clear Chat', action: clearMessages },
    { id: 'export', icon: Download, label: 'Export', action: () => setExportModalOpen(true) },
    { id: 'copy-all', icon: Copy, label: 'Copy All', action: () => copyAllMessages() },
    { id: 'suggestions', icon: Lightbulb, label: 'Smart Tips', action: () => setShowSuggestions(!showSuggestions) }
  ];

  // Smart Suggestions Data (stabilized to avoid render loops)
  // Keep this list constant; do not re-create on each render.
  const SMART_SUGGESTIONS = React.useMemo(
    () => [
      'Explain this code step by step',
      'Find bugs in this code',
      'Optimize this algorithm',
      'Add error handling',
      'Write unit tests for this',
      'Convert to TypeScript',
      'Make this more readable',
      'Add documentation',
    ],
    []
  );

  // Auto-resize textarea
  const resizeRafRef = useRef<number | null>(null);
  const adjustTextareaHeight = () => {
    if (inputRef.current) {
      // Set to auto to measure true scrollHeight, then set only if changed
      const el = inputRef.current;
      el.style.height = 'auto';
      const scrollHeight = el.scrollHeight;
      const maxHeight = 180;
      const next = Math.min(scrollHeight, maxHeight);
      const nextPx = `${next}px`;
      if (el.style.height !== nextPx) el.style.height = nextPx;
    }
  };
  const scheduleAdjustTextarea = () => {
    if (resizeRafRef.current) cancelAnimationFrame(resizeRafRef.current);
    resizeRafRef.current = requestAnimationFrame(adjustTextareaHeight);
  };
  useEffect(() => () => { if (resizeRafRef.current) cancelAnimationFrame(resizeRafRef.current); }, []);

  // Debounced, IME-safe send helper
  const SEND_DEBOUNCE_MS = 200;
  const sendIfReady = useCallback(() => {
    if (composingRef.current) return; // don't send during IME composition
    const now = Date.now();
    if (now - lastSendAtRef.current < SEND_DEBOUNCE_MS) return; // debounce double fires
    if (!input.trim() || isTyping) return; // nothing to send or already streaming
    lastSendAtRef.current = now;
    // use existing handler; schedule resize after clearing input inside
    void handleSendMessage();
    // ensure textarea shrinks after send on next frame
    scheduleAdjustTextarea();
  }, [input, isTyping]);

  // Character count and limits
  const maxCharacters = 4000;
  // Memoize input styles by full input to keep styles in sync with content
  const inputStyleMemo = useMemo(() => createInputStyles(input), [input]);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (value.length <= maxCharacters) {
      setInput(value);
      scheduleAdjustTextarea();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
  if (e.key === 'Escape') {
      setInput('');
      scheduleAdjustTextarea();
    }
  };

  // Global Chat Input Key Scope (priority 50)
  useKeyScope({
    id: 'chat-input',
    priority: 50,
    when: () => !!document.activeElement && (document.activeElement as HTMLElement).hasAttribute?.('data-chat-input'),
    onKeyDown: (e) => {
      const chord = toChord(e);
      // Enter (no Shift) sends, Shift+Enter newline
      if (chord === 'Enter') {
        e.preventDefault();
  // Respect IME composition
  if (!composingRef.current) sendIfReady();
        return true;
      }
      if (chord === 'Ctrl+Enter' || chord === 'Meta+Enter') {
        e.preventDefault();
  if (!composingRef.current) sendIfReady();
        return true;
      }
      if (e.key === 'Escape') {
        setInput('');
        scheduleAdjustTextarea();
        return true;
      }
      return false;
    },
  });

  // Settings Modal Scope: Esc closes (priority 80)
  useKeyScope(settingsOpen ? {
    id: 'settings-modal',
    priority: 80,
    when: () => true,
    onKeyDown: (e) => {
      if (e.key === 'Escape') {
        setSettingsOpen(false);
        return true;
      }
      // Trap Tab within modal
      if (e.key === 'Tab') {
        const modal = document.querySelector('[data-ai-settings]') as HTMLElement | null;
        if (!modal) return false;
        const focusables = modal.querySelectorAll<HTMLElement>(
          'a[href], button, textarea, input, select, [tabindex]:not([tabindex="-1"])'
        );
        if (focusables.length === 0) return false;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        const active = document.activeElement as HTMLElement | null;
        if (!e.shiftKey && active === last) { e.preventDefault(); first.focus(); return true; }
        if (e.shiftKey && active === first) { e.preventDefault(); last.focus(); return true; }
      }
      return false;
    },
  } : null);

  // Keyboard overlay and search scopes
  useKeyScope({
    id: 'chat-keys',
    priority: 60,
    when: () => !settingsOpen && !exportModalOpen,
    onKeyDown: (e) => {
      const chord = toChord(e);
      if (chord === 'Shift+/' || e.key === '?') {
        e.preventDefault();
        setShowKeysOverlay(v => !v);
        return true;
      }
      if (chord === 'Ctrl+f' || chord === 'Meta+f') {
        e.preventDefault();
        setSearchOpen(true);
        setTimeout(() => searchInputRef.current?.focus(), 0);
        return true;
      }
      return false;
    }
  });

  // When opening search, ensure focus
  useEffect(() => {
    if (searchOpen) setTimeout(() => searchInputRef.current?.focus(), 0);
  }, [searchOpen]);

  // Export Modal Scope: Esc closes + Tab trap (priority 85)
  useKeyScope(exportModalOpen ? {
    id: 'export-modal',
    priority: 85,
    when: () => true,
    onKeyDown: (e) => {
      if (e.key === 'Escape') { setExportModalOpen(false); return true; }
      if (e.key === 'Tab') {
        const modal = document.querySelector('[data-export-modal]') as HTMLElement | null;
        if (!modal) return false;
        const focusables = modal.querySelectorAll<HTMLElement>('a[href], button, textarea, input, select, [tabindex]:not([tabindex="-1"])');
        if (focusables.length === 0) return false;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        const active = document.activeElement as HTMLElement | null;
        if (!e.shiftKey && active === last) { e.preventDefault(); first.focus(); return true; }
        if (e.shiftKey && active === first) { e.preventDefault(); last.focus(); return true; }
      }
      return false;
    },
  } : null);

  // Focus management: removed input-driven resize to avoid double reflow
  // Textarea height is adjusted via onChange using requestAnimationFrame

  // Smart Suggestions Effect
  // Important: only depend on `input`; keep suggestions stable and only update when changed
  useEffect(() => {
    let next: string[] = [];
    if (input.length > 3) {
      const q = input.toLowerCase();
      const matching = SMART_SUGGESTIONS.filter((suggestion) =>
        suggestion.toLowerCase().includes(q) || q.includes(suggestion.split(' ')[0].toLowerCase())
      );
      next = matching.slice(0, 3);
    }
    setSuggestions((prev) => {
      if (prev.length === next.length && prev.every((v, i) => v === next[i])) return prev;
      return next;
    });
  }, [input, SMART_SUGGESTIONS]);

  // Set dark theme on mount
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', 'dark');
  }, []);

  // Auto-attempt initial Ollama model discovery (once) if endpoint configured
  useEffect(() => {
    if (providerKeys.ollama && ollama.length === 0) {
      fetchOllamaModels();
    }
  }, [providerKeys.ollama, ollama.length]);

  // Responsive Design Effect
  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      
      setIsMobile(width < 768);
      setIsTablet(width >= 768 && width < 1024);
      
      // Adjust component width based on screen size
  // Width responsive adjustments removed (parent governs width)
    };

    handleResize(); // Initial call
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []); // Remove setCurrentWidth from dependencies

  // Local resize removed; parent controls width. isResizing retained if future visual feedback needed.

  // (Inline VirtualizedMessageList extracted to components/ai/virtual/VirtualMessageList)

  return (
    <>
    <style>{globalStyles}</style>
  <Container $w={currentWidth} $isMobile={isMobile} data-component="ai-assistant" className="ai-assistant-container">
  {/* Screen reader live region node is rendered inside the transcript container */}
      {/* Beginner Mode toggle now handled by AIHeader; inline fallback removed */}
    {/* Header augmentation: Beginner Mode + Presets injected via AIHeader props if used upstream */}
    {/* If no AIHeader wrapper used, we can optionally show a minimal inline control bar here in future */}
  {/* Centralized toast rendering */}
  {/* toasts centralized */}

  {/* External resize handle managed in EnhancedIDE (removed local handle) */}

      {/* Redesigned Header (centered branding + control row) */}
  <Header $isMobile={isMobile} data-ai-brand>
        <style>{`
          [data-ai-brand] { flex-direction:column; align-items:stretch; position:relative; padding:14px 10px 8px 10px !important; gap:0; }
          [data-ai-brand] .brand-block { display:flex; flex-direction:row; align-items:center; justify-content:center; gap:12px; position:relative; flex:1; min-width:0; padding-bottom:4px; }
          [data-ai-brand] .ai-logo-wrap { position:relative; overflow:hidden; animation: aiLogoPulse 7s ease-in-out infinite; display:flex; align-items:center; justify-content:center; width:44px; height:44px; border-radius:12px; }
          [data-ai-brand] .ai-logo-wrap .ai-logo-sheen { position:absolute; inset:0; background:linear-gradient(120deg, rgba(255,255,255,0) 15%, rgba(255,255,255,0.18) 40%, rgba(255,255,255,0) 65%); mix-blend-mode:screen; animation: aiLogoSheen 5.5s cubic-bezier(.25,.6,.3,1) infinite; pointer-events:none; }
          [data-ai-brand] .brand-text { display:flex; flex-direction:column; align-items:center; gap:2px; min-width:0; }
          [data-ai-brand] .ai-brand-title { 
            margin:0; font-size:18px; font-weight:700; letter-spacing:.5px; font-family:"JetBrains Mono","Fira Code","SF Mono",monospace; line-height:1.1; display:inline-block;
            background:linear-gradient(120deg,#8C7444 0%,#C2A76E 35%,#F5E9C4 50%,#A58B5F 70%,#8C7444 100%);
            background-size:220% 100%;
            -webkit-background-clip:text; background-clip:text; color:transparent;
            filter:drop-shadow(0 1px 4px rgba(0,0,0,.45));
            animation: aiTitleGradient 7s linear infinite, aiTitleGlitch 3s steps(1,end) infinite;
          }
          [data-ai-brand] .ai-brand-subtag { display:inline-block; font-size:11px; font-weight:600; opacity:.9; font-family:"JetBrains Mono","Fira Code","SF Mono",monospace; text-align:center; line-height:1.15; white-space:nowrap; }
          [data-ai-brand] .ai-brand-subtag .ltr { display:inline-block; background:linear-gradient(90deg,#C2A76E,#A58B5F,#C2A76E); background-size:200% 100%; -webkit-background-clip:text; color:transparent; animation: aiLetterSheen 5s cubic-bezier(.2,.8,.2,1) infinite; animation-delay:var(--dl,0ms); filter:drop-shadow(0 0 2px rgba(194,167,110,0.18)); }
          [data-ai-brand] .ai-brand-subtag .ltr.glitch { animation: aiLetterSheen 5s cubic-bezier(.2,.8,.2,1) infinite, aiLetterGlitch 6s steps(1,end) infinite; }
          [data-ai-brand] .controls-row { display:flex; align-items:center; justify-content:center; gap:12px; }
          [data-ai-brand] .group { display:flex; align-items:center; gap:10px; }
          [data-ai-brand] .beginner-btn { display:flex; align-items:center; gap:6px; padding:6px 10px; font-size:11px; font-weight:600; cursor:pointer; border-radius:6px; border:1px solid; transition:all .25s ease; }
          [data-ai-brand] .preset-trigger { display:flex; align-items:center; gap:6px; padding:6px 10px; font-size:11px; font-weight:600; border-radius:6px; border:1px solid #FFFFFF10; background:rgba(26,26,26,0.2); color:#E8E8E8; cursor:not-allowed; opacity:.45; }
          [data-ai-brand] .preset-trigger.enabled { cursor:pointer; opacity:1; background:rgba(26,26,26,0.4); }
          [data-ai-brand] .status-shell { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; background:linear-gradient(135deg, rgba(194,167,110,0.08), rgba(165,139,95,0.08)); border:1px solid #FFFFFF10; font-size:11px; font-weight:600; }
          [data-ai-brand] .actions { display:flex; gap:6px; }
          @media (max-width: 820px){ [data-ai-brand] { flex-wrap:wrap; } [data-ai-brand] .controls-row { width:100%; justify-content:center; flex-wrap:wrap; } }
          @keyframes aiLogoSheen { 0%{transform:translateX(-120%) rotate(25deg); opacity:0;} 10%{opacity:.7;} 40%{transform:translateX(0) rotate(25deg); opacity:.15;} 60%{opacity:0;} 100%{transform:translateX(130%) rotate(25deg); opacity:0;} }
          @keyframes aiLogoPulse { 0%,100% { box-shadow:0 4px 14px rgba(0,0,0,0.35),0 0 5px rgba(194,167,110,0.25);} 50% { box-shadow:0 6px 18px rgba(0,0,0,0.5),0 0 8px rgba(194,167,110,0.4);} }
          @keyframes aiTitleGradient { 0%{background-position:0% 0%;} 50%{background-position:100% 0%;} 100%{background-position:0% 0%;} }
          @keyframes aiTitleGlitch { 0%,97%,100% { transform:none; text-shadow:none;} 98% { transform:translateY(-1px) skewX(.4deg); text-shadow:1px 0 rgba(194,167,110,.5), -1px 0 rgba(165,139,95,.5);} 99% { transform:translateY(1px) skewX(-.4deg); text-shadow:-1px 0 rgba(194,167,110,.35), 1px 0 rgba(165,139,95,.35);} }
          @keyframes aiLetterSheen { 0%{background-position:0% 0%;} 50%{background-position:100% 0%;} 100%{background-position:0% 0%;} }
          @keyframes aiLetterGlitch { 0%,97%,100% { transform:none; text-shadow:none;} 98% { transform:translateY(-1px) skewX(.5deg); text-shadow:1px 0 rgba(194,167,110,.5), -1px 0 rgba(165,139,95,.5);} 99% { transform:translateY(1px) skewX(-.5deg); text-shadow:-1px 0 rgba(194,167,110,.35), 1px 0 rgba(165,139,95,.35);} }
          @media (prefers-reduced-motion:reduce){ [data-ai-brand] .ai-logo-wrap, [data-ai-brand] .ai-logo-wrap .ai-logo-sheen, [data-ai-brand] .ai-brand-title, [data-ai-brand] .ai-brand-subtag .ltr { animation:none!important; background-position:0 0; } }
        `}</style>
        <div className="brand-block">
          <div className="ai-logo-wrap">
            <div className="ai-logo-sheen" />
            <Bot size={28} />
          </div>
          <div className="brand-text">
            <span className="ai-brand-title">SynapseCore AI</span>
            <span className="ai-brand-subtag">
              {(() => {
                const currentModel = getFilteredModels().find(m => m.id === selectedModel);
                const text = `Powered by ${currentModel?.name || selectedModel}`;
                return text.split('').map((ch, i) => (
                  <DelayLetter key={i} className={`ltr${i % 17 === 0 ? ' glitch' : ''}`} $dl={`${i * 55}ms`}>
                    {ch === ' ' ? '\u00A0' : ch}
                  </DelayLetter>
                ))
              })()}
            </span>
          </div>
    {/* Removed dev-only Tests and Self-Check buttons */}
        </div>
  <div className="controls-row">
          <div className="group">
            <button
              onClick={() => {
                // Warn if switching mid-stream; change still applies, but only next request uses it
                guardModeSwitch(streamState.isStreaming, (msg) => addNotification('info', msg, 2500));
                const next = !beginnerMode;
                const updated = { ...aiSettings, mode: next ? 'beginner' : 'pro' } as any;
                setAiSettings(updated);
                saveAiSettings(updated);
              }}
        // aria-pressed omitted to avoid external linter false positives
              className="beginner-btn"
              title="Beginner Mode: single-file, commented, simpler explanations"
              style={{
                borderColor: beginnerMode ? withAlpha(SYNAPSE_COLORS.goldPrimary, 0.4) : SYNAPSE_COLORS.borderSubtle,
                background: beginnerMode ? `linear-gradient(135deg, ${withAlpha(SYNAPSE_COLORS.goldPrimary,0.2)}, ${withAlpha(SYNAPSE_COLORS.goldSecondary,0.13)})` : withAlpha(SYNAPSE_COLORS.bgSecondary,0.4),
                color: SYNAPSE_COLORS.textPrimary
              }}
              onMouseEnter={(e)=>{ e.currentTarget.style.borderColor= withAlpha(SYNAPSE_COLORS.goldPrimary,0.6); if(beginnerMode) e.currentTarget.style.background=`linear-gradient(135deg, ${withAlpha(SYNAPSE_COLORS.goldPrimary,0.33)}, ${withAlpha(SYNAPSE_COLORS.goldSecondary,0.2)})`; }}
              onMouseLeave={(e)=>{ e.currentTarget.style.borderColor= beginnerMode?withAlpha(SYNAPSE_COLORS.goldPrimary,0.4):SYNAPSE_COLORS.borderSubtle; e.currentTarget.style.background= beginnerMode?`linear-gradient(135deg, ${withAlpha(SYNAPSE_COLORS.goldPrimary,0.2)}, ${withAlpha(SYNAPSE_COLORS.goldSecondary,0.13)})`:withAlpha(SYNAPSE_COLORS.bgSecondary,0.4); }}
            >
              <BeginnerDot $active={beginnerMode} />
              Beginner
            </button>
          </div>
          <div className="group">
            {(() => {
              const currentModel = getFilteredModels().find(m => m.id === selectedModel);
              const provider = currentModel?.provider;
              const status = connectionStatus[provider || ''] || 'disconnected';
              const responseTime = apiResponseTimes[provider || ''];
              
              return (
        <div className="status-shell" title={`${provider}: ${status}${responseTime ? ` (${responseTime}ms)` : ''}`}>
                  {status === 'connected' && <Wifi size={12} color={SYNAPSE_COLORS.success} />}
                  {status === 'disconnected' && <WifiOff size={12} color={SYNAPSE_COLORS.textSecondary} />}
                  {status === 'testing' && <Activity size={12} color={SYNAPSE_COLORS.goldPrimary} />}
                  {status === 'error' && <AlertCircle size={12} color={SYNAPSE_COLORS.error} />}
                  <span style={{ 
          color: status === 'connected' ? SYNAPSE_COLORS.success : 
            status === 'testing' ? SYNAPSE_COLORS.goldPrimary : 
            status === 'error' ? SYNAPSE_COLORS.error : SYNAPSE_COLORS.textSecondary
                  }}>
                    {provider?.toUpperCase()}
                  </span>
                  {responseTime ? <span style={{ color: SYNAPSE_COLORS.textTertiary, fontSize: '10px' }}>
                      {responseTime}ms
                    </span> : null}
                  {streamState.queuedJobs > 0 && (
                    <QueuePill title={`${streamState.queuedJobs} request(s) queued`}>
                      Q{streamState.queuedJobs}
                    </QueuePill>
                  )}
                  {streamState.isStreaming ? <span style={{
                      background: SYNAPSE_COLORS.blueGray,
                      color: SYNAPSE_COLORS.textPrimary,
                      padding: '0 6px',
                      borderRadius: '10px',
                      fontSize: '10px',
                      fontWeight: 600
                    }}>LIVE</span> : null}
                  {lastAbortReason && !streamState.isStreaming ? <span style={{
                      background: SYNAPSE_COLORS.textTertiary,
                      color: SYNAPSE_COLORS.textPrimary,
                      padding: '0 6px',
                      borderRadius: '10px',
                      fontSize: '10px',
                      fontWeight: 500
                    }} title={`Last abort: ${lastAbortReason}`}>ABORT</span> : null}
                </div>
              );
            })()}
          </div>
  <div className="actions">
            {/* Settings Popover Trigger (STEP 9) */}
            <div style={{ position:'relative' }}>
              <button
                data-ai-settings-trigger
                data-testid="settings-btn"
                onClick={()=> setSettingsOpen(o=>!o)}
                
                title="AI Settings"
                style={{
                  ...buttonStyles,
                  width: 'auto',
                  padding: '6px 10px',
                  display:'flex',
                  gap:6,
                  fontSize:11,
                  fontWeight:600
                }}
              >⚙️</button>
        {settingsOpen ? <AiSettingsModalPro
                  value={advSettings as any}
                  onChange={handleAdvChange as any}
                  onSave={handleAdvSave}
                  presets={[]}
                  onExport={handleAdvExport}
                  onImport={handleAdvImport}
          initialTab={initialSettingsTab as any}
          onClose={()=>{ setSettingsOpen(false); setInitialSettingsTab(undefined); }}
                /> : null}
            </div>
            <button
              data-ai-settings-trigger
              className="preset-trigger enabled"
              onClick={() => { setInitialSettingsTab('api-keys'); setSettingsOpen(true); }}
              title="Open API Keys"
            >API Keys</button>
            <button
              style={buttonStyles}
              onClick={clearMessages}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = withAlpha(SYNAPSE_COLORS.goldPrimary, 0.15);
                e.currentTarget.style.borderColor = SYNAPSE_COLORS.goldPrimary;
                e.currentTarget.style.transform = 'translateY(-1px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = withAlpha(SYNAPSE_COLORS.bgSecondary, 0.8);
                e.currentTarget.style.borderColor = SYNAPSE_COLORS.borderSubtle;
                e.currentTarget.style.transform = 'translateY(0)';
              }}
              title="Clear chat"
            >
              <RotateCcw size={15} />
            </button>
            {onClose ? <button
                style={buttonStyles}
                onClick={onClose}
                onMouseEnter={(e) => { e.currentTarget.style.background = withAlpha(SYNAPSE_COLORS.error, 0.15); e.currentTarget.style.borderColor = SYNAPSE_COLORS.error; e.currentTarget.style.transform = 'translateY(-1px)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = withAlpha(SYNAPSE_COLORS.bgSecondary, 0.8); e.currentTarget.style.borderColor = SYNAPSE_COLORS.borderSubtle; e.currentTarget.style.transform = 'translateY(0)'; }}
                title="Close AI Assistant"
              >
                <X size={15} />
              </button> : null}

            {/* Presets dropdown moved to the far right (end of row) */}
            <div style={{ position:'relative' }} data-presets-inline>
              <button
                onClick={() => setShowPresetMenuInline(v=>!v)}
                className="preset-trigger enabled"
                title={`Select a ${beginnerMode ? 'Beginner' : 'Pro'} preset`}
              >{activePreset ? activePreset : (beginnerMode ? 'Beginner Presets' : 'Pro Presets')} <ChevronDown size={14} /></button>
              {showPresetMenuInline ? <div style={{ position:'absolute', top:'110%', right:0, minWidth:280, background: SYNAPSE_COLORS.bgDark, border:`1px solid ${SYNAPSE_COLORS.borderSubtle}`, borderRadius:8, boxShadow: SYNAPSE_ELEVATION.shadowLg, padding:6, zIndex:30 }}>
                  {pinnedForMode.length > 0 && (
                    <div style={{ display:'flex', flexWrap:'wrap', gap:6, padding:'4px 6px 8px 6px' }}>
                      {pinnedForMode.map(id => {
                        const p = findPresetById(aiSettings.mode, id);
                        if (!p) return null;
                        return (
                          <button key={`pin-${id}`} onClick={()=>{ setActivePreset(id); setShowPresetMenuInline(false); setTimeout(()=> sendPresetMessage(id, p.systemHint), 0); }}
                            style={{ fontSize:11, borderRadius:999, padding:'4px 8px', background: SYNAPSE_ELEVATION.surfaceHover, color: SYNAPSE_COLORS.textPrimary, border:`1px solid ${SYNAPSE_ELEVATION.borderStrong}`, display:'flex', alignItems:'center', gap:6 }}
                            title={p.description}
                          >{p.label}</button>
                        );
                      })}
                    </div>
                  )}

                  <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
                    {(aiSettings.mode === 'beginner' ? BEGINNER_PRESETS : PRO_PRESETS).map(p => (
                      <div key={p.id} style={{ display:'flex', alignItems:'stretch', gap:6 }}>
                        <button disabled={isTyping}
                          onClick={()=>{ setActivePreset(p.id); setShowPresetMenuInline(false); setTimeout(()=> sendPresetMessage(p.id, p.systemHint), 0); }}
                          style={{ flex:1, textAlign:'left', background: activePreset===p.id?`linear-gradient(135deg,${withAlpha(SYNAPSE_COLORS.goldPrimary,0.13)},${withAlpha(SYNAPSE_COLORS.goldSecondary,0.13)})`:'transparent', border:'none', color:SYNAPSE_COLORS.textPrimary, padding:'8px 10px', borderRadius:6, fontSize:12, cursor:'pointer' }}
                          onMouseEnter={(e)=>{ if(activePreset!==p.id) e.currentTarget.style.background = SYNAPSE_ELEVATION.surface as string; }}
                          onMouseLeave={(e)=>{ if(activePreset!==p.id) e.currentTarget.style.background = activePreset===p.id?`linear-gradient(135deg,${withAlpha(SYNAPSE_COLORS.goldPrimary,0.13)},${withAlpha(SYNAPSE_COLORS.goldSecondary,0.13)})`:'transparent'; }}
                          title={p.description}
                        >{activePreset===p.id && <Check size={14} color={SYNAPSE_COLORS.goldPrimary} />}<span style={{ display:'block', fontWeight:700 }}>{p.label}</span><span style={{ display:'block', fontSize:11, opacity:.8 }}>{p.description}</span></button>
                        <button onClick={()=> togglePin(p.id)} title={pinnedForMode.includes(p.id) ? 'Unpin' : 'Pin'}
                          style={{ width:34, minWidth:34, display:'flex', alignItems:'center', justifyContent:'center', border:`1px solid ${SYNAPSE_COLORS.borderSubtle}`, borderRadius:6, background: SYNAPSE_ELEVATION.surface, color: SYNAPSE_COLORS.textPrimary }}>
                          {pinnedForMode.includes(p.id) ? <Pin size={14} color={SYNAPSE_COLORS.goldPrimary} /> : <PinOff size={14} />} 
                        </button>
                      </div>
                    ))}
                  </div>
                </div> : null}
            </div>
          </div>
        </div>
      </Header>

  {/* Inline API settings removed */}

      {/* Enhanced Controls */}
      <div style={{ 
        padding: '12px 16px', 
        borderBottom: '1px solid #1A1A1A', 
        backgroundColor: '#121212',
        display: 'flex', 
        flexDirection: 'column',
        gap: '12px'
      }}>
        {/* Language Selector */}
        <div style={{ position: 'relative' }} data-dropdown="language">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <Code size={14} color="#C2A76E" />
            <span style={{ fontSize: '12px', color: '#E8E8E8', fontWeight: '600', fontFamily: 'JetBrains Mono, Fira Code, SF Mono, monospace' }}>Programming Language</span>
          </div>
          
          <div style={{
            padding: '10px 14px',
            borderRadius: '8px',
            background: 'linear-gradient(135deg, #121212 0%, #1A1A1A 50%, #121212 100%)',
            borderImage: 'linear-gradient(135deg, #C2A76E, #A58B5F, #C2A76E, #C2A76E) 1',
            border: '1px solid transparent',
            color: '#AAB2BD',
            fontSize: '13px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            cursor: 'pointer',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
            backdropFilter: 'blur(8px)',
            position: 'relative',
            overflow: 'hidden'
          }}
          onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-1px)';
            e.currentTarget.style.boxShadow = '0 4px 16px rgba(255, 215, 0, 0.2), 0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0px)';
            e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)';
          }}
          >
            <span>{languages.find(l => l.id === selectedLanguage)?.icon}</span>
            <span>{languages.find(l => l.id === selectedLanguage)?.name}</span>
            <span style={{ color: '#AAB2BD', fontSize: '11px', fontFamily: 'JetBrains Mono, Fira Code, SF Mono, monospace' }}>
              ({languages.find(l => l.id === selectedLanguage)?.category})
            </span>
            <ChevronDown size={12} style={{ marginLeft: 'auto', opacity: 0.7 }} />
          </div>

          {showLanguageDropdown ? <div style={{
              position: 'absolute',
              top: '100%',
              left: 0,
              right: 0,
              marginTop: '4px',
              background: 'linear-gradient(135deg, #121212 0%, #1A1A1A 50%, #121212 100%)',
              borderRadius: '12px',
              borderImage: 'linear-gradient(135deg, #C2A76E, #A58B5F, #C2A76E, #C2A76E) 1',
              border: '1px solid transparent',
              zIndex: 1000,
              maxHeight: '320px',
              overflowY: 'auto',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.6), 0 2px 16px rgba(194, 167, 110, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(16px)',
              animation: 'dropdownSlide 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            }}>
              {/* Language Category Filter */}
              <div style={{ padding: '12px', borderBottom: '1px solid #FFFFFF10' }}>
                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                  {['all', 'web', 'backend', 'mobile', 'data', 'database', 'devops', 'functional', 'system', 'latexdocs'].map(category => (
                    <button
                      key={category}
                      onClick={() => setLanguageCategory(category)}
                      style={{
                        padding: '4px 10px',
                        borderRadius: '16px',
                        background: languageCategory === category 
                          ? 'linear-gradient(135deg, #C2A76E, #A58B5F)' 
                          : 'linear-gradient(135deg, #1A1A1A, #1F1F1F)',
                        border: '1px solid #FFFFFF10',
                        color: languageCategory === category ? '#121212' : '#AAB2BD',
                        fontSize: '10px',
                        fontWeight: 500,
                        cursor: 'pointer',
                        textTransform: 'capitalize',
                        transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
                        boxShadow: languageCategory === category 
                          ? '0 2px 8px rgba(194,167,110,0.3)' 
                          : '0 1px 4px rgba(0,0,0,0.2)',
                      }}
                      onMouseEnter={(e) => {
                        if (languageCategory !== category) {
                          e.currentTarget.style.background = 'linear-gradient(135deg, #222222, #2A2A2A)';
                          e.currentTarget.style.transform = 'translateY(-1px)';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (languageCategory !== category) {
                          e.currentTarget.style.background = 'linear-gradient(135deg, #1A1A1A, #1F1F1F)';
                          e.currentTarget.style.transform = 'translateY(0px)';
                        }
                      }}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              {/* Language Options */}
              {getFilteredLanguages().map(lang => (
                <div
                  key={lang.id}
                  onClick={() => {
                    setSelectedLanguage(lang.id);
                    setShowLanguageDropdown(false);
                  }}
                  style={{
                    padding: '12px 16px',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    background: selectedLanguage === lang.id 
                      ? 'linear-gradient(135deg, rgba(194, 167, 110, 0.12), rgba(165, 139, 95, 0.10))' 
                      : 'transparent',
                    borderLeft: selectedLanguage === lang.id ? '3px solid #C2A76E' : '3px solid transparent',
                    transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
                    position: 'relative',
                    overflow: 'hidden'
                  }}
                  onMouseEnter={(e) => {
                    if (selectedLanguage !== lang.id) {
                      e.currentTarget.style.background = 'linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02))';
                      e.currentTarget.style.borderLeft = '3px solid #C2A76E';
                    }
                    e.currentTarget.style.transform = 'translateX(4px)';
                  }}
                  onMouseLeave={(e) => {
                    if (selectedLanguage !== lang.id) {
                      e.currentTarget.style.background = 'transparent';
                      e.currentTarget.style.borderLeft = '3px solid transparent';
                    }
                    e.currentTarget.style.transform = 'translateX(0px)';
                  }}
                >
                  <span style={{ display: 'flex', alignItems: 'center', fontSize: '16px' }}>{lang.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ color: '#AAB2BD', fontSize: '13px', fontWeight: '500' }}>
                        {lang.name}
                      </span>
                      <span style={{
                        padding: '1px 4px',
                        background: '#374151',
                        color: '#AAB2BD',
                        fontSize: '9px',
                        textTransform: 'uppercase'
                      }}>
                        {lang.category}
                      </span>
                    </div>
                    <div style={{ color: '#AAB2BD', fontSize: '11px', fontFamily: 'JetBrains Mono, Fira Code, SF Mono, monospace' }}>
                      {(() => { const m=getFilteredModels().find(m=>m.id===selectedModel); return m? `${m.provider} • ${m.contextLength}`: '—'; })()}
                    </div>
                  </div>
                  {selectedLanguage === lang.id && (
                    <div style={{
                      width: '8px',
                      height: '8px',
                      borderRadius: '50%',
                      background: '#C2A76E',
                      boxShadow: '0 0 8px rgba(194,167,110,0.6)'
                    }} />
                  )}
                </div>
              ))}
            </div> : null}
        </div>

        {/* AI Model Selector */}
        <div style={{ position: 'relative' }} data-dropdown="model">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <Brain size={14} color="#C2A76E" />
            <span style={{ fontSize: '12px', color: '#E8E8E8', fontWeight: '600', fontFamily: 'JetBrains Mono, Fira Code, SF Mono, monospace' }}>AI Model</span>
          </div>
          
          <div style={{
            padding: '10px 14px',
            borderRadius: '8px',
            background: 'linear-gradient(135deg, #121212 0%, #1A1A1A 50%, #121212 100%)',
            borderImage: 'linear-gradient(135deg, #C2A76E, #A58B5F, #C2A76E, #C2A76E) 1',
            border: '1px solid transparent',
            color: '#AAB2BD',
            fontSize: '13px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            cursor: 'pointer',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
            backdropFilter: 'blur(8px)',
            position: 'relative',
            overflow: 'hidden'
          }}
          onClick={() => setShowModelDropdown(!showModelDropdown)}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-1px)';
            e.currentTarget.style.boxShadow = '0 4px 16px rgba(255, 215, 0, 0.2), 0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0px)';
            e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)';
          }}
          >
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <span>{getFilteredModels().find(m => m.id === selectedModel)?.name || 'Select Model'}{beginnerMode ? ' • Beginner' : ''}</span>
                <span style={{
                  padding: '1px 4px',
                  background: (() => {
                    const model = getFilteredModels().find(m => m.id === selectedModel);
                    return model && isModelAvailable(model) ? '#2ECC71' : '#E74C3C';
                  })(),
                  color: '#AAB2BD',
                  fontSize: '9px',
                  textTransform: 'uppercase'
                }}>
                  {(() => {
                    const model = getFilteredModels().find(m => m.id === selectedModel);
                    return model && isModelAvailable(model) ? 'Ready' : 'No Key';
                  })()}
                </span>
              </div>
              <div style={{ color: '#AAB2BD', fontSize: '11px', fontFamily: 'JetBrains Mono, Fira Code, SF Mono, monospace' }}>
                {(() => { const m=getFilteredModels().find(m=>m.id===selectedModel); return m? `${m.provider} • ${m.contextLength}`: '—'; })()}
              </div>
            </div>
            <ChevronDown size={12} style={{ opacity: 0.7 }} />
          </div>

          {showModelDropdown ? <div style={{
              position: 'absolute',
              top: '100%',
              left: 0,
              right: 0,
              marginTop: '4px',
              background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 50%, #0a0a0a 100%)',
              borderRadius: '12px',
              borderImage: 'linear-gradient(135deg, #FFD700, #F59E0B, #EAB308, #FFD700) 1',
              border: '1px solid transparent',
              zIndex: 1000,
              maxHeight: '420px',
              overflowY: 'auto',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.6), 0 2px 16px rgba(255, 215, 0, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(16px)',
              animation: 'dropdownSlide 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            }}>
              {/* Model Provider Filter */}
              <div style={{ padding: '12px', borderBottom: '1px solid rgba(255, 215, 0, 0.1)' }}>
                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                  {getAvailableProviders().map(provider => (
                    <button
                      key={provider}
                      onClick={() => setModelProvider(provider)}
                     
                      style={{
                        padding: '4px 10px',
                        borderRadius: '16px',
                        background: modelProvider === provider 
                          ? 'linear-gradient(135deg, #C2A76E, #A58B5F)' 
                          : 'linear-gradient(135deg, #1A1A1A, #1F1F1F)',
                        border: '1px solid #FFFFFF10',
                        color: modelProvider === provider ? '#121212' : '#AAB2BD',
                        boxShadow: modelProvider === provider 
                          ? '0 2px 8px rgba(194,167,110,0.3)' 
                          : '0 1px 4px rgba(0,0,0,0.2)',
                      }}
                      onMouseEnter={(e) => {
                        if (modelProvider !== provider) {
                          e.currentTarget.style.background = 'linear-gradient(135deg, #222222, #2A2A2A)';
                          e.currentTarget.style.transform = 'translateY(-1px)';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (modelProvider !== provider) {
                          e.currentTarget.style.background = 'linear-gradient(135deg, #1A1A1A, #1F1F1F)';
                          e.currentTarget.style.transform = 'translateY(0px)';
                        }
                      }}
                    >
                      {provider}
                    </button>
                  ))}
                </div>
              </div>

              {/* Grouped Model Options */}
              {Object.entries(getGroupedModels()).map(([provider, models]) => (
                <div key={provider} style={{ borderBottom: '1px solid #1A1A1A' }}>
                  <div style={{
                    padding: '8px 12px',
                    background: 'linear-gradient(90deg, #111 0%, #181818 50%, #111 100%)',
                    fontSize: '11px',
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    color: '#C2A76E',
                    display: 'flex',
                    justifyContent: 'space-between',
                    position: 'sticky',
                    top: 0,
                    zIndex: 5
                  }}>
                    <span>{provider} ({models.length})</span>
                  </div>
                  {models.map(model => {
                    const meta = modelOptionMap[model.id];
                    const badge = meta?.badge || (model.provider === 'ollama' ? 'Local' : undefined);
                    const deprecated = meta?.deprecated;
                    return (
                      <div
                        key={model.id}
                        onClick={() => {
                          setSelectedModel(model.id);
                          setShowModelDropdown(false);
                        }}
                        style={{
                          padding: '12px',
                          cursor: 'pointer',
                          backgroundColor: selectedModel === model.id ? '#1A1A1A' : 'transparent',
                          borderBottom: '1px solid #1A1A1A',
                          opacity: isModelAvailable(model) ? 1 : 0.5
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#1A1A1A'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = selectedModel === model.id ? '#1A1A1A' : 'transparent'}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px', flexWrap: 'wrap' }}>
                          <span style={{ color: '#AAB2BD', fontSize: '13px', fontWeight: '500' }}>
                            {model.name}{deprecated ? ' (Legacy)' : ''}
                          </span>
                          {badge ? <span style={{
                              padding: '1px 6px',
                              borderRadius: '12px',
                              background: badge === 'Best' ? '#C2A76E33' : badge === 'Fast' ? '#2ECC7133' : badge === 'Reasoning' ? '#6366F133' : badge === 'Experimental' ? '#F59E0B33' : '#374151',
                              color: badge === 'Best' ? '#C2A76E' : badge === 'Fast' ? '#2ECC71' : badge === 'Reasoning' ? '#6366F1' : badge === 'Experimental' ? '#F59E0B' : '#AAB2BD',
                              fontSize: '10px',
                              textTransform: 'uppercase'
                            }} title={meta?.notes || badge}>
                              {badge}
                            </span> : null}
                          <span style={{
                            padding: '1px 4px',
                            background: isModelAvailable(model) ? '#2ECC71' : '#E74C3C',
                            color: '#AAB2BD',
                            fontSize: '9px',
                            textTransform: 'uppercase'
                          }}>
                            {isModelAvailable(model) ? 'Ready' : 'No Key'}
                          </span>
                          <span style={{
                            padding: '1px 4px',
                            background: '#374151',
                            color: '#AAB2BD',
                            fontSize: '9px',
                            textTransform: 'uppercase'
                          }}>
                            {model.provider}
                          </span>
                        </div>
                        <div style={{ color: '#AAB2BD', fontSize: '11px', marginBottom: '2px' }}>
                          {model.description}
                        </div>
                        <div style={{ color: '#AAB2BD', fontSize: '10px' }}>
                          <span style={{ marginRight: '12px' }}>Context: {model.contextLength}</span>
                          <span>Strengths: {model.strengths.join(', ')}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div> : null}
        </div>

        {/* Quick Actions */}
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <div 
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '8px',
              padding: '6px 12px',
              background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, rgba(251, 191, 36, 0.1) 100%)',
              border: '1px solid rgba(245, 158, 11, 0.2)',
              borderRadius: '8px',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              backdropFilter: 'blur(8px)',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.2)',
              fontFamily: '"JetBrains Mono", "Fira Code", "SF Mono", monospace'
            }}
            onClick={() => setShowQuickPrompts(!showQuickPrompts)}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'linear-gradient(135deg, rgba(245, 158, 11, 0.2) 0%, rgba(251, 191, 36, 0.2) 100%)';
              e.currentTarget.style.borderColor = 'rgba(245, 158, 11, 0.4)';
              e.currentTarget.style.transform = 'translateY(-1px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, rgba(251, 191, 36, 0.1) 100%)';
              e.currentTarget.style.borderColor = 'rgba(245, 158, 11, 0.2)';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
            title="Toggle quick prompts"
          >
            <Lightbulb size={14} color="#C2A76E" />
            <span style={{ 
              fontSize: '12px', 
              fontWeight: '600', 
              color: '#C2A76E',
              userSelect: 'none',
              fontFamily: 'inherit'
            }}>
              Quick Prompts
            </span>
            {showQuickPrompts ? <ChevronUp size={14} color="#C2A76E" /> : <ChevronDown size={14} color="#C2A76E" />}
          </div>
        </div>
      </div>

      {/* Quick Prompts */}
      {showQuickPrompts ? <div style={{ padding: '12px 16px', borderBottom: '1px solid #1A1A1A', backgroundColor: '#121212', fontFamily: '"JetBrains Mono", "Fira Code", "SF Mono", monospace' }}>
          {/* Category Filter */}
          <div style={{ marginBottom: '12px', display: 'flex', gap: '8px', flexWrap: 'wrap', fontFamily: 'inherit' }}>
            {['all', 'frontend', 'backend', 'devops', 'ai', 'algorithms', 'testing', 'documentation', 'analysis'].map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                style={{
                  padding: '4px 8px',
                  border: '1px solid #1a1a1a',
                  background: selectedCategory === category ? '#1a1a1a' : '#000000',
                  color: '#AAB2BD',
                  fontSize: '11px',
                  cursor: 'pointer',
                  textTransform: 'capitalize',
                  fontFamily: 'inherit'
                }}
              >
                {category}
              </button>
            ))}
          </div>
          
          {/* Prompt Grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
            gap: '8px',
            fontFamily: 'inherit'
          }}>
            {quickPrompts
              .filter(prompt => selectedCategory === 'all' || prompt.category === selectedCategory)
              .map(prompt => (
        <button
                key={prompt.id}
                style={{
                  padding: '8px',
                  border: '1px solid #1a1a1a',
                  background: '#000000',
                  color: '#AAB2BD',
                  fontSize: '11px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  textAlign: 'left',
          transition: 'all 0.2s ease',
          fontFamily: 'inherit'
                }}
                onClick={() => handleQuickPrompt(prompt.prompt)}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#1a1a1a';
                  e.currentTarget.style.transform = 'translateY(-1px)';
                  e.currentTarget.style.boxShadow = '0 4px 12px rgba(194,167,110,0.25)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = '#000000';
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
                title={prompt.prompt}
              >
                <span style={{ color: prompt.color }}>{prompt.icon}</span>
                <span style={{ fontFamily: 'inherit' }}>{prompt.title}</span>
              </button>
            ))}
          </div>
        </div> : null}

  {/* Enhanced Messages with Stagger Animation */}
  <div
  style={messagesStyles}
    ref={messageListRef}
    data-testid="messages"
  className="ai-chat-scrollbar"
  >
    <style>{chatScrollbarCss}</style>
        {/* Search bar */}
        {searchOpen ? <div style={{ position:'sticky', top:0, zIndex:5, display:'flex', gap:8, alignItems:'center', padding:'6px 8px', background:'rgba(0,0,0,0.5)', borderBottom:'1px solid #1a1a1a' }}>
            <Search size={14} color="#C2A76E" />
            <input
              ref={searchInputRef}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search in conversation… (Esc to close)"
              style={{ flex:1, background:'#0f0f0f', color:'#ddd', border:'1px solid #333', borderRadius:6, padding:'6px 8px', fontSize:12 }}
              onKeyDown={(e) => { if (e.key === 'Escape') { setSearchOpen(false); setSearchQuery(''); } }}
            />
            <button
              className="msg-ctrl"
              onClick={() => { setSearchOpen(false); setSearchQuery(''); }}
              title="Close search"
            >Close</button>
          </div> : null}

        {/* Empty-state CTA for API Keys */}
        {(() => {
          const hasUser = messages.some(m => m.type === 'user');
          const currentModel = getFilteredModels().find(m => m.id === selectedModel);
          const needsKey = currentModel && currentModel.provider !== 'ollama' && !isModelAvailable(currentModel);
          if (!hasUser && needsKey) {
            return (
              <div style={{ padding:'24px', textAlign:'center', color:'#AAB2BD' }}>
                <div style={{ fontSize:14, marginBottom:8 }}>Add your API key to start chatting</div>
                <div style={{ fontSize:12, opacity:.85, marginBottom:12 }}>Open Settings → API Keys, paste the key for {currentModel.provider.toUpperCase()}, then send your first message.</div>
                <button
                  className="msg-ctrl"
                  onClick={() => { setInitialSettingsTab('api-keys'); setSettingsOpen(true); }}
                  title="Open AI Settings — API Keys"
                >Open API Keys</button>
              </div>
            );
          }
          return null;
        })()}

        <VirtualizedMessageList
          items={messages}
          keyOf={(m) => m.id}
          estimatedRowHeight={140}
          overscanPx={isMobile ? Math.max(600, Math.floor(VLIST_OVERSCAN_PX * 0.8)) : VLIST_OVERSCAN_PX}
          containerRef={messageListRef}
          storageKey={`ai.scroll:${projectIdRef.current || 'default'}`}
          renderRow={(message, idx) => {
            const prev = idx > 0 ? messages[idx - 1] : null;
            const grouped = !!(prev && prev.type === message.type && (message.timestamp.getTime() - prev.timestamp.getTime()) < 3 * 60 * 1000);
            const meta = (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, opacity: 0.9 }}>
                <span>{message.timestamp.toLocaleString()}</span>
                {message.type === 'ai' && (
                  <button
                    className="msg-ctrl"
                    title="Copy message"
                    onClick={() => copyToClipboard(message.content, message.id)}
                  >Copy</button>
                )}
        {message.type === 'ai' && !message.isStreaming && (
                  <button
                    className="msg-ctrl"
          title="Send to Editor"
          
                    onClick={() => {
                      try {
                        const blocks = extractCodeBlocks(message.content);
                        if (!blocks.length) {
                          const fname = defaultFilename('ai-output', idx + 1, 'md');
                          if (!domEditorBridge.sizeGuard(message.content)) {
                            showToast({ kind: 'warning', message: 'Large content. Opened in new tab.', contextKey: 'editor:guard:msg' });
                          }
                          domEditorBridge.openNewTab({ filename: fname, code: message.content, language: 'markdown' });
                          showToast({ kind: 'success', message: 'Sent message to editor', contextKey: 'editor:msg' });
                          return;
                        }
                        blocks.forEach((b, i2) => {
                          const { language, ext } = guessByLanguage(b.language);
                          const fname = defaultFilename('ai-snippet', i2 + 1, ext);
                          const code = b.code;
                          if (!domEditorBridge.sizeGuard(code)) {
                            showToast({ kind: 'warning', message: `Snippet ${i2 + 1} is large. Opened in new tab.`, contextKey: `editor:guard:${i2}` });
                          }
                          domEditorBridge.openNewTab({ filename: fname, code, language });
                        });
                        showToast({ kind: 'success', message: `Sent ${blocks.length} snippet(s) to editor`, contextKey: 'editor:snippets' });
                      } catch (e: any) {
                        reportError({ source: 'ui', code: 'unknown', message: String(e?.message || e) });
                      }
                    }}
                  >Send to Editor</button>
                )}
              </div>
            );
            const footer = (message.type === 'ai') ? (
              <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                {message.isStreaming ? (
                  <button
                    className="msg-ctrl"
                    title="Stop"
                    onClick={() => { lastAbortedMsgIdRef.current = message.id; abortStreaming('user_cancel'); }}
                  >Stop</button>
                ) : lastAbortedMsgIdRef.current === message.id ? (
                  <button
                    className="msg-ctrl"
                    title="Continue"
                    onClick={() => {
                      // Find nearest preceding user message to this AI message
                      let prevUser: string | null = null;
                      for (let j = idx - 1; j >= 0; j--) {
                        if (messages[j].type === 'user') { prevUser = messages[j].content; break; }
                      }
                      overrideContentRef.current = prevUser || input;
                      suppressNextUserAppendRef.current = true;
                      void handleSendMessage();
                      lastAbortedMsgIdRef.current = null;
                    }}
                  >Continue</button>
                ) : null}
                {/* Regenerate for last AI message */}
                {idx === messages.length - 1 && !message.isStreaming && (
                  <button
                    className="msg-ctrl"
                    title="Regenerate"
                    onClick={() => {
                      // Find the nearest preceding user message
                      for (let i = messages.length - 1; i >= 0; i--) {
                        if (messages[i].type === 'user') {
                          overrideContentRef.current = messages[i].content;
                          suppressNextUserAppendRef.current = true;
                          void handleSendMessage();
                          break;
                        }
                      }
                    }}
                  >Regenerate</button>
                )}
              </div>
            ) : null;

            return (
              <section
                data-testid={message.type === 'ai' ? 'assistant-msg' : message.type === 'user' ? 'user-msg' : 'system-msg'}
                data-rid={currentStreamingMsgIdRef.current === message.id ? 'active' : undefined}
              >
              <ChatMessage
                id={message.id}
                type={message.type as any}
                timestamp={message.timestamp}
                alignRight={message.type === 'user'}
                subLabel={message.type === 'ai' ? (getFilteredModels().find(m => m.id === message.model)?.name || message.model) : undefined}
                canCopy={message.type === 'ai'}
                copied={copiedMessageId === message.id}
                onCopy={() => copyToClipboard(message.content, message.id)}
                grouped={grouped}
                meta={meta}
                footer={footer}
              >
                {message.type === 'ai' ? (
                  <div>
                    {renderMessageContent(message.content, message)}
                    {/* Apply-to-Editor footer for first fenced block when not streaming */}
                    {!message.isStreaming && (() => {
                      const first = extractFirstFencedBlock(message.content);
                      const code = first.codeBlock;
                      const lang = first.languageFromFence;
                      if (!code) return null;
                      const isShell = /^(sh|bash|shell|zsh|powershell|ps1|cmd)$/i.test(lang || '');
                      const oversized = code.length > 200_000 || code.split(/\r?\n/).length > 2000;
                      const disabled = oversized;
                      const label = insertBehavior === 'newTab' ? 'Apply: Open in new tab' : 'Apply: Insert at cursor';
                      return (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10 }}>
                          <button
                            type="button"
                            disabled={disabled}
                            className="ai-apply-footer-btn"
                            onClick={async () => {
                              if (oversized) return;
                              try {
                                const { normalizeAssistantMessage } = await import('@/utils/ai/lang/normalizeOutput');
                                const { getLangSpec } = await import('@/utils/ai/lang/languageMap');
                                const selectedSpec = getLangSpec(selectedLanguage) || getLangSpec('javascript')!;
                                const payload = `\n\n//// file: \n\n\`\`\`${lang || ''}\n${code}\n\`\`\``;
                                const { files } = normalizeAssistantMessage(payload, { selectedLang: selectedSpec, mode: (message?.mode as any) || (aiSettings.mode as any) || 'beginner' });
                                const f = files[0] || { path: `snippet-${Date.now()}.${(lang||'txt')}`, code, fence: lang } as any;
                                let tabId: string;
                                if (insertBehavior === 'newTab') {
                                  const r = await editorOpenNewTab({ filename: f.path, code: f.code, language: inferFenceLang(f.fence, f.code) });
                                  tabId = r.tabId;
                                } else {
                                  const r = await insertIntoActive({ code: f.code, language: inferFenceLang(f.fence, f.code) });
                                  tabId = r.tabId;
                                }
                                if (autoPreview && lang && /^(html?|css|javascript)$/.test((lang||'').toLowerCase())) {
                                  await previewRun(tabId);
                                }
                                showToast({ kind: 'success', message: insertBehavior === 'newTab' ? 'Opened snippet in new tab' : 'Inserted snippet' });
                              } catch {
                                showToast({ kind: 'error', message: 'Apply failed' });
                              }
                            }}
                            title={disabled ? 'Snippet too large to apply from footer' : label}
                          >
                            {label}
                          </button>
                          {isShell ? <span style={{ fontSize: 11, opacity: 0.8 }}>Shell-like code. Review before running.</span> : null}
                          {oversized ? <span style={{ fontSize: 11, opacity: 0.8 }}>Too large to auto-apply.</span> : null}
                        </div>
                      );
                    })()}
                  </div>
                ) : message.content}
              </ChatMessage>
              </section>
            );
          }}
  />
  <div ref={messagesEndRef} />

  {/* a11y live region removed */}

  {isTyping && !messages.some(m => (m as any).isStreaming) ? <div style={{ 
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-start',
            marginBottom: '16px'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              marginBottom: '6px',
              fontSize: '11px',
              color: '#AAB2BD',
              paddingLeft: '4px'
            }}>
              <Bot size={12} color="#C2A76E" />
              <span>AI Assistant</span>
              <span style={{ color: '#6B7280' }}>•</span>
              <span style={{ color: '#2ECC71' }}>typing...</span>
            </div>
            <div style={{
              ...createMessageStyles(false),
              background: 'linear-gradient(135deg, #121212 0%, #1A1A1A 50%, #121212 100%)',
              border: '1px solid #FFFFFF10',
              minWidth: '80px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '12px 20px'
            }}>
              <div style={{ 
                display: 'flex', 
                gap: '4px', 
                alignItems: 'center'
              }}>
                <div style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  background: '#FFD700',
                  animation: 'typingDot 1.4s ease-in-out infinite',
                  animationDelay: '0s'
                }} />
                <div style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  background: '#FFD700',
                  animation: 'typingDot 1.4s ease-in-out infinite',
                  animationDelay: '0.2s'
                }} />
                <div style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  background: '#FFD700',
                  animation: 'typingDot 1.4s ease-in-out infinite',
                  animationDelay: '0.4s'
                }} />
              </div>
            </div>
          </div> : null}
        <div ref={messagesEndRef} />
      </div>

  {/* Enhanced Input System */}
  <div style={{ ...inputContainerStyles, paddingBottom: 'calc(12px + env(safe-area-inset-bottom, 0px))' }} className="ai-composer">
        {/* Character Counter and Status */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '8px',
          fontSize: '11px',
          color: '#666'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ color: getCharacterCountColor(input.length, maxCharacters) }}>
              {input.length}/{maxCharacters}
            </span>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              opacity: 0.7
            }}>
              <kbd style={{
                padding: '1px 4px',
                background: '#1a1a1a',
                border: '1px solid #2a2a2a',
                borderRadius: '3px',
                fontSize: '9px',
                color: '#888'
              }}>Enter</kbd>
              <span style={{ fontSize: '9px' }}>Send</span>
              <span style={{ margin: '0 4px', color: '#333' }}>•</span>
              <kbd style={{
                padding: '1px 4px',
                background: '#1a1a1a',
                border: '1px solid #2a2a2a',
                borderRadius: '3px',
                fontSize: '9px',
                color: '#888'
              }}>Shift+Enter</kbd>
              <span style={{ fontSize: '9px' }}>New line</span>
            </div>
          </div>
          
          {/* Enhanced Model Status Indicator */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              padding: '2px 6px',
              borderRadius: '4px',
              background: 'rgba(0, 0, 0, 0.3)',
              fontSize: '10px'
            }}>
              <div style={{
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                background: (() => {
                  const model = getFilteredModels().find(m => m.id === selectedModel);
                  return model && isModelAvailable(model) ? '#10B981' : '#EF4444';
                })(),
                boxShadow: `0 0 6px ${(() => {
                  const model = getFilteredModels().find(m => m.id === selectedModel);
                  return model && isModelAvailable(model) ? '#10B981' : '#EF4444';
                })()}60`
              }} />
              <span style={{ 
                fontSize: '10px',
                color: (() => {
                  const model = getFilteredModels().find(m => m.id === selectedModel);
                  return model && isModelAvailable(model) ? '#10B981' : '#EF4444';
                })()
              }}>
                {(() => {
                  const model = getFilteredModels().find(m => m.id === selectedModel);
                  return model && isModelAvailable(model) ? 'Ready' : 'No Key';
                })()}
              </span>
              {/* Response Time Indicator */}
              {(() => {
                const model = getFilteredModels().find(m => m.id === selectedModel);
                const responseTime = apiResponseTimes[model?.provider || ''];
                if (responseTime) {
                  return (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '2px' }}>
                      <Clock size={8} color="#666" />
                      <span style={{ color: '#666', fontSize: '9px' }}>
                        {responseTime}ms
                      </span>
                    </div>
                  );
                }
                return null;
              })()}
            </div>
          </div>
        </div>
        
        {/* Quick Actions Bar - Above Input */}
        <div
          onDragOver={qaOnDragOver}
          onDragLeave={qaOnDragLeave}
          onDrop={qaOnDrop}
          style={{
          padding: '12px 20px',
          background: qaDragging ? 'linear-gradient(135deg, rgba(194,167,110,0.08) 0%, rgba(165,139,95,0.08) 100%)' : 'linear-gradient(135deg, #121212 0%, #1A1A1A 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '12px',
          backdropFilter: 'blur(8px)',
          borderImage: qaDragging ? 'linear-gradient(135deg, #C2A76E, #A58B5F) 1' : undefined,
          borderColor: qaDragging ? 'transparent' : undefined,
          outline: qaDragging ? '2px dashed rgba(194,167,110,0.35)' : 'none',
          outlineOffset: qaDragging ? '2px' : '0',
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            flex: 1
          }}>
            <span style={{
              fontSize: '11px',
              color: '#AAB2BD',
              fontWeight: '600',
              letterSpacing: '1px',
              display: 'flex',
              alignItems: 'center'
            }}>
              QUICK ACTIONS
            </span>
            <div style={{
              height: '1px',
              background: 'linear-gradient(90deg, rgba(194,167,110,0.35), transparent)',
              flex: 1
            }} />
          </div>
          
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            {/* Hidden input for Quick Attach action */}
            <input ref={quickAttachInputRef} type="file" multiple onChange={quickAttachOnChange} style={{ display:'none' }} />
            {quickActions.map((action) => {
              const IconComponent = action.icon;
              return (
        <button
                  key={action.id}
                  onClick={() => {
                    action.action();
                    if (action.id === 'suggestions') {
                      // Keep suggestions open, close others
                    }
                  }}
                  style={{
          width: '36px',
          height: '36px',
          borderRadius: '10px',
          border: '1px solid #FFFFFF10',
          background: 'linear-gradient(135deg, #1A1A1A, #1F1F1F)',
          color: '#C2A76E',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    backdropFilter: 'blur(10px)',
                    position: 'relative',
                    overflow: 'hidden'
                  }}
                  title={action.label}
                  onMouseEnter={(e) => {
          e.currentTarget.style.background = 'linear-gradient(135deg, rgba(194,167,110,0.18), rgba(165,139,95,0.12))';
          e.currentTarget.style.borderColor = '#C2A76E';
                    e.currentTarget.style.transform = 'translateY(-1px)';
                    e.currentTarget.style.boxShadow = '0 4px 12px rgba(194,167,110,0.25)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'linear-gradient(135deg, #1A1A1A, #1F1F1F)';
                    e.currentTarget.style.borderColor = '#FFFFFF10';
                    e.currentTarget.style.transform = 'translateY(0px)';
                    e.currentTarget.style.boxShadow = 'none';
                  }}
                >
                  <IconComponent size={18} />
                  
                  {/* Hover effect overlay */}
                  <div style={{
                    position: 'absolute',
                    inset: 0,
                    background: 'linear-gradient(135deg, rgba(194,167,110,0.15), rgba(165,139,95,0.06))',
                    opacity: 0,
                    transition: 'opacity 0.2s ease',
                    pointerEvents: 'none'
                  }} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Input Container with Enhanced Send Button */}
        {/* Input Container with AttachBar and Enhanced Send Button */}
        <div style={{ position: 'relative' }}>
          {/* Attach control + chips (non-intrusive) */}
          <div style={{ marginBottom: 8 }}>
            <AttachBar />
          </div>
          {/* Mini Smart Suggestions */}
          {suggestions.length > 0 && (
            <div style={{
              position: 'absolute',
              bottom: '100%',
              left: 0,
              right: 0,
              background: 'linear-gradient(145deg, rgba(37,37,37,0.95) 0%, rgba(18,18,18,0.98) 100%)',
              backdropFilter: 'blur(16px)',
              border: '1px solid #3a3a3a',
              borderBottom: 'none',
              borderRadius: '12px 12px 0 0',
              padding: '12px 14px 14px',
              boxShadow: '0 12px 32px rgba(0,0,0,0.5), 0 4px 16px rgba(0,0,0,0.3), inset 0 1px 0 rgba(194,167,110,0.1)',
              zIndex: 100
            }}>
              <div style={{
                fontSize: '11px',
                color: '#c2a76e',
                marginBottom: '10px',
                fontWeight: 600,
                letterSpacing: '0.6px',
                opacity: 0.95,
                fontFamily: '"JetBrains Mono", "Fira Code", monospace'
              }}>
                SMART SUGGESTIONS:
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                {suggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setInput(suggestion);
                      setSuggestions([]);
                      scheduleAdjustTextarea();
                    }}
                    style={{
                      background: 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)',
                      border: '1px solid #3a3a3a',
                      borderRadius: '8px',
                      padding: '6px 11px',
                      color: '#AAB2BD',
                      fontSize: '11px',
                      cursor: 'pointer',
                      textAlign: 'left',
                      transition: 'all 0.25s ease',
                      whiteSpace: 'nowrap',
                      fontFamily: '"JetBrains Mono", "Fira Code", monospace'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(145deg, rgba(194,167,110,0.1) 0%, rgba(37,37,37,0.9) 100%)';
                      e.currentTarget.style.borderColor = '#c2a76e';
                      e.currentTarget.style.transform = 'translateY(-1px)';
                      e.currentTarget.style.boxShadow = '0 6px 14px rgba(0,0,0,0.4)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)';
                      e.currentTarget.style.borderColor = '#3a3a3a';
                      e.currentTarget.style.transform = 'translateY(0px)';
                      e.currentTarget.style.boxShadow = 'none';
                    }}
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          )}
          
          <textarea
            ref={inputRef}
            value={input}
            onChange={handleInputChange}
            data-chat-input
            data-testid="prompt-input"
            onKeyDown={handleKeyDown}
            onCompositionStart={() => { composingRef.current = true; }}
            onCompositionEnd={() => {
              composingRef.current = false;
              // If user pressed Enter to finish composition and no modifiers, send now
              if (pendingEnterRef.current) {
                pendingEnterRef.current = false;
                sendIfReady();
              }
            }}
            onPaste={() => { setTimeout(() => scheduleAdjustTextarea(), 0); }}
            placeholder="Ask anything about coding, design, or development... (Enter to send, Shift+Enter for new line)"
            style={inputStyleMemo}
            onFocus={(e) => {
              e.currentTarget.style.borderImage = 'linear-gradient(135deg, #FFD700, #F59E0B, #EAB308, #FFD700) 1';
              e.currentTarget.style.boxShadow = '0 4px 16px rgba(255, 215, 0, 0.2), 0 2px 8px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)';
            }}
            onBlur={(e) => {
              if (!input.trim()) {
                e.currentTarget.style.borderImage = 'linear-gradient(135deg, #1a1a1a, #2a2a2a, #1a1a1a) 1';
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.05)';
              }
            }}
          />
          {/* Inline status / hints */}
          {!beginnerMode && !isTyping && !input.trim() && (
            <div style={{ position:'absolute', bottom: 6, left: 14, fontSize:11, color:'#707070', pointerEvents:'none', fontFamily:'"JetBrains Mono","Fira Code",monospace' }}>
              Press <span style={{color:'#C2A76E'}}>Enter</span> to send
            </div>
          )}
          {isTyping ? <div style={{ position:'absolute', bottom: 6, left: 14, display:'flex', alignItems:'center', gap:6, fontSize:11, color:'#C2A76E', fontFamily:'"JetBrains Mono","Fira Code",SF Mono,monospace' }} title="Model is generating…">
              <span style={{ width:10, height:10, borderRadius:'50%', background:'linear-gradient(135deg,#C2A76E,#A58B5F)', boxShadow:'0 0 6px rgba(194,167,110,0.6)', position:'relative', animation:'aiPulse 1.1s ease-in-out infinite' }} />
              <span>{(() => { const m = getFilteredModels().find(mm=>mm.id===selectedModel); return `Thinking (${m?.name || selectedModel})…`; })()}</span>
              {showCancelHint ? <span style={{ marginLeft:8, opacity:.7, color:'#AAB2BD' }}>(Esc to cancel)</span> : null}
            </div> : null}
          
          {/* Enhanced Send Button */}
          <div style={{
            position: 'absolute',
            right: '8px',
            top: '50%',
            transform: 'translateY(-50%)',
            display: 'flex',
            alignItems: 'center',
            gap: '6px'
          }}>
            {/* Character limit warning */}
            {input.length >= maxCharacters * 0.9 && (
              <div style={{
                padding: '2px 6px',
                background: input.length >= maxCharacters * 0.95 ? '#E74C3C' : '#E1C542', 
                color: '#121212',
                fontSize: '9px',
                borderRadius: '4px',
                fontWeight: '600',
                animation: input.length >= maxCharacters ? 'pulse 1s infinite' : 'none'
              }}>
                {input.length >= maxCharacters ? 'LIMIT' : 'NEAR LIMIT'}
              </div>
            )}
            
            {/* Enhanced Send Button */}
      {streamState.isStreaming ? <button
        onClick={() => { abortStreaming('user_cancel'); setIsTyping(false); scheduleAdjustTextarea(); }}
                style={{
                  background: 'linear-gradient(135deg,#E74C3C,#C0392B)',
                  border: '1px solid #FFFFFF10',
                  color: '#fff',
                  width: '48px',
                  height: '48px',
                  borderRadius: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  transition: 'all .25s',
                  boxShadow: '0 4px 12px rgba(231,76,60,0.35)'
                }}
                title="Cancel streaming"
                data-testid="cancel-stream-btn"
                onMouseEnter={(e) => { e.currentTarget.style.background='linear-gradient(135deg,#C0392B,#E74C3C)'; e.currentTarget.style.transform='translateY(-1px) scale(1.05)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background='linear-gradient(135deg,#E74C3C,#C0392B)'; e.currentTarget.style.transform='translateY(0) scale(1)'; }}
              >
                <X size={20} />
              </button> : null}
            <button
              onClick={() => sendIfReady()}
              disabled={!input.trim() || isTyping || input.length > maxCharacters}
              style={{
                background: (input.trim() && !isTyping && input.length <= maxCharacters)
                  ? 'linear-gradient(135deg, #C2A76E, #A58B5F)'
                  : 'rgba(42, 42, 42, 0.8)',
                border: '1px solid #FFFFFF10',
                color: (input.trim() && !isTyping && input.length <= maxCharacters) ? '#121212' : '#6B7280',
                width: '48px',
                height: '48px',
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: (input.trim() && !isTyping && input.length <= maxCharacters) ? 'pointer' : 'not-allowed',
                transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                opacity: (input.trim() && !isTyping && input.length <= maxCharacters) ? 1 : 0.5,
                boxShadow: (input.trim() && !isTyping && input.length <= maxCharacters)
                  ? '0 4px 12px rgba(194, 167, 110, 0.3)'
                  : 'none',
                backdropFilter: 'blur(8px)',
                position: 'relative',
                overflow: 'hidden'
              }}
              onMouseEnter={(e) => {
                if (input.trim() && !isTyping && input.length <= maxCharacters) {
                  e.currentTarget.style.transform = 'translateY(-1px) scale(1.05)';
                  e.currentTarget.style.boxShadow = '0 6px 16px rgba(194, 167, 110, 0.4)';
                }
              }}
              onMouseLeave={(e) => {
                if (input.trim() && !isTyping && input.length <= maxCharacters) {
                  e.currentTarget.style.transform = 'translateY(0px) scale(1)';
                  e.currentTarget.style.boxShadow = '0 4px 12px rgba(255, 215, 0, 0.3)';
                }
              }}
              title={(input.trim() && !isTyping && input.length <= maxCharacters) 
                ? 'Send message (Enter)' 
                : !input.trim() 
                  ? 'Type a message first' 
                  : isTyping 
                    ? 'AI is responding...' 
                    : 'Message too long'
              }
              data-testid="send-btn"
            >
              {isTyping ? (
                <div style={{
                  width: '20px',
                  height: '20px',
                  border: '2px solid transparent',
                  borderTop: '2px solid currentColor',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite'
                }} />
              ) : (
                <Send size={20} />
              )}
            </button>
          </div>
        </div>
        
        {/* Progressive Character Count Bar */}
        <div style={{
          width: '100%',
          height: '2px',
          background: '#1a1a1a',
          borderRadius: '1px',
          marginTop: '8px',
          overflow: 'hidden'
        }}>
          <div style={{
            height: '100%',
            width: `${Math.min((input.length / maxCharacters) * 100, 100)}%`,
            background: `linear-gradient(90deg, ${getCharacterCountColor(input.length, maxCharacters)}, ${getCharacterCountColor(input.length, maxCharacters)}80)`,
            borderRadius: '1px',
            transition: 'all 0.3s ease',
            boxShadow: input.length > 0 ? `0 0 8px ${getCharacterCountColor(input.length, maxCharacters)}40` : 'none'
          }} />
        </div>
      </div>

      {/* Debug overlay (local flag) */}
      {debugOn ? <div style={{ position:'fixed', right:10, bottom:10, zIndex:2000, background:'rgba(0,0,0,0.6)', color:'#ddd', padding:'8px 10px', border:'1px solid #333', borderRadius:8, fontSize:11 }}>
          <div>isStreaming: {String(streamState.isStreaming)}</div>
          <div>flushes: {flushCountRef.current || 0}</div>
          <div>buffer: {streamBufferRef.current.length}</div>
          <div>lastFlushAge: {lastFlushAtRef.current ? (Date.now()-lastFlushAtRef.current) : 0}ms</div>
          <div>model: {selectedModel}</div>
          <div>lastError: {lastSystemNote || '-'}</div>
          <button style={{ marginTop:6 }} onClick={() => {
            try {
              const payload = {
                isStreaming: streamState.isStreaming,
                flushes: flushCountRef.current || 0,
                bufLen: streamBufferRef.current.length,
                lastFlushAgeMs: lastFlushAtRef.current ? (Date.now()-lastFlushAtRef.current) : 0,
                model: selectedModel,
                note: lastSystemNote,
              };
              navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
              addNotification('success', 'Copied debug payload');
            } catch {}
          }}>Copy Session Debug</button>
        </div> : null}

      {/* Enhanced Error State Display */}
      {errorState.hasError ? <div style={{
          position: 'fixed',
          top: '20px',
          left: '50%',
          transform: 'translateX(-50%)',
          background: 'rgba(239, 68, 68, 0.95)',
          backdropFilter: 'blur(20px)',
          border: '1px solid rgba(239, 68, 68, 0.3)',
          borderRadius: '12px',
          padding: '16px 20px',
          color: 'white',
          zIndex: 1003,
          maxWidth: '500px',
          width: '90%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '12px',
          animation: 'slideDown 0.3s ease-out',
          boxShadow: '0 8px 32px rgba(239, 68, 68, 0.3)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
            <div style={{ fontSize: '20px' }}>
              {(() => {
                switch (errorState.errorType) {
                  case 'network': return '🌐';
                  case 'auth': return '🔑';
                  case 'rate_limit': return '⏱️';
                  case 'server': return '🔧';
                  default: return '❌';
                }
              })()}
            </div>
            <div>
              <div style={{ fontWeight: '600', fontSize: '14px', marginBottom: '2px' }}>
                {(() => {
                  switch (errorState.errorType) {
                    case 'network': return 'Connection Error';
                    case 'auth': return 'Authentication Error';
                    case 'rate_limit': return 'Rate Limited';
                    case 'server': return 'Server Error';
                    default: return 'Error';
                  }
                })()}
              </div>
              <div style={{ fontSize: '12px', opacity: 0.9 }}>
                {errorState.message}
              </div>
            </div>
          </div>
          
          <div style={{ display: 'flex', gap: '8px' }}>
            {errorState.retryable ? <button
                onClick={() => {
                  clearError();
                  // Retry last action if possible
                  if (input.trim()) {
                    handleSendMessage();
                  }
                }}
                style={{
                  background: 'rgba(255, 255, 255, 0.2)',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  borderRadius: '6px',
                  padding: '6px 12px',
                  color: 'white',
                  fontSize: '12px',
                  cursor: 'pointer',
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(255, 255, 255, 0.3)';
                  e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.5)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(255, 255, 255, 0.2)';
                  e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.3)';
                }}
              >
                🔄 Retry
              </button> : null}
            
            <button
              onClick={clearError}
              style={{
                background: 'none',
                border: 'none',
                color: 'white',
                cursor: 'pointer',
                padding: '4px',
                borderRadius: '4px',
                transition: 'background 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(255, 255, 255, 0.2)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'none'}
              
              title="Dismiss"
            >
              <X size={16} />
            </button>
          </div>
        </div> : null}

  {/* Smart Suggestions Panel (Responsive) */}
      {showSuggestions ? <div
          style={{
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: isMobile ? '90vw' : isTablet ? '80vw' : '400px',
            maxWidth: isMobile ? '90vw' : '500px',
            background: 'linear-gradient(145deg, rgba(37,37,37,0.95) 0%, rgba(18,18,18,0.98) 100%)',
            backdropFilter: 'blur(16px)',
            border: '1px solid #3a3a3a',
            borderBottom: 'none',
            borderRadius: isMobile ? '12px' : '14px',
            padding: 0,
            boxShadow: '0 12px 32px rgba(0,0,0,0.5), 0 4px 16px rgba(0,0,0,0.3), inset 0 1px 0 rgba(194,167,110,0.1)'
          }}
        >
          <div style={{
            padding: '20px 24px 16px',
            borderBottom: '1px solid #333333',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: 'rgba(194,167,110,0.05)'
          }}>
            <h3 style={{
              fontSize: '18px',
              fontWeight: 600,
              margin: 0,
              color: '#c2a76e',
              letterSpacing: '0.5px',
              fontFamily: '"JetBrains Mono", "Fira Code", monospace'
            }}>SMART SUGGESTIONS</h3>
            <button
              onClick={() => setShowSuggestions(false)}
              style={{
                width: '32px',
                height: '32px',
                background: 'transparent',
                border: 'none',
                color: '#888888',
                cursor: 'pointer',
                borderRadius: '6px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(194,167,110,0.15)'; e.currentTarget.style.color = '#c2a76e'; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#888888'; }}
              
            >
              <X size={18} />
            </button>
          </div>
          <div style={{
            display: 'grid',
            gap: '10px',
            maxHeight: '320px',
            overflowY: 'auto',
            padding: '22px 24px 24px'
          }}>
            {SMART_SUGGESTIONS.map((suggestion: string, index: number) => (
              <button
                key={index}
                onClick={() => {
                  setInput(suggestion);
                  setShowSuggestions(false);
                  scheduleAdjustTextarea();
                }}
                style={{
                  background: 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)',
                  border: '1px solid #3a3a3a',
                  borderRadius: '8px',
                  padding: '14px 16px',
                  color: '#AAB2BD',
                  cursor: 'pointer',
                  textAlign: 'left',
                  transition: 'all 0.25s ease',
                  fontSize: '13px',
                  fontFamily: '"JetBrains Mono", "Fira Code", monospace'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'linear-gradient(145deg, rgba(194,167,110,0.1) 0%, rgba(37,37,37,0.9) 100%)';
                  e.currentTarget.style.borderColor = '#c2a76e';
                  e.currentTarget.style.transform = 'translateY(-1px)';
                  e.currentTarget.style.boxShadow = '0 6px 14px rgba(0,0,0,0.4)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)';
                  e.currentTarget.style.borderColor = '#3a3a3a';
                  e.currentTarget.style.transform = 'translateY(0px)';
                  e.currentTarget.style.boxShadow = 'none';
                }}
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div> : null}

      {/* Export Modal (Responsive) */}
      {exportModalOpen ? <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0, 0, 0, 0.8)',
            backdropFilter: 'blur(10px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1002,
            padding: isMobile ? '20px' : '0'
          }}
          onClick={() => setExportModalOpen(false)}
        >
          <div
            data-export-modal
            style={{
              background: 'linear-gradient(145deg, rgba(37,37,37,0.95) 0%, rgba(18,18,18,0.98) 100%)',
              border: '1px solid #3a3a3a',
              borderRadius: isMobile ? '12px' : '14px',
              padding: 0,
              width: isMobile ? '100%' : '540px',
              maxWidth: isMobile ? '100%' : '92vw',
              boxShadow: '0 12px 32px rgba(0,0,0,0.5), 0 4px 16px rgba(0,0,0,0.3), inset 0 1px 0 rgba(194,167,110,0.1)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{
              padding: '20px 24px 16px',
              borderBottom: '1px solid #333333',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              background: 'rgba(194,167,110,0.05)'
            }}>
              <h3 style={{
                fontSize: '18px',
                fontWeight: 600,
                margin: 0,
                color: '#c2a76e',
                letterSpacing: '0.5px',
                fontFamily: '"JetBrains Mono", "Fira Code", monospace'
              }}>EXPORT CHAT HISTORY</h3>
              <button
                onClick={() => setExportModalOpen(false)}
                style={{
                  width: '32px',
                  height: '32px',
                  background: 'transparent',
                  border: 'none',
                  color: '#888888',
                  cursor: 'pointer',
                  borderRadius: '6px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(194,167,110,0.15)'; e.currentTarget.style.color = '#c2a76e'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#888888'; }}
                
              >
                <X size={18} />
              </button>
            </div>
            <div style={{ display: 'flex', gap: '14px', flexDirection: 'column', padding: '24px' }}>
              <button
                onClick={() => {
                  const chatData = {
                    messages,
                    exportDate: new Date().toISOString(),
                    totalMessages: messages.length
                  };
                  const blob = new Blob([JSON.stringify(chatData, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `ai-chat-export-${new Date().toISOString().split('T')[0]}.json`;
                  a.click();
                  URL.revokeObjectURL(url);
                  setExportModalOpen(false);
                  addNotification('success', 'Chat exported successfully!');
                }}
                style={{
                  background: 'linear-gradient(145deg, #c2a76e 0%, #a8935e 100%)',
                  color: '#1a1a1a',
                  border: '1px solid #c2a76e',
                  borderRadius: '8px',
                  padding: '14px 18px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 600,
                  transition: 'all 0.25s ease',
                  fontFamily: '"JetBrains Mono", "Fira Code", monospace'
                }}
                onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-1px)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0px)'}
              >
                Export as JSON
              </button>
              
              <button
                onClick={() => {
                  const chatText = messages.map(msg => 
                    `[${msg.timestamp.toLocaleString()}] ${msg.type.toUpperCase()}: ${msg.content}`
                  ).join('\n\n');
                  const blob = new Blob([chatText], { type: 'text/plain' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `ai-chat-export-${new Date().toISOString().split('T')[0]}.txt`;
                  a.click();
                  URL.revokeObjectURL(url);
                  setExportModalOpen(false);
                  addNotification('success', 'Chat exported successfully!');
                }}
                style={{
                  background: 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)',
                  color: '#AAB2BD',
                  border: '1px solid #3a3a3a',
                  borderRadius: '8px',
                  padding: '14px 18px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 500,
                  transition: 'all 0.25s ease',
                  fontFamily: '"JetBrains Mono", "Fira Code", monospace'
                }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'linear-gradient(145deg, rgba(194,167,110,0.1) 0%, rgba(37,37,37,0.9) 100%)'; e.currentTarget.style.borderColor = '#c2a76e'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)'; e.currentTarget.style.borderColor = '#3a3a3a'; e.currentTarget.style.transform = 'translateY(0)'; }}
              >
                Export as Text
              </button>

              <button
                onClick={() => {
                  const md = messages.map(msg => {
                    const who = msg.type === 'ai' ? 'Assistant' : msg.type === 'user' ? 'User' : 'System';
                    const ts = msg.timestamp.toLocaleString();
                    return `### ${who} · ${ts}\n\n${msg.type === 'ai' ? msg.content : `\`\`\`\n${  msg.content  }\n\`\`\``}`;
                  }).join('\n\n---\n\n');
                  const blob = new Blob([md], { type: 'text/markdown' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `ai-chat-export-${new Date().toISOString().split('T')[0]}.md`;
                  a.click();
                  URL.revokeObjectURL(url);
                  setExportModalOpen(false);
                  addNotification('success', 'Chat exported as Markdown!');
                }}
                style={{
                  background: 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)',
                  color: '#AAB2BD',
                  border: '1px solid #3a3a3a',
                  borderRadius: '8px',
                  padding: '14px 18px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 500,
                  transition: 'all 0.25s ease',
                  fontFamily: '"JetBrains Mono", "Fira Code", monospace'
                }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'linear-gradient(145deg, rgba(194,167,110,0.1) 0%, rgba(37,37,37,0.9) 100%)'; e.currentTarget.style.borderColor = '#c2a76e'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)'; e.currentTarget.style.borderColor = '#3a3a3a'; e.currentTarget.style.transform = 'translateY(0)'; }}
              >
                Export as Markdown
              </button>
              
              <button
                onClick={() => setExportModalOpen(false)}
                style={{
                  background: 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)',
                  color: '#b8b8b8',
                  border: '1px solid #3a3a3a',
                  borderRadius: '8px',
                  padding: '14px 18px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 500,
                  transition: 'all 0.25s ease',
                  fontFamily: '"JetBrains Mono", "Fira Code", monospace'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'linear-gradient(145deg, rgba(194,167,110,0.1) 0%, rgba(37,37,37,0.9) 100%)';
                  e.currentTarget.style.borderColor = '#c2a76e';
                  e.currentTarget.style.color = '#AAB2BD';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'linear-gradient(145deg, rgba(37,37,37,0.8) 0%, rgba(18,18,18,0.9) 100%)';
                  e.currentTarget.style.borderColor = '#3a3a3a';
                  e.currentTarget.style.color = '#b8b8b8';
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div> : null}

      {/* Keyboard Shortcuts Overlay */}
      {showKeysOverlay ? <div
          
          onClick={() => setShowKeysOverlay(false)}
          style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.6)', zIndex: 1100, display:'flex', alignItems:'center', justifyContent:'center' }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{ background:'linear-gradient(145deg, rgba(37,37,37,0.95), rgba(18,18,18,0.98))', border:'1px solid #333', borderRadius:12, padding:'18px 20px', width: 420, maxWidth:'92vw', color:'#ddd' }}
          >
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10 }}>
              <div style={{ fontWeight:700, color:'#c2a76e' }}>Keyboard Shortcuts</div>
              <button className="msg-ctrl" onClick={() => setShowKeysOverlay(false)}>Close</button>
            </div>
            <ul style={{ listStyle:'none', padding:0, margin:0, fontSize:12, lineHeight:1.8 }}>
              <li><kbd>Enter</kbd> — Send</li>
              <li><kbd>Shift</kbd> + <kbd>Enter</kbd> — New line</li>
              <li><kbd>Ctrl</kbd>/<kbd>Cmd</kbd> + <kbd>Enter</kbd> — Send</li>
              <li><kbd>Esc</kbd> — Cancel streaming or clear input</li>
              <li><kbd>?</kbd> — Toggle this overlay</li>
              <li><kbd>Ctrl</kbd>/<kbd>Cmd</kbd> + <kbd>F</kbd> — Search in conversation</li>
            </ul>
          </div>
        </div> : null}
      </Container>
    </>
  );
};

export default AiAssistant;
