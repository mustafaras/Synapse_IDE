import React, { useCallback, useId, useMemo, useRef, useState } from 'react';
import * as Theme from '@/ui/theme/synapseTheme';
import { showToast } from '@/ui/toast/api';
import { type AiPreset, type AiSettings, BUILT_IN_PRESETS } from '@/stores/aiSettings.schema';
import { listModelsByProvider, type ProviderKey } from '@/utils/ai/models/registry';
import { inferEndpointForModel } from '@/utils/ai/models/registry';
import { languages } from '@/components/ai/AiAssistantConfig';

// shared sizing for controls (local constants; not exported)
const CONTROL_H = 32;
const RADIUS_MD = 10;
const PAD_X = 12;
const LAST4_GHOST = true; // optional visual last-4 preview when masked

// generic surface/border (all from existing tokens)
const SURFACE = 'var(--color-glass-01)';
const TEXT = 'var(--color-text-high)';
const TEXT_MED = Theme.SYNAPSE_COLORS.textSecondary;

const baseBtn: React.CSSProperties = {
  height: CONTROL_H,
  padding: `0 ${PAD_X}px`,
  borderRadius: RADIUS_MD,
  border: `1px solid ${Theme.SYNAPSE_COLORS.borderSubtle}`,
  background: SURFACE,
  color: TEXT,
  fontFamily: 'inherit',
  fontSize: 13,
  fontWeight: 600,
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 8,
};

const baseField: React.CSSProperties = {
  height: CONTROL_H,
  padding: `0 ${PAD_X}px`,
  borderRadius: RADIUS_MD,
  border: `1px solid ${Theme.SYNAPSE_COLORS.borderSubtle}`,
  background: 'var(--color-bg-primary)',
  color: TEXT,
  fontFamily: 'inherit',
  fontSize: 13,
};

interface Props {
  value: AiSettings;
  onChange: (next: Partial<AiSettings>) => void; // narrow partial updates
  onSave?: () => void;
  presets?: AiPreset[];
  onCreatePreset?: (name: string) => void;
  onDeletePreset?: (id: string) => void;
  onExport?: (includeKeys: boolean) => void;
  onImport?: (file: File, overwriteKeys: boolean) => void;
  // Optional: limit which sections render (used by Pro modal tabs)
  sections?: Array<'mode-lang' | 'provider-model' | 'generation' | 'presets' | 'keys' | 'profiles'>;
  // Optional: hide internal Save button when parent provides its own footer actions
  hideSaveButton?: boolean;
}

const Section: React.FC<{ title: string } & React.HTMLAttributes<HTMLDivElement>> = ({ title, children, ...rest }) => {
  const headingId = useId();
  return (
    <div
      role="group"
      aria-labelledby={headingId}
      {...rest}
      style={{
        ...rest.style,
        background: Theme.SYNAPSE_ELEVATION.surface,
        border: `1px solid ${Theme.SYNAPSE_COLORS.borderSubtle}`,
  borderRadius: 12,
  padding: 24,
  fontFamily: 'inherit'
      }}
    >
      <h3 id={headingId} style={{
        margin: 0,
  fontFamily: 'inherit',
        fontSize: 13,
        color: Theme.SYNAPSE_COLORS.textSecondary,
        lineHeight: Theme.SYNAPSE_TYPO.lineHeight.normal,
        marginBottom: 8,
      }}>{title}</h3>
      {children}
    </div>
  );
};

type Safety = NonNullable<AiSettings['safetyLevel']>;

// Central normalizer: clamps, coerces, and cascades provider→model, language, presets
type Settings = AiSettings;
function coerceSettings(input: Settings, presetsIn: AiPreset[] = []): Settings {
  // 1) Safe numbers
  const temperature = Math.min(1, Math.max(0, Number.isFinite(input.temperature) ? input.temperature : 0));
  const maxTokens = Math.max(1, Number.isFinite(input.maxTokens) ? Math.floor(input.maxTokens) : 1);
  const timeoutMs = Math.max(500, Number.isFinite(input.timeoutMs) ? Math.floor(input.timeoutMs) : 500);

  // 2) Language
  const langIds = new Set(languages.map(l => l.id));
  const languageId = langIds.has(input.languageId) ? input.languageId : (languages[0]?.id ?? 'en');

  // 3) Provider → model
  const models = listModelsByProvider(input.provider);
  const model = models.some(m => m.id === input.model) ? input.model : (models[0]?.id ?? '');

  // 4) Preset id
  const allPresets = [...BUILT_IN_PRESETS, ...(presetsIn ?? [])];
  const presetIds = new Set(allPresets.map(p => p.id));
  const activePresetId = presetIds.has(input.activePresetId ?? '') ? input.activePresetId : undefined;

  // 5) Keys (trim)
  const keys = Object.fromEntries(
    Object.entries(input.keys ?? {}).map(([k, v]) => [k, (v ?? '').trim()])
  ) as NonNullable<Settings['keys']>;

  return {
    ...input,
    temperature,
    maxTokens,
    timeoutMs,
    languageId,
    model,
    keys,
    ...(activePresetId !== undefined ? { activePresetId } : {}),
  } as Settings;
}

export const AdvancedSettingsPanel: React.FC<Props> = ({ value, onChange, onSave: _onSave, presets = [], onCreatePreset: _onCreatePreset, onDeletePreset: _onDeletePreset, onExport, onImport, sections, hideSaveButton: _hideSaveButton }) => {
  const [includeKeys, setIncludeKeys] = useState(false);
  const [showKeys, setShowKeys] = useState<Record<ProviderKey, boolean>>({ openai: false, anthropic: false, google: false, ollama: false });
  const [keysResetTick, setKeysResetTick] = useState(0);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [statusMsg, setStatusMsg] = useState<string>('');
  const [tempOutOfRange, setTempOutOfRange] = useState(false);
  const [maxOutOfRange, setMaxOutOfRange] = useState(false);
  const [timeoutOutOfRange, setTimeoutOutOfRange] = useState(false);
  const [creatingPreset, setCreatingPreset] = useState(false);
  const [presetName, setPresetName] = useState('');
  const [presetNameError, setPresetNameError] = useState('');
  const [conflictWith, setConflictWith] = useState<AiPreset | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [overwriteKeys, setOverwriteKeys] = useState(false);
  const presetsListRef = useRef<HTMLUListElement | null>(null);
  const presetNameRef = useRef<HTMLInputElement | null>(null);

  const providerModels = useMemo(() => listModelsByProvider(value.provider), [value.provider]);
  const hasModels = providerModels.length > 0;

  const clampTemp = (n: number) => Math.min(1, Math.max(0, Number.isFinite(n) ? n : 0));
  const clampTokens = (n: number) => Math.max(1, Math.floor(n || 1));

  const handleBeginner = useCallback(() => onChange({ mode: 'beginner' }), [onChange]);
  const handlePro = useCallback(() => onChange({ mode: 'pro' }), [onChange]);
  const handleLang = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => onChange({ languageId: e.target.value }), [onChange]);
  const handleProvider = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => {
    const provider = e.target.value as ProviderKey;
    const models = listModelsByProvider(provider);
    const model = models[0]?.id ?? '';
    onChange({ provider, model });
    setStatusMsg('Provider changed. Model list updated.');
  }, [onChange]);
  const handleModel = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => onChange({ model: e.target.value }), [onChange]);
  const handleTemp = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = parseFloat(e.target.value);
    const out = Number.isNaN(raw) || raw < 0 || raw > 1;
    setTempOutOfRange(out);
    onChange({ temperature: clampTemp(raw) });
  }, [onChange]);
  const handleMaxTokens = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = parseInt(e.target.value, 10);
    const out = Number.isNaN(raw) || raw < 1;
    setMaxOutOfRange(out);
    onChange({ maxTokens: clampTokens(raw) });
  }, [onChange]);
  const clampTimeout = (n: number) => Math.max(500, Math.floor(n || 500));
  const handleTimeout = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = parseInt(e.target.value, 10);
    const out = Number.isNaN(raw) || raw < 500;
    setTimeoutOutOfRange(out);
    onChange({ timeoutMs: clampTimeout(raw) });
  }, [onChange]);
  const handleStream = useCallback((e: React.ChangeEvent<HTMLInputElement>) => onChange({ stream: e.target.checked }), [onChange]);
  const handleSafety = useCallback((e: React.ChangeEvent<HTMLSelectElement>) => onChange({ safetyLevel: e.target.value as Safety }), [onChange]);
  const normalizeOllama = (s: string) => {
    const t = s.trim();
    if (!t) return t;
    if (/^https?:\/\//i.test(t)) return t;
    return `http://${t}`;
  };
  
  const handlePresetApply = useCallback((p: AiPreset) => {
    const cleaned: Partial<AiSettings> = {};
    Object.entries(p.values || {}).forEach(([k, v]) => {
      if (v !== undefined) (cleaned as any)[k] = v;
    });
    onChange({ ...cleaned, activePresetId: p.id });
    showToast({ kind: 'success', contextKey: 'settings:preset', title: 'Preset applied', message: p.label });
  }, [onChange]);
  const handleExport = useCallback(() => {
    try { onExport?.(includeKeys); }
    catch { showToast({ kind: 'error', title: 'Export failed', message: 'Unable to export settings' }); setStatusMsg('Export failed'); }
  }, [onExport, includeKeys]);
  const handleImportPick = useCallback(() => fileRef.current?.click(), []);
  const handleImport = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) { setStatusMsg('Import cancelled'); return; }
    const MAX_IMPORT = 2 * 1024 * 1024; // 2MB
    if (f.size > MAX_IMPORT) {
      showToast({ kind: 'error', title: 'Import too large', message: 'Max 2MB JSON file' });
      setStatusMsg('Import failed: file too large');
      e.currentTarget.value = '';
      return;
    }
    if (f.type && f.type !== 'application/json' && !f.name.endsWith('.json')) {
      showToast({ kind: 'error', title: 'Invalid file type', message: 'Please select a .json file' });
      setStatusMsg('Import failed: not JSON');
      e.currentTarget.value = '';
      return;
    }
    try {
      const text = await f.text();
      try { JSON.parse(text); } // validate only; actual import still delegated
      catch {
        showToast({ kind: 'error', title: 'Invalid JSON', message: 'Could not parse file' });
        setStatusMsg('Import failed: invalid JSON');
        e.currentTarget.value = '';
        return;
      }
    setStatusMsg('Import ready');
    onImport?.(f, overwriteKeys);
      setTimeout(() => setStatusMsg('Import completed'), 100);
    } catch {
      showToast({ kind: 'error', title: 'Import failed', message: 'Unable to read file' });
      setStatusMsg('Import failed: read error');
    } finally {
      e.currentTarget.value = '';
    }
  }, [onImport, overwriteKeys]);
  const handleIncludeKeysChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => setIncludeKeys(e.target.checked), []);

  // Stable handlers for dynamic collections to avoid inline arrow functions in JSX
  const presetHandlers = useMemo(() => {
    const map: Record<string, () => void> = {};
  const all = [...BUILT_IN_PRESETS, ...(presets || [])];
    const seen = new Set<string>();
    for (const p of all) {
      if (seen.has(p.id)) { try { console.warn('[AI Settings] Duplicate preset id:', p.id); } catch {} }
      seen.add(p.id);
      map[p.id] = () => handlePresetApply(p);
    }
    return map;
  }, [presets, handlePresetApply]);

  // Stable factory for onChangeKey that doesn't capture keys object per row render
  const onChangeKey = useCallback((pk: ProviderKey, next: string) => {
    const normalized = pk === 'ollama' ? normalizeOllama(next) : next.trim();
    onChange({ keys: { ...(value.keys || {}), [pk]: normalized } });
  }, [onChange, value.keys]);

  const onToggleKey = useCallback((pk: ProviderKey) => {
    setShowKeys(s => ({ ...s, [pk]: !s[pk] }));
  }, []);

  const show = (id: NonNullable<Props['sections']>[number]) => !sections || sections.includes(id);

  // Build combined presets (dedupe by id, last-wins) and validate active id for rendering state only
  const allPresets = useMemo(() => {
    const order = [...BUILT_IN_PRESETS, ...(presets || [])];
    const map = new Map<string, AiPreset>();
    for (const p of order) map.set(p.id, p);
    return Array.from(map.values());
  }, [presets]);
  const validActiveId = !value.activePresetId ? false : allPresets.some(p => p.id === value.activePresetId);
  const builtInIds = useMemo(() => new Set(BUILT_IN_PRESETS.map(p => p.id)), []);
  const customPresetsSorted = useMemo(() => [...(presets || [])].sort((a,b)=> a.label.localeCompare(b.label, undefined, { sensitivity:'base' })), [presets]);

  // Repair stale model when provider changes
  React.useEffect(() => {
    const exists = providerModels.some(m => m.id === value.model);
    if (!exists) {
      onChange({ model: providerModels[0]?.id ?? '' });
    }
  }, [providerModels, value.model, onChange]);

  // Remask any revealed keys when provider changes (timer state is in rows and will be cleared on unmount)
  React.useEffect(() => {
    setShowKeys({ openai: false, anthropic: false, google: false, ollama: false });
  setKeysResetTick(t => t + 1);
  }, [value.provider]);

  // Clear status messages after delay to avoid repeated screen reader chatter
  React.useEffect(() => {
    if (!statusMsg) return;
    const t = window.setTimeout(() => setStatusMsg(''), 2500);
    return () => window.clearTimeout(t);
  }, [statusMsg]);

  // Focus name input when starting create
  React.useEffect(() => { if (creatingPreset) setTimeout(()=> presetNameRef.current?.focus(), 0); }, [creatingPreset]);

  // Normalize once on mount to repair legacy values
  React.useEffect(() => {
    const fixed = coerceSettings(value as Settings, presets);
    if (
      fixed.temperature !== value.temperature ||
      fixed.maxTokens !== value.maxTokens ||
      fixed.timeoutMs !== value.timeoutMs ||
      fixed.languageId !== value.languageId ||
      fixed.model !== value.model ||
      fixed.activePresetId !== value.activePresetId
    ) {
      onChange(fixed);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 18, fontFamily: 'var(--synapse-font, "JetBrains Mono", "Fira Code", "SF Mono", monospace)' }}>
      {/* Live region for assistive announcements (polite and atomic) */}
      <div role="status" aria-live="polite" aria-atomic="true" style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clip: 'rect(0 0 0 0)' }}>{statusMsg}</div>

      {show('mode-lang') && (
      <Section title="Mode & Language">
        <fieldset aria-describedby="mode-help" style={{ border: 'none', padding: 0, margin: 0 }}>
          <legend style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clip: 'rect(0 0 0 0)' }}>Assistant Mode</legend>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, height: CONTROL_H }}>
              <input id="mode-beginner" type="radio" name="assistant-mode" checked={value.mode === 'beginner'} onChange={handleBeginner} />
              <label htmlFor="mode-beginner">Beginner</label>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, height: CONTROL_H }}>
              <input id="mode-pro" type="radio" name="assistant-mode" checked={value.mode === 'pro'} onChange={handlePro} />
              <label htmlFor="mode-pro">Pro</label>
            </div>
            <select aria-label="Programming Language" value={value.languageId} onChange={handleLang} style={{ ...baseField, minWidth: 160 }}>
              {languages.map(l => (<option key={l.id} value={l.id}>{l.name}</option>))}
            </select>
          </div>
          <div id="mode-help" style={{ marginTop: 8, fontSize: 12, color: TEXT_MED, lineHeight: 1.4 }}>
            Choose assistant mode: Beginner (single-file) or Pro (multi-file).
          </div>
        </fieldset>
      </Section>
      )}

      {show('provider-model') && (
      <Section title="Provider & Model">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <select aria-label="Provider" value={value.provider} onChange={handleProvider} style={{ ...baseField, minWidth: 160 }}>
            <option value="openai">OpenAI</option>
            <option value="anthropic">Anthropic</option>
            <option value="google">Gemini</option>
            <option value="ollama">Ollama</option>
          </select>
          <select aria-label="Model" value={value.model} onChange={handleModel} style={{ ...baseField, minWidth: 180 }}>
            {hasModels ? providerModels.map(m => (<option key={m.id} value={m.id}>{m.label}</option>)) : <option value="" />}
          </select>
          {/* Capability chip (non-interactive) */}
          {value.model ? (
            <div style={{ fontSize: 11, color: TEXT_MED }} aria-live="polite">
              Endpoint: {inferEndpointForModel(value.model) || 'unknown'} · Streaming: yes
            </div>
          ) : null}
        </div>
        <div style={{ marginTop: 8, fontSize: 12, color: TEXT_MED, lineHeight: 1.4 }}>{hasModels ? 'Choose a provider, then select a compatible model.' : 'No compatible models for this provider.'}</div>
      </Section>
      )}

      {show('generation') && (
      <Section title="Text Generation">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <label htmlFor="gen-temp" style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'inherit' }}>Temperature
            <input id="gen-temp" aria-describedby="temp-hint" aria-invalid={tempOutOfRange? 'true': undefined} aria-errormessage={tempOutOfRange? 'gen-temp-error': undefined} inputMode="numeric" type="number" step={0.1} min={0} max={1} value={value.temperature} onChange={handleTemp} onBlur={(e)=> onChange({ temperature: clampTemp(parseFloat(e.target.value)) })} style={{ ...baseField, width: '100%' }} />
          </label>
          <div id="temp-hint" style={{ fontSize: 12, color: TEXT_MED, lineHeight: 1.4 }}>Controls randomness; lower = more deterministic.</div>
          <div id="gen-temp-error" role="alert" style={{ display: tempOutOfRange? 'block' : 'none', fontSize: 12, color: TEXT_MED }}>Value out of recommended range. It will be clamped.</div>
          <label htmlFor="gen-max" style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'inherit' }}>Max Tokens
            <input id="gen-max" aria-invalid={maxOutOfRange? 'true': undefined} aria-errormessage={maxOutOfRange? 'gen-max-error': undefined} inputMode="numeric" type="number" min={1} value={value.maxTokens} onChange={handleMaxTokens} onBlur={(e)=> onChange({ maxTokens: clampTokens(parseInt(e.target.value,10)) })} style={{ ...baseField, width: '100%' }} />
          </label>
          <div id="gen-max-error" role="alert" style={{ display: maxOutOfRange? 'block' : 'none', fontSize: 12, color: TEXT_MED }}>Value out of recommended range. It will be clamped.</div>
          <label htmlFor="gen-timeout" style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'inherit' }}>Request Timeout (ms)
            <input id="gen-timeout" aria-invalid={timeoutOutOfRange? 'true': undefined} aria-errormessage={timeoutOutOfRange? 'gen-timeout-error': undefined} inputMode="numeric" type="number" min={500} step={500} value={value.timeoutMs} onChange={handleTimeout} onBlur={(e)=> onChange({ timeoutMs: clampTimeout(parseInt(e.target.value,10)) })} style={{ ...baseField, width: '100%' }} />
          </label>
          <div id="gen-timeout-error" role="alert" style={{ display: timeoutOutOfRange? 'block' : 'none', fontSize: 12, color: TEXT_MED }}>Value out of recommended range. It will be clamped.</div>
          <label style={{ display:'flex', alignItems:'center', gap:8, fontSize: 13, height: CONTROL_H }}>Stream
            <input type="checkbox" checked={value.stream} onChange={handleStream} />
          </label>
          <label htmlFor="gen-safety" style={{ fontSize: 13, display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'inherit' }}>Safety
            <select id="gen-safety" value={value.safetyLevel||'standard'} onChange={handleSafety} style={{ ...baseField }}>
              <option value="standard">Standard</option>
              <option value="strict">Strict</option>
              <option value="off">Off</option>
            </select>
            <span style={{ fontSize: 12, color: TEXT_MED, lineHeight: 1.4, marginTop: 6 }}>Higher safety may reduce risky content.</span>
          </label>
        </div>
      </Section>
      )}

      

  {show('keys') && (
  <Section title="API Keys">
    <div style={{ display:'flex', flexDirection:'column', gap: 12 }}>
      {(['openai','anthropic','google','ollama'] as ProviderKey[]).map(pk => (
        <KeyRow
          key={pk}
          pk={pk}
          value={value.keys?.[pk] || ''}
          shown={!!showKeys[pk]}
          onShowToggle={onToggleKey}
          onChange={onChangeKey}
          resetTick={keysResetTick}
          onStatus={setStatusMsg}
        />
      ))}
      {(['openai','anthropic','google'] as ProviderKey[]).includes(value.provider) && !value.keys?.[value.provider] ? (
        <div style={{ fontSize: 12, color: TEXT_MED }}>No API key detected; requests may fail.</div>
      ) : null}
      <div id="keys-hint" style={{ fontSize: 12, color: TEXT_MED }}>
        Keys are kept locally for this app. Never share them.
      </div>
    </div>
  </Section>
  )}

      {show('presets') && (
      <Section title="Presets">
        <div style={{ fontSize: 12, color: TEXT_MED, marginBottom: 8 }}>Quickly re-apply saved settings. Active preset is highlighted.</div>
        {/* Create flow */}
        {!creatingPreset ? (
          <button onClick={()=> { setPresetName(''); setPresetNameError(''); setCreatingPreset(true); }} style={baseBtn}>Save as Preset</button>
        ) : (
          <div onKeyDown={(e)=> { if (e.key==='Escape') { setCreatingPreset(false); setPresetNameError(''); setConflictWith(null); } }} style={{ display:'flex', gap:8, alignItems:'center', marginBottom:8 }}>
            <input ref={presetNameRef} value={presetName} onChange={(e)=> { const v=e.target.value; setPresetName(v); setPresetNameError(''); }} placeholder="Preset name" aria-invalid={presetNameError? 'true': undefined} aria-errormessage={presetNameError? 'preset-name-error': undefined} style={{ ...baseField, flex:1 }} />
            <button onClick={()=> {
              const trimmed = presetName.trim();
              const valid = /^[\w .-]{2,40}$/.test(trimmed);
              if (!trimmed) { setPresetNameError('Name required'); setStatusMsg('Name required'); return; }
              if (!valid) { setPresetNameError('Use letters, numbers, spaces, ., -, _ (2–40 chars)'); return; }
              const existing = customPresetsSorted.find(p => p.label.toLowerCase() === trimmed.toLowerCase());
              if (existing) { setConflictWith(existing); setStatusMsg('Preset will replace an existing one if confirmed.'); return; }
              try { _onCreatePreset?.(trimmed); setStatusMsg('Preset saved.'); } finally { setCreatingPreset(false); setPresetName(''); setPresetNameError(''); setConflictWith(null); setTimeout(()=> presetsListRef.current?.focus(), 0); }
            }} style={baseBtn}>Save</button>
            <button onClick={()=> { setCreatingPreset(false); setPresetName(''); setPresetNameError(''); setConflictWith(null); }} style={baseBtn}>Cancel</button>
          </div>
        )}
        {presetNameError ? (<div id="preset-name-error" role="alert" style={{ fontSize:12, color: TEXT_MED, marginTop: 4 }}>{presetNameError}</div>) : null}
        {conflictWith ? (
          <div onKeyDown={(e)=> { if (e.key==='Escape') setConflictWith(null); }} style={{ fontSize:12, color: TEXT_MED, display:'flex', gap:8, alignItems:'center', marginBottom:8 }}>
            A preset named <b title={conflictWith.label}>{conflictWith.label}</b> exists. Replace it?
            <button onClick={()=> { if (!conflictWith) return; try { _onDeletePreset?.(conflictWith.id); _onCreatePreset?.(presetName.trim()); setStatusMsg('Preset saved.'); } finally { setConflictWith(null); setCreatingPreset(false); setPresetName(''); setTimeout(()=> presetsListRef.current?.focus(), 0); } }} style={baseBtn}>Replace</button>
            <button onClick={()=> setConflictWith(null)} style={baseBtn}>Cancel</button>
          </div>
        ) : null}

        {/* Empty state for custom presets */}
        {customPresetsSorted.length === 0 && (
          <div style={{ background: Theme.SYNAPSE_ELEVATION.surface, border:`1px solid ${Theme.SYNAPSE_COLORS.borderSubtle}`, borderRadius:12, padding:12, fontSize:12, color: TEXT_MED, marginTop:8 }}>
            <div>No custom presets yet.</div>
            <div style={{ marginTop:4 }}>Use <b>Save as Preset</b> to capture your current settings.</div>
          </div>
        )}

        <ul ref={presetsListRef as any} tabIndex={-1} role="list" style={{ display:'flex', flexDirection:'column', gap: 8, listStyle: 'none', padding: 0, margin: 0, outline:'none' }}>
          {[...BUILT_IN_PRESETS, ...customPresetsSorted].map(p => (
            <li key={p.id} id={`preset-row-${p.id}`} role="listitem" style={{ display:'flex', alignItems:'center', gap:8, justifyContent:'space-between' }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, flex:1, minWidth:0 }}>
                <PresetButton idAttr={`preset-btn-${p.id}`} preset={p} isActive={!!(validActiveId ? value.activePresetId === p.id : false)} onApply={presetHandlers[p.id]} ariaLabel={`Apply preset: ${p.label}`} />
              </div>
              {!builtInIds.has(p.id) && (
                <button aria-label={`Delete preset ${p.label}`} aria-controls={`preset-row-${p.id}`} onClick={()=> setConfirmDeleteId(confirmDeleteId === p.id ? null : p.id)} style={baseBtn}>Delete</button>
              )}
              {confirmDeleteId === p.id && (
                <div role="alertdialog" aria-labelledby={`preset-${p.id}-name`} style={{ display:'flex', gap:8, alignItems:'center', fontSize:12, color: TEXT_MED }}>
                  Delete preset <b id={`preset-${p.id}-name`}>{p.label}</b>? This cannot be undone.
                  <button onClick={()=> { try { _onDeletePreset?.(p.id); setStatusMsg('Preset deleted.'); } finally { setConfirmDeleteId(null); requestAnimationFrame(()=> { const el = document.getElementById(`preset-btn-${p.id}`) as HTMLElement | null; (el?.nextElementSibling as HTMLElement | null)?.focus?.(); presetsListRef.current?.focus(); }); } }} style={baseBtn}>Delete</button>
                  <button onClick={()=> setConfirmDeleteId(null)} style={baseBtn}>Cancel</button>
                </div>
              )}
            </li>
          ))}
        </ul>
      </Section>
      )}
      {show('profiles') && (
      <Section title="Profiles & Export">
        <div style={{ fontSize:12, color: TEXT_MED, marginBottom:8 }}>Export your current settings to JSON. Import a JSON profile to restore.</div>
        <div style={{ display:'flex', flexDirection:'column', gap: 12, alignItems:'flex-start', flexWrap:'wrap' }}>
          <label style={{ display:'flex', alignItems:'center', gap:6, fontSize: 12 }}>
            <input type="checkbox" checked={includeKeys} onChange={handleIncludeKeysChange} /> Include API keys
          </label>
          <button onClick={() => { setStatusMsg('Export started'); try { handleExport(); setTimeout(()=>setStatusMsg('Export completed'), 100); } catch {/* handled in handleExport */} }} style={baseBtn}>Export JSON</button>
          <label style={{ display:'flex', alignItems:'center', gap:6, fontSize: 12 }}>
            <input type="checkbox" checked={overwriteKeys} onChange={(e)=> setOverwriteKeys(e.target.checked)} /> Overwrite API keys
          </label>
          {overwriteKeys ? <div style={{ fontSize:12, color: TEXT_MED }}>This will replace existing keys if present in the file.</div> : null}
          <button onClick={() => { setStatusMsg('Import file picker opened'); handleImportPick(); }} style={baseBtn} aria-controls="adv-import-input">Import JSON</button>
          <input id="adv-import-input" ref={fileRef} type="file" accept="application/json" style={{ display:'none' }} onChange={handleImport} />
        </div>
      </Section>
      )}
    </div>
  );
};

export default AdvancedSettingsPanel;

// Memoized row components to isolate rerenders
const rowLabelStyle: React.CSSProperties = { width: 96, fontSize: 12, color: TEXT_MED };

const KeyRow = React.memo(({ pk, value, shown, onShowToggle, onChange, onStatus, resetTick }: {
  pk: ProviderKey;
  value: string;
  shown: boolean;
  onShowToggle: (pk: ProviderKey) => void;
  onChange: (pk: ProviderKey, next: string) => void;
  onStatus: (msg: string) => void;
  resetTick?: number;
}) => {
  const id = `key-${pk}`;
  const rowRef = React.useRef<HTMLDivElement | null>(null);
  const inputRef = React.useRef<HTMLInputElement | null>(null);
  const timerRef = React.useRef<number | null>(null);
  // Track latest `shown` state to avoid stale closures in timers
  const shownRef = React.useRef<boolean>(shown);
  const [isFocused, setIsFocused] = React.useState(false);

  // Clear timer on unmount
  React.useEffect(() => () => { if (timerRef.current) { clearTimeout(timerRef.current); timerRef.current = null; } }, []);
  // Also clear timer and remask when resetTick changes (e.g., provider switch)
  React.useEffect(() => {
  if (timerRef.current) { clearTimeout(timerRef.current); timerRef.current = null; }
    if (shown) { onShowToggle(pk); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetTick]);

  // keep ref in sync with prop
  React.useEffect(() => { shownRef.current = shown; }, [shown]);

  const ensureHide = () => {
    if (shownRef.current) {
      onShowToggle(pk);
      // keep focus on the input when auto-hiding
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  };
  const ensureShow = () => { if (!shown) onShowToggle(pk); };

  const revealWithTimer = () => {
    // show now
    ensureShow();
    // reset any existing timer
    if (timerRef.current) { clearTimeout(timerRef.current); timerRef.current = null; }
    // auto-hide after 5s
    timerRef.current = setTimeout(() => { ensureHide(); timerRef.current = null; }, 5000) as unknown as number;
  };

  const stopTimer = () => { if (timerRef.current) { clearTimeout(timerRef.current); timerRef.current = null; } };

  const onRowBlur: React.FocusEventHandler<HTMLDivElement> = (e) => {
    // If focus moved outside this row, immediately hide
    if (!e.currentTarget.contains(e.relatedTarget as Node | null)) {
      stopTimer();
      ensureHide();
    }
  };

  const handleCopy = async () => {
    try {
      // try modern clipboard API
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        await navigator.clipboard.writeText(value || '');
      } else {
        // fallback to textarea method
        const ta = document.createElement('textarea');
        ta.value = value || '';
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand?.('copy');
        document.body.removeChild(ta);
      }
      // content-free feedback
      onStatus('Key copied.');
      showToast({ kind: 'success', contextKey: 'settings:keycopy', title: 'Copied', message: 'Copied.' });
    } catch {
      onStatus('Copy failed.');
      showToast({ kind: 'error', contextKey: 'settings:keycopy', title: 'Copy failed', message: 'Copy failed.' });
    }
  };

  const missingOllamaProtocol = pk === 'ollama' && !!value && !/^https?:\/\//i.test(value);
  const describedBy = missingOllamaProtocol ? `${id}-hint` : undefined;

  return (
    <div ref={rowRef} onBlur={onRowBlur} style={{ display:'flex', alignItems:'center', gap: 8 }}>
      <div style={rowLabelStyle}>{pk.toUpperCase()}</div>
      <div style={{ position:'relative', display:'flex', alignItems:'center', flex:1, minWidth:0 }}>
        <label htmlFor={id} style={{ position:'absolute', width:1, height:1, overflow:'hidden', clip:'rect(0 0 0 0)' }}>{pk.toUpperCase()} API Key</label>
        <input
          ref={inputRef}
          id={id}
          aria-describedby={describedBy}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
          type={shown?'text':'password'}
          value={value}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onChange={(e)=> onChange(pk, e.target.value)}
          placeholder={pk==='ollama'?'http://localhost:11434':'••••••••'}
          style={{ ...baseField, flex:1 }}
        />
        {/* Optional masked last-4 ghost, visual only */}
        {LAST4_GHOST && !shown && !isFocused && value && value.length >= 4 ? (
          <span aria-hidden="true" style={{ position:'absolute', right: 10, fontSize: 12, color: TEXT_MED, pointerEvents:'none' }}>•••• - {value.slice(-4)}</span>
        ) : null}
      </div>
      <div style={{ display:'flex', alignItems:'center', gap: 8 }}>
        <button
          onClick={() => { if (shown) { stopTimer(); ensureHide(); } else { revealWithTimer(); } }}
          aria-pressed={shown}
          aria-controls={id}
          aria-label={`Toggle visibility for ${pk} API key`}
          style={baseBtn}
        >
          {shown ? 'Hide' : 'Show'}
        </button>
        <button
          onClick={handleCopy}
          aria-label={`Copy ${pk} API key`}
          style={baseBtn}
        >
          Copy
        </button>
      </div>
      {/* Row-level hint for Ollama protocol */}
      {missingOllamaProtocol ? <div id={`${id}-hint`} style={{ fontSize: 12, color: TEXT_MED, marginLeft: 96 + 8, flexBasis: '100%' }}>
          Use a full URL, e.g., http://localhost:11434.
        </div> : null}
    </div>
  );
});

const PresetButton = React.memo(({ preset, isActive, onApply, idAttr, ariaLabel }: {
  preset: AiPreset;
  isActive: boolean;
  onApply: () => void;
  idAttr?: string;
  ariaLabel?: string;
}) => {
  const name = preset.label;
  return (
    <button id={idAttr} aria-label={ariaLabel || `Apply preset: ${name}`} onClick={onApply} aria-pressed={isActive} style={{ height: 32, fontSize: 13, padding: '0 10px', border: `1px solid ${Theme.SYNAPSE_COLORS.borderSubtle}`, borderRadius: 8, background: Theme.SYNAPSE_ELEVATION.surface, fontWeight: 600, fontFamily: 'inherit', maxWidth:'100%', textOverflow:'ellipsis', overflow:'hidden', whiteSpace:'nowrap' }} title={name}>
      {name}
    </button>
  );
});
