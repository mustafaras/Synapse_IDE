import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { getModel, inferEndpointForModel, listModelsByProvider } from '@/utils/ai/models/registry';
import { Cpu, Eye, EyeOff, Gauge, Key, Pin, SlidersHorizontal, UserCog, X } from 'lucide-react';
import AdvancedSettingsPanel from '@/components/ai/settings/AdvancedSettingsPanel';
import type { AiPreset, AiSettings } from '@/stores/aiSettings.schema';
import { clearThread, exportThread, getActiveProjectId, importThread, loadPinnedContext, loadSummaryMode, savePinnedContext, saveSummaryMode } from '@/components/ai/AiAssistantConfig';
import { showToast } from '@/ui/toast/api';
import { redactKey, testAnthropic, testGemini, testOpenAI } from '@/services/ai/tests/providerTesters';

// shared sizing for controls (local constants; not exported)
const CONTROL_H = 32;
const RADIUS_MD = 10;
const PAD_X = 12;

// generic surface/border (all from existing tokens)
const SURFACE = 'var(--color-glass-01)';
const BORDER = '1px solid var(--color-border)';
const TEXT = 'var(--color-text-high)';
const TEXT_MED = 'var(--color-text-med)';
const DIVIDER = 'var(--color-divider)';

const baseBtn: React.CSSProperties = {
  height: CONTROL_H,
  padding: `0 ${PAD_X}px`,
  borderRadius: RADIUS_MD,
  border: BORDER,
  background: SURFACE,
  color: TEXT,
  fontFamily: 'inherit',
  fontSize: 13,
  fontWeight: 600,
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 8,
};

type TabKey = 'general' | 'provider' | 'generation' | 'profiles' | 'thread' | 'api-keys';

type Props = {
  value: AiSettings;
  onChange: (next: Partial<AiSettings>) => void;
  onSave?: () => void;
  presets?: AiPreset[];
  onCreatePreset?: (name: string) => void;
  onDeletePreset?: (id: string) => void;
  onExport?: (includeKeys: boolean) => void;
  onImport?: (file: File, overwriteKeys: boolean) => void;
  onClose: () => void;
  initialTab?: TabKey;
};

const TAB_META: { key: TabKey; label: string; Icon: React.ComponentType<any> }[] = [
  { key: 'general', label: 'General', Icon: SlidersHorizontal },
  { key: 'provider', label: 'Provider', Icon: Cpu },
  { key: 'generation', label: 'Generation', Icon: Gauge },
  { key: 'profiles', label: 'Presets', Icon: UserCog },
  { key: 'api-keys', label: 'API Keys', Icon: Key },
  { key: 'thread', label: 'Thread & Context', Icon: Pin },
];
const TABS: TabKey[] = TAB_META.map(t => t.key);

const STORAGE_KEY = 'aiSettingsModalPro.activeTab';

// Small secret input with show/hide toggle preserving 32px control height
function SecretField({ ariaLabel, value, onChange, testId }: { ariaLabel: string; value: string; onChange: (v: string) => void; testId?: string }) {
  const [show, setShow] = useState(false);
  return (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
      <input
        aria-label={ariaLabel}
        type={show ? 'text' : 'password'}
        value={value}
        onChange={e => onChange(e.currentTarget.value)}
  data-testid={testId}
        style={{ height: CONTROL_H, padding: `0 ${PAD_X}px`, borderRadius: RADIUS_MD, border: BORDER, background: SURFACE, color: TEXT, fontFamily: 'inherit', fontSize: 13, flex: 1 }}
      />
      <button
        onClick={() => setShow(s => !s)}
        aria-label={`Toggle visibility for ${ariaLabel}`}
        aria-pressed={show}
        title={show ? 'Hide' : 'Show'}
        className="focus-ring"
        style={{
          ...baseBtn,
          width: 36,
          minWidth: 36,
          padding: 0,
          display: 'grid',
          placeItems: 'center',
        }}
      >{show ? <EyeOff size={16} aria-hidden="true" /> : <Eye size={16} aria-hidden="true" />}</button>
    </div>
  );
}

const AiSettingsModalPro: React.FC<Props> = ({ value, onChange, onSave, presets, onCreatePreset, onDeletePreset, onExport, onImport, onClose, initialTab }) => {
  // Persist last used tab
  const [active, setActive] = useState<TabKey>(() => {
    try {
    if (initialTab && (['general','provider','generation','profiles','thread','api-keys'] as const).includes(initialTab as any)) return initialTab as TabKey;
    const saved = localStorage.getItem(STORAGE_KEY) as TabKey | null;
  if (saved && (['general','provider','generation','profiles','thread','api-keys'] as const).includes(saved as any)) return saved as TabKey;
    } catch {}
    return 'general';
  });
  const closeRef = useRef<HTMLButtonElement | null>(null);
  const dialogRef = useRef<HTMLDivElement | null>(null);
  const lastActiveElementRef = useRef<HTMLElement | null>(null);
  const [assistantWidth, setAssistantWidth] = useState<number | null>(null);
  const dialogWidth = useMemo(() => {
    // Slightly wider to resolve Show/Hide button fit: +20px each side (~+40 total)
    const base = 'min(520px, 65vw)';
    if (assistantWidth && Number.isFinite(assistantWidth)) {
      const target = Math.max(320, Math.round(assistantWidth - 24));
      return `min(${target}px, ${base})`;
    }
    return base;
  }, [assistantWidth]);

  // Basic focus management + scroll lock + restore focus
  useEffect(() => {
    lastActiveElementRef.current = (document.activeElement as HTMLElement) ?? null;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
      // Restore focus to the element that opened the modal
      try { lastActiveElementRef.current?.focus(); } catch {}
    };
  }, [onClose]);

  // Persist selected tab
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, active); } catch {}
  }, [active]);

  // First-run light normalization: ensure model exists for current provider
  useEffect(() => {
    try {
      const models = listModelsByProvider(value.provider);
      const exists = models.some(m => m.id === value.model);
      if (!exists) {
        onChange({ model: models[0]?.id ?? '' });
      }
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Capture AI Assistant container width so modal never exceeds it
  useEffect(() => {
    const calc = () => {
      const el = document.querySelector('[data-component="ai-assistant"]') as HTMLElement | null;
      if (!el) { setAssistantWidth(null); return; }
      const rect = el.getBoundingClientRect();
      setAssistantWidth(Math.max(0, Math.round(rect.width)) || null);
    };
    calc();
    let raf = 0;
    const onResize = () => {
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(calc);
    };
    window.addEventListener('resize', onResize);
    return () => {
      if (raf) cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
    };
  }, []);

  // Focus trap within the dialog
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key !== 'Tab') return;
    const root = dialogRef.current;
    if (!root) return;
    const focusableSelectors = [
      'a[href]','button:not([disabled])','input:not([disabled])','select:not([disabled])','textarea:not([disabled])',
      '[tabindex]:not([tabindex="-1"])','[contenteditable="true"]'
    ].join(',');
    const nodes = Array.from(root.querySelectorAll<HTMLElement>(focusableSelectors))
      .filter(el => el.offsetParent !== null || el === document.activeElement);
    if (nodes.length === 0) {
      e.preventDefault();
      if (closeRef.current) closeRef.current.focus(); else root.focus();
      return;
    }
    const first = nodes[0];
    const last = nodes[nodes.length - 1];
    const activeEl = document.activeElement as HTMLElement | null;
    if (!e.shiftKey && activeEl === last) { e.preventDefault(); first.focus(); return; }
    if (e.shiftKey && (activeEl === first || activeEl === root)) { e.preventDefault(); last.focus();  }
  };

  const handleTabListKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (['ArrowRight','ArrowLeft','ArrowUp','ArrowDown'].includes(e.key)) {
      e.preventDefault();
      const idx = TABS.indexOf(active);
      const forward = e.key === 'ArrowRight' || e.key === 'ArrowDown';
      const nextIdx = forward ? (idx + 1) % TABS.length : (idx - 1 + TABS.length) % TABS.length;
      const next = TABS[nextIdx];
      setActive(next);
      // Move DOM focus to the newly active tab
      requestAnimationFrame(() => {
        const el = document.getElementById(`ai-tab-${next}`) as HTMLButtonElement | null;
        el?.focus();
      });
      return;
    }
    if (e.key === 'Home') {
      e.preventDefault();
      const first = TABS[0];
      setActive(first);
      requestAnimationFrame(() => (document.getElementById(`ai-tab-${first}`) as HTMLButtonElement | null)?.focus());
      return;
    }
    if (e.key === 'End') {
      e.preventDefault();
      const last = TABS[TABS.length - 1];
      setActive(last);
      requestAnimationFrame(() => (document.getElementById(`ai-tab-${last}`) as HTMLButtonElement | null)?.focus());
      
    }
  };

  const safePresets = useMemo(() => presets ?? [], [presets]);
  // Keep an immutable snapshot to support Reset
  const initialRef = useRef<AiSettings | null>(null);
  if (!initialRef.current) initialRef.current = value;
  const handleApply = useCallback(() => {
    // Apply should persist via onSave if provided; otherwise just toast
    try { onSave?.(); showToast({ kind: 'success', title: 'Applied', message: 'Settings applied' }); } catch {}
  }, [onSave]);
  const handleReset = useCallback(() => {
    if (!initialRef.current) return;
    const snapshot = initialRef.current;
    // Push full snapshot back via onChange in a single merge
    onChange({ ...snapshot });
    showToast({ kind: 'info', title: 'Reset', message: 'Reverted unsaved changes' });
  }, [onChange]);

  // Stable tab select handler
  const onSelectTab = useCallback((k: TabKey) => setActive(k), []);

  // Memoized TabButton to reduce re-renders
  const TabButton = React.memo(({ tabKey, label, Icon, active, onSelect }: { tabKey: TabKey; label: string; Icon: React.ComponentType<any>; active: boolean; onSelect: (k: TabKey) => void }) => {
    return (
      <button
        id={`ai-tab-${tabKey}`}
        role="tab"
        aria-controls={`ai-panel-${tabKey}`}
        aria-selected={active}
        tabIndex={active?0:-1}
        onClick={() => onSelect(tabKey)}
        className="focus-ring"
        style={{
          ...baseBtn,
          display: 'flex',
          background: active ? 'color-mix(in oklab, var(--brand-primary), transparent 88%)' : SURFACE,
          border: active ? '1px solid color-mix(in oklab, var(--brand-primary), transparent 60%)' : BORDER,
        }}
      >
        <Icon size={16} aria-hidden="true" /> {label}
      </button>
    );
  });

  // Sections to show for current tab
  const sectionsForTab = useMemo(() => {
    switch (active) {
      case 'general': return ['mode-lang'] as any;
      case 'provider': return ['provider-model'] as any;
      case 'generation': return ['generation'] as any;
      case 'profiles': return ['presets','profiles'] as any;
      default: return undefined as any;
    }
  }, [active]);

  // Local state for Thread & Context tab
  const [pinnedDraft, setPinnedDraft] = useState<string>(() => (loadPinnedContext() || []).join('\n'));
  const [summaryMode, setSummaryMode] = useState<ReturnType<typeof loadSummaryMode>>(() => loadSummaryMode());
  const handleThreadExport = () => {
    const pid = getActiveProjectId();
    const json = exportThread(pid);
    try {
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `thread-${pid}-${Date.now()}.json`; a.click();
      URL.revokeObjectURL(url);
      showToast({ kind: 'success', title: 'Exported', message: 'Thread exported' });
    } catch {}
  };
  const handleThreadImport = async () => {
    const inputEl = document.createElement('input');
    inputEl.type = 'file'; inputEl.accept = 'application/json';
    inputEl.onchange = async () => {
      const file = inputEl.files?.[0]; if (!file) return;
      const text = await file.text();
      try { importThread(getActiveProjectId(), text); showToast({ kind: 'success', title: 'Imported', message: 'Thread imported' }); }
      catch { showToast({ kind: 'error', title: 'Import failed', message: 'Invalid thread file' }); }
    };
    inputEl.click();
  };
  const handleThreadReset = () => {
    clearThread(getActiveProjectId());
    showToast({ kind: 'warning', title: 'Cleared', message: 'Thread cleared' });
  };
  const handlePinnedSave = () => {
    const lines = pinnedDraft.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    try { savePinnedContext(lines); showToast({ kind: 'success', title: 'Saved', message: 'Pinned context saved' }); } catch {}
  };
  const handlePinnedRevert = () => {
    setPinnedDraft((loadPinnedContext() || []).join('\n'));
  };
  const handleSummaryMode = (m: 'standard' | 'aggressive') => {
    setSummaryMode(m); saveSummaryMode(m);
  };

  // ===============
  // Diagnostics state (API key tests)
  // ===============
  const PASS_TTL_MS = 120_000; // 2 minutes
  const [diagBusy, setDiagBusy] = useState<null | 'openai' | 'anthropic' | 'gemini' | 'all'>(null);
  const [diagCache, setDiagCache] = useState<{ openai?: number; anthropic?: number; gemini?: number }>({});
  const diagNow = Date.now();
  const diagPassed = (p: 'openai'|'anthropic'|'gemini') => {
    const t = diagCache[p];
    return !!t && (diagNow - t < PASS_TTL_MS);
  };
  const markPassed = (p: 'openai'|'anthropic'|'gemini') => setDiagCache(prev => ({ ...prev, [p]: Date.now() }));

  const providerKeys = useMemo(() => ({
    openai: value.keys?.openai,
    anthropic: value.keys?.anthropic,
    gemini: value.keys?.google,
  }), [value.keys]);

  async function runDiag(p: 'openai'|'anthropic'|'gemini') {
    setDiagBusy(p);
    try {
      if (p === 'openai') {
        const r = await testOpenAI(providerKeys.openai);
        if (r.ok) { showToast({ kind: 'success', message: 'OpenAI key works!', contextKey: 'diag:openai:ok' }); markPassed('openai'); }
      } else if (p === 'anthropic') {
        const r = await testAnthropic(providerKeys.anthropic);
        if (r.ok) { showToast({ kind: 'success', message: 'Anthropic key works!', contextKey: 'diag:anthropic:ok' }); markPassed('anthropic'); }
      } else {
        const r = await testGemini(providerKeys.gemini);
        if (r.ok) { showToast({ kind: 'success', message: 'Gemini key works!', contextKey: 'diag:gemini:ok' }); markPassed('gemini'); }
      }
    } finally {
      setDiagBusy(null);
    }
  }

  async function runDiagAll() {
    setDiagBusy('all');
    try {
      for (const p of ['openai','anthropic','gemini'] as const) {
         
        await runDiag(p);
      }
    } finally {
      setDiagBusy(null);
    }
  }

  return (
    <div role="dialog" aria-modal="true" aria-labelledby="ai-settings-title" aria-describedby="ai-settings-subtitle" className="theme-ide-pro" data-ai-settings-overlay style={{
      position: 'fixed', inset: 0, zIndex: 10080,
      background: 'color-mix(in oklab, var(--color-bg-primary), transparent 52%)',
      backdropFilter: 'blur(12px)',
      transition: 'none'
    }}>
  {/* Disable transitions/animations inside the modal to avoid background sliding effects */}
  <style>{`
[data-ai-settings-overlay], [data-ai-settings-overlay] * { transition: none !important; animation: none !important; }
[data-ai-settings], [data-ai-settings] * { transition: none !important; animation: none !important; }
  `}</style>
  <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', padding: '8vh 12px' }}>
  <div ref={dialogRef} data-ai-settings onKeyDown={handleKeyDown} tabIndex={-1} style={{
      width: dialogWidth,
      height: 'min(78vh, 700px)',
      display: 'grid', gridTemplateRows: '64px 1fr 64px',
      background: 'linear-gradient(145deg, color-mix(in oklab, var(--color-bg-secondary), transparent 8%), color-mix(in oklab, var(--color-bg-primary), transparent 2%))',
      border: '1px solid color-mix(in oklab, var(--brand-primary), transparent 80%)',
      borderRadius: '16px',
      boxShadow: '0 12px 32px rgba(0,0,0,0.5), 0 4px 16px rgba(0,0,0,0.3), inset 0 1px 0 rgba(194,167,110,0.10)',
      color: 'var(--color-text-high)',
      fontFamily: 'var(--synapse-font, "JetBrains Mono", "Fira Code", "SF Mono", monospace)',
  overflow: 'hidden'
        }}>
          {/* Header */}
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px', borderBottom: '1px solid var(--color-border)', background: 'color-mix(in oklab, var(--brand-primary), transparent 95%)' }}>
            <div>
  <h2 id="ai-settings-title" style={{ margin: 0, fontSize: 16, fontFamily: 'inherit', letterSpacing: '0.3px', color: 'var(--brand-primary)' }}>AI Settings</h2>
  <div id="ai-settings-subtitle" style={{ fontSize: 12, color: TEXT_MED, fontFamily: 'inherit' }}>Configure assistant providers, models, and behavior</div>
            </div>
            <button ref={closeRef} onClick={onClose} aria-label="Close" aria-keyshortcuts="Escape" className="focus-ring" style={{
              ...baseBtn,
              width: 36,
              padding: 0,
              display: 'grid',
              placeItems: 'center'
            }}>
              <X size={18} aria-hidden="true" />
            </button>
          </div>

    {/* Content */}
  <div style={{ overflow: 'auto', padding: '24px 22px' }}>
            <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
              {/* Vertical Tabs Sidebar */}
              <div role="tablist" aria-label="AI settings sections" aria-orientation="vertical" onKeyDown={handleTabListKeyDown} style={{ display: 'flex', flexDirection: 'column', alignItems: 'stretch', gap: 8, minWidth: 160 }}>
                {TAB_META.map(({ key, label, Icon }) => (
                  <TabButton key={key} tabKey={key} label={label} Icon={Icon} active={active===key} onSelect={onSelectTab} />
                ))}
              </div>
              {/* Single mounted tab panel */}
              <div id={`ai-panel-${active}`} role="tabpanel" aria-labelledby={`ai-tab-${active}`} style={{ flex: 1, minWidth: 0, overflow: 'auto' }}>
                {active !== 'thread' && active !== 'api-keys' ? (
                  <AdvancedSettingsPanel
                    value={value}
                    onChange={onChange}
                    {...(onSave ? { onSave } : {})}
                    presets={safePresets}
                    {...(onCreatePreset ? { onCreatePreset } : {})}
                    {...(onDeletePreset ? { onDeletePreset } : {})}
                    {...(onExport ? { onExport } : {})}
                    {...(onImport ? { onImport } : {})}
                    sections={sectionsForTab as any}
                    hideSaveButton
                  />
                ) : active === 'thread' ? (
                  <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
                    <div>
                      <div style={{ fontSize:12, opacity:.8, marginBottom:6 }}>Thread</div>
                      <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                        <button onClick={handleThreadExport} style={baseBtn}>Export</button>
                        <button onClick={handleThreadImport} style={baseBtn}>Import</button>
                        <button onClick={handleThreadReset} style={baseBtn}>Reset</button>
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize:12, opacity:.8, marginBottom:6 }}>Summarization</div>
                      <div style={{ display:'flex', gap:8 }}>
                        {(['standard','aggressive'] as const).map(m => (
                          <button key={m} onClick={()=> handleSummaryMode(m)}
                            style={{
                              ...baseBtn,
                              background: summaryMode===m ? 'color-mix(in oklab, var(--brand-primary), transparent 90%)' : SURFACE,
                              border: summaryMode===m ? '1px solid color-mix(in oklab, var(--brand-primary), transparent 60%)' : BORDER,
                            }}>
                            {m}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize:12, opacity:.8, marginBottom:6 }}>Pinned Context (one per line)</div>
                      <textarea value={pinnedDraft} onChange={e=> setPinnedDraft(e.target.value)} rows={5} style={{ width:'100%', background:'var(--color-bg-primary)', color:'var(--color-text-high)', border:'1px solid var(--color-border)', borderRadius:10, padding:10, fontSize:12, fontFamily:'inherit' }} />
                      <div style={{ display:'flex', justifyContent:'flex-end', gap:8, marginTop:6 }}>
                        <button onClick={handlePinnedRevert} style={baseBtn}>Revert</button>
                        <button onClick={handlePinnedSave} style={{
                          ...baseBtn,
                          background: 'linear-gradient(135deg, var(--brand-primary), var(--brand-accent))',
                          border: '1px solid color-mix(in oklab, var(--brand-primary), transparent 35%)',
                          color: '#111'
                        }}>Save</button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
                    <div style={{ fontSize:12, opacity:.8 }}>Provider API Keys</div>
                    {/* OpenAI */}
                    <div style={{ display:'grid', gap:6 }}>
                      <label style={{ fontSize:12, color: TEXT_MED }}>OpenAI API Key</label>
                      <SecretField ariaLabel="OpenAI API Key" value={value.keys?.openai ?? ''} onChange={(v)=> onChange({ keys: { openai: v } } as any)} testId="key-openai" />
                    </div>
                    {/* Anthropic */}
                    <div style={{ display:'grid', gap:6 }}>
                      <label style={{ fontSize:12, color: TEXT_MED }}>Anthropic API Key</label>
                      <SecretField ariaLabel="Anthropic API Key" value={value.keys?.anthropic ?? ''} onChange={(v)=> onChange({ keys: { anthropic: v } } as any)} testId="key-anthropic" />
                    </div>
                    {/* Google */}
                    <div style={{ display:'grid', gap:6 }}>
                      <label style={{ fontSize:12, color: TEXT_MED }}>Google API Key</label>
                      <SecretField ariaLabel="Google API Key" value={value.keys?.google ?? ''} onChange={(v)=> onChange({ keys: { google: v } } as any)} testId="key-gemini" />
                    </div>
                    {/* Ollama */}
                    <div style={{ display:'grid', gap:6 }}>
                      <label style={{ fontSize:12, color: TEXT_MED }}>Ollama URL</label>
                      <div style={{ display:'flex', gap:8, alignItems:'center' }}>
                        <input
                          aria-label="Ollama URL"
                          type="text"
                          placeholder="http://localhost:11434"
                          style={{ height: CONTROL_H, padding: `0 ${PAD_X}px`, borderRadius: RADIUS_MD, border: BORDER, background: SURFACE, color: TEXT, fontFamily: 'inherit', fontSize: 13, flex: 1 }}
                          value={value.keys?.ollama ?? ''}
                          onChange={e => onChange({ keys: { ollama: e.currentTarget.value } } as any)}
                        />
                      </div>
                    </div>

                    {/* Diagnostics */}
                    <div style={{ marginTop: 8 }}>
                      <div style={{ fontSize:12, opacity:.8, marginBottom:6 }}>Diagnostics</div>
                      {/* Capability chip for current model */}
                      <div style={{ fontSize:11, opacity:.75, marginBottom:8 }}>
                        {(() => {
                          const m = getModel(value.model);
                          const endpoint = inferEndpointForModel(value.model);
                          const streaming = endpoint !== 'gemini_generate';
                          return (
                            <>
                              Model: <b>{m?.label ?? value.model}</b> · Endpoint: <b>{endpoint ?? 'unknown'}</b> · Streaming: <b>{streaming ? 'yes' : 'no'}</b>
                            </>
                          );
                        })()}
                      </div>
                      {/* Redacted key preview */}
                      <div style={{ fontSize:11, opacity:.6, marginBottom:8 }}>
                        OpenAI: <code>{redactKey(providerKeys.openai)}</code> · Anthropic: <code>{redactKey(providerKeys.anthropic)}</code> · Gemini: <code>{redactKey(providerKeys.gemini)}</code>
                      </div>
                      <div style={{ display:'flex', gap:8, flexWrap:'wrap', alignItems:'center' }}>
                        <button style={baseBtn} disabled={!!diagBusy} onClick={() => runDiag('openai')} aria-busy={diagBusy==='openai'} title={diagPassed('openai') ? 'Passed recently' : 'Run OpenAI key test'}>
                          {diagBusy==='openai' ? 'Testing…' : 'Test OpenAI'} {diagPassed('openai') && <span style={{ opacity:.7, marginLeft:6 }}>✔︎</span>}
                        </button>
                        <button style={baseBtn} disabled={!!diagBusy} onClick={() => runDiag('anthropic')} aria-busy={diagBusy==='anthropic'} title={diagPassed('anthropic') ? 'Passed recently' : 'Run Anthropic key test'}>
                          {diagBusy==='anthropic' ? 'Testing…' : 'Test Anthropic'} {diagPassed('anthropic') && <span style={{ opacity:.7, marginLeft:6 }}>✔︎</span>}
                        </button>
                        <button style={baseBtn} disabled={!!diagBusy} onClick={() => runDiag('gemini')} aria-busy={diagBusy==='gemini'} title={diagPassed('gemini') ? 'Passed recently' : 'Run Gemini key test'}>
                          {diagBusy==='gemini' ? 'Testing…' : 'Test Gemini'} {diagPassed('gemini') && <span style={{ opacity:.7, marginLeft:6 }}>✔︎</span>}
                        </button>
                        <button style={{ ...baseBtn, fontWeight:700 }} disabled={!!diagBusy} onClick={runDiagAll} aria-busy={diagBusy==='all'} title="Run all provider tests sequentially">
                          {diagBusy==='all' ? 'Testing All…' : 'Test All'}
                        </button>
                      </div>
                      <div style={{ fontSize:11, opacity:.55, marginTop:8 }}>Tests use a 15s timeout and only list models; failures route to the error panel.</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

      {/* Footer */}
  <div style={{ display: 'flex', justifyContent: 'center', gap: 8, alignItems: 'center', padding: '0 20px', borderTop: DIVIDER, background: 'linear-gradient(0deg, var(--color-bg-secondary), transparent)' }}>
      <button onClick={handleReset} className="focus-ring" style={baseBtn}>Reset</button>
      <button onClick={onClose} className="focus-ring" aria-keyshortcuts="Escape" style={baseBtn}>Close</button>
  <button onClick={handleApply} className="focus-ring" aria-keyshortcuts="Control+S Command+S" style={{
              ...baseBtn,
              background: 'linear-gradient(135deg, var(--brand-primary), var(--brand-accent))',
              border: '1px solid color-mix(in oklab, var(--brand-primary), transparent 35%)',
      color: 'var(--color-bg-primary)'
      }}>Apply</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiSettingsModalPro;
