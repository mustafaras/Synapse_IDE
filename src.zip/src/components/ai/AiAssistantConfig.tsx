import React from 'react';
import { compileContext } from '@/utils/ai/context/contextCompiler';
import type { ContextInput } from '@/utils/ai/context/contextSources';
import { getPrompt } from '@/prompts/usePrompt';
import { annotateTrace, getActiveTraceId } from '@/utils/obs/instrument';
import {
  BarChart3,
  BookOpen,
  Brain,
  Bug,
  Cloud,
  Code,
  Cpu,
  Database,
  FileCode,
  FileText,
  Globe,
  Layers,
  Lightbulb,
  Package,
  Palette,
  Search,
  Server,
  Settings,
  Shield,
  Smartphone,
  Terminal,
  Wrench,
  Zap,
} from 'lucide-react';

// Types for configuration data
export interface QuickPrompt {
  id: string;
  title: string;
  prompt: string;
  icon: React.ReactNode;
  category: string;
  color: string;
}

export interface Language {
  id: string;
  name: string;
  category: string;
  icon: React.ReactNode;
}

export interface AiModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  contextLength: string;
  strengths: string[];
}

// Prompt 8 — Reliability: error taxonomy, redaction, and telemetry helpers
export type ErrorKind =
  | 'auth'        // 401/403 invalid/expired key
  | 'rate'        // 429 quota/rate limit
  | 'timeout'     // client/server timeout
  | 'network'     // offline/DNS/fetch fail
  | 'cancelled'   // user/new_request abort
  | 'model'       // unsupported model/parameters
  | 'server'      // 5xx
  | 'unknown';

export function classifyError(e: any): ErrorKind {
  try {
    const s = (e?.status ?? e?.response?.status) | 0;
    if (s === 401 || s === 403) return 'auth';
    if (s === 429) return 'rate';
    if (s >= 500 && s <= 599) return 'server';
    if (e?.name === 'AbortError' || e === 'new_request' || e === 'idle_timeout' || e === 'user_cancel' || e === 'unmount') return 'cancelled';
    if (e?.code === 'ETIMEDOUT' || e?.name === 'TimeoutError') return 'timeout';
    if (typeof e?.message === 'string' && e.message.toLowerCase().includes('model')) return 'model';
    if (typeof navigator !== 'undefined' && navigator && (navigator as any).onLine === false) return 'network';
  } catch {}
  return 'unknown';
}

export function userFacingMessage(kind: ErrorKind): string {
  switch (kind) {
    case 'auth': return 'Authentication failed. Check your API key in AI Settings → API Keys.';
    case 'rate': return 'You hit a rate/quota limit. Please retry in a moment.';
    case 'timeout': return 'The request timed out. Retrying may help.';
    case 'network': return 'You appear to be offline. Please check your connection.';
    case 'cancelled': return 'Previous request was cancelled.';
    case 'model': return 'Selected model is unavailable or unsupported. Pick another model in AI Settings.';
    case 'server': return 'The server had a problem. Please try again shortly.';
    default: return 'Something went wrong. Please try again.';
  }
}

export function redactKey(value?: string) {
  if (!value) return '';
  try {
    if (value.length <= 8) return '••••';
    return `${value.slice(0,3)  }••••${  value.slice(-3)}`;
  } catch { return '••••'; }
}

export type TelemetryEventName =
  | 'send_start' | 'delta_flush' | 'send_complete'
  | 'send_error' | 'send_abort'
  | 'apply_copy' | 'apply_insert' | 'apply_replace' | 'apply_newtab' | 'apply_preview'
  | 'settings_test' | 'settings_save';

export function emitTelemetry(evt: TelemetryEventName, data: Record<string, any> = {}) {
  try {
    const safe = JSON.parse(JSON.stringify(data, (_k, v) => {
      if (typeof v === 'string' && v.length > 512) return `${v.slice(0,512)  }…`;
      return v;
    }));
    // Keep console noise down: sample frequent events
    const noisy = evt === 'delta_flush';
    if (noisy) {
      const n = Number((safe as any).n ?? 0);
      // Log every 10th flush and at 1, 2, 5
      const important = n <= 5 || n % 10 === 0;
      if (important) { if (typeof console !== 'undefined' && console?.debug) console.debug('[telemetry]', evt, safe); }
    } else {
      if (typeof console !== 'undefined' && console?.debug) console.debug('[telemetry]', evt, safe);
    }
  } catch {}
}

// STEP 6: Structured model catalog metadata (overlays on aiModels for grouping & badges)
export interface ModelOption {
  id: string; // must match an entry in aiModels (or dynamic local model)
  provider: string; // provider key
  badge?: 'Best' | 'Fast' | 'Reasoning' | 'Experimental' | 'Local';
  notes?: string | undefined; // short tooltip style note
  deprecated?: boolean | undefined; // flag older entries (still selectable for compatibility)
  hidden?: boolean | undefined; // omit from primary list unless already selected
}

// Enhanced Quick prompts configuration - Comprehensive development workflows
export const quickPrompts: QuickPrompt[] = [
  // Frontend Development
  {
    id: 'react-full-stack',
    title: 'Full React App',
    prompt:
      'Create a complete React application with TypeScript, routing, state management, API integration, authentication, responsive design, error handling, and production-ready configuration',
    icon: <Code size={16} />,
    category: 'frontend',
    color: '#C2A76E',
  },
  {
    id: 'next-app',
    title: 'Next.js Project',
    prompt:
      'Build a Next.js application with App Router, server components, API routes, database integration, authentication, SEO optimization, and deployment configuration',
    icon: <Globe size={16} />,
    category: 'frontend',
    color: '#A58B5F',
  },
  {
    id: 'ui-system',
    title: 'Design System',
    prompt:
      'Create a comprehensive design system with reusable components, tokens, theming, accessibility standards, documentation, and Storybook integration',
    icon: <Palette size={16} />,
    category: 'frontend',
    color: '#E74C3C',
  },

  // Backend Development
  {
    id: 'api-microservice',
    title: 'Microservice API',
    prompt:
      'Design a scalable microservice with REST/GraphQL API, database models, authentication, rate limiting, caching, monitoring, testing, and Docker deployment',
    icon: <Server size={16} />,
    category: 'backend',
    color: '#C2A76E',
  },
  {
    id: 'database-design',
    title: 'Database Architecture',
    prompt:
      'Design complete database schema with relationships, indexes, migrations, seed data, query optimization, backup strategies, and performance monitoring',
    icon: <Database size={16} />,
    category: 'backend',
    color: '#A58B5F',
  },
  {
    id: 'auth-system',
    title: 'Authentication System',
    prompt:
      'Implement comprehensive authentication with JWT, OAuth, role-based access control, password policies, session management, and security best practices',
    icon: <Shield size={16} />,
    category: 'backend',
    color: '#C2A76E',
  },

  // DevOps & Infrastructure
  {
    id: 'ci-cd-pipeline',
    title: 'CI/CD Pipeline',
    prompt:
      'Set up complete CI/CD pipeline with automated testing, code quality checks, security scanning, multi-environment deployment, and monitoring',
    icon: <Zap size={16} />,
    category: 'devops',
    color: '#AAB2BD',
  },
  {
    id: 'docker-k8s',
    title: 'Container Orchestration',
    prompt:
      'Create Docker containers and Kubernetes deployment with scaling, load balancing, service mesh, monitoring, logging, and disaster recovery',
    icon: <Layers size={16} />,
    category: 'devops',
    color: '#A58B5F',
  },

  // AI & Machine Learning
  {
    id: 'ml-pipeline',
    title: 'ML Pipeline',
    prompt:
      'Build end-to-end machine learning pipeline with data preprocessing, model training, validation, deployment, monitoring, and A/B testing',
    icon: <Brain size={16} />,
    category: 'ai',
    color: '#E74C3C',
  },
  {
    id: 'ai-integration',
    title: 'AI Integration',
    prompt:
      'Integrate AI services (OpenAI, Anthropic, Google) with proper error handling, rate limiting, cost optimization, and user experience design',
    icon: <Cpu size={16} />,
    category: 'ai',
    color: '#2ECC71',
  },

  // Algorithms & Data Structures
  {
    id: 'algorithm-optimization',
    title: 'Algorithm & Optimization',
    prompt:
      'Implement complex algorithms with detailed analysis, optimization techniques, performance benchmarking, and real-world applications',
    icon: <Search size={16} />,
    category: 'algorithms',
    color: '#C2A76E',
  },

  // Testing & Quality
  {
    id: 'testing-strategy',
    title: 'Testing Strategy',
    prompt:
      'Create comprehensive testing strategy with unit, integration, e2e tests, performance testing, security testing, and quality assurance processes',
    icon: <Bug size={16} />,
    category: 'testing',
    color: '#A58B5F',
  },

  // Documentation & Architecture
  {
    id: 'technical-docs',
    title: 'Technical Documentation',
    prompt:
      'Write comprehensive technical documentation with architecture diagrams, API documentation, user guides, deployment instructions, and maintenance procedures',
    icon: <FileText size={16} />,
    category: 'documentation',
    color: '#AAB2BD',
  },
  {
    id: 'code-review',
    title: 'Code Analysis',
    prompt:
      'Perform detailed code review with security analysis, performance optimization, best practices, refactoring suggestions, and architectural improvements',
    icon: <Lightbulb size={16} />,
    category: 'analysis',
    color: '#C2A76E',
  },
];

// Language options - Comprehensive programming languages with categories
export const languages: Language[] = [
  // Web Development
  {
    id: 'javascript',
    name: 'JavaScript',
    category: 'web',
    icon: <Code size={14} color="#C2A76E" />,
  },
  {
    id: 'typescript',
    name: 'TypeScript',
    category: 'web',
    icon: <Code size={14} color="#A58B5F" />,
  },
  { id: 'html', name: 'HTML', category: 'web', icon: <FileCode size={14} color="#C2A76E" /> },
  { id: 'css', name: 'CSS', category: 'web', icon: <Palette size={14} color="#AAB2BD" /> },
  { id: 'scss', name: 'SCSS/Sass', category: 'web', icon: <Palette size={14} color="#C2A76E" /> },
  { id: 'vue', name: 'Vue.js', category: 'web', icon: <Code size={14} color="#2ECC71" /> },
  { id: 'react', name: 'React/JSX', category: 'web', icon: <Code size={14} color="#C2A76E" /> },
  { id: 'angular', name: 'Angular', category: 'web', icon: <Code size={14} color="#E74C3C" /> },
  { id: 'svelte', name: 'Svelte', category: 'web', icon: <Code size={14} color="#E1C542" /> },

  // Backend Languages
  { id: 'python', name: 'Python', category: 'backend', icon: <Code size={14} color="#C2A76E" /> },
  { id: 'java', name: 'Java', category: 'backend', icon: <Code size={14} color="#A58B5F" /> },
  { id: 'csharp', name: 'C#', category: 'backend', icon: <Code size={14} color="#2ECC71" /> },
  { id: 'cpp', name: 'C++', category: 'backend', icon: <Zap size={14} color="#AAB2BD" /> },
  { id: 'c', name: 'C', category: 'backend', icon: <Wrench size={14} color="#AAB2BD" /> },
  { id: 'go', name: 'Go', category: 'backend', icon: <Code size={14} color="#C2A76E" /> },
  { id: 'rust', name: 'Rust', category: 'backend', icon: <Settings size={14} color="#E74C3C" /> },
  { id: 'php', name: 'PHP', category: 'backend', icon: <Code size={14} color="#AAB2BD" /> },
  { id: 'ruby', name: 'Ruby', category: 'backend', icon: <Code size={14} color="#E74C3C" /> },
  { id: 'kotlin', name: 'Kotlin', category: 'backend', icon: <Code size={14} color="#A58B5F" /> },
  { id: 'scala', name: 'Scala', category: 'backend', icon: <Code size={14} color="#E74C3C" /> },
  {
    id: 'nodejs',
    name: 'Node.js',
    category: 'backend',
    icon: <Server size={14} color="#2ECC71" />,
  },

  // Mobile Development
  {
    id: 'swift',
    name: 'Swift',
    category: 'mobile',
    icon: <Smartphone size={14} color="#C2A76E" />,
  },
  {
    id: 'objectivec',
    name: 'Objective-C',
    category: 'mobile',
    icon: <Smartphone size={14} color="#A58B5F" />,
  },
  {
    id: 'dart',
    name: 'Dart/Flutter',
    category: 'mobile',
    icon: <Smartphone size={14} color="#AAB2BD" />,
  },
  {
    id: 'reactnative',
    name: 'React Native',
    category: 'mobile',
    icon: <Smartphone size={14} color="#C2A76E" />,
  },

  // Data Science & ML
  { id: 'r', name: 'R', category: 'data', icon: <BarChart3 size={14} color="#AAB2BD" /> },
  { id: 'matlab', name: 'MATLAB', category: 'data', icon: <BarChart3 size={14} color="#C2A76E" /> },
  { id: 'julia', name: 'Julia', category: 'data', icon: <BarChart3 size={14} color="#A58B5F" /> },

  // Databases & Query
  { id: 'sql', name: 'SQL', category: 'database', icon: <Database size={14} color="#C2A76E" /> },
  {
    id: 'postgresql',
    name: 'PostgreSQL',
    category: 'database',
    icon: <Database size={14} color="#A58B5F" />,
  },
  {
    id: 'mysql',
    name: 'MySQL',
    category: 'database',
    icon: <Database size={14} color="#C2A76E" />,
  },
  {
    id: 'mongodb',
    name: 'MongoDB',
    category: 'database',
    icon: <Database size={14} color="#2ECC71" />,
  },

  // DevOps & Config
  {
    id: 'bash',
    name: 'Bash/Shell',
    category: 'devops',
    icon: <Terminal size={14} color="#2ECC71" />,
  },
  {
    id: 'powershell',
    name: 'PowerShell',
    category: 'devops',
    icon: <Terminal size={14} color="#C2A76E" />,
  },
  { id: 'yaml', name: 'YAML', category: 'devops', icon: <FileText size={14} color="#E74C3C" /> },
  { id: 'json', name: 'JSON', category: 'devops', icon: <FileText size={14} color="#AAB2BD" /> },
  {
    id: 'dockerfile',
    name: 'Dockerfile',
    category: 'devops',
    icon: <Package size={14} color="#AAB2BD" />,
  },
  {
    id: 'terraform',
    name: 'Terraform',
    category: 'devops',
    icon: <Cloud size={14} color="#A58B5F" />,
  },

  // Other Languages
  {
    id: 'haskell',
    name: 'Haskell',
    category: 'functional',
    icon: <BookOpen size={14} color="#AAB2BD" />,
  },
  {
    id: 'erlang',
    name: 'Erlang',
    category: 'functional',
    icon: <Code size={14} color="#E74C3C" />,
  },
  {
    id: 'elixir',
    name: 'Elixir',
    category: 'functional',
    icon: <Code size={14} color="#A58B5F" />,
  },
  {
    id: 'clojure',
    name: 'Clojure',
    category: 'functional',
    icon: <Code size={14} color="#C2A76E" />,
  },
  { id: 'assembly', name: 'Assembly', category: 'system', icon: <Cpu size={14} color="#6B7280" /> },
  // LaTeX & Papers
  {
    id: 'latex',
    name: 'LaTeX',
    category: 'latexdocs',
    icon: <FileText size={14} color="#C2A76E" />,
  },
  {
    id: 'bibtex',
    name: 'BibTeX',
    category: 'latexdocs',
    icon: <FileText size={14} color="#A58B5F" />,
  },
];

// AI Model options - Comprehensive models with proper API key requirements
export const aiModels: AiModel[] = [
  // OpenAI Models
  {
    id: 'gpt-5',
    name: 'GPT-5',
    provider: 'openai',
    description:
      'Next‑generation flagship model for advanced coding, reasoning, and agentic orchestration (experimental entry – ensure API availability).',
    contextLength: 'TBD',
    strengths: ['Agentic tasks', 'Deep reasoning', 'Code generation', 'Planning'],
  },
  {
    id: 'gpt-5-mini',
    name: 'GPT-5 Mini',
    provider: 'openai',
    description:
      'Faster, cost-focused GPT‑5 variant for iterative coding & well-scoped tasks (experimental).',
    contextLength: 'TBD',
    strengths: ['Speed', 'Cost efficiency', 'Low latency', 'General coding'],
  },
  {
    id: 'gpt-5-nano',
    name: 'GPT-5 Nano',
    provider: 'openai',
    description:
      'Ultra-fast GPT‑5 tier optimized for simple transformations & inline assists (experimental).',
    contextLength: 'TBD',
    strengths: ['Ultra low latency', 'Cost efficiency', 'Light transforms'],
  },
  {
    id: 'gpt-4o',
    name: 'GPT-4o',
    provider: 'openai',
    description: 'Latest GPT-4o with enhanced multimodal capabilities and speed',
    contextLength: '128k tokens',
    strengths: ['Multimodal', 'Speed', 'Reasoning', 'Latest features'],
  },
  {
    id: 'gpt-4o-mini',
    name: 'GPT-4o Mini',
    provider: 'openai',
    description: 'Compact version of GPT-4o, fast and cost-effective',
    contextLength: '128k tokens',
    strengths: ['Speed', 'Cost-effective', 'Efficiency', 'Quick tasks'],
  },
  {
    id: 'chatgpt-4o-latest',
    name: 'ChatGPT-4o Latest',
    provider: 'openai',
    description: 'Latest ChatGPT model with most recent improvements',
    contextLength: '128k tokens',
    strengths: ['Latest updates', 'Conversational', 'Code generation'],
  },
  {
    id: 'gpt-4-turbo',
    name: 'GPT-4 Turbo',
    provider: 'openai',
    description: 'Most capable GPT-4 model, excellent for complex coding tasks',
    contextLength: '128k tokens',
    strengths: ['Complex reasoning', 'Code generation', 'Architecture design'],
  },
  // Claude 4 family (experimental placeholders; ensure your account has access)
  {
    id: 'claude-4-opus',
    name: 'Claude 4 Opus',
    provider: 'anthropic',
    description: 'Next-gen Claude 4 Opus (experimental entry; verify access).',
    contextLength: '200k tokens',
    strengths: ['Deep reasoning', 'Long context']
  },
  {
    id: 'claude-4-sonnet',
    name: 'Claude 4 Sonnet',
    provider: 'anthropic',
    description: 'Balanced Claude 4 Sonnet (experimental entry; verify access).',
    contextLength: '200k tokens',
    strengths: ['Balanced performance', 'Coding']
  },
  {
    id: 'claude-4-haiku',
    name: 'Claude 4 Haiku',
    provider: 'anthropic',
    description: 'Fast Claude 4 Haiku (experimental entry; verify access).',
    contextLength: '200k tokens',
    strengths: ['Speed', 'Cost-effective']
  },
  {
    id: 'gpt-4',
    name: 'GPT-4',
    provider: 'openai',
    description: 'High-quality responses, great for detailed development work',
    contextLength: '8k tokens',
    strengths: ['Code quality', 'Problem solving', 'Documentation'],
  },
  {
    id: 'gpt-3.5-turbo',
    name: 'GPT-3.5 Turbo',
    provider: 'openai',
    description: 'Fast and efficient, good for most coding tasks',
    contextLength: '16k tokens',
    strengths: ['Speed', 'General coding', 'Quick fixes', 'Cost-effective'],
  },

  // Anthropic Models
  {
    id: 'claude-3.5-opus-20241022',
    name: 'Claude 3.5 Opus (Latest)',
    provider: 'anthropic',
    description:
      'High-capacity Claude 3.5 Opus variant targeting complex architectural & reasoning workloads (experimental entry).',
    contextLength: '200k tokens',
    strengths: ['Deep reasoning', 'Long-form analysis', 'Architecture', 'Tool use'],
  },
  {
    id: 'claude-3.5-vision-20241022',
    name: 'Claude 3.5 Vision',
    provider: 'anthropic',
    description: 'Visual + textual reasoning model (ensure vision beta access).',
    contextLength: '200k tokens',
    strengths: ['Vision understanding', 'Code + diagram analysis', 'Reasoning'],
  },
  {
    id: 'claude-3-5-sonnet-20241022',
    name: 'Claude 3.5 Sonnet (Latest)',
    provider: 'anthropic',
    description: 'Most advanced Claude model with enhanced coding and reasoning',
    contextLength: '200k tokens',
    strengths: ['Advanced reasoning', 'Code generation', 'Complex analysis', 'Tool use'],
  },
  {
    id: 'claude-3-5-sonnet-20240620',
    name: 'Claude 3.5 Sonnet',
    provider: 'anthropic',
    description: 'Excellent balance of intelligence and speed for development',
    contextLength: '200k tokens',
    strengths: ['Code generation', 'Analysis', 'Creative writing', 'Math'],
  },
  {
    id: 'claude-3-5-haiku-20241022',
    name: 'Claude 3.5 Haiku',
    provider: 'anthropic',
    description: 'Fast and intelligent model for quick coding tasks',
    contextLength: '200k tokens',
    strengths: ['Speed', 'Efficiency', 'Quick responses', 'Code completion'],
  },
  {
    id: 'claude-3-opus-20240229',
    name: 'Claude 3 Opus',
    provider: 'anthropic',
    description: 'Most capable Claude 3 model for complex analysis and reasoning',
    contextLength: '200k tokens',
    strengths: ['Complex reasoning', 'Analysis', 'Research', 'Architecture design'],
  },
  {
    id: 'claude-3-sonnet-20240229',
    name: 'Claude 3 Sonnet',
    provider: 'anthropic',
    description: 'Balanced Claude 3 model for general development tasks',
    contextLength: '200k tokens',
    strengths: ['Balanced performance', 'Code generation', 'Explanations'],
  },
  {
    id: 'claude-3-haiku-20240307',
    name: 'Claude 3 Haiku',
    provider: 'anthropic',
    description: 'Fast Claude 3 model for quick coding assistance',
    contextLength: '200k tokens',
    strengths: ['Speed', 'Quick tasks', 'Efficiency', 'Cost-effective'],
  },

  // Google Models
  {
    id: 'gemini-2.0-pro-exp',
    name: 'Gemini 2.0 Pro (Experimental)',
    provider: 'google',
    description:
      'Experimental Gemini 2.0 Pro with expanded reasoning & tool integration (verify access).',
    contextLength: '2M tokens',
    strengths: ['Huge context', 'Reasoning', 'Tool orchestration', 'Multimodal'],
  },
  {
    id: 'gemini-2.0-flash-lite',
    name: 'Gemini 2.0 Flash Lite',
    provider: 'google',
    description: 'Lightweight Gemini 2.0 Flash tier tuned for ultra-fast iteration.',
    contextLength: '1M tokens',
    strengths: ['Speed', 'Low cost', 'High throughput', 'Multimodal'],
  },
  {
    id: 'gemini-2.0-flash-exp',
    name: 'Gemini 2.0 Flash (Experimental)',
    provider: 'google',
    description: 'Latest experimental Gemini model with enhanced capabilities',
    contextLength: '1M tokens',
    strengths: ['Latest features', 'Multimodal', 'Large context', 'Speed'],
  },
  {
    id: 'gemini-1.5-pro-latest',
    name: 'Gemini 1.5 Pro (Latest)',
    provider: 'google',
    description: 'Most capable Gemini model with huge context window',
    contextLength: '2M tokens',
    strengths: ['Huge context', 'Complex reasoning', 'Multimodal', 'Code analysis'],
  },
  {
    id: 'gemini-1.5-pro',
    name: 'Gemini 1.5 Pro',
    provider: 'google',
    description: 'Advanced Gemini model for complex development tasks',
    contextLength: '1M tokens',
    strengths: ['Large context', 'Reasoning', 'Code generation', 'Analysis'],
  },
  {
    id: 'gemini-1.5-flash',
    name: 'Gemini 1.5 Flash',
    provider: 'google',
    description: 'Fast and efficient Gemini model for quick responses',
    contextLength: '1M tokens',
    strengths: ['Speed', 'Efficiency', 'Large context', 'Quick tasks'],
  },
  {
    id: 'gemini-1.5-flash-8b',
    name: 'Gemini 1.5 Flash-8B',
    provider: 'google',
    description: 'Compact and fast model for lightweight coding tasks',
    contextLength: '1M tokens',
    strengths: ['Speed', 'Efficiency', 'Cost-effective', 'Quick responses'],
  },
  {
    id: 'gemini-pro',
    name: 'Gemini Pro',
    provider: 'google',
    description: 'Standard Gemini model with strong reasoning capabilities',
    contextLength: '32k tokens',
    strengths: ['Reasoning', 'Code analysis', 'General tasks'],
  },
  {
    id: 'gemini-pro-vision',
    name: 'Gemini Pro Vision',
    provider: 'google',
    description: 'Multimodal model that can analyze code screenshots and diagrams',
    contextLength: '32k tokens',
    strengths: ['Vision', 'Diagrams', 'Screenshots', 'Image analysis'],
  },

  // Ollama Models (Local)
  {
    id: 'llama3.1',
    name: 'Llama 3.1 (8B)',
    provider: 'ollama',
    description: 'Latest Meta Llama model with enhanced capabilities',
    contextLength: '32k tokens',
    strengths: ['Latest features', 'Local', 'Privacy', 'Multilingual'],
  },
  {
    id: 'llama3.1:70b',
    name: 'Llama 3.1 (70B)',
    provider: 'ollama',
    description: 'Large Llama model with superior performance',
    contextLength: '32k tokens',
    strengths: ['High performance', 'Complex reasoning', 'Local', 'Privacy'],
  },
  {
    id: 'llama3',
    name: 'Llama 3 (8B)',
    provider: 'ollama',
    description: "Meta's Llama 3 model for general tasks",
    contextLength: '8k tokens',
    strengths: ['Balanced', 'Local', 'Open source', 'Multilingual'],
  },
  {
    id: 'llama2',
    name: 'Llama 2 (7B)',
    provider: 'ollama',
    description: "Meta's open-source model, runs locally",
    contextLength: '4k tokens',
    strengths: ['Privacy', 'Local', 'Open source', 'Stable'],
  },
  {
    id: 'codellama',
    name: 'Code Llama (7B)',
    provider: 'ollama',
    description: 'Specialized for code generation and understanding',
    contextLength: '16k tokens',
    strengths: ['Code focus', 'Local', 'Fast', 'Programming'],
  },
  {
    id: 'codellama:13b',
    name: 'Code Llama (13B)',
    provider: 'ollama',
    description: 'Larger Code Llama for better code generation',
    contextLength: '16k tokens',
    strengths: ['Better coding', 'Local', 'Detailed explanations'],
  },
  {
    id: 'mistral',
    name: 'Mistral (7B)',
    provider: 'ollama',
    description: 'Efficient open-source model with good coding capabilities',
    contextLength: '8k tokens',
    strengths: ['Efficiency', 'Local', 'Multilingual', 'Fast'],
  },
  {
    id: 'mixtral',
    name: 'Mixtral 8x7B',
    provider: 'ollama',
    description: 'Mixture of experts model with high performance',
    contextLength: '32k tokens',
    strengths: ['High performance', 'Efficiency', 'Local', 'Multilingual'],
  },
  {
    id: 'phi3',
    name: 'Phi-3 (3.8B)',
    provider: 'ollama',
    description: "Microsoft's efficient small model for coding",
    contextLength: '4k tokens',
    strengths: ['Compact', 'Fast', 'Coding', 'Efficient'],
  },
  {
    id: 'phi',
    name: 'Phi-2 (2.7B)',
    provider: 'ollama',
    description: "Microsoft's small but capable model for coding",
    contextLength: '2k tokens',
    strengths: ['Compact', 'Fast', 'Coding', 'Lightweight'],
  },
  {
    id: 'deepseek-coder',
    name: 'DeepSeek Coder (6.7B)',
    provider: 'ollama',
    description: 'Specialized coding model with excellent programming capabilities',
    contextLength: '16k tokens',
    strengths: ['Code generation', 'Multiple languages', 'Documentation'],
  },
  {
    id: 'deepseek-coder:33b',
    name: 'DeepSeek Coder (33B)',
    provider: 'ollama',
    description: 'Large specialized coding model for complex tasks',
    contextLength: '16k tokens',
    strengths: ['Advanced coding', 'Architecture design', 'Complex algorithms'],
  },
  {
    id: 'qwen2.5-coder',
    name: 'Qwen2.5 Coder (7B)',
    provider: 'ollama',
    description: "Alibaba's coding model with strong programming abilities",
    contextLength: '32k tokens',
    strengths: ['Code generation', 'Asian languages', 'Mathematical reasoning'],
  },
  {
    id: 'starcoder2',
    name: 'StarCoder2 (3B)',
    provider: 'ollama',
    description: 'Code generation model trained on diverse programming languages',
    contextLength: '16k tokens',
    strengths: ['Code completion', 'Multiple languages', 'Fast', 'Local'],
  },
];

// STEP 6: Provider-aware model catalog with badges.
// This intentionally does NOT remove legacy model ids; it layers metadata for grouping & UI labeling.
export const MODEL_OPTIONS: ModelOption[] = [
  // OpenAI
  {
    id: 'gpt-5',
    provider: 'openai',
    badge: 'Best',
    notes: 'Next-gen flagship (experimental availability)',
  },
  { id: 'gpt-5-mini', provider: 'openai', badge: 'Fast', notes: 'Speed / cost tier' },
  { id: 'gpt-5-nano', provider: 'openai', badge: 'Fast', notes: 'Ultra low latency tier' },
  { id: 'gpt-4o', provider: 'openai', badge: 'Best', notes: 'Multimodal, balanced performance' },
  { id: 'gpt-4o-mini', provider: 'openai', badge: 'Fast', notes: 'Fast iterative tasks' },
  { id: 'chatgpt-4o-latest', provider: 'openai', badge: 'Best', notes: 'Latest ChatGPT features' },
  {
    id: 'gpt-4-turbo',
    provider: 'openai',
    badge: 'Reasoning',
    notes: 'Complex reasoning & code planning',
  },
  {
    id: 'gpt-4',
    provider: 'openai',
    badge: 'Reasoning',
    deprecated: true,
    notes: 'Legacy GPT-4 (kept for compat)',
  },
  {
    id: 'gpt-3.5-turbo',
    provider: 'openai',
    badge: 'Fast',
    deprecated: true,
    notes: 'Legacy fast tier',
  },

  // Anthropic
  { id: 'claude-4-opus', provider: 'anthropic', badge: 'Best', notes: 'Experimental entry; verify access' },
  { id: 'claude-4-sonnet', provider: 'anthropic', badge: 'Reasoning' },
  { id: 'claude-4-haiku', provider: 'anthropic', badge: 'Fast' },
  {
    id: 'claude-3.5-opus-20241022',
    provider: 'anthropic',
    badge: 'Best',
    notes: 'High depth reasoning',
  },
  {
    id: 'claude-3.5-vision-20241022',
    provider: 'anthropic',
    badge: 'Experimental',
    notes: 'Vision + textual reasoning',
  },
  {
    id: 'claude-3-5-sonnet-20241022',
    provider: 'anthropic',
    badge: 'Best',
    notes: 'Latest balanced Claude',
  },
  {
    id: 'claude-3-5-sonnet-20240620',
    provider: 'anthropic',
    badge: 'Reasoning',
    deprecated: true,
    notes: 'Earlier Sonnet',
  },
  {
    id: 'claude-3-5-haiku-20241022',
    provider: 'anthropic',
    badge: 'Fast',
    notes: 'Speed focused Claude',
  },
  { id: 'claude-3-opus-20240229', provider: 'anthropic', badge: 'Reasoning', deprecated: true },
  { id: 'claude-3-sonnet-20240229', provider: 'anthropic', badge: 'Reasoning', deprecated: true },
  { id: 'claude-3-haiku-20240307', provider: 'anthropic', badge: 'Fast', deprecated: true },

  // Google / Gemini
  {
    id: 'gemini-2.0-pro-exp',
    provider: 'google',
    badge: 'Experimental',
    notes: 'Expanded reasoning / tool use',
  },
  { id: 'gemini-2.0-flash-lite', provider: 'google', badge: 'Fast', notes: 'Ultra fast iteration' },
  {
    id: 'gemini-2.0-flash-exp',
    provider: 'google',
    badge: 'Experimental',
    notes: 'Latest Flash experimental',
  },
  {
    id: 'gemini-1.5-pro-latest',
    provider: 'google',
    badge: 'Best',
    notes: 'Latest Pro large context',
  },
  { id: 'gemini-1.5-pro', provider: 'google', badge: 'Reasoning', deprecated: true },
  { id: 'gemini-1.5-flash', provider: 'google', badge: 'Fast' },
  { id: 'gemini-1.5-flash-8b', provider: 'google', badge: 'Fast', notes: 'Compact variant' },
  { id: 'gemini-pro', provider: 'google', badge: 'Reasoning', deprecated: true },
  {
    id: 'gemini-pro-vision',
    provider: 'google',
    badge: 'Experimental',
    notes: 'Vision capabilities',
  },

  // Local / Ollama catalog (static overlay; dynamic models added at runtime with Local badge automatically)
  { id: 'llama3.1', provider: 'ollama', badge: 'Local' },
  { id: 'llama3.1:70b', provider: 'ollama', badge: 'Local' },
  { id: 'llama3', provider: 'ollama', badge: 'Local', deprecated: true },
  { id: 'llama2', provider: 'ollama', badge: 'Local', deprecated: true },
  { id: 'codellama', provider: 'ollama', badge: 'Local' },
  { id: 'codellama:13b', provider: 'ollama', badge: 'Local' },
  { id: 'mistral', provider: 'ollama', badge: 'Local' },
  { id: 'mixtral', provider: 'ollama', badge: 'Local' },
  { id: 'phi3', provider: 'ollama', badge: 'Local' },
  { id: 'phi', provider: 'ollama', badge: 'Local', deprecated: true },
  { id: 'deepseek-coder', provider: 'ollama', badge: 'Local' },
  { id: 'deepseek-coder:33b', provider: 'ollama', badge: 'Local' },
  { id: 'qwen2.5-coder', provider: 'ollama', badge: 'Local' },
  { id: 'starcoder2', provider: 'ollama', badge: 'Local' },
];

// Fast lookup map for model metadata
export const modelOptionMap: Record<string, ModelOption> = MODEL_OPTIONS.reduce(
  (acc, m) => {
    acc[m.id] = m;
    return acc;
  },
  {} as Record<string, ModelOption>
);

// Helper to merge catalog metadata with core model definition
export const getEnrichedModel = (
  id: string
):
  | (AiModel & {
      badge?: ModelOption['badge'];
      notes?: string | undefined;
      deprecated?: boolean | undefined;
    })
  | undefined => {
  const base = aiModels.find(m => m.id === id);
  if (!base) return undefined;
  const extra = modelOptionMap[id];
  if (!extra) return base;
  return { ...base, badge: extra.badge, notes: extra.notes, deprecated: extra.deprecated };
};

// =========================
// Presets & Prompt Builders (Prompt 3)
// =========================
export interface AiPreset {
  id: string;
  label: string;
  description: string;
  systemHint: string;
  format: 'single-file' | 'multi-file';
}

// Beginner presets (single-file)
export const BEGINNER_PRESETS: AiPreset[] = [
  {
    id: 'calculator',
    label: 'Well Design HTML Calculator',
    description:
      'One self-contained HTML file; semantic HTML, CSS-in-<style>, accessible labels, clear comments.',
    systemHint:
      'Produce ONE self-contained HTML file with inline <style> and <script>. Explain with concise comments. Use semantic elements and accessible labels. No external scripts or CDNs.',
    format: 'single-file',
  },
  {
    id: 'landing',
    label: 'Landing Page',
    description:
      'Single HTML file; responsive grid/flex, minimal CSS, comments explaining sections.',
    systemHint:
      'Create ONE HTML file with responsive layout, minimal CSS, and comments for each section. No external assets.',
    format: 'single-file',
  },
  {
    id: 'portfolio',
    label: 'Portfolio',
    description: 'Single HTML; sections for About/Projects/Contact; ARIA labels and comments.',
    systemHint:
      'One HTML file, sections: About, Projects, Contact. Include ARIA labels and inline comments. No external assets.',
    format: 'single-file',
  },
  {
    id: 'todo-vanilla',
    label: 'Vanilla JS To-Do',
    description: 'Single HTML with vanilla JS; keyboard accessible; comments.',
    systemHint:
      'A single HTML file implementing a to-do app with vanilla JS and keyboard accessibility. Comments required.',
    format: 'single-file',
  },
  // Back-compat alias for existing menu key
  {
    id: 'todo',
    label: 'To-Do (Alias)',
    description: 'Alias for vanilla to-do — single HTML with inline JS and comments.',
    systemHint:
      'A single HTML file implementing a to-do app with vanilla JS and keyboard accessibility. Comments required.',
    format: 'single-file',
  },
];

// Pro presets (multi-file)
export const PRO_PRESETS: AiPreset[] = [
  {
    id: 'react-ts-todo',
    label: 'React + TS To-Do',
    description:
      'Multi-file React + TypeScript scaffold (components, hooks, styles), plus a brief README.',
    systemHint:
      'Scaffold a small React + TypeScript app split across multiple files. Each code block MUST include a language and filename meta: ```tsx filename:src/components/TodoItem.tsx ...```. Provide a short README in ```md filename:README.md```. Keep imports relative. No external network calls. No CDNs.',
    format: 'multi-file',
  },
  {
    id: 'ts-lib',
    label: 'TypeScript Library',
    description:
      'Multi-file TS library with src/index.ts, a utils module, and a minimal test file.',
    systemHint:
      'Create a small TypeScript library split across multiple files. Use filename meta in fences. Include ```ts filename:src/index.ts``` and ```ts filename:src/utils/math.ts```. Add a minimal test in ```ts filename:tests/basic.test.ts```. No external deps.',
    format: 'multi-file',
  },
  {
    id: 'web-components',
    label: 'Web Components',
    description: 'Multi-file vanilla Web Components with CSS modules and a demo index.html.',
    systemHint:
      'Build multiple files for vanilla Web Components. Include ```html filename:demo/index.html```, components in ```js filename:src/components/Xyz.js``` with shadow DOM, and CSS in ```css filename:src/styles/theme.css```. Use filename meta.',
    format: 'multi-file',
  },
];

export function findPresetById(mode: AiMode, id?: string | null): AiPreset | null {
  if (!id) return null;
  const pool = mode === 'beginner' ? BEGINNER_PRESETS : PRO_PRESETS;
  return pool.find(p => p.id === id) ?? null;
}

// New profile-aware compiler integration (keeps old API returning string)
export interface SystemPromptBuildResult {
  systemPrompt: string;
  userPrelude?: string;
  contextSummary: string;
  tokensEstimated: number;
}

export function buildSystemPrompt(opts: {
  mode: AiMode;
  preset?: AiPreset | null;
  pinnedContext?: string[];
}): string {
  const { mode, preset, pinnedContext } = opts;
  // Build minimal context: pinned + optional preset hint flows into quickPrompts
  const quicks: string[] = [];
  if (preset?.systemHint) quicks.push(preset.systemHint);
  const ctxMinimal: import('@/utils/ai/context/contextSources').ContextInput = {
    settings: { mode },
  };
  if ((pinnedContext ?? []).length) ctxMinimal.pinnedNotes = pinnedContext as string[];
  if (quicks.length) ctxMinimal.quickPrompts = quicks;
  const compiled = compileContext(ctxMinimal);
  const langName = undefined as string | undefined;
  const fence = 'txt';
  const spec = mode === 'pro' ? 'system.pro@stable' : 'system.beginner@stable';
  const { text: sys } = getPrompt(spec, {
    LANG_NAME: langName ?? 'the requested language',
    FENCE_LANG: fence,
    CONTEXT_SNIPPET: compiled.summary,
  });
  try {
    const tid = getActiveTraceId();
    if (tid) annotateTrace(tid, { promptId: spec.split('@')[0], promptVersion: spec.split('@')[1] || 'latest' });
  } catch {}
  if (import.meta.env?.MODE === 'development') {
    // eslint-disable-next-line no-console
    console.debug('[buildSystemPrompt] mode=', mode, 'tokens≈', compiled.tokensEstimated);
  }
  return sys;
}

// V2: Structured result while preserving compatibility with existing callers.
export function buildSystemPromptV2(input: {
  mode: AiMode;
  preset?: AiPreset | null;
  pinnedContext?: string[];
  // optional dynamic context inputs
  activeFilePath?: string;
  activeFileContent?: string;
  selectedText?: string;
  projectBrief?: string;
  quickPrompts?: string[];
  languageId?: string;
  monacoLanguage?: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
}): SystemPromptBuildResult {
  const settings: ContextInput['settings'] = { mode: input.mode };
  if (typeof input.languageId === 'string') settings.languageId = input.languageId;
  if (typeof input.monacoLanguage === 'string') settings.monacoLanguage = input.monacoLanguage;
  if (typeof input.model === 'string') settings.model = input.model;
  if (typeof input.temperature === 'number') settings.temperature = input.temperature;
  if (typeof input.maxTokens === 'number') settings.maxTokens = input.maxTokens;

  const ctxIn: ContextInput = { settings };
  if (input.activeFilePath !== undefined) ctxIn.activeFilePath = input.activeFilePath;
  if (input.activeFileContent !== undefined) ctxIn.activeFileContent = input.activeFileContent;
  if (input.selectedText !== undefined) ctxIn.selectedText = input.selectedText;
  if (input.projectBrief !== undefined) ctxIn.projectBrief = input.projectBrief;
  if (input.quickPrompts !== undefined) ctxIn.quickPrompts = input.quickPrompts;
  if (input.pinnedContext !== undefined) ctxIn.pinnedNotes = input.pinnedContext;

  const compiled = compileContext(ctxIn);
  const spec = input.mode === 'pro' ? 'system.pro@stable' : 'system.beginner@stable';
  const fence = input.monacoLanguage || input.languageId || 'txt';
  const langName = input.monacoLanguage || input.languageId || 'the requested language';
  const { text: systemPrompt } = getPrompt(spec, {
    LANG_NAME: langName,
    FENCE_LANG: fence,
    CONTEXT_SNIPPET: compiled.summary,
  });
  try {
    const tid = getActiveTraceId();
    if (tid) annotateTrace(tid, { promptId: spec.split('@')[0], promptVersion: spec.split('@')[1] || 'latest' });
  } catch {}

  if (import.meta.env?.MODE === 'development') {
    // eslint-disable-next-line no-console
    console.debug('[prompt] tokens≈', compiled.tokensEstimated, 'summary chars=', compiled.summary.length);
  }

  return {
  systemPrompt,
    contextSummary: compiled.summary,
    tokensEstimated: compiled.tokensEstimated,
  };
}

// Optional helper for fence info parsing
export function parseFenceInfo(info: string | undefined) {
  const raw = (info || '').trim();
  const lang = raw.split(/\s+/)[0] || '';
  const m = raw.match(/filename:([^\s]+)/i);
  const filename = m?.[1] ?? null;
  return { lang, filename };
}

// Default values and categories
export const defaultLanguage = 'javascript';
export const defaultModel = 'gpt-4-turbo';

export const languageCategories = [
  'all',
  'web',
  'backend',
  'mobile',
  'data',
  'database',
  'devops',
  'functional',
  'system',
];

export const modelProviders = ['all', 'openai', 'anthropic', 'google', 'ollama'];

export const promptCategories = [
  'all',
  'frontend',
  'backend',
  'devops',
  'ai',
  'algorithms',
  'testing',
  'documentation',
  'analysis',
];

// Helper functions for filtering
export const getLanguagesByCategory = (category: string): Language[] => {
  if (category === 'all') return languages;
  return languages.filter(lang => lang.category === category);
};

export const getModelsByProvider = (provider: string): AiModel[] => {
  if (provider === 'all') return aiModels;
  return aiModels.filter(model => model.provider === provider);
};

export const getPromptsByCategory = (category: string): QuickPrompt[] => {
  if (category === 'all') return quickPrompts;
  return quickPrompts.filter(prompt => prompt.category === category);
};

// Model availability checker
type ApiKeyConfig = { openai?: string; anthropic?: string; google?: string; ollama?: string };
export const isModelAvailable = (model: AiModel, apiKeys: ApiKeyConfig): boolean => {
  switch (model.provider) {
    case 'openai':
      return !!apiKeys.openai;
    case 'anthropic':
      return !!apiKeys.anthropic;
    case 'google':
      return !!apiKeys.google;
    case 'ollama':
      return !!apiKeys.ollama;
    default:
      return false;
  }
};

// =========================
// AI Settings (Prompt 2)
// =========================
export type AiMode = 'beginner' | 'pro';
export type DefaultInsertBehavior = 'insert' | 'replace' | 'new-tab';

export interface AiSettings {
  mode: AiMode;
  modelId: string | null; // null => use current default
  defaultInsert: DefaultInsertBehavior;
  autoPreview: boolean;
}

export const AI_SETTINGS_STORAGE_KEY = 'synapse.ai.settings';

export const DEFAULT_AI_SETTINGS: AiSettings = {
  mode: 'beginner',
  modelId: null,
  defaultInsert: 'insert',
  autoPreview: true,
};

type AiSettingsListener = (s: AiSettings) => void;
const aiSettingsListeners = new Set<AiSettingsListener>();

export function loadAiSettings(): AiSettings {
  try {
    const raw = localStorage.getItem(AI_SETTINGS_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_AI_SETTINGS };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_AI_SETTINGS, ...parsed } as AiSettings;
  } catch {
    return { ...DEFAULT_AI_SETTINGS };
  }
}

export function saveAiSettings(s: AiSettings) {
  try {
    localStorage.setItem(AI_SETTINGS_STORAGE_KEY, JSON.stringify(s));
  } finally {
    aiSettingsListeners.forEach(fn => {
      try {
        fn(s);
      } catch {
        /* ignore notify errors */
      }
    });
  }
}

export function subscribeAiSettings(fn: AiSettingsListener) {
  aiSettingsListeners.add(fn);
  return () => aiSettingsListeners.delete(fn);
}

// =========================
// Conversation Continuity (Prompt 4)
// =========================
export type ChatRole = 'system' | 'user' | 'assistant';

export interface StoredMessage {
  role: ChatRole;
  content: string;
  ts: number; // epoch ms
  modelId?: string | null;
  // Mode at the time this message was created; used to freeze per-request behavior (Beginner vs Pro)
  mode?: 'beginner' | 'pro';
}

export interface StoredThread {
  projectId: string;
  summary?: string; // rolling summary text (compact)
  messages: StoredMessage[]; // recent tail kept verbatim
  updatedAt: number; // epoch ms
  version: 1;
}

export const THREAD_NS = 'synapse.ai.threads'; // threads namespace
export const PINNED_CONTEXT_KEY = 'synapse.ai.pinnedContext'; // string[]
export const SUMMARY_MODE_KEY = 'synapse.ai.summary.mode'; // 'standard' | 'aggressive'

// very rough approx: 1 token ~ 4 chars (safe upper bound)
export function estimateTokens(s: string) {
  const TOKEN_CHARS_PER_TOKEN = 4;
  return Math.ceil(((s as string)?.length ?? 0) / TOKEN_CHARS_PER_TOKEN);
}

export const CONTEXT_BUDGET_TOKENS = 6000; // leave room for response
export const SUMMARY_TRIGGER_MSGS = 40; // when to summarize
export const SUMMARY_KEEP_TAIL = 10; // keep last N full messages after summarizing
export const SUMMARY_MAX_TOKENS = 900; // target <= ~900 tokens summary

export type SummaryMode = 'standard' | 'aggressive';
export function loadSummaryMode(): SummaryMode {
  try {
    const v = localStorage.getItem(SUMMARY_MODE_KEY);
    return v === 'aggressive' ? 'aggressive' : 'standard';
  } catch {
    return 'standard';
  }
}
export function saveSummaryMode(mode: SummaryMode) {
  try {
    localStorage.setItem(SUMMARY_MODE_KEY, mode);
  } catch {
    /* ignore */
  }
}

// Best-effort project id resolver, falls back to 'default'
export function getActiveProjectId(): string {
  try {
    return localStorage.getItem('synapse.project.id') || 'default';
  } catch {
    return 'default';
  }
}

export function loadPinnedContext(): string[] {
  try {
    const raw = localStorage.getItem(PINNED_CONTEXT_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.filter(Boolean) : [];
  } catch {
    return [];
  }
}

export function savePinnedContext(lines: string[]) {
  localStorage.setItem(PINNED_CONTEXT_KEY, JSON.stringify(lines.filter(Boolean)));
}

function threadKey(projectId: string) {
  return `${THREAD_NS}.${projectId}`;
}

export function loadThread(projectId: string): StoredThread {
  try {
    const raw = localStorage.getItem(threadKey(projectId));
    if (!raw) throw new Error('no thread');
    const parsed = JSON.parse(raw);
    return {
      version: 1,
      projectId,
      summary: parsed.summary ?? '',
      messages: Array.isArray(parsed.messages) ? parsed.messages : [],
      updatedAt: parsed.updatedAt ?? Date.now(),
    };
  } catch {
    return { version: 1, projectId, summary: '', messages: [], updatedAt: Date.now() };
  }
}

export function saveThread(t: StoredThread) {
  t.updatedAt = Date.now();
  localStorage.setItem(threadKey(t.projectId), JSON.stringify(t));
}

export function appendToThread(projectId: string, msg: StoredMessage) {
  const t = loadThread(projectId);
  t.messages.push(msg);
  saveThread(t);
  return t;
}

export function replaceThread(projectId: string, updater: (t: StoredThread) => StoredThread) {
  const t = loadThread(projectId);
  const next = updater(t);
  saveThread(next);
  return next;
}

export function shouldSummarize(t: StoredThread) {
  const mode = loadSummaryMode();
  const AGGRESSIVE_MSG_FLOOR = 10;
  const HALF_DIVISOR = 2;
  const msgTrigger =
    mode === 'aggressive'
      ? Math.max(AGGRESSIVE_MSG_FLOOR, Math.floor(SUMMARY_TRIGGER_MSGS / HALF_DIVISOR))
      : SUMMARY_TRIGGER_MSGS;
  if (t.messages.length >= msgTrigger) return true;
  const tokenSum = estimateTokens((t.summary || '') + t.messages.map(m => m.content).join('\n'));
  const AGGRESSIVE_THRESHOLD_RATIO = 0.8;
  const tokenThreshold =
    mode === 'aggressive'
      ? Math.floor(CONTEXT_BUDGET_TOKENS * AGGRESSIVE_THRESHOLD_RATIO)
      : CONTEXT_BUDGET_TOKENS;
  return tokenSum > tokenThreshold;
}

// Builds a summarization prompt payload (system+user text), but does not send it.
export function buildSummaryRequestPayload(t: StoredThread) {
  const header = `You are a summarizer for a coding assistant.
Goal: compress prior conversation into a compact, factual project brief.
Include ONLY:
- user goals & constraints
- accepted decisions & chosen stacks
- code/style conventions and "do/don't" rules
- open todos/questions
Output <= ${SUMMARY_MAX_TOKENS} tokens. Bullet points allowed. No extra commentary.`;

  // Pack older messages (all except tail)
  const cutoff = Math.max(0, t.messages.length - SUMMARY_KEEP_TAIL);
  const older = t.messages.slice(0, cutoff);
  const olderText = older.map(m => `[${m.role.toUpperCase()}] ${m.content}`).join('\n');

  const userBlob = `Summarize the following prior dialogue for continuity:\n\n${olderText}`;

  return {
    system: header,
    user: userBlob,
    keepTailFromIndex: cutoff,
  };
}

// Select recent messages that fit within a token budget (leaving margin). Returns forward order.
export function selectRecentForBudget(
  messages: StoredMessage[],
  baseTokens: number,
  budget: number,
  margin: number
) {
  const out: StoredMessage[] = [];
  let used = baseTokens;
  for (const m of [...messages].reverse()) {
    const line = `[${m.role}] ${m.content}\n`;
    const cost = estimateTokens(line);
    if (used + cost > budget - margin) break;
    out.push(m);
    used += cost;
  }
  return out.reverse();
}

// Thread management helpers for UI
export function clearThread(projectId: string) {
  const empty: StoredThread = {
    projectId,
    version: 1,
    summary: '',
    messages: [],
    updatedAt: Date.now(),
  };
  saveThread(empty);
  return empty;
}

export function exportThread(projectId: string) {
  const t = loadThread(projectId);
  const JSON_INDENT = 2;
  return JSON.stringify(t, null, JSON_INDENT);
}

export function importThread(projectId: string, json: string) {
  const parsed = JSON.parse(json);
  const t: StoredThread = {
    version: 1,
    projectId,
    summary: typeof parsed.summary === 'string' ? parsed.summary : '',
    messages: Array.isArray(parsed.messages) ? parsed.messages.filter(Boolean) : [],
    updatedAt: Date.now(),
  };
  saveThread(t);
  return t;
}

// =========================
// Prompt 5 — Resilience Utilities
// =========================
// Soft timeouts and retry knobs (kept conservative)
// Prompt 3 — Stream Lifecycle Hardening
// Extend hard/idle timeouts to reduce premature aborts while guaranteeing cleanup
export const REQUEST_TIMEOUT_MS = 120000; // hard cap for streaming requests (120s)
export const IDLE_CHUNK_TIMEOUT_MS = 25000; // abort if no stream chunks for N ms (25s)
export const RETRY_BACKOFF_MS = 800; // single retry backoff
export const ALLOW_MODEL_FALLBACK = true; // enable provider-aware fallback

export type ProviderErrorType =
  | 'auth'
  | 'rate_limit'
  | 'server'
  | 'network'
  | 'not_found'
  | 'bad_request'
  | 'unknown';
export interface ProviderErrInfo {
  retryable: boolean;
  type: ProviderErrorType;
  status?: number;
  message?: string;
}

export function classifyProviderError(err: unknown): ProviderErrInfo {
  const HTTP_BAD_REQUEST = 400;
  const HTTP_UNAUTHORIZED = 401;
  const HTTP_FORBIDDEN = 403;
  const HTTP_NOT_FOUND = 404;
  const HTTP_TOO_MANY = 429;
  const HTTP_SERVER_LO = 500;
  const HTTP_SERVER_HI = 600;
  const asAny = err as { message?: string; name?: string } | undefined;
  const msg = asAny?.message || String(err ?? '');
  // Common HTTP status patterns
  const m = msg.match(/\b(\d{3})\b/);
  const status = m ? parseInt(m[1], 10) : undefined;
  if (status) {
    if (status === HTTP_UNAUTHORIZED || status === HTTP_FORBIDDEN)
      return { retryable: false, type: 'auth', status, message: msg };
    if (status === HTTP_NOT_FOUND)
      return { retryable: false, type: 'not_found', status, message: msg };
    if (status === HTTP_BAD_REQUEST)
      return { retryable: false, type: 'bad_request', status, message: msg };
    if (status === HTTP_TOO_MANY)
      return { retryable: true, type: 'rate_limit', status, message: msg };
    if (status >= HTTP_SERVER_LO && status < HTTP_SERVER_HI)
      return { retryable: true, type: 'server', status, message: msg };
  }
  if (/AbortError/i.test(asAny?.name || '') || /aborted|abort/i.test(msg))
    return { retryable: true, type: 'network', message: 'aborted' };
  if (/network|fetch|failed to fetch/i.test(msg))
    return { retryable: true, type: 'network', message: msg };
  const base: ProviderErrInfo = { retryable: true, type: 'unknown', message: msg };
  if (typeof status === 'number') base.status = status;
  return base;
}

// Provider-aware fallback selection (prefer same provider, then stable default)
export function selectFallbackModel(currentId: string, provider: string): string | null {
  const sameProviderModels = aiModels.filter(m => m.provider === provider).map(m => m.id);
  const pick = (candidates: string[]): string | null => {
    for (const id of candidates) {
      if (id && id !== currentId && sameProviderModels.includes(id)) return id;
    }
    return null;
  };
  switch (provider) {
    case 'openai':
      // Prefer 5→4o chain
      return pick(['gpt-5', 'gpt-5-mini', 'gpt-5-nano', 'gpt-4o', 'gpt-4o-mini', 'chatgpt-4o-latest', 'gpt-4-turbo']);
    case 'anthropic':
      return pick([
        'claude-4-opus', 'claude-4-sonnet', 'claude-4-haiku',
        'claude-3-5-sonnet-20241022', 'claude-3.5-haiku-20241022', 'claude-3-sonnet-20240229',
      ]);
    case 'google':
      return pick(['gemini-1.5-pro-latest', 'gemini-1.5-flash', 'gemini-1.5-flash-8b']);
    case 'ollama':
      // Generic local default; availability depends on user installation
      return 'llama3.1';
    default:
      return null;
  }
}

// Friendly toast facade (console fallback). UI components may ignore this and show their own toasts.
export function notify(type: 'success' | 'error' | 'warning' | 'info', message: string) {
  import('@/ui/toast/api')
    .then(mod => {
      try { mod.showToast({ kind: type, message, contextKey: `notify:${type}:${message}` }); } catch {}
    })
    .catch(() => {
      // eslint-disable-next-line no-console
      console.log(`[AI:${type}]`, message);
    });
}

// =========================
// Prompt 6 — Selection helpers (tiny, dependency-free)
// =========================
export function detectLangFromFilename(name?: string): string {
  if (!name) return '';
  const ext = name.split('.').pop()?.toLowerCase() || '';
  const map: Record<string, string> = {
    js: 'javascript',
    mjs: 'javascript',
    cjs: 'javascript',
    ts: 'typescript',
    tsx: 'tsx',
    jsx: 'jsx',
    html: 'html',
    css: 'css',
    json: 'json',
    py: 'python',
    rb: 'ruby',
    php: 'php',
    java: 'java',
    kt: 'kotlin',
    cs: 'csharp',
    cpp: 'cpp',
    cxx: 'cpp',
    cc: 'cpp',
    h: 'cpp',
    hpp: 'cpp',
    md: 'markdown',
    sh: 'bash',
    yml: 'yaml',
    yaml: 'yaml',
  };
  return map[ext] || '';
}

export function commentDelimiters(lang: string) {
  const l = (lang || '').toLowerCase();
  if (
    [
      'javascript',
      'typescript',
      'tsx',
      'jsx',
      'java',
      'csharp',
      'cpp',
      'c',
      'go',
      'rust',
      'kotlin',
    ].includes(l)
  )
    return { line: '//', blockStart: '/*', blockEnd: '*/' } as const;
  if (l === 'python' || l === 'ruby') return { line: '#', blockStart: null, blockEnd: null } as const;
  if (l === 'html' || l === 'xml') return { line: null, blockStart: '<!--', blockEnd: '-->' } as const;
  if (l === 'css') return { line: null, blockStart: '/*', blockEnd: '*/' } as const;
  return { line: '//', blockStart: '/*', blockEnd: '*/' } as const; // safe default
}

export type AiSelectionAction = 'improve' | 'explain' | 'commentize';

export function buildSelectionUserPrompt(params: {
  action: AiSelectionAction;
  code: string; // selected text (or entire file)
  lang?: string; // e.g., 'typescript', 'html'
  mode: AiMode; // 'beginner' | 'pro'
}) {
  const { action, code, lang = '', mode } = params;

  const shared = [
    `Language: ${lang || 'plaintext'}`,
    'Assume the selection is valid and should keep the same behavior.',
    'NEVER add external network resources (no CDN <script> or <link>).',
  ].join('\n');

  if (action === 'improve') {
    const proExtras = [
      'Refactor for readability, safety, and performance.',
      'Keep public API and runtime behavior identical.',
      'Prefer strong typing (if TS), small pure functions, and clear names.',
      'Return ONLY the improved code in one fenced block using the same language.',
    ];
    const beginnerExtras = [
      'Make the code easier to read and simpler without changing behavior.',
      'Avoid advanced patterns; keep it straightforward.',
      'Return ONLY the improved code in one fenced block using the same language.',
    ];
  const extras = mode === 'pro' ? proExtras.join('\n') : beginnerExtras.join('\n');
  return `${shared}\n${extras}\n\nSelected Code:\n\n${code}`;
  }

  if (action === 'commentize') {
    const { line, blockStart, blockEnd } = commentDelimiters(lang);
    const commentRules = [
      'Add short, beginner-friendly inline comments that explain intent (not obvious syntax).',
      'Do NOT change code except adding comments.',
      line
        ? `Use line comments with "${line}" where possible.`
        : `Use block comments with "${blockStart} ... ${blockEnd}".`,
      'Avoid over-commenting: ~1 comment per logical block or tricky line.',
      'Return ONLY the commented code in one fenced block using the same language.',
    ].join('\n');
    return `${shared}\n${commentRules}\n\nSelected Code:\n\n${code}`;
  }

  // explain
  const explainRules = [
    'Explain concisely in Markdown what the selection does, inputs/outputs, and key trade-offs.',
    'If relevant, reference noteworthy lines by quoting tiny snippets (no long code).',
    'List 3–5 improvement suggestions as bullets (do not modify code).',
    'Return ONLY Markdown explanation (no code fences).',
  ].join('\n');
  return `${shared}\n${explainRules}\n\nSelected Code:\n\n${code}`;
}

// ================== Preview Security: Sanitizer + CSP injection ==================
export interface SanitizeOptions {
  allowInlineScripts?: boolean; // default true (still sandboxed + CSP)
  allowDataImages?: boolean; // default true
}

const TAGS_REMOVE_COMPLETELY = new Set([
  'iframe',
  'frame',
  'embed',
  'object',
  'applet',
  'link',
  'meta',
  'base',
  'source',
]);

// Basic HTML detection
export function isLikelyHtml(snippet: string) {
  const s = String(snippet || '').trim().toLowerCase();
  return s.startsWith('<!doctype html') || s.includes('<html') || s.includes('<body') || s.includes('<head');
}

// Remove <script src=...>, keep inline scripts optionally
function stripScriptTags(html: string, allowInline: boolean) {
  // Remove external-script tags entirely
  html = html.replace(/<script\b[^>]*\bsrc\s*=\s*[^>]*>[\s\S]*?<\/script>/gi, '');
  if (!allowInline) {
    // Remove all script tags if inline not allowed
    return html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '');
  }
  // Keep inline <script>
  return html;
}

// Remove dangerous tags and attributes (onload=, onclick=, etc.)
function stripDangerousNodesAndAttrs(html: string, allowDataImages: boolean) {
  // 1) Remove entire nodes for specific tags
  html = html.replace(
    new RegExp(`<\\/?(?:${Array.from(TAGS_REMOVE_COMPLETELY).join('|')})\\b[^>]*>`, 'gi'),
    ''
  );

  // 2) Remove event handler attributes: on*
  html = html.replace(/\s+on[a-z]+\s*=\s*(".*?"|'.*?'|[^\s>]+)/gi, '');

  // 3) Remove javascript: URIs in href/src
  html = html.replace(/\s(href|src)\s*=\s*("|')\s*javascript:[^"']*(\2)/gi, ' $1="#"');
  html = html.replace(/\s(href|src)\s*=\s*javascript:[^\s>]+/gi, ' $1="#"');

  // 4) Block remote http(s) assets (also handle img/video/audio poster)
  const urlReplacer = (_: string, attr: string, q?: string, v?: string) => {
    const val = (v || '').trim();
    if (/^data:/i.test(val)) {
      return allowDataImages ? ` ${attr}=${q}${val}${q}` : ` ${attr}=""`;
    }
    if (/^(?:https?:|\/\/)/i.test(val)) {
      return ` ${attr}=""`;
    }
    return ` ${attr}=${q || ''}${val}${q || ''}`;
  };
  html = html.replace(/\s(src|poster)\s*=\s*(")(.*?)\2/gi, urlReplacer);
  html = html.replace(/\s(src|poster)\s*=\s*(')(.*?)\2/gi, urlReplacer);
  html = html.replace(/\s(src|poster)\s*=\s*([^\s>]+)/gi, urlReplacer);

  // 5) Sanitize style attributes: remove url(http...) and expression()
  html = html.replace(/\sstyle\s*=\s*("|')([\s\S]*?)\1/gi, (_m, q, css) => {
    const clean = String(css)
      .replace(/url\((?:["']?\s*)?(https?:)?\/\/[^)]+\)/gi, '/*url-removed*/')
      .replace(/expression\s*\([^)]*\)/gi, '/*expr-removed*/')
      .replace(/@import\s+[^;]+;/gi, '/*import-removed*/');
    return ` style=${q}${clean}${q}`;
  });

  return html;
}

// Remove CSS @import and external urls inside <style> blocks
function sanitizeStyleBlocks(html: string) {
  return html.replace(/<style\b[^>]*>([\s\S]*?)<\/style>/gi, (_m, css) => {
    const clean = String(css)
      .replace(/@import\s+[^;]+;/gi, '/*import-removed*/')
      .replace(/url\((?:["']?\s*)?(https?:)?\/\/[^)]+\)/gi, '/*url-removed*/')
      .replace(/expression\s*\([^)]*\)/gi, '/*expr-removed*/');
    return `<style>${clean}</style>`;
  });
}

function ensureHead(html: string) {
  const hasHtml = /<html[\s>]/i.test(html);
  const hasHead = /<head[\s>]/i.test(html);
  if (!hasHtml) {
    html = `<!doctype html><html><head></head><body>${html}</body></html>`;
  } else if (!hasHead) {
    html = html.replace(/<html([\s>])/i, '<html$1<head></head>');
  }
  return html;
}

function injectStrictCsp(html: string) {
  const csp = [
    "default-src 'none'",
    "base-uri 'none'",
    "form-action 'none'",
    "frame-ancestors 'none'",
    "connect-src 'none'",
    "img-src 'self' data: blob:",
    "font-src 'self' data:",
    "media-src 'self' data:",
    "style-src 'unsafe-inline'",
    "script-src 'unsafe-inline'",
    "frame-src 'none'",
    "object-src 'none'",
  ].join('; ');

  const meta = `<meta http-equiv="Content-Security-Policy" content="${csp}">`;
  // Insert as first element in <head>
  return html.replace(/<head[^>]*>/i, (m) => `${m}${meta}`);
}

export function sanitizeHtmlForPreview(raw: string, opts?: SanitizeOptions) {
  const allowInline = opts?.allowInlineScripts ?? true;
  const allowDataImages = opts?.allowDataImages ?? true;

  let html = String(raw || '');

  // 1) Normalize structure
  html = ensureHead(html);

  // 2) Remove dangerous resources
  html = stripScriptTags(html, allowInline);
  html = stripDangerousNodesAndAttrs(html, allowDataImages);
  html = sanitizeStyleBlocks(html);

  // 3) Inject strict CSP
  html = injectStrictCsp(html);

  // Optional debug, keep off by default
  const debug = false;
  if (debug) {
    const removedScripts = (raw.match(/<script\b/gi) || []).length - (html.match(/<script\b/gi) || []).length;
    const removedLinks = (raw.match(/<link\b/gi) || []).length - (html.match(/<link\b/gi) || []).length;
    const removedIframes = (raw.match(/<iframe\b/gi) || []).length - (html.match(/<iframe\b/gi) || []).length;
    // eslint-disable-next-line no-console
    console.log(`[SANITIZER] removed: scripts=${removedScripts}, links=${removedLinks}, iframes=${removedIframes}`);
  }

  return html;
}

// ================== Stream + List Performance ==================
export const STREAM_FLUSH_MS = 80;    // batch streamed tokens into ~10-16 fps updates for smooth streaming
export const MAX_DOM_APPEND_PER_FLUSH = 4000; // guard: slice huge deltas
export const VLIST_OVERSCAN_PX = 600; // render ±600px beyond viewport
export const VLIST_MEASURE_DEBOUNCE_MS = 80;

export function nowMs() {
  try {
    // performance.now() is high-resolution in browsers; fallback to Date.now()
    return performance.now();
  } catch {
    return Date.now();
  }
}

// ================== Prompt 3: Lightweight validators (pure helpers) ==================
export type ProviderId = 'openai' | 'anthropic' | 'google' | 'ollama';

// Validate presence of API keys based on aiSettings shape (best-effort; non-throwing)
export function validateApiKeys(aiSettings: any): { ok: boolean; missing: ProviderId[] } {
  try {
    const missing: ProviderId[] = [];
    const p = aiSettings?.providers ?? aiSettings?.api?.providers ?? null;
    if (p?.openai?.enabled && !p?.openai?.apiKey) missing.push('openai');
    if (p?.anthropic?.enabled && !p?.anthropic?.apiKey) missing.push('anthropic');
    if (p?.google?.enabled && !p?.google?.apiKey) missing.push('google');
    // ollama is typically local; do not require apiKey; endpoint optional depending on app
    // if your app requires endpoint, uncomment the next two lines
    // if (p?.ollama?.enabled && !p?.ollama?.endpoint) missing.push('ollama');
    return { ok: missing.length === 0, missing };
  } catch {
    return { ok: true, missing: [] };
  }
}

// Prefer app network status if available; fallback to navigator.onLine
export function isOnline(): boolean {
  try { return navigator.onLine !== false; } catch { return true; }
}

// Pick effective model id without mutating state (follow existing defaults if present)
export function pickEffectiveModel(selectedModel: string | undefined, aiSettings: any): string | null {
  try {
    return selectedModel || aiSettings?.defaults?.model || aiSettings?.modelId || null;
  } catch {
    return selectedModel || null;
  }
}

export function rafThrottle<T extends (...args: unknown[]) => void>(fn: T) {
  let ticking = false;
  let lastArgs: Parameters<T> | null = null;
  return (...args: Parameters<T>) => {
    lastArgs = args;
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      ticking = false;
      const a = lastArgs; lastArgs = null;
      if (a) fn(...a);
    });
  };
}

// ================== Dev-only Telemetry (console) ==================
export const TELEMETRY_KEY = 'synapse.ai.telemetry'; // '0'|'1'|'verbose'

export type TelemetryPhase =
  | 'chat_start'
  | 'chat_stream'
  | 'chat_complete'
  | 'chat_error'
  | 'summary_run'
  | 'summary_error'
  | 'fallback_used'
  | 'selection_action'     // improve/explain/commentize
  | 'preview_render';      // sanitized HTML preview

export interface TelemetryEvent {
  phase: TelemetryPhase;
  ts: number;                  // ms epoch
  modelId?: string | null;
  mode?: 'beginner' | 'pro';
  action?: string;             // e.g., 'chat', 'preset:react-ts-todo', 'improve', 'explain'
  elapsedMs?: number;          // duration for the phase
  streamedChars?: number;
  estTokens?: number;
  tokensPerSec?: number;
  retryCount?: number;
  fallbackModelId?: string | null;
  summarization?: { triggered: boolean; elapsedMs?: number };
  preview?: { auto: boolean; removed?: { scripts?: number; links?: number; iframes?: number; urls?: number; imports?: number } };
  ok?: boolean;
  note?: string;               // short note; never include user code or prompts
}

const _telemetryBuf: TelemetryEvent[] = [];
const _maxBuf = 200;

export function isTelemetryOn(): boolean {
  try { return localStorage.getItem(TELEMETRY_KEY) === '1' || localStorage.getItem(TELEMETRY_KEY) === 'verbose'; }
  catch { return false; }
}

export function telemetryVerbose(): boolean {
  try { return localStorage.getItem(TELEMETRY_KEY) === 'verbose'; }
  catch { return false; }
}

export function recordTelemetry(e: TelemetryEvent) {
  if (!isTelemetryOn()) return;
  _telemetryBuf.push(e);
  if (_telemetryBuf.length > _maxBuf) _telemetryBuf.shift();
  // Console only; compact line for quick scanning:
  const { phase, elapsedMs, modelId, mode, action, streamedChars, estTokens, tokensPerSec, retryCount, fallbackModelId, ok } = e;
  // eslint-disable-next-line no-console
  console.log(`[AI-TEL] ${phase} | model=${modelId ?? 'default'} | mode=${mode ?? '-'} | action=${action ?? '-'} | t=${elapsedMs ?? 0}ms | chars=${streamedChars ?? 0} | tok≈${estTokens ?? 0} | tok/s≈${tokensPerSec ?? 0} | retry=${retryCount ?? 0} | fallback=${fallbackModelId ?? '-'} | ok=${ok ?? true}`);
  // eslint-disable-next-line no-console
  if (telemetryVerbose()) console.debug('[AI-TEL:detail]', e);
}

export function flushTelemetryBuffer(): TelemetryEvent[] {
  return _telemetryBuf.slice();
}

// Small timers
export function tStart(): number { return nowMs(); }
export function tEnd(t0: number): number { return Math.max(0, nowMs() - t0); }

// Optional: quick diff stats for sanitizer (raw vs sanitized)
export function computeSanitizeDiff(raw: string, sanitized: string) {
  const c = (s: string, re: RegExp) => (s.match(re) || []).length;
  return {
    scripts: Math.max(0, c(raw, /<script\b/gi) - c(sanitized, /<script\b/gi)),
    links:   Math.max(0, c(raw, /<link\b/gi) - c(sanitized, /<link\b/gi)),
    iframes: Math.max(0, c(raw, /<iframe\b/gi) - c(sanitized, /<iframe\b/gi)),
    imports: (raw.match(/@import/gi) || []).length,
    urls:    (raw.match(/url\(/gi) || []).length - (sanitized.match(/url\(/gi) || []).length
  };
}

// ================== Project Brief (RAG-lite, zero deps) ==================
export const BRIEF_MAX_TOKENS = 1800;     // target ~1.8k tokens
export const BRIEF_FILES_LIMIT = 12;      // cap scanned files
export const BRIEF_RECENT_EDIT_LIMIT = 10;

const BRIEF_PREF = [
  'README.md','readme.md','README','package.json','tsconfig.json','vite.config.ts','next.config.js',
  'pnpm-lock.yaml','yarn.lock'
];

export function trimToTokens(s: string, maxTok: number) {
  if (!s) return '';
  const maxChars = maxTok * 4;
  return s.length > maxChars ? `${s.slice(0, maxChars)}\n…(truncated)` : s;
}

export async function buildProjectBrief(opts: {
  getFileText: (path: string) => Promise<string | null>;
  listFiles: () => Promise<string[]>;
  getRecentEdited?: () => string[]; // optional
  getActiveFile?: () => { path: string, content: string } | null;
}): Promise<string> {
  const files = await opts.listFiles();
  if (!Array.isArray(files) || !files.length) return 'Project brief: (empty workspace)';

  // Rank files
  const preferred = files.filter(f => BRIEF_PREF.includes(f));
  const recent = (opts.getRecentEdited?.() || []).filter(p => files.includes(p)).slice(0, BRIEF_RECENT_EDIT_LIMIT);
  const active = opts.getActiveFile?.()?.path;

  const picked = new Set<string>();
  const push = (p: string | null | undefined) => { if (p && files.includes(p)) picked.add(p); };

  preferred.forEach(push);
  push(active);
  recent.forEach(push);

  // Fill up with top-level src files
  for (const f of files) {
    if (picked.size >= BRIEF_FILES_LIMIT) break;
    if (/^src\//.test(f) && /\.(md|tsx?|jsx?|css|html|json)$/.test(f)) picked.add(f);
  }

  const sections: string[] = [];
  for (const p of picked) {
    const text = await opts.getFileText(p);
    if (text) {
      sections.push(`### ${p}\n${trimToTokens(text, Math.floor(BRIEF_MAX_TOKENS / Math.max(1, picked.size)))}`);
    }
  }

  const activeFile = opts.getActiveFile?.();
  if (activeFile?.content) {
    sections.unshift(`### ACTIVE FILE: ${activeFile.path}\n${trimToTokens(activeFile.content, Math.floor(BRIEF_MAX_TOKENS * 0.25))}`);
  }

  const header = [
    'Project Brief (Repo-aware, condensed):',
    '- Summarizes key configuration, docs and active/recent files.',
    '- Use as high-priority context; do not contradict this brief.'
  ].join('\n');

  return [header, ...sections].join('\n\n');
}

export async function refreshProjectBrief(ctx: {
  getFileText: (p: string) => Promise<string | null>;
  listFiles: () => Promise<string[]>;
  getRecentEdited?: () => string[];
  getActiveFile?: () => { path: string, content: string } | null;
}) {
  const brief = await buildProjectBrief(ctx);
  const pinned = loadPinnedContext();
  // Replace existing “Project Brief:” block if present
  const rest = pinned.filter(x => !/^Project Brief/.test(x));
  savePinnedContext([brief, ...rest]);
  return brief;
}

// ================== Prompt 12 — File Ops Plan (schema, validate, cache) ==================
export interface FileOp {
  op: 'create' | 'modify' | 'rename' | 'delete';
  path: string;
  language?: string;
  content?: string;
  from?: string;
  strategy?: 'replace_selection' | 'replace_file' | 'append' | 'prepend';
}
export interface FilePlan { version: number; operations: FileOp[]; }

export function secureNormalizePath(p: string) {
  const raw = String(p || '');
  // Reject absolute paths (/, \\) and Windows drive-letter paths (C:\, D:/)
  if (/^[\\/]/.test(raw) || /^[A-Za-z]:/.test(raw)) {
    throw new Error('Invalid path');
  }
  const norm = raw.replace(/\\/g, '/').replace(/^\/+/, '');
  if (norm.includes('..')) throw new Error('Invalid path');
  return norm;
}
type RawFileOp = {
  op: string;
  path?: string;
  content?: string;
  from?: string;
  language?: string;
  strategy?: FileOp['strategy'];
};

export function validatePlan(plan: unknown): FilePlan {
  if (!plan || typeof plan !== 'object') throw new Error('Invalid plan');
  const p = plan as { version?: unknown; operations?: unknown };
  if (p.version !== 1) throw new Error('Unsupported version');
  if (!Array.isArray(p.operations)) throw new Error('Invalid operations');
  if (p.operations.length > 30) throw new Error('Too many ops');
  const ops: FileOp[] = (p.operations as unknown[]).map((o: unknown, i: number) => {
    if (!o || typeof o !== 'object') throw new Error(`Op ${i} invalid`);
    const ro = o as Partial<RawFileOp>;
    const op = String(ro.op || '');
    const base: FileOp = { op: op as FileOp['op'], path: secureNormalizePath(String(ro.path || '')) } as FileOp;
    if (base.op !== 'create' && base.op !== 'modify' && base.op !== 'rename' && base.op !== 'delete') {
      throw new Error(`Op ${i} type`);
    }
    if ((base.op === 'create' || base.op === 'modify') && typeof ro.content !== 'string') {
      throw new Error(`Op ${i} content required`);
    }
    if (base.op === 'rename') {
      base.from = secureNormalizePath(String(ro.from || ''));
      if (!base.from) throw new Error(`Op ${i} from`);
    }
    if (ro.language) base.language = String(ro.language);
    if (ro.strategy) base.strategy = ro.strategy;
    if (ro.content && ro.content.length > 200_000) throw new Error(`Op ${i} content too large`);
    if (base.op === 'create' || base.op === 'modify') {
      base.content = ro.content ?? '';
    }
    return base;
  });
  return { version: 1, operations: ops };
}

let _lastPlan: FilePlan | null = null;
export function setLastPlan(p: FilePlan | null) { _lastPlan = p; }
export function getLastPlan() { return _lastPlan; }

// ================== Prompt 12 — Dry-Run & Apply helpers ==================
import { useFileExplorerStore } from '@/stores/fileExplorerStore';
import { openNewTab } from '@/services/editorBridge';
import type { FileNode } from '@/types/state';

function getParentOf(path: string) {
  const i = path.lastIndexOf('/');
  return i >= 0 ? (i === 0 ? '/' : path.slice(0, i)) : '/';
}
function getNameOf(path: string) {
  const i = path.lastIndexOf('/');
  return i >= 0 ? path.slice(i + 1) : path;
}

export async function dryRunPlan(plan: FilePlan) {
  const diffs: string[] = [];
  const fe = useFileExplorerStore.getState();
  for (const op of plan.operations) {
    if (op.op === 'create') {
      const exists = !!fe.getFileByPath(op.path);
      diffs.push(`CREATE ${op.path} (${exists ? 'overwrites?' : 'new'})`);
    } else if (op.op === 'modify') {
      const cur = (fe.getFileByPath(op.path)?.content as string) || '';
      const next = op.strategy === 'append' ? cur + (op.content || '')
        : op.strategy === 'prepend' ? (op.content || '') + cur
        : op.strategy === 'replace_selection' ? `(selection replace preview)`
        : (op.content || '');
      diffs.push(`MODIFY ${op.path}\n--- CURRENT ---\n${trimToTokens(cur, 400)}\n--- PROPOSED ---\n${trimToTokens(next, 400)}`);
    } else if (op.op === 'rename') {
      diffs.push(`RENAME ${op.from} → ${op.path}`);
    } else if (op.op === 'delete') {
      diffs.push(`DELETE ${op.path}`);
    }
  }
  await openNewTab({ filename: `[AI] File Plan Dry-Run.md`, code: `# Dry-Run\n\n${diffs.map(d => `- - -\n${d}`).join('\n\n')}`, language: 'markdown' });
}

export async function applyPlan(plan: FilePlan) {
  const fe = useFileExplorerStore.getState();
  for (const op of plan.operations) {
    if (op.op === 'create') {
      const parent = getParentOf(op.path);
      const name = getNameOf(op.path);
      const existing = fe.getFileByPath(op.path);
      const fileNode: FileNode = existing || {
        id: `file-${Date.now()}-${Math.random().toString(36).slice(2)}`,
        name,
        type: 'file',
        path: op.path,
        content: '',
        language: op.language,
        lastModified: new Date(),
        size: (op.content || '').length,
      };
      if (!existing) fe.addFile(fileNode, parent || '/');
      fe.updateFile(fileNode.id, { content: op.content || '' });
    } else if (op.op === 'modify') {
      const node = fe.getFileByPath(op.path);
      const cur = (node?.content as string) || '';
      let next = op.content || '';
      if (op.strategy === 'append') next = cur + (op.content || '');
      else if (op.strategy === 'prepend') next = (op.content || '') + cur;
      fe.updateFile(node?.id || '', { content: next });
    } else if (op.op === 'rename') {
      const node = fe.getFileByPath(op.from!);
      if (node) {
        const newParent = getParentOf(op.path);
        const newName = getNameOf(op.path);
        const oldParent = getParentOf(node.path);
        if (newParent !== oldParent) {
          fe.moveFile(node.id, newParent || '/');
        }
        if (newName !== node.name) {
          fe.renameFile(node.id, newName);
        }
      }
    } else if (op.op === 'delete') {
      const node = fe.getFileByPath(op.path);
      if (node) fe.deleteFile(node.id);
    }
  }
  notify('success', 'File plan applied.');
}

// ================== Prompt 13 — Redaction Guard ==================
export const REDACTION_TAG = '⟦REDACTED⟧';
const REDACT_PATTERNS: RegExp[] = [
  /(?<=^|\s)(?:AWS|GCP|AZURE)?_?(?:SECRET|ACCESS|API)?_?KEY\s*=\s*['"]?([A-Za-z0-9_+/=-]{16,})['"]?/gim,
  /(?:sk|rk|pk)_[A-Za-z0-9]{16,}/g,
  /Bearer\s+[-A-Za-z0-9._~+/]{16,}/gi,
  /(?:^|\s)[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g,
  /^\s*[A-Za-z0-9_]+\s*=\s*.+$/gm,
  // URL query tokens (access_token, id_token, token, key, session_token, refresh_token)
  /([?&](?:access_token|id_token|token|api_key|key|session_token|refresh_token)=)[^&#\s]{8,}/gi,
];
export function redactOutbound(text: string) {
  if (!text) return text;
  let out = text;
  for (const re of REDACT_PATTERNS) {
    out = out.replace(re, m => {
      if (/^\s*[A-Za-z0-9_]+\s*=/.test(m)) {
        return m.replace(/=\s*.*/, `=${REDACTION_TAG}`);
      }
      return REDACTION_TAG;
    });
  }
  // Preserve query key while redacting value for URL tokens
  out = out.replace(/([?&](?:access_token|id_token|token|api_key|key|session_token|refresh_token)=)[^&#\s]{8,}/gi, (_full, p1) => `${p1}${REDACTION_TAG}`);
  return out;
}

// ================== Prompt 14 — Mock Provider + Golden Tasks ==================
export const MOCK_MODEL_ID = 'mock:stream';
export const mockProvider = {
  id: 'mock',
  stream: async ({ messages, onStart, onDelta, onComplete, onError, signal }: {
    messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>;
    onStart?: () => void;
    onDelta?: (chunk: string) => void;
    onComplete?: (output: string) => void;
    onError?: (e: unknown) => void;
    signal?: AbortSignal;
  }) => {
    try {
      onStart?.();
      const seed = JSON.stringify(messages || '').length % 97;
      const lorem = 'const answer = 42; // lorem ipsum dolor sit amet\n';
      let out = '';
      for (let i = 0; i < 40; i++) {
        if (signal?.aborted) throw new Error('aborted');
        const chunk = lorem.slice(0, (i % lorem.length) + 1);
        out += chunk;
  onDelta?.(chunk);
  await new Promise(r => setTimeout(r, 12 + ((i + seed) % 7)));
      }
      onComplete?.(out);
      return out;
    } catch (e) { onError?.(e); throw e; }
  },
  complete: async ({ messages }: { messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> }) => {
    const body = `Mock completion.\n\n\`\`\`\n${messages?.[messages.length - 1]?.content || ''}\n\`\`\``;
    return body;
  }
};

export const GOLDEN_TASKS: Array<{ id: string; mode: 'beginner' | 'pro'; prompt: string }> = [
  { id: 'calc', mode: 'beginner', prompt: 'preset:calculator\nwell design html calculator with monthly payment' },
  { id: 'react_todo', mode: 'pro', prompt: 'preset:react-ts-todo\nbasic todo app with filters' },
  { id: 'explain', mode: 'pro', prompt: 'Explain the time complexity of this code:\n```ts\nfunction f(n:number){let s=0;for(let i=0;i<n;i++)s+=i;return s;}\n```' }
];

type GoldenOk = { id: string; ok: true; ms: number; chars: number };
type GoldenFail = { id: string; ok: false; ms: number; err: string };
type GoldenResult = GoldenOk | GoldenFail;
type ProviderApi = { complete(args: { messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>; model: string }): Promise<string> };

export async function runGoldenTasks(providerApi: ProviderApi, modelId: string) {
  const results: GoldenResult[] = [];
  for (const t of GOLDEN_TASKS) {
    const t0 = performance.now();
    let text = '';
    try {
      text = await providerApi.complete({ messages: [
        { role: 'system', content: buildSystemPrompt({ mode: t.mode, preset: null, pinnedContext: [] }) },
        { role: 'user', content: t.prompt }
      ], model: modelId });
      results.push({ id: t.id, ok: true, ms: Math.round(performance.now() - t0), chars: text.length });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      results.push({ id: t.id, ok: false, ms: Math.round(performance.now() - t0), err: msg });
    }
  }
  // eslint-disable-next-line no-console
  console.table(results);
  return results;
}

// ================== Prompt 15 — Determinism & Cost Controls ==================
export interface ModelCaps {
  id: string;
  provider: string;
  maxTokens: number;
  supportsSeed?: boolean;
  supportsJson?: boolean;
  priceInputPer1k?: number;
  priceOutputPer1k?: number;
}
export const MODEL_CAPS: ModelCaps[] = [
  { id: 'gpt-4.1-mini', provider: 'openai', maxTokens: 128000, supportsSeed: true, priceInputPer1k: 0.15, priceOutputPer1k: 0.60 },
  { id: 'claude-3.7-sonnet', provider: 'anthropic', maxTokens: 200000, supportsSeed: true, priceInputPer1k: 0.80, priceOutputPer1k: 4.00 },
  { id: 'gemini-2.0-flash', provider: 'google', maxTokens: 1000000, supportsSeed: true, priceInputPer1k: 0.075, priceOutputPer1k: 0.30 },
  { id: MOCK_MODEL_ID, provider: 'mock', maxTokens: 16000, supportsSeed: true, priceInputPer1k: 0, priceOutputPer1k: 0 },
];

// Extend existing AiSettings via declaration merging
declare module './AiAssistantConfig' {
  interface AiSettings {
    temperature?: number;
    topP?: number;
    seed?: number | null;
  }
}
// Provide defaults by merging at load time; keep base DEFAULT_AI_SETTINGS single source above.
