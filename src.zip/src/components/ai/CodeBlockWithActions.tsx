import React, { useCallback, useId, useMemo, useRef, useState } from 'react';
import { SYNAPSE_ACCENT, SYNAPSE_ANIM, SYNAPSE_COLORS, SYNAPSE_ELEVATION } from '@/ui/theme/synapseTheme';
import { Copy, FilePlus, PlusSquare, Replace, Rocket } from 'lucide-react';
import {
  inferLanguageFromFence,
  insertIntoActive,
  openNewTab,
  replaceSelection,
} from '@/services/editorBridge';
import { runPreview } from '@/services/previewBridge';
import { BEGINNER_ASSISTANT_ENABLED } from '@/features/beginnerAssistant';
import './codeBlock.css';

interface CodeBlockWithActionsProps {
  code: string;
  languageHint?: string;
  isPrimary?: boolean; // first code fence in message gets full toolbar
}

const langExt: Record<string, string> = {
  javascript: 'js',
  typescript: 'ts',
  html: 'html',
  css: 'css',
  python: 'py',
  json: 'json',
  markdown: 'md',
};

export const CodeBlockWithActions: React.FC<CodeBlockWithActionsProps> = ({
  code,
  languageHint,
  isPrimary,
}) => {
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const [liveMsg, setLiveMsg] = useState('');
  const uid = useId();
  const toolbarId = useMemo(() => `cbwa-toolbar-${uid}`,[uid]);
  const codeRegionId = useMemo(() => `cbwa-code-${uid}`,[uid]);
  const btnRefs = useRef<HTMLButtonElement[]>([]);
  const lang = inferLanguageFromFence(languageHint, code);
  const ext = langExt[lang] || 'txt';

  const focusBtn = useCallback((i: number) => { btnRefs.current[i]?.focus(); }, []);
  const onToolbarKeyDown = useCallback((e: React.KeyboardEvent) => {
    const i = btnRefs.current.findIndex((el) => el === document.activeElement);
    if (e.key === 'ArrowRight') { e.preventDefault(); focusBtn(Math.min(btnRefs.current.length - 1, Math.max(0, i) + 1)); }
    if (e.key === 'ArrowLeft')  { e.preventDefault(); focusBtn(Math.max(0, (i < 0 ? 0 : i) - 1)); }
    if (e.key === 'Home')       { e.preventDefault(); focusBtn(0); }
    if (e.key === 'End')        { e.preventDefault(); focusBtn(btnRefs.current.length - 1); }
    if (e.key === 'Escape')     { e.preventDefault(); document.getElementById(codeRegionId)?.focus?.(); }
  }, [codeRegionId, focusBtn]);

  const tipIds = useMemo(() => ({
    copy: `${toolbarId}-tip-copy`,
    new: `${toolbarId}-tip-new`,
    insert: `${toolbarId}-tip-insert`,
    replace: `${toolbarId}-tip-replace`,
    preview: `${toolbarId}-tip-preview`,
  }), [toolbarId]);

  const handle = useCallback(async (action: 'copy' | 'insert' | 'new' | 'replace' | 'preview') => {
    if (action === 'copy') {
      try {
        await navigator.clipboard.writeText(code);
        setCopied(true);
        setLiveMsg('Copied to clipboard');
        setTimeout(() => { setCopied(false); setLiveMsg(''); }, 1000);
      } catch {}
      return;
    }
    setBusy(true);
    try {
      if (action === 'insert') {
        const { tabId } = await insertIntoActive({ code, language: lang });
        await runPreview(tabId);
      } else if (action === 'replace') {
        const { tabId } = await replaceSelection({ code, language: lang });
        await runPreview(tabId);
      } else if (action === 'new') {
        const filename = `snippet-${Date.now()}.${ext}`;
        await openNewTab({ filename, code, language: lang });
      } else if (action === 'preview') {
        const filename = `snippet-${Date.now()}.${ext}`;
        const { tabId } = await openNewTab({ filename, code, language: lang });
        await runPreview(tabId);
      }
    } catch (e) {
      console.warn('Code block action failed', e);
    } finally {
      setBusy(false);
    }
  }, [code, ext, lang]);

  const setCopyRef = useCallback((el: HTMLButtonElement | null) => { btnRefs.current[0] = el!; }, []);
  const setNewRef = useCallback((el: HTMLButtonElement | null) => { btnRefs.current[1] = el!; }, []);
  const setInsertRef = useCallback((el: HTMLButtonElement | null) => { btnRefs.current[2] = el!; }, []);
  const setReplaceRef = useCallback((el: HTMLButtonElement | null) => { btnRefs.current[3] = el!; }, []);
  const setPreviewRef = useCallback((el: HTMLButtonElement | null) => { btnRefs.current[4] = el!; }, []);

  const onCopyClick = useCallback(() => { void handle('copy'); }, [handle]);
  const onNewClick = useCallback(() => { void handle('new'); }, [handle]);
  // Secret-scrub heuristic
  const SECRET_REGEX = /(sk-[a-z0-9]{20,}|AIza[0-9A-Za-z_\-]{10,}|ghp_[0-9A-Za-z]{30,})/i;
  const containsSecrets = useCallback((s: string) => SECRET_REGEX.test(s), []);
  const onInsertClick = useCallback(() => {
    if (containsSecrets(code) && !window.confirm('This block looks like it may contain secrets (API keys). Insert anyway?')) return;
    void handle('insert');
    setTimeout(() => document.getElementById(codeRegionId)?.focus?.(), 0);
  }, [code, codeRegionId, containsSecrets, handle]);
  const onReplaceClick = useCallback(() => {
    if (containsSecrets(code) && !window.confirm('This block looks like it may contain secrets (API keys). Replace anyway?')) return;
    void handle('replace');
    setTimeout(() => document.getElementById(codeRegionId)?.focus?.(), 0);
  }, [code, codeRegionId, containsSecrets, handle]);
  const onPreviewClick = useCallback(() => { void handle('preview'); }, [handle]);

  if (!BEGINNER_ASSISTANT_ENABLED) {
    return (
      <pre style={basePreStyle}>
        <code>{code}</code>
      </pre>
    );
  }

  const primary = !!isPrimary;

  return (
    <div className="cbwa-wrap" style={wrapperStyle as any} data-primary={primary}>
      {/* Local golden-black micro-styles for a11y tooltips and focus rings */}
      <style>{cbwaCss}</style>
      <div className="cbwa-head" style={headerStyle as any}>
        <span style={langBadgeStyle}>{languageHint || lang}</span>
        <div
          id={toolbarId}
          role="toolbar"
          aria-label="Code actions"
          aria-controls={codeRegionId}
          className="cbwa-toolbar"
          style={toolbarStyle}
          onKeyDown={onToolbarKeyDown}
        >
          <ToolbarButton
            setRef={setCopyRef}
            ariaLabel="Copy code"
            title="Copy code"
            onClick={onCopyClick}
            ariaDescribedBy={tipIds.copy}
            active={copied}
          >
            <Copy size={14} aria-hidden="true" focusable="false" />
          </ToolbarButton>
          <ToolbarButton
            setRef={setNewRef}
            ariaLabel="Open in new tab"
            title="Open in new tab"
            onClick={onNewClick}
            ariaDescribedBy={tipIds.new}
            disabled={busy}
          >
            <FilePlus size={14} aria-hidden="true" focusable="false" />
          </ToolbarButton>
          {primary ? <>
              <ToolbarButton
                setRef={setInsertRef}
                ariaLabel="Insert at cursor"
                title="Insert into active tab"
                onClick={onInsertClick}
                ariaDescribedBy={tipIds.insert}
                disabled={busy}
              >
                <PlusSquare size={14} aria-hidden="true" focusable="false" />
              </ToolbarButton>
              <ToolbarButton
                setRef={setReplaceRef}
                ariaLabel="Replace editor content"
                title="Replace editor content"
                onClick={onReplaceClick}
                ariaDescribedBy={tipIds.replace}
                disabled={busy}
              >
                <Replace size={14} aria-hidden="true" focusable="false" />
              </ToolbarButton>
              <ToolbarButton
                setRef={setPreviewRef}
                ariaLabel="Preview"
                title="Preview (HTML/CSS/JS)"
                onClick={onPreviewClick}
                ariaDescribedBy={tipIds.preview}
                disabled={busy}
              >
                <Rocket size={14} aria-hidden="true" focusable="false" />
              </ToolbarButton>
            </> : null}
        </div>
        <div aria-live="polite" aria-atomic="true" className="cbwa-sr-only">{liveMsg}</div>
      </div>
  <pre id={codeRegionId} tabIndex={-1} className="cbwa-pre" style={basePreStyle}>
        <code>{code}</code>
      </pre>
    </div>
  );
};

interface TBProps {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
  ariaLabel: string;
  disabled?: boolean;
  active?: boolean;
  setRef?: (el: HTMLButtonElement | null) => void;
  ariaDescribedBy?: string;
}
const ToolbarButton: React.FC<TBProps> = ({
  children,
  onClick,
  title,
  ariaLabel,
  disabled,
  active,
  setRef,
  ariaDescribedBy,
}) => (
  <button
    ref={setRef}
    type="button"
    onClick={onClick}
    title={title}
    aria-label={ariaLabel}
    aria-pressed={false}
    disabled={disabled}
    tabIndex={0}
  className="cbwa-btn"
    style={{
      background: active ? 'rgba(16,185,129,0.15)' : 'rgba(0,0,0,0.4)',
      border: '1px solid rgba(194,167,110,0.35)',
      color: active ? '#10b981' : '#C2A76E',
      borderRadius: 6,
      padding: '4px 6px',
      width: 32,
      height: 32,
      display: 'flex',
      alignItems: 'center',
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontSize: 11,
      lineHeight: 1,
      opacity: disabled ? 0.5 : 0.85,
      transition: 'all 120ms ease',
      position: 'relative',
    }}
    aria-describedby={ariaDescribedBy}
    onKeyDown={handleBtnKeyDown}
    onMouseEnter={handleMouseEnter}
    onMouseLeave={handleMouseLeave}
  >
    {children}
    <span id={ariaDescribedBy} role="tooltip" className="cbwa-tooltip">{title}</span>
  </button>
);

function handleBtnKeyDown(this: HTMLButtonElement, e: React.KeyboardEvent<HTMLButtonElement>) {
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    // onClick is attached to the same element; let the click happen via calling click()
    (e.currentTarget as HTMLButtonElement).click();
  }
}

function handleMouseEnter(e: React.MouseEvent<HTMLButtonElement>) {
  const el = e.currentTarget as HTMLButtonElement;
  if (el.disabled) return;
  el.style.opacity = '1';
  el.style.background = 'rgba(0,0,0,0.65)';
}

function handleMouseLeave(e: React.MouseEvent<HTMLButtonElement>) {
  const el = e.currentTarget as HTMLButtonElement;
  if (el.disabled) return;
  // Heuristic: if it has success color, keep opaque; else revert
  const activeColor = getComputedStyle(el).color;
  const isSuccess = activeColor.includes('10b981');
  el.style.opacity = isSuccess ? '1' : '0.85';
  el.style.background = isSuccess ? 'rgba(16,185,129,0.15)' : 'rgba(0,0,0,0.4)';
}

// Styles
const wrapperStyle: React.CSSProperties = {
  position: 'relative',
  background: SYNAPSE_ELEVATION.surface,
  border: `1px solid ${SYNAPSE_ELEVATION.border}`,
  borderRadius: 12,
  margin: '12px 0',
  overflow: 'hidden',
  boxShadow: SYNAPSE_ELEVATION.shadowSm,
};
const headerStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 8,
  padding: '6px 10px 4px 10px',
  background: 'linear-gradient(90deg, rgba(203,161,53,0.08), rgba(203,161,53,0))',
  borderBottom: `1px solid ${SYNAPSE_ELEVATION.border}`,
};
const toolbarStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 6,
  flexWrap: 'wrap',
};
const langBadgeStyle: React.CSSProperties = {
  fontSize: 11,
  textTransform: 'uppercase',
  letterSpacing: 0.5,
  background: 'rgba(203,161,53,0.18)',
  color: SYNAPSE_ACCENT.gold,
  padding: '2px 6px',
  borderRadius: 6,
  fontFamily: 'JetBrains Mono, monospace',
};
const basePreStyle: React.CSSProperties = {
  margin: 0,
  padding: '12px 14px',
  fontSize: 12,
  lineHeight: 1.5,
  overflowX: 'auto',
  fontFamily: 'JetBrains Mono, Fira Code, SFMono-Regular, Menlo, monospace',
  color: SYNAPSE_COLORS.textPrimary,
};

export default CodeBlockWithActions;

// Local golden-black micro-styles for toolbar and tooltip
const cbwaCss = `
.cbwa-toolbar { display:flex; gap:6px; align-items:center; position:relative; }
.cbwa-btn { outline: none; border: 1px solid ${SYNAPSE_ELEVATION.border}; background: ${SYNAPSE_ELEVATION.surface}; color: ${SYNAPSE_ACCENT.gold}; transition: all ${SYNAPSE_ANIM.fast}; }
.cbwa-btn:hover { background: ${SYNAPSE_ELEVATION.surfaceHover}; color: ${SYNAPSE_ACCENT.gold}; box-shadow: ${SYNAPSE_ELEVATION.shadowSm}; }
.cbwa-btn:active { transform: translateY(0.5px); background: ${SYNAPSE_ELEVATION.surfaceActive}; }
.cbwa-btn:focus-visible { border-color: ${SYNAPSE_ACCENT.gold}; box-shadow: 0 0 0 2px rgba(203,161,53,0.25); }
.cbwa-tooltip { position:absolute; left:50%; top:-8px; transform: translate(-50%, -100%); z-index:1000; padding:4px 8px; font-size:12px; border-radius:6px; background: rgba(0,0,0,0.85); color: ${SYNAPSE_COLORS.textPrimary}; opacity:0; pointer-events:none; transition: opacity ${SYNAPSE_ANIM.fast}; white-space:nowrap; }
.cbwa-btn:hover .cbwa-tooltip, .cbwa-btn:focus-visible .cbwa-tooltip { opacity: 1; }
.cbwa-sr-only { position:absolute !important; width:1px; height:1px; padding:0; margin:-1px; overflow:hidden; clip: rect(0 0 0 0); white-space:nowrap; border:0; }
@media (prefers-reduced-motion: reduce) { .cbwa-btn, .cbwa-tooltip { transition: none; } }
`;
