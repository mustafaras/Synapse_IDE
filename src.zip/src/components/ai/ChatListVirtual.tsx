import React, { useMemo, useRef } from 'react';
import { useChatVirtual } from '@/hooks/useChatVirtual';
import { useResizeObserver } from '@/hooks/useResizeObserver';
import { MessageItem } from './MessageItem';

type Msg = { id: string; role: 'user'|'assistant'|'system'; content: string; ts: number };

export function ChatListVirtual({ messages, stickDistance = 24 }: { messages: Msg[]; stickDistance?: number }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const { range, layout, setItemHeight, getItemStyle, isAtBottom, scrollToBottom } = useChatVirtual({
    count: messages.length,
    estimateItemHeight: 92,
    overscan: 6,
    scrollEl: scrollRef as any,
  });

  React.useEffect(() => {
    if (isAtBottom(stickDistance)) scrollToBottom();
  }, [messages.length, layout.totalHeight]);

  const items = useMemo(() => {
    const out: React.ReactElement[] = [];
    for (let i = range.start; i <= range.end; i++) {
      const msg = messages[i];
      const Row = () => {
        const ref = useResizeObserver((h) => setItemHeight(i, h));
        return (
          <div ref={ref as any} style={getItemStyle(i)}>
            <MessageItem index={i} msg={msg} />
          </div>
        );
      };
      out.push(<Row key={msg.id} />);
    }
    return out;
  }, [messages, range, setItemHeight, getItemStyle]);

  return (
    <div ref={scrollRef as any} style={{ position: 'relative', overflow: 'auto', height: '100%' }}>
      <div style={{ height: layout.totalHeight, position: 'relative' }}>
        {items}
      </div>
    </div>
  );
}

export default ChatListVirtual;