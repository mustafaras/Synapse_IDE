import React from 'react';
import { Bot, Check, Copy } from 'lucide-react';
import { createMessageStyles } from './AiAssistantStyles';
import { SYNAPSE_COLORS, SYNAPSE_ELEVATION, withAlpha } from '@/ui/theme/synapseTheme';

type MessageType = 'user' | 'ai' | 'system';

export type ChatMessageProps = {
  id: string;
  type: MessageType;
  timestamp: Date;
  roleLabel?: string | undefined; // e.g., "AI Assistant", "System"
  subLabel?: string | undefined;  // e.g., model name or language
  alignRight?: boolean | undefined;
  canCopy?: boolean | undefined;
  copied?: boolean | undefined;
  onCopy?: (() => void) | undefined;
  // Optional controls/meta
  meta?: React.ReactNode;
  footer?: React.ReactNode;
  grouped?: boolean;
  children: React.ReactNode;
  // passthrough data attributes for testing hooks
  [dataAttr: `data-${string}`]: any;
};

// Unified chat message bubble with header chips and optional copy for AI
const ChatMessageBase: React.FC<ChatMessageProps> = ({
  type,
  timestamp,
  roleLabel,
  subLabel,
  alignRight,
  canCopy,
  copied,
  onCopy,
  meta,
  footer,
  grouped,
  children,
}) => {
  const isUser = type === 'user';
  const cls = [
    'chat-message',
    type ? `message--${type}` : '',
    isUser ? 'message--user' : 'message--ai',
    grouped ? 'grouped' : '',
  ].filter(Boolean).join(' ');

  return (
    <div
      className={cls}
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: alignRight ? 'flex-end' : 'flex-start',
        marginBottom: 16,
      }}
    >
      {(type === 'ai' || type === 'system') && (
        <div
          className="chat-message__meta"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            marginBottom: 6,
            fontSize: 11,
            color: SYNAPSE_COLORS.blueGray,
            paddingLeft: type === 'system' ? 0 : 4,
          }}
        >
          {type === 'ai' && (
            <>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <Bot size={12} color={SYNAPSE_COLORS.goldPrimary} />
              </div>
              <span>AI Assistant</span>
              {subLabel ? <>
                  <span style={{ color: SYNAPSE_COLORS.textTertiary }}>•</span>
                  <span
                    style={{
                      color: SYNAPSE_COLORS.goldPrimary,
                      fontSize: 10,
                      background: withAlpha(SYNAPSE_COLORS.goldPrimary, 0.12),
                      padding: '1px 4px',
                      borderRadius: 4,
                    }}
                  >
                    {subLabel}
                  </span>
                </> : null}
            </>
          )}
          {type === 'system' && (
            <>
              <span style={{ color: SYNAPSE_COLORS.error }}>System</span>
            </>
          )}
          <span style={{ color: SYNAPSE_COLORS.textTertiary }}>•</span>
          <span>{timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
      )}

      <div
        className="chat-message__bubble"
        style={{ ...createMessageStyles(isUser, type), position: 'relative' }}
      >
        <div style={{ position: 'relative', zIndex: 1 }}>{children}</div>
        {footer}
        {canCopy ? <div className="msg-actions" style={{ position: 'absolute', top: 6, right: 6, display: 'flex', gap: 6 }}>
            <button
              className="chat-message__copy"
              style={{
                background: SYNAPSE_ELEVATION.surface,
                border: `1px solid ${withAlpha(SYNAPSE_COLORS.goldPrimary, 0.3)}`,
                borderRadius: 6,
                color: copied ? SYNAPSE_COLORS.success : SYNAPSE_COLORS.goldPrimary,
                cursor: 'pointer',
                padding: 4,
                transition: 'opacity 0.2s ease, transform 0.2s ease',
                zIndex: 2,
              }}
              onClick={onCopy}
              title={copied ? 'Copied!' : 'Copy message'}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'scale(1.06)';
                (e.currentTarget as HTMLButtonElement).style.background = SYNAPSE_ELEVATION.surfaceHover as any;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'scale(1)';
                (e.currentTarget as HTMLButtonElement).style.background = SYNAPSE_ELEVATION.surface as any;
              }}
              aria-label="Copy assistant message"
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
            </button>
          </div> : null}
      </div>

      {meta ? <div className="msg-meta" aria-hidden="true">{meta}</div> : null}

      {type === 'user' && (
        <div
          className="chat-message__meta--user"
          style={{
            marginTop: 6,
            fontSize: 10,
            color: SYNAPSE_COLORS.textTertiary,
            display: 'flex',
            alignItems: 'center',
            gap: 4,
          }}
        >
          {roleLabel ? <>
              <span>{roleLabel}</span>
              <span>•</span>
            </> : null}
          <span>{timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
      )}
    </div>
  );
};

const ChatMessage = React.memo(
  ChatMessageBase,
  (prev, next) => (
    prev.id === next.id &&
    prev.type === next.type &&
    prev.timestamp.getTime() === next.timestamp.getTime() &&
    prev.copied === next.copied &&
    prev.canCopy === next.canCopy &&
    // Cheap content change detection: children length if string
    (typeof prev.children === 'string' && typeof next.children === 'string'
      ? prev.children.length === next.children.length
      : prev.children === next.children)
  )
);

export default ChatMessage;
