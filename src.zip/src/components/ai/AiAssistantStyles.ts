import React from 'react';
import { SYNAPSE_ACCENT, SYNAPSE_ANIM, SYNAPSE_COLORS, SYNAPSE_ELEVATION, SYNAPSE_LAYOUT, SYNAPSE_TYPO, withAlpha } from '@/ui/theme/synapseTheme';

// Styles - Neural theme with dynamic colors (Theme-aware + Responsive)
export const createContainerStyles = (
  currentWidth: number,
  isMobile: boolean
): React.CSSProperties => ({
  width: `${currentWidth}px`,
  height: '100vh',
  marginTop: '0px',
  marginBottom: '0px',
  display: 'flex',
  flexDirection: 'column',
  background: `linear-gradient(0deg, ${SYNAPSE_ELEVATION.surface}, ${SYNAPSE_ELEVATION.surface}), ${SYNAPSE_COLORS.bgSecondary}`,
  border: `1px solid ${SYNAPSE_ELEVATION.border}`,
  borderRadius: '0px',
  overflow: 'hidden',
  position: 'relative',
  zIndex: 1000,
  boxShadow: isMobile ? SYNAPSE_ELEVATION.shadowMd : SYNAPSE_ELEVATION.shadowLg,
  backdropFilter: 'blur(8px)',
  color: SYNAPSE_COLORS.textPrimary,
  fontFamily: SYNAPSE_TYPO.fontFamily,
  transition: `background ${SYNAPSE_ANIM.base}, box-shadow ${SYNAPSE_ANIM.base}`,
});

export const createHeaderStyles = (isMobile: boolean): React.CSSProperties => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: isMobile ? `${SYNAPSE_LAYOUT.padMd} ${SYNAPSE_LAYOUT.padLg}` : `${SYNAPSE_LAYOUT.padLg} ${SYNAPSE_LAYOUT.padXl}`,
  minHeight: '108px', // Reduced by 10px
  borderBottom: `1px solid ${SYNAPSE_ELEVATION.border}`,
  background: `linear-gradient(0deg, ${SYNAPSE_ELEVATION.surfaceHover}, ${SYNAPSE_ELEVATION.surface}), ${SYNAPSE_COLORS.bgSecondary}`,
  position: 'sticky',
  top: 0,
  zIndex: 1002,
  backdropFilter: 'blur(8px)',
  boxShadow: SYNAPSE_ELEVATION.shadowSm,
  borderRadius: '0 0 0px 0px',
  fontFamily: SYNAPSE_TYPO.fontFamily,
  transition: `background ${SYNAPSE_ANIM.base}, box-shadow ${SYNAPSE_ANIM.base}, border-color ${SYNAPSE_ANIM.base}`,
});

export const titleStyles: React.CSSProperties = {
  margin: 0,
  fontSize: '18px', // preserve size
  fontWeight: 700,
  background: `linear-gradient(270deg, ${SYNAPSE_COLORS.goldPrimary}, ${SYNAPSE_COLORS.goldSecondary}, ${SYNAPSE_COLORS.goldPrimary}, ${SYNAPSE_COLORS.goldPrimary})`,
  backgroundSize: '400% 400%',
  WebkitBackgroundClip: 'text',
  WebkitTextFillColor: 'transparent',
  backgroundClip: 'text',
  display: 'flex',
  alignItems: 'center',
  gap: SYNAPSE_LAYOUT.gapMd,
  transition: `background ${SYNAPSE_ANIM.base}`,
  animation: 'gradientShift 4s ease infinite',
};

export const iconStyles: React.CSSProperties = {
  width: '36px',
  height: '36px',
  background: SYNAPSE_ACCENT.goldMuted,
  border: `1px solid ${SYNAPSE_COLORS.borderHighlight}`,
  borderRadius: SYNAPSE_LAYOUT.radiusMd,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: SYNAPSE_COLORS.textAccent,
  boxShadow: SYNAPSE_ELEVATION.shadowSm,
  backdropFilter: 'blur(8px)',
  transition: `background ${SYNAPSE_ANIM.base}, box-shadow ${SYNAPSE_ANIM.base}, transform ${SYNAPSE_ANIM.fast}`,
};

export const buttonStyles: React.CSSProperties = {
  width: '32px',
  height: '32px',
  border: `1px solid ${SYNAPSE_ELEVATION.border}`,
  backgroundColor: SYNAPSE_ELEVATION.surface,
  color: SYNAPSE_COLORS.textPrimary,
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: SYNAPSE_LAYOUT.radiusMd,
  transition: `background ${SYNAPSE_ANIM.base}, box-shadow ${SYNAPSE_ANIM.base}, transform ${SYNAPSE_ANIM.fast}`,
  backdropFilter: 'blur(8px)',
  boxShadow: SYNAPSE_ELEVATION.shadowSm,
  fontFamily: 'inherit',
};

export const messagesStyles: React.CSSProperties = {
  flex: 1,
  overflowY: 'auto',
  padding: SYNAPSE_LAYOUT.padLg,
  display: 'flex',
  flexDirection: 'column',
  gap: SYNAPSE_LAYOUT.gapSm,
  backgroundColor: SYNAPSE_ELEVATION.surface,
  backdropFilter: 'blur(6px)',
  fontFamily: 'inherit',
};

// Scoped elegant scrollbar for chat area
export const chatScrollbarCss = `
  .ai-chat-scrollbar { scrollbar-color: rgba(194,167,110,0.35) transparent; scrollbar-width: thin; }
  .ai-chat-scrollbar::-webkit-scrollbar { width: 10px; }
  .ai-chat-scrollbar::-webkit-scrollbar-track { background: transparent; }
  .ai-chat-scrollbar::-webkit-scrollbar-thumb {
    background: linear-gradient(180deg, rgba(194,167,110,0.45), rgba(165,139,95,0.35));
    border: 2px solid rgba(0,0,0,0.35);
    border-radius: 8px;
    box-shadow: inset 0 0 6px rgba(0,0,0,0.25);
  }
  .ai-chat-scrollbar::-webkit-scrollbar-thumb:hover {
    background: linear-gradient(180deg, rgba(194,167,110,0.65), rgba(165,139,95,0.55));
  }
`;

export const createMessageStyles = (
  isUser: boolean,
  messageType?: string
): React.CSSProperties => ({
  maxWidth: '85%',
  alignSelf: isUser ? 'flex-end' : 'flex-start',
  padding: `${SYNAPSE_LAYOUT.padSm} ${SYNAPSE_LAYOUT.padMd}`,
  marginBottom: '4px',
  borderRadius: isUser ? '20px 20px 6px 20px' : '20px 20px 20px 6px',
  background: isUser
    ? withAlpha(SYNAPSE_COLORS.goldPrimary, 0.9)
    : messageType === 'system'
      ? 'rgba(231, 76, 60, 0.6)'
      : SYNAPSE_ELEVATION.surface,
  color: isUser ? '#0E0E0E' : SYNAPSE_COLORS.textPrimary,
  fontSize: SYNAPSE_TYPO.fontSize.medium,
  lineHeight: '1.5',
  fontWeight: isUser ? '500' : '400',
  fontFamily: SYNAPSE_TYPO.fontFamily,
  border: isUser
    ? `1px solid ${SYNAPSE_ELEVATION.border}`
    : messageType === 'system'
      ? '1px solid rgba(231, 76, 60, 0.4)'
      : `1px solid ${SYNAPSE_ELEVATION.border}`,
  position: 'relative',
  boxShadow: SYNAPSE_ELEVATION.shadowSm,
  backdropFilter: 'blur(8px)',
  transition: `background ${SYNAPSE_ANIM.base}, box-shadow ${SYNAPSE_ANIM.base}, transform ${SYNAPSE_ANIM.fast}`,
  wordWrap: 'break-word',
  whiteSpace: 'pre-wrap',
  animation: 'messageSlideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
});

export const inputContainerStyles: React.CSSProperties = {
  padding: SYNAPSE_LAYOUT.padLg,
  borderTop: `1px solid ${SYNAPSE_ELEVATION.border}`,
  background: `linear-gradient(0deg, ${SYNAPSE_ELEVATION.surface}, ${SYNAPSE_ELEVATION.surface}), ${SYNAPSE_COLORS.bgDark}`,
  backdropFilter: 'blur(8px)',
  position: 'relative',
  overflow: 'hidden',
  fontFamily: 'inherit',
};

export const createInputStyles = (_input: string): React.CSSProperties => ({
  width: '100%',
  minHeight: '160px',
  maxHeight: '180px',
  padding: `${SYNAPSE_LAYOUT.padMd} 60px ${SYNAPSE_LAYOUT.padMd} ${SYNAPSE_LAYOUT.padLg}`,
  borderRadius: SYNAPSE_LAYOUT.radiusLg,
  border: `1px solid ${SYNAPSE_ELEVATION.border}`,
  background: SYNAPSE_ELEVATION.surface,
  color: SYNAPSE_COLORS.textPrimary,
  fontSize: SYNAPSE_TYPO.fontSize.medium,
  lineHeight: '1.5',
  resize: 'none',
  outline: 'none',
  fontFamily: SYNAPSE_TYPO.fontFamily,
  transition: `background ${SYNAPSE_ANIM.base}, box-shadow ${SYNAPSE_ANIM.base}, border-color ${SYNAPSE_ANIM.base}`,
  boxShadow: SYNAPSE_ELEVATION.shadowSm,
  backdropFilter: 'blur(6px)',
  overflow: 'hidden',
  wordWrap: 'break-word',
  whiteSpace: 'pre-wrap',
});

export const createResizeHandleStyles = (isResizing: boolean): React.CSSProperties => ({
  position: 'absolute',
  left: 0,
  top: 0,
  bottom: 0,
  width: '4px',
  cursor: 'col-resize',
  background: isResizing ? SYNAPSE_ACCENT.goldMuted : 'transparent',
  zIndex: 10,
});

// CSS Animations and Styles
export const globalStyles = `
  @keyframes gradientShift {
    0%, 100% {
      background-position: 0% 50%;
    }
    50% {
      background-position: 100% 50%;
    }
  }
  
  @keyframes dropdownSlide {
    0% {
      opacity: 0;
      transform: translateY(-8px) scale(0.95);
    }
    100% {
      opacity: 1;
      transform: translateY(0px) scale(1);
    }
  }
  
  @keyframes messageSlideIn {
    0% {
      opacity: 0;
      transform: translateY(12px) scale(0.95);
    }
    100% {
      opacity: 1;
      transform: translateY(0px) scale(1);
    }
  }
  
  @keyframes typingDot {
    0%, 80%, 100% {
      opacity: 0.3;
      transform: scale(0.8);
    }
    40% {
      opacity: 1;
      transform: scale(1.2);
    }
  }
  @keyframes aiPulse {
    0% { transform: scale(0.9); filter: brightness(1); }
    50% { transform: scale(1.25); filter: brightness(1.35); }
    100% { transform: scale(0.9); filter: brightness(1); }
  }
  
  @keyframes spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
  
  @keyframes pulse {
    0%, 100% {
      opacity: 0.3;
      transform: scale(1);
    }
    50% {
      opacity: 0.6;
      transform: scale(1.05);
    }
  }
  
  @keyframes slideInFromRight {
    0% {
      opacity: 0;
      transform: translateX(100%);
    }
    100% {
      opacity: 1;
      transform: translateX(0%);
    }
  }
  
  @keyframes fadeIn {
    0% {
      opacity: 0;
    }
    100% {
      opacity: 1;
    }
  }
  
  @keyframes slideDown {
    0% {
      opacity: 0;
      transform: translateY(-20px);
      max-height: 0;
    }
    100% {
      opacity: 1;
      transform: translateY(0);
      max-height: 200px;
    }
  }
  
  @keyframes slideUp {
    0% {
      opacity: 1;
      transform: translateY(0);
      max-height: 200px;
    }
    100% {
      opacity: 0;
      transform: translateY(-20px);
      max-height: 0;
    }
  }
  
  @keyframes glow {
    0%, 100% {
      box-shadow: 0 0 5px rgba(194, 167, 110, 0.35);
    }
    50% {
      box-shadow: 0 0 20px rgba(194, 167, 110, 0.65), 0 0 30px rgba(194, 167, 110, 0.45);
    }
  }
  
  @keyframes bounce {
    0%, 20%, 50%, 80%, 100% {
      transform: translateY(0);
    }
    40% {
      transform: translateY(-4px);
    }
    60% {
      transform: translateY(-2px);
    }
  }
  
  @keyframes shake {
    0%, 100% {
      transform: translateX(0);
    }
    10%, 30%, 50%, 70%, 90% {
      transform: translateX(-2px);
    }
    20%, 40%, 60%, 80% {
      transform: translateX(2px);
    }
  }
  
  @keyframes ripple {
    0% {
      transform: scale(0);
      opacity: 1;
    }
    100% {
      transform: scale(4);
      opacity: 0;
    }
  }
  
  @keyframes heartbeat {
    0%, 100% {
      transform: scale(1);
    }
    14% {
      transform: scale(1.1);
    }
    28% {
      transform: scale(1);
    }
    42% {
      transform: scale(1.1);
    }
    70% {
      transform: scale(1);
    }
  }
  
  /* Enhanced hover effects */
  .animated-hover {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }
  
  .animated-hover:hover {
    transform: translateY(-1px);
    filter: brightness(1.1);
  }
  
  /* Stagger animation for children */
  .stagger-children > * {
    animation-delay: calc(var(--stagger-delay, 0) * 100ms);
  }
  
  @keyframes quickActionsSlide {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes quickActionItem {
    from {
      opacity: 0;
      transform: translateY(60px) scale(0.8);
    }
    to {
      opacity: 1;
      transform: translateY(0) scale(1);
    }
  }

  /* ================= CODE TOOLBAR THEME (STEP 5) ================= */
  .ai-code-wrapper { position: relative; background: linear-gradient(145deg,#0d0d0d,#181818); border:1px solid var(--borderSoft, rgba(255,255,255,0.12)); border-radius:12px; margin:12px 0; padding-top:42px; box-shadow:0 6px 20px -6px rgba(0,0,0,0.65), 0 0 0 1px rgba(255,255,255,0.04); }
  .ai-code-wrapper .ai-code-lang { position:absolute; top:8px; left:10px; background: var(--bgOverlay, rgba(194,167,110,0.15)); color: var(--textPrimary, #C2A76E); padding:4px 8px; font-size:11px; font-weight:600; font-family:"JetBrains Mono",monospace; letter-spacing:.5px; border-radius:8px; backdrop-filter:blur(8px); }
  .ai-code-toolbar { position:absolute; top:6px; right:8px; display:flex; gap:6px; z-index:2; }
  .ai-code-action { width:32px; height:32px; display:flex; align-items:center; justify-content:center; border-radius:8px; border:1px solid var(--borderSoft, rgba(255,255,255,0.14)); background: var(--bgOverlay, rgba(0,0,0,0.55)); color: var(--textPrimary,#C2A76E); cursor:pointer; font-size:12px; line-height:1; position:relative; transition:background .18s, color .18s, transform .18s, box-shadow .18s; }
  .ai-code-action:hover { background: var(--goldSoft, rgba(194,167,110,0.2)); color:#FFD370; }
  .ai-code-action:active { transform:translateY(1px) scale(.95); }
  .ai-code-action:focus-visible { outline:none; box-shadow:0 0 0 2px rgba(0,0,0,0.6), 0 0 0 3px var(--goldSoft, rgba(194,167,110,0.55)); }
  .ai-code-pre { margin:0; padding:12px 14px 16px; font-size:12px; line-height:1.5; overflow:auto; color:#f5f5f5; font-family:"JetBrains Mono","Fira Code",monospace; }
  .ai-code-toolbar:focus-within .ai-code-action:first-child { /* optional style when toolbar active */ }
  .ai-code-toolbar[aria-disabled='true'] { opacity:.5; pointer-events:none; }
  .ai-code-wrapper[data-limited='true'] .ai-code-action[data-full-only='true'] { display:none; }
  .ai-code-wrapper:focus-within { border-color: var(--goldSoft, rgba(194,167,110,0.45)); }
  @media (max-width: 600px){ .ai-code-action { width:30px; height:30px; } }


  @keyframes suggestionsPanelSlide {
    from {
      opacity: 0;
      transform: translate(-50%, -50%) scale(0.9);
    }
    to {
      opacity: 1;
      transform: translate(-50%, -50%) scale(1);
    }
  }
  
  /* Smooth transitions */
  * {
    transition: all 0.2s ease;
  }
  
  /* Custom easing curves */
  .ease-out-quart {
    transition-timing-function: cubic-bezier(0.25, 1, 0.5, 1);
  }
  
  .ease-in-out-back {
    transition-timing-function: cubic-bezier(0.68, -0.55, 0.265, 1.55);
  }

  /* Responsive Media Queries */
  @media (max-width: 768px) {
    .container {
      width: calc(100vw - 20px) !important;
      margin: 10px !important;
      border-radius: 8px !important;
    }
    
    .header {
      padding: 12px 16px !important;
    }
    
    .quick-action-btn {
      width: 40px !important;
      height: 40px !important;
    }
    
    .modal {
      margin: 20px !important;
      border-radius: 12px !important;
    }
  }

  @media (max-width: 480px) {
    .container {
      width: calc(100vw - 10px) !important;
      margin: 5px !important;
    }
    
    .suggestions-panel {
      width: 95vw !important;
      margin: 10px !important;
    }
  }

  /* Touch-friendly interactions for mobile */
  @media (hover: none) and (pointer: coarse) {
    .interactive-element {
      min-height: 44px;
      min-width: 44px;
    }
    
    .touch-target {
      padding: 12px !important;
    }
  }

  /* Code Syntax Highlighting Styles */
  .code-block {
    background: rgba(26, 26, 26, 0.95);
    border: 1px solid #FFFFFF10;
    border-radius: 8px;
    margin: 12px 0;
    overflow: hidden;
  }

  .code-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 12px;
  background: rgba(194, 167, 110, 0.08);
  border-bottom: 1px solid #FFFFFF10;
  }

  .code-lang {
    color: #C2A76E;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
  }

  .code-copy {
    background: none;
    border: 1px solid #FFFFFF10;
    border-radius: 4px;
    color: #C2A76E;
    padding: 4px 8px;
    cursor: pointer;
    font-size: 12px;
    transition: all 0.2s ease;
  }

  .code-copy:hover {
    background: rgba(194, 167, 110, 0.12);
    border-color: #C2A76E;
  }

  .code-content {
    padding: 12px;
    margin: 0;
    overflow-x: auto;
    font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
    font-size: 14px;
    line-height: 1.5;
  color: #E8E8E8;
  }

  .inline-code {
    background: rgba(194, 167, 110, 0.12);
    border: 1px solid #FFFFFF10;
    border-radius: 4px;
    padding: 2px 6px;
    font-family: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
    font-size: 0.9em;
    color: #C2A76E;
  }

  .function-name {
    color: #C2A76E;
    font-weight: 600;
  }

  .keyword {
    color: #AAB2BD;
    font-weight: 600;
  }

  .string {
    color: #2ECC71;
  }

  .number {
    color: #C2A76E;
  }

  .comment {
    color: #6B7280;
    font-style: italic;
  }

  /* Scrollbar for code blocks */
  .code-content::-webkit-scrollbar {
    height: 6px;
  }

  .code-content::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.2);
  }

  .code-content::-webkit-scrollbar-thumb {
    background: rgba(194, 167, 110, 0.3);
    border-radius: 3px;
  }

  .code-content::-webkit-scrollbar-thumb:hover {
    background: rgba(194, 167, 110, 0.5);
  }
  
  /* Centralized AI toast styles (Step 11) */
  .ai-toast-stack { position:absolute; top:8px; left:8px; display:flex; flex-direction:column; gap:8px; z-index:350; }
  .ai-toast { background:rgba(40,40,40,0.95); border:1px solid #C2A76E44; padding:8px 12px; border-radius:8px; font-size:12px; color:#E8E8E8; display:flex; align-items:center; gap:12px; box-shadow:0 4px 14px rgba(0,0,0,0.5); backdrop-filter:blur(6px); animation:fadeIn .25s ease; }
  .ai-toast[data-autofade='true'] { animation: fadeIn .25s ease, toastFadeOut .4s ease-in forwards; animation-delay: 0s, 3.6s; }
  @keyframes toastFadeOut { to { opacity:0; transform:translateY(-4px); } }
  .ai-toast button { background:linear-gradient(135deg,#C2A76E,#A58B5F); border:none; color:#111; padding:4px 10px; border-radius:6px; cursor:pointer; font-size:11px; font-weight:600; }
  .ai-toast[data-type='error'] { border-color:#E74C3C66; }
  .ai-toast[data-type='success'] { border-color:#2ECC7166; }
  .ai-toast[data-type='warning'] { border-color:#E1C54266; }
  .ai-toast[data-type='info'] { border-color:#3498DB66; }
`;

// Character count color function
export const getCharacterCountColor = (inputLength: number, maxCharacters: number): string => {
  const percentage = (inputLength / maxCharacters) * 100;
  if (percentage >= 90) return '#E74C3C'; // limit
  if (percentage >= 75) return '#E1C542'; // warning
  return '#2ECC71'; // safe
};
