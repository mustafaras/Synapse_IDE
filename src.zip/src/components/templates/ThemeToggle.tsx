import React from 'react';
import ThemeSwitcher from './ThemeSwitcher';

// Simple wrapper for clarity and future extensibility
const ThemeToggle: React.FC = () => <ThemeSwitcher />;

export default ThemeToggle;
