/**
 * ThemeSwitcher Component - Universal Theme Toggle
 *
 * Features:
 * - Modern SVG icons: Sun (light), Moon (dark), Circle (neutral)
 * - WCAG-compliant accessibility with aria-labels
 * - Theme-specific hover glow effects matching accent colors
 * - Glassmorphism container with backdrop blur
 * - Keyboard navigation support
 * - Mobile-responsive design
 *
 * The component provides clear visual cues for theme selection
 * with proper accessibility support and enhanced user experience.
 */

import React from 'react';
import styled, { css, keyframes } from 'styled-components';
import { useTheme } from '../../contexts/ThemeContext';

/* Theme-specific keyframes for active state pulse animation */
const subtlePulseLight = keyframes`
  0%, 100% { box-shadow: 0 0 8px rgba(59, 130, 246, 0.3); }
  50% { box-shadow: 0 0 16px rgba(59, 130, 246, 0.5); }
`;

const subtlePulseDark = keyframes`
  0%, 100% { box-shadow: 0 0 8px rgba(99, 102, 241, 0.3); }
  50% { box-shadow: 0 0 16px rgba(99, 102, 241, 0.5); }
`;

const subtlePulseNeutral = keyframes`
  0%, 100% { box-shadow: 0 0 8px rgba(251, 191, 36, 0.3); }
  50% { box-shadow: 0 0 16px rgba(251, 191, 36, 0.5); }
`;

const SwitcherContainer = styled.div<{ $theme: any }>`
  position: fixed;
  top: 2rem;
  right: 2rem;
  display: flex;
  background: var(--glass-background, rgba(255, 255, 255, 0.1));
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid var(--glass-border, rgba(255, 255, 255, 0.2));
  border-radius: 50px;
  padding: 0.25rem;
  z-index: 1000;
  box-shadow: var(--shadow-glass);
  transition: all 0.3s ease-in-out;

  @media (max-width: 768px) {
    top: 1rem;
    right: 1rem;
    padding: 0.2rem;
  }
`;

const ThemeButton = styled.button<{ $theme: any; $active: boolean; $themeName: string }>`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 48px;
  height: 48px;
  border: ${props => {
    // Add soft border for better contrast, especially in light mode
    if (props.$active) {
      switch (props.$themeName) {
        case 'light':
          return '1px solid rgba(59, 130, 246, 0.3)';
        case 'dark':
          return '1px solid rgba(99, 102, 241, 0.3)';
        case 'neutral':
          return '1px solid rgba(251, 191, 36, 0.3)';
        default:
          return '1px solid var(--color-primary)';
      }
    }
    return '1px solid rgba(0, 0, 0, 0.1)'; // Soft border for inactive buttons
  }};
  border-radius: 50px;
  background: ${props => {
    if (props.$active) {
      switch (props.$themeName) {
        case 'light':
          return 'linear-gradient(135deg, rgba(59, 130, 246, 0.2), rgba(96, 165, 250, 0.1))'; // Light blue gradient
        case 'dark':
          return 'linear-gradient(135deg, rgba(99, 102, 241, 0.3), rgba(139, 92, 246, 0.2))'; // Dark indigo gradient
        case 'neutral':
          return 'linear-gradient(135deg, rgba(251, 191, 36, 0.2), rgba(252, 211, 77, 0.1))'; // Neutral amber gradient
        default:
          return 'var(--color-primary)';
      }
    }
    return 'transparent';
  }};
  box-shadow: ${props => {
    // Enhanced drop-shadow for better visibility
    const baseShadow = '0 0 6px rgba(0, 0, 0, 0.05)';
    if (props.$active) {
      switch (props.$themeName) {
        case 'light':
          return `${baseShadow}, 0 2px 8px rgba(59, 130, 246, 0.1)`;
        case 'dark':
          return `${baseShadow}, 0 2px 8px rgba(99, 102, 241, 0.1)`;
        case 'neutral':
          return `${baseShadow}, 0 2px 8px rgba(251, 191, 36, 0.1)`;
        default:
          return baseShadow;
      }
    }
    return baseShadow;
  }};
  cursor: pointer;
  transition:
    all 0.3s ease-in-out,
    text-shadow 0.3s ease-in-out;
  font-size: 20px;
  position: relative;
  outline: none;

  /* SVG icon styling */
  svg {
    transition: all 0.3s ease-in-out;
    color: ${props => {
      if (props.$active) {
        switch (props.$themeName) {
          case 'light':
            return 'rgba(59, 130, 246, 0.9)';
          case 'dark':
            return 'rgba(99, 102, 241, 0.9)';
          case 'neutral':
            return 'rgba(251, 191, 36, 0.9)';
          default:
            return 'var(--color-text)';
        }
      }
      return 'var(--color-text-secondary)';
    }};
  }

  /* Keyboard focus support */
  &:focus-visible {
    outline: 2px solid var(--color-primary);
    outline-offset: 2px;
    box-shadow: 0 0 0 4px var(--color-primary) 20;
  }

  /* Enhanced hover glow effect matching theme accents */
  &:hover {
    transform: scale(1.1);
    box-shadow: ${props => {
      switch (props.$themeName) {
        case 'light':
          return '0 0 20px rgba(59, 130, 246, 0.6), 0 0 40px rgba(59, 130, 246, 0.3)'; // Blue accent for light
        case 'dark':
          return '0 0 20px rgba(99, 102, 241, 0.8), 0 0 40px rgba(99, 102, 241, 0.4)'; // Indigo accent for dark
        case 'neutral':
          return '0 0 20px rgba(251, 191, 36, 0.6), 0 0 40px rgba(251, 191, 36, 0.3)'; // Amber accent for neutral
        default:
          return '0 0 20px var(--color-primary)60';
      }
    }};

    /* SVG icon glow effect per theme specification */
    svg {
      color: ${props => {
        switch (props.$themeName) {
          case 'light':
            return '#3B82F6';
          case 'dark':
            return '#8B5CF6';
          case 'neutral':
            return '#FBBF24';
          default:
            return 'var(--color-primary)';
        }
      }};
      filter: drop-shadow(0 0 8px currentColor);
    }
  }

  &:active {
    transform: scale(0.95);
  }

  /* Active state enhancement with subtle pulse animation */
  ${props =>
    props.$active &&
    css`
      animation: ${props.$themeName === 'light'
          ? subtlePulseLight
          : props.$themeName === 'dark'
            ? subtlePulseDark
            : props.$themeName === 'neutral'
              ? subtlePulseNeutral
              : 'none'}
        2s ease-in-out infinite;
    `}

  @media (max-width: 768px) {
    width: 42px;
    height: 42px;
    font-size: 18px;
  }
`;

// Modern SVG Icons for themes
const SunIcon: React.FC<{ size?: number }> = ({ size = 20 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="5" />
    <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
  </svg>
);

const MoonIcon: React.FC<{ size?: number }> = ({ size = 20 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
  </svg>
);

const CircleIcon: React.FC<{ size?: number }> = ({ size = 20 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="10" />
    <path d="M12 2a10 10 0 0 0 0 20z" fill="currentColor" fillOpacity="0.3" />
  </svg>
);

const ThemeSwitcher: React.FC = () => {
  const { theme, themeName, setTheme } = useTheme();

  const themes = [
    { name: 'light' as const, icon: <SunIcon size={20} />, label: 'Light Theme' },
    { name: 'neutral' as const, icon: <CircleIcon size={20} />, label: 'Neutral Theme' },
    { name: 'dark' as const, icon: <MoonIcon size={20} />, label: 'Dark Theme' },
  ];

  return (
    <SwitcherContainer $theme={theme}>
      {themes.map(({ name, icon, label }) => (
        <ThemeButton
          key={name}
          $theme={theme}
          $active={themeName === name}
          $themeName={name}
          onClick={() => setTheme(name)}
          title={label}
          aria-label={label}
          role="button"
          tabIndex={0}
          onKeyDown={e => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setTheme(name);
            }
          }}
        >
          {icon}
        </ThemeButton>
      ))}
    </SwitcherContainer>
  );
};

export default ThemeSwitcher;
