import React from 'react';
import styled, { keyframes } from 'styled-components';
import Logo from '../atoms/Logo';
import { useTheme } from '../../contexts/ThemeContext';

const rocketPulse = keyframes`
  0%, 100% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
`;

const LaunchButtonStyled = styled.button<{ $theme: any; $themeName: string }>`
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;

  /* Glass background with border and blur */
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1.5px solid
    ${({ $themeName }) =>
      $themeName === 'light' ? 'rgba(59, 130, 246, 0.85)' : 'rgba(255, 255, 255, 0.2)'};
  border-radius: 50px;

  /* Text styling */
  font-size: 0.875rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--color-text);

  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  /* Remove all glow, box-shadow, and text-shadow effects */
  animation: none !important;
  box-shadow: none !important;
  text-shadow: none !important;

  &:hover {
    animation: none !important;
    box-shadow: none !important;
    text-shadow: none !important;
    border-color: ${({ $themeName }) =>
      $themeName === 'light' ? 'rgba(59, 130, 246, 1)' : 'rgba(255, 255, 255, 0.3)'};
    transform: translateY(-4px) scale(1.05);
  }

  &:active {
    transform: translateY(-2px) scale(1.02);
  }
`;

const IconContainer = styled.div`
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;

  /* Hover pulse animation for rocket icon */
  ${LaunchButtonStyled}:hover & {
    animation: ${rocketPulse} 0.6s ease-in-out infinite;
  }

  /* Enhanced icon visibility for all themes */
  svg {
    filter: drop-shadow(0 1px 2px rgba(0, 0, 0, 0.3));
    transition: all 0.3s ease;
  }
`;

const RocketIcon: React.FC = () => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    style={{
      textShadow: '0 1px 2px rgba(0, 0, 0, 0.5)',
    }}
  >
    <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" />
    <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" />
    <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0" />
    <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" />
  </svg>
);

interface HeroSectionProps {
  onLaunchIDE?: () => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ onLaunchIDE }) => {
  const { theme, themeName } = useTheme();

  return (
    <section className="pt-24 pb-12">
      <div className="w-full px-0">
        {/* Logo */}
        <div className="mb-6 fade-in" style={{ animationDelay: '0s' }}>
          <Logo size={160} />
        </div>

        {/* App Brand Title */}
        <h2
          className="text-2xl font-bold font-brand text-transparent bg-gradient-to-r from-blue-500 to-purple-600 bg-clip-text 
                       uppercase tracking-wider mb-12 fade-in lg:text-left text-center lg:text-2xl md:text-xl"
          style={{ animationDelay: '0.1s' }}
        >
          A CODER-APP
        </h2>

        {/* Description - Split into two paragraphs */}
        <div className="space-y-6">
          <p
            className="text-base leading-relaxed mt-12 fade-in
                        text-gray-600 dark:text-gray-400"
            style={{
              animationDelay: '0.2s',
              fontFamily:
                'JetBrains Mono, Fira Code, "SF Mono", Monaco, Inconsolata, "Roboto Mono", "Oxygen Mono", "Ubuntu Monospace", monospace',
              fontWeight: '400',
              fontSize: '0.95rem',
              lineHeight: '1.7',
              width: '1010px',
              maxWidth: '1010px',
              wordWrap: 'break-word',
              margin: 0,
              padding: 0,
              boxSizing: 'border-box',
              textAlign: 'justify',
              textJustify: 'inter-word',
            }}
          >
            Synapse Coder App is an advanced, high-performance development environment designed to
            meet the complex needs of modern software engineering. Supporting over 20 programming
            languages including JavaScript, Python, C++, TypeScript, and more, it combines powerful
            features like AI-assisted coding, intelligent autocomplete, and syntax-aware editing
            with seamless Git integration and real-time collaborative development.
          </p>

          <p
            className="text-base leading-relaxed fade-in
                        text-gray-600 dark:text-gray-400"
            style={{
              animationDelay: '0.3s',
              fontFamily:
                'JetBrains Mono, Fira Code, "SF Mono", Monaco, Inconsolata, "Roboto Mono", "Oxygen Mono", "Ubuntu Monospace", monospace',
              fontWeight: '400',
              fontSize: '0.95rem',
              lineHeight: '1.7',
              width: '1010px',
              maxWidth: '1010px',
              wordWrap: 'break-word',
              margin: 0,
              marginTop: '20px',
              padding: 0,
              boxSizing: 'border-box',
              textAlign: 'justify',
              textJustify: 'inter-word',
            }}
          >
            Its modular extension system allows teams to tailor the environment to their specific
            workflows, while built-in project templates for popular tech stacks such as React,
            Node.js, Django, and Flask enable rapid and efficient project initialization. The
            customizable code editor offers fine-grained control over themes, keybindings, and
            layouts, while autosave and version tracking ensure that progress is never lost. Robust
            API support and integrated debugging tools streamline the full development lifecycle
            from prototyping to deployment. Whether you're building solo or as part of a distributed
            team, Synapse provides a scalable, intelligent, and unified coding platform built for
            speed, precision, and adaptability.
          </p>
        </div>

        {/* Launch IDE Button - Moved below paragraphs */}
        <div className="fade-in" style={{ animationDelay: '0.4s', marginTop: '70px' }}>
          <LaunchButtonStyled
            $theme={theme}
            $themeName={themeName}
            onClick={onLaunchIDE || (() => {})}
          >
            <IconContainer>
              <RocketIcon />
            </IconContainer>
            <span>Launch IDE</span>
          </LaunchButtonStyled>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
