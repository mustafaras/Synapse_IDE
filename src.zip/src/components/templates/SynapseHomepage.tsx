import React, { useEffect, useState } from 'react';
import styled, { css, keyframes } from 'styled-components';
import { useTheme } from '../../contexts/ThemeContext';
import HeroSection from './HeroSection';
import ThemeToggle from './ThemeToggle';
import { NeuralBackground, NeuralGlassCard } from '../atoms';

// Professional, extensive card descriptions for enterprise IDE
const neuralCards = [
  {
    id: 1,
    title: 'AI Error Detection',
    description:
      'Advanced machine learning algorithms provide comprehensive real-time code analysis, vulnerability detection, and performance optimization recommendations with enterprise-grade accuracy. Our neural network continuously learns from millions of code patterns to identify potential issues before they impact production environments, ensuring code quality and security compliance.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M9 12L11 14L15 10"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" />
        <path
          d="M12 3C12 3 15 6 15 12S12 21 12 21"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <path
          d="M12 3C12 3 9 6 9 12S12 21 12 21"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      </svg>
    ),
  },
  {
    id: 2,
    title: 'Neural Code Assistant',
    description:
      'Context-aware AI companion featuring intelligent code completion, architecture recommendations, and automated refactoring with deep understanding of your codebase patterns. This advanced system analyzes your coding style, project structure, and industry best practices to provide personalized suggestions that enhance productivity and code maintainability across all development phases.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="12" cy="12" r="2" stroke="currentColor" strokeWidth="2" />
        <path
          d="M12 6V8M16 8L14 10M16 16L14 14M12 18V16M8 16L10 14M8 8L10 10"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      </svg>
    ),
  },
  {
    id: 3,
    title: 'Cloud Deployment',
    description:
      'Streamlined deployment pipeline with automatic scaling, container orchestration, and multi-cloud support. Deploy to AWS, Azure, GCP with zero-configuration setup and comprehensive monitoring. Our intelligent deployment system handles infrastructure provisioning, load balancing, and auto-scaling while maintaining high availability and cost optimization across global regions.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M18 10H22L18 6L14 10H18Z"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M18 6V14"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M6 18C4.34315 18 3 16.6569 3 15C3 13.3431 4.34315 12 6 12C6.35064 10.8885 7.3712 10.0952 8.55279 10.0091C8.82399 8.84815 9.86563 8 11.1111 8C12.6717 8 13.9778 9.22386 14.0899 10.7486"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
        />
      </svg>
    ),
  },
  {
    id: 4,
    title: 'Performance Analytics',
    description:
      'Comprehensive runtime monitoring with detailed metrics, memory profiling, and AI-powered optimization insights. Track performance bottlenecks in real-time with actionable recommendations and predictive analysis. Our advanced telemetry system provides deep visibility into application behavior, resource utilization, and user experience metrics to drive data-driven optimization decisions.',
    icon: (
      <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M22 12H18L15 21L9 3L6 12H2"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="12" cy="12" r="1" stroke="currentColor" strokeWidth="2" />
        <path
          d="M8 8L12 12L16 8"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M8 16L12 12L16 16"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    ),
  },
];

const PageContainer = styled.div<{ $theme: any }>`
  min-height: 100vh;
  background: transparent; /* Make transparent to show neural background */
  font-family: var(--font-family-primary);
  transition: all 300ms var(--timing-function-global);
  overflow: hidden;
  position: relative;
  z-index: 1; /* Ensure content is above neural background */

  &::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: ${props => props.$theme.background};
    z-index: -2; /* Behind neural background */
    transition: all 300ms var(--timing-function-global);
  }
`;

const MainGrid = styled.div`
  /* Parent container - full left aligned layout */
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;

  /* Container layout properties - remove centering and max-width */
  width: 100%;
  margin: 0;
  padding-inline: 0;
  min-height: 100vh;
  position: relative;

  /* Grid children - extended branding block aligned with SynapseIDE width */
  .branding-section {
    display: flex;
    flex-direction: column;
    padding-block: 0 4rem; /* No top padding, normal bottom */
    justify-content: flex-start;
    align-items: flex-start;
    text-align: left;
    gap: var(--spacing-lg);

    /* Let BrandTitle determine container width naturally */
    width: fit-content;
    min-width: 0;
    max-width: none;

    /* Normal spacing */
    padding-left: clamp(2rem, 5vw, 3rem);
    padding-right: 0;
  }

  /* Responsive design */
  @media (max-width: 1024px) {
    .branding-section {
      padding-block: 0 3rem; /* No top padding for tablet */
      align-items: center;
      text-align: center;
      max-width: none; /* Allow full width on tablet */
    }
  }

  @media (max-width: 768px) {
    .branding-section {
      width: 100%;
      padding-block: 0 2rem; /* No top padding for mobile */
      padding-inline: var(--spacing-md);
      align-items: center;
      text-align: center;
      max-width: none; /* Allow full width on mobile */
    }
  }
`;

const FloatingControls = styled.div`
  position: fixed;
  top: var(--spacing-lg);
  right: var(--spacing-lg);
  z-index: 8000; /* Status bar'dan düşük, homepage elementleri için */

  display: flex;
  align-items: center;
  gap: var(--spacing-sm);

  /* Minimal styling - functional over decorative */
  background: var(--glass-background);
  border-radius: var(--border-radius-full);
  padding: var(--spacing-xs) var(--spacing-sm);

  transition: all 300ms var(--timing-function-global);

  &:hover {
    background: var(--glass-background-hover, rgba(255, 255, 255, 0.15));
    transform: scale(1.05); /* Only scale, no translateY */
  }

  @media (max-width: 768px) {
    top: var(--spacing-md);
    right: var(--spacing-md);
    padding: var(--spacing-xs);
  }
`;

const BrandTitle = styled.h1<{ $theme?: any }>`
  /* Professional, coding-focused typography - Proto Mono font from image */
  font-family:
    'Proto Mono', 'ProtoMono', 'Proto-Mono', 'JetBrains Mono', 'Fira Code', 'SF Mono', Consolas,
    'Roboto Mono', monospace;
  font-size: clamp(5rem, 10vw, 10rem); /* Increased from 4rem-8rem to 5rem-10rem */
  font-weight: 950; /* Maximum bold - increased from 900 to 950 */
  line-height: var(--line-height-tight);
  letter-spacing: -0.02em; /* Tighter spacing for professional look */

  /* Extra bold styling for enhanced impact */
  text-shadow:
    1px 1px 0px rgba(0, 0, 0, 0.1),
    2px 2px 0px rgba(0, 0, 0, 0.05);

  /* Prevent line breaks - ensure single line display */
  white-space: nowrap;
  overflow: visible;
  text-overflow: clip;

  /* Left-aligned for branding section */
  text-align: left;
  align-self: flex-start;

  /* Animated gradient - theme-specific moving colors */
  background: ${props => {
    const theme = props.$theme;
    if (!theme)
      return 'linear-gradient(270deg, var(--color-primary), var(--color-accent), var(--color-primary))';

    const themeName = theme.name || 'light';

    switch (themeName) {
      case 'light':
        return `linear-gradient(270deg, #3B82F6, #60A5FA, #8B5CF6, #3B82F6)`;
      case 'dark':
        return `linear-gradient(270deg, #6366F1, #8B5CF6, #A855F7, #6366F1)`;
      case 'neutral':
        return `linear-gradient(270deg, #F59E0B, #FBBF24, #F97316, #F59E0B)`;
      default:
        return 'linear-gradient(270deg, var(--color-primary), var(--color-accent), var(--color-primary))';
    }
  }};
  background-size: 400% 400%;
  animation: gradientShift 4s ease infinite;

  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;

  /* Enhanced shadow for larger text */
  filter: drop-shadow(0 3px 10px rgba(0, 0, 0, 0.15));

  margin: 0; /* Remove all margins for clean alignment */
  margin-bottom: 0rem; /* Recommended spacing to clear both blocks properly */
  transition: all 400ms cubic-bezier(0.4, 0, 0.2, 1);

  &:hover {
    transform: scale(1.02); /* Only scale, no translateY */
    filter: drop-shadow(0 5px 15px rgba(0, 0, 0, 0.2));
  }

  /* Blinking cursor animation for underscore */
  .cursor {
    animation: blink 1s infinite;
    /* Inherit all parent styles to match the gradient text */
    background: inherit;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-family: inherit;
    font-weight: inherit; /* Use same weight as parent */
    font-size: inherit;
    /* Make underscore slightly thicker but not too bold */
    transform: scaleY(1.1) scaleX(1.1);
    display: inline-block;
    transform-origin: center bottom;
  }

  /* Theme-specific glitch/hacker effects */
  &.glitch {
    animation: glitch 0.3s ease-in-out;
  }

  @keyframes glitch {
    0% {
      transform: translate(0);
      filter: hue-rotate(0deg);
    }
    10% {
      transform: translate(-2px, 1px);
      text-shadow: ${props => {
        const theme = props.$theme;
        const themeName = theme?.name || 'light';

        switch (themeName) {
          case 'light':
            return `
              -2px 0 #3B82F6,
              2px 0 #60A5FA,
              0 0 10px #3B82F6,
              0 0 20px #60A5FA
            `;
          case 'dark':
            return `
              -2px 0 #6366F1,
              2px 0 #8B5CF6,
              0 0 10px #6366F1,
              0 0 20px #8B5CF6
            `;
          case 'neutral':
            return `
              -2px 0 #10B981,
              2px 0 #34D399,
              0 0 10px #10B981,
              0 0 20px #34D399
            `;
          default:
            return `
              -2px 0 #3B82F6,
              2px 0 #60A5FA,
              0 0 10px #3B82F6
            `;
        }
      }};
    }
    20% {
      transform: translate(-1px, -1px);
    }
    30% {
      transform: translate(1px, 2px);
      filter: hue-rotate(90deg);
    }
    40% {
      transform: translate(2px, -1px);
    }
    50% {
      transform: translate(-1px, 1px);
      text-shadow: ${props => {
        const theme = props.$theme;
        const themeName = theme?.name || 'light';

        switch (themeName) {
          case 'light':
            return `
              1px 1px #3B82F6,
              -1px -1px #60A5FA,
              0 0 5px #3B82F6
            `;
          case 'dark':
            return `
              1px 1px #6366F1,
              -1px -1px #8B5CF6,
              0 0 5px #6366F1
            `;
          case 'neutral':
            return `
              1px 1px #10B981,
              -1px -1px #34D399,
              0 0 5px #10B981
            `;
          default:
            return `
              1px 1px #3B82F6,
              -1px -1px #60A5FA
            `;
        }
      }};
    }
    60% {
      transform: translate(1px, 1px);
    }
    70% {
      transform: translate(-2px, 1px);
      filter: hue-rotate(180deg);
    }
    80% {
      transform: translate(2px, -2px);
    }
    90% {
      transform: translate(1px, -1px);
    }
    100% {
      transform: translate(0);
      filter: hue-rotate(0deg);
      text-shadow: none;
    }
  }

  @keyframes gradientShift {
    0% {
      background-position: 0% 50%;
    }
    50% {
      background-position: 100% 50%;
    }
    100% {
      background-position: 0% 50%;
    }
  }

  @keyframes blink {
    0%,
    50% {
      opacity: 1;
    }
    51%,
    100% {
      opacity: 0;
    }
  }

  /* Responsive adjustments - maintaining single line */
  @media (max-width: 1024px) {
    font-size: clamp(4rem, 8vw, 7rem); /* Adjusted for tablet */
    text-align: center;
    align-self: center;
  }

  @media (max-width: 768px) {
    font-size: clamp(3rem, 7vw, 5rem); /* Adjusted for mobile */
    text-align: center;
    align-self: center;
  }

  @media (max-width: 480px) {
    font-size: clamp(2.5rem, 6vw, 4rem); /* Minimum size for small screens */
  }
`;

// Enhanced bottom-left card container with animation improvements
const BottomLeftCards = styled.div`
  /* Fixed positioning aligned under hero section */
  position: fixed;
  bottom: 0rem; /* bottom-8 (32px) */
  left: clamp(1rem, 3vw, 2rem); /* Match paragraph left alignment */
  z-index: 50; /* z-50 */

  /* Flex layout with horizontal scrolling */
  display: flex;
  gap: 1.5rem; /* gap-6 (24px) */
  width: 1200px; /* Increased container width */
  max-width: 1200px; /* Increased container width */
  overflow-x: auto; /* overflow-x-auto */
  overflow-y: visible; /* Allow overflow for animations */

  /* Scroll snapping for mobile */
  scroll-snap-type: x mandatory; /* scroll-snap-x mandatory */
  scroll-behavior: smooth;

  /* Hide scrollbars for clean appearance */
  scrollbar-width: none; /* Firefox */
  -ms-overflow-style: none; /* IE and Edge */
  &::-webkit-scrollbar {
    display: none; /* Chrome, Safari, Opera */
  }

  /* Remove all container styling (no borders, shadows, backgrounds) */
  background: transparent;
  border: none;
  padding: 0;
  padding-bottom: 2rem; /* Add padding for hover animation space */

  /* Smooth transitions with improved animation curve */
  transition: none;

  /* GPU optimization */
  will-change: auto;

  /* Momentum scrolling on iOS */
  -webkit-overflow-scrolling: touch;

  /* Responsive adjustments */
  @media (max-width: 1024px) {
    bottom: 1.5rem;
    left: clamp(1.5rem, 4vw, 2.5rem);
    width: min(930px, calc(100vw - 3rem));
    max-width: min(930px, calc(100vw - 3rem));
    gap: 1.25rem;
  }

  @media (max-width: 768px) {
    bottom: 1rem;
    left: 1rem;
    width: calc(100vw - 2rem);
    max-width: calc(100vw - 2rem);
    gap: 1rem;
  }

  @media (max-width: 640px) {
    bottom: 0.75rem;
    left: 0.75rem;
    right: 0.75rem;
    width: calc(100vw - 1.5rem);
    max-width: calc(100vw - 1.5rem);
    gap: 0.75rem;
  }

  @media (max-width: 480px) {
    bottom: 0.5rem;
    left: 0.5rem;
    right: 0.5rem;
    width: calc(100vw - 1rem);
    max-width: calc(100vw - 1rem);
    gap: 0.5rem;
  }

  /* Adjust for reduced motion */
  @media (prefers-reduced-motion: reduce) {
    transition: none;
  }
`;

// Glitch/ışınlanma animasyonu
const glitchLine = keyframes`
  0% { opacity: 0; transform: scaleX(0.1) translateX(-50%) skewX(0deg); filter: blur(8px) brightness(2); }
  20% { opacity: 1; transform: scaleX(1.1) translateX(-50%) skewX(10deg); filter: blur(2px) brightness(1.5); }
  40% { opacity: 1; transform: scaleX(0.95) translateX(-50%) skewX(-8deg); filter: blur(1px) brightness(1.2); }
  60% { opacity: 1; transform: scaleX(1.02) translateX(-50%) skewX(4deg); filter: blur(0.5px) brightness(1.1); }
  80% { opacity: 1; transform: scaleX(1) translateX(-50%) skewX(0deg); filter: blur(0px) brightness(1); }
  100% { opacity: 1; transform: scaleX(1) translateX(-50%) skewX(0deg); filter: none; }
`;

const GlitchLine = styled.div<{ $themeName: string; $animate: boolean }>`
  width: 110vw;
  height: 2px;
  background: ${({ $themeName }) =>
    $themeName === 'dark'
      ? 'linear-gradient(90deg, #6366F1, #8B5CF6, #A855F7)'
      : $themeName === 'neutral'
        ? 'linear-gradient(90deg, #F59E0B, #FBBF24, #F97316)'
        : 'linear-gradient(90deg, #60A5FA, #A78BFA, #F472B6)'};
  margin: 0px 0 6px 0;
  position: relative;
  left: -12%;
  transform: translateX(-50%);
  border-radius: 3px;
  box-shadow: 0 2px 12px 0 rgba(80, 80, 120, 0.12);
  opacity: 1;
  ${({ $animate }) =>
    $animate &&
    css`
      animation: ${glitchLine} 1.5s cubic-bezier(0.7, 0, 0.3, 1);
    `}
`;

const SynapseHomepage: React.FC<{ onLaunchIDE?: () => void; onSettings?: () => void }> = ({
  onLaunchIDE,
}) => {
  const { theme, themeName } = useTheme();
  const [isGlitching, setIsGlitching] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [displayText, setDisplayText] = useState('');
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [lineGlitch, setLineGlitch] = useState(true); // çizgi animasyonu için

  // Auto-cycle through cards every 3 seconds (daha da kısa)
  useEffect(() => {
    const cardCycleInterval = setInterval(() => {
      setCurrentCardIndex(prevIndex => (prevIndex + 1) % neuralCards.length);
    }, 3000); // 3_000ms

    return () => clearInterval(cardCycleInterval);
  }, []);

  // Typing effect
  useEffect(() => {
    const fullText = 'Synapse_IDE';
    let currentIndex = 0;

    const triggerTyping = () => {
      setIsTyping(true);
      setDisplayText('');
      currentIndex = 0;

      const typeInterval = setInterval(() => {
        if (currentIndex < fullText.length) {
          setDisplayText(fullText.substring(0, currentIndex + 1));
          currentIndex++;
        } else {
          clearInterval(typeInterval);
          setTimeout(() => setIsTyping(false), 500);
        }
      }, 100); // Each character types in 100ms
    };

    // Initial typing on mount
    triggerTyping();

    // Typing effect every 30 seconds
    const typingInterval = setInterval(triggerTyping, 30000);

    return () => clearInterval(typingInterval);
  }, []);

  // Trigger typing effect on theme change
  useEffect(() => {
    const fullText = 'Synapse_IDE';
    let currentIndex = 0;

    setIsTyping(true);
    setDisplayText('');
    currentIndex = 0;

    const typeInterval = setInterval(() => {
      if (currentIndex < fullText.length) {
        setDisplayText(fullText.substring(0, currentIndex + 1));
        currentIndex++;
      } else {
        clearInterval(typeInterval);
        setTimeout(() => setIsTyping(false), 500);
      }
    }, 100);

    return () => clearInterval(typeInterval);
  }, [themeName]);

  // Random glitch effect every 8-15 seconds (more subtle)
  useEffect(() => {
    const triggerGlitch = () => {
      setIsGlitching(true);
      setTimeout(() => setIsGlitching(false), 300); // Glitch duration
    };

    const getRandomInterval = () => Math.random() * 7000 + 8000; // 8-15 seconds

    let timeoutId: NodeJS.Timeout;

    const scheduleNextGlitch = () => {
      timeoutId = setTimeout(() => {
        triggerGlitch();
        scheduleNextGlitch();
      }, getRandomInterval());
    };

    scheduleNextGlitch();

    // Cleanup function to prevent infinite loops
    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
    };
  }, []);

  // Çizgi animasyonu: açılışta ve tema değiştiğinde tetiklenir
  useEffect(() => {
    setLineGlitch(true);
    const t = setTimeout(() => setLineGlitch(false), 3000);
    return () => clearTimeout(t);
  }, [themeName]);

  return (
    <PageContainer $theme={theme}>
      <NeuralBackground />
      <FloatingControls>
        <ThemeToggle />
      </FloatingControls>
      <MainGrid>
        {/* Left branding block - clean, no container */}
        <section className="branding-section">
          <BrandTitle
            $theme={{ name: themeName }}
            className={isGlitching ? 'glitch' : ''}
            data-theme={themeName}
          >
            {isTyping ? (
              <>
                {displayText}
                <span className="cursor">_</span>
              </>
            ) : (
              <>
                Synapse<span className="cursor">_</span>IDE
              </>
            )}
          </BrandTitle>
          {/* BrandTitle altına tam genişlikte 5px çizgi, glitch animasyonlu */}
          <GlitchLine $themeName={themeName} $animate={lineGlitch} />
          <HeroSection onLaunchIDE={onLaunchIDE || (() => {})} />
        </section>
      </MainGrid>
      <BottomLeftCards>
        <div>
          <NeuralGlassCard
            title={neuralCards[currentCardIndex].title}
            description={neuralCards[currentCardIndex].description}
            onClick={() => console.log(`Clicked on ${neuralCards[currentCardIndex].title}`)}
            cardIndex={currentCardIndex}
          />
        </div>
      </BottomLeftCards>
    </PageContainer>
  );
};

export default SynapseHomepage;

// Check for compilation errors - no changes needed, just verification
