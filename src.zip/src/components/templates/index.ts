export { default as SynapseHomepage } from './SynapseHomepage';
export { default as HeroSection } from './HeroSection';
export { default as ThemeSwitcher } from './ThemeSwitcher';
export { default as ThemeToggle } from './ThemeToggle';
