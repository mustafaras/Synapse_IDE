import { useId } from 'react';

export type PreviewRatio = '50/50' | '70/30';

export interface PreviewToolbarProps {
  ratio: PreviewRatio;
  onRatioChange: (v: PreviewRatio) => void;
  auto: boolean;
  onToggleAuto: () => void;
  onRefresh: () => void;
  onClear: () => void;
  viewport: 'auto' | 'mobile' | 'tablet' | 'desktop';
  onViewportChange: (v: 'auto' | 'mobile' | 'tablet' | 'desktop') => void;
  busy?: boolean;
}

export default function PreviewToolbar({ ratio, onRatioChange, auto, onToggleAuto, onRefresh, onClear, viewport, onViewportChange, busy }: PreviewToolbarProps) {
  const gid = useId();
  const announce = (msg: string) => {
    try {
      const node = document.getElementById(`${gid}-live`);
      if (node) { node.textContent = msg; setTimeout(() => { node.textContent = ''; }, 1500); }
    } catch {}
  };
  return (
    <div className="syn-preview-toolbar" role="toolbar" aria-label="Preview controls">
      <button className="ptb-btn" onClick={() => { onRefresh(); announce('Preview refreshed'); }} aria-label="Refresh preview" disabled={!!busy} title="Refresh (Ctrl/Cmd+R)">
        <i className="lucide-rotate-cw" aria-hidden="true" /> <span className="ptb-text">Refresh</span>
      </button>
      <button className="ptb-btn" onClick={() => { onClear(); announce('Preview cleared'); }} aria-label="Clear output" title="Clear (Ctrl/Cmd+K)">
        <i className="lucide-eraser" aria-hidden="true" /> <span className="ptb-text">Clear</span>
      </button>

      <div className="ptb-sep" aria-hidden="true" />

      <div role="group" aria-labelledby={`${gid}-ratio`} className="ptb-segment">
        <span id={`${gid}-ratio`} className="sr-only">Editor/Preview ratio</span>
  {(['50/50','70/30'] as const).map(v => (
          <button key={v} className={`ptb-seg ${ratio===v ? 'is-active' : ''}`} onClick={() => { onRatioChange(v); announce(`Ratio ${v}`); }} aria-pressed={ratio===v}>
            {v}
          </button>
        ))}
      </div>

      <label className="ptb-toggle" title="Auto refresh">
        <input type="checkbox" checked={auto} onChange={() => { onToggleAuto(); announce(`Auto refresh ${!auto ? 'on' : 'off'}`); }} aria-label="Auto refresh" />
        <span className="ptb-toggle-ui"><i className="lucide-zap" aria-hidden="true"/></span>
        <span className="ptb-text">Auto</span>
      </label>

      <div className="ptb-sep" aria-hidden="true" />

      <label className="ptb-select">
        <span className="ptb-text">Viewport</span>
        <select aria-label="Viewport" value={viewport} onChange={(e) => { onViewportChange(e.target.value as any); announce(`Viewport ${e.target.value}`); }}>
          <option value="auto">Auto</option>
          <option value="mobile">375</option>
          <option value="tablet">768</option>
          <option value="desktop">1280</option>
        </select>
      </label>

      <div aria-live="polite" className="sr-only" id={`${gid}-live`} />
    </div>
  );
}
