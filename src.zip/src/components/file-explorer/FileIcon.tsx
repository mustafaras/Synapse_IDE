import React from 'react';
import {
  Archive,
  Code,
  Database,
  File,
  FileAudio,
  FileCode,
  FileImage,
  FileText,
  FileVideo,
  Folder,
  Settings,
} from 'lucide-react';

// 🎯 FILE ICON COMPONENT: Professional file type icon system
export interface FileIconProps {
  filename: string;
  isFolder?: boolean;
  size?: number;
  className?: string;
  style?: React.CSSProperties;
}

// 🎯 FILE TYPE MAPPINGS: Comprehensive file extension to icon mapping
const getFileIcon = (filename: string, isFolder: boolean = false) => {
  if (isFolder) {
    return Folder;
  }

  const extension = filename.split('.').pop()?.toLowerCase() || '';

  // Code files
  if (['js', 'jsx', 'ts', 'tsx', 'vue', 'svelte'].includes(extension)) {
    return FileCode;
  }

  if (['html', 'css', 'scss', 'sass', 'less', 'styl'].includes(extension)) {
    return Code;
  }

  if (['json', 'xml', 'yaml', 'yml', 'toml', 'ini', 'conf'].includes(extension)) {
    return Settings;
  }

  if (
    ['py', 'java', 'cpp', 'c', 'cs', 'php', 'rb', 'go', 'rs', 'swift', 'kt'].includes(extension)
  ) {
    return Code;
  }

  // Image files
  if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp', 'ico', 'tiff'].includes(extension)) {
    return FileImage;
  }

  // Video files
  if (['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv', '3gp'].includes(extension)) {
    return FileVideo;
  }

  // Audio files
  if (['mp3', 'wav', 'flac', 'aac', 'ogg', 'wma', 'm4a'].includes(extension)) {
    return FileAudio;
  }

  // Archive files
  if (['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz'].includes(extension)) {
    return Archive;
  }

  // Database files
  if (['db', 'sqlite', 'sql', 'mdb'].includes(extension)) {
    return Database;
  }

  // Text files
  if (['txt', 'md', 'rst', 'log', 'readme'].includes(extension)) {
    return FileText;
  }

  // Default file icon
  return File;
};

// 🎯 FILE ICON COLORS: Professional color scheme for different file types
const getFileIconColor = (filename: string, isFolder: boolean = false) => {
  if (isFolder) {
    return '#C2A76E'; // Gold for folders
  }

  const extension = filename.split('.').pop()?.toLowerCase() || '';

  // JavaScript/TypeScript - Golden secondary
  if (['js', 'jsx', 'ts', 'tsx'].includes(extension)) {
    return '#D4B982';
  }

  // Vue/Svelte - Muted gold
  if (['vue', 'svelte'].includes(extension)) {
    return '#C2A76E';
  }

  // CSS/Styling - Light gray
  if (['css', 'scss', 'sass', 'less', 'styl'].includes(extension)) {
    return '#9CA3AF';
  }

  // HTML - Golden tertiary
  if (extension === 'html') {
    return '#E6D3A3';
  }

  // JSON/Config - Medium gray
  if (['json', 'xml', 'yaml', 'yml', 'toml', 'ini', 'conf'].includes(extension)) {
    return '#6B7280';
  }

  // Images - Light golden
  if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp', 'ico', 'tiff'].includes(extension)) {
    return '#E6D3A3';
  }

  // Videos - Dark gray
  if (['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv', '3gp'].includes(extension)) {
    return '#4B5563';
  }

  // Audio - Medium golden
  if (['mp3', 'wav', 'flac', 'aac', 'ogg', 'wma', 'm4a'].includes(extension)) {
    return '#D4B982';
  }

  // Archives - Dark gray
  if (['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz'].includes(extension)) {
    return '#4B5563';
  }

  // Other code files - Light gray
  if (
    ['py', 'java', 'cpp', 'c', 'cs', 'php', 'rb', 'go', 'rs', 'swift', 'kt'].includes(extension)
  ) {
    return '#9CA3AF';
  }

  // Default - Neutral
  return '#9CA3AF';
};

export const FileIcon: React.FC<FileIconProps> = ({
  filename,
  isFolder = false,
  size = 16,
  className = '',
  style = {},
}) => {
  const IconComponent = getFileIcon(filename, isFolder);
  const iconColor = getFileIconColor(filename, isFolder);

  return (
    <IconComponent
      size={size}
      strokeWidth={1.5}
      className={className}
      style={{
        color: iconColor,
        flexShrink: 0,
        opacity: 0.85,
        transition: 'all 0.2s ease-in-out',
        ...style,
      }}
    />
  );
};

export default FileIcon;
