// Enhanced FileExplorer types based on the enhancement plan
import type { FileNode } from '../../types/state';

export interface EnhancedFileNode
  extends Omit<FileNode, 'size' | 'lastModified' | 'content' | 'language'> {
  parentId?: string;
  depth: number;
  isVisible: boolean;
  children: EnhancedFileNode[];
  dragState?: 'dragging' | 'hover' | 'dropping';
  theme?: {
    color: string;
    glow: boolean;
    pattern: string;
  };
  size: number;
  lastModified: Date;
  content?: string;
  language?: string;
}

export interface DragContext {
  sourceFiles: EnhancedFileNode[];
  targetFolder?: EnhancedFileNode;
  dragPosition: { x: number; y: number };
  isValidDrop: boolean;
  dragPreview?: React.ReactElement;
}

export interface FileExplorerState {
  files: EnhancedFileNode[];
  selectedFiles: Set<string>;
  expandedFolders: Set<string>;
  dragContext: DragContext | null;
  viewOptions: {
    viewMode: 'tree' | 'list' | 'grid';
    sortBy: 'name' | 'type' | 'modified' | 'size';
    sortOrder: 'asc' | 'desc';
    showHidden: boolean;
    compactMode: boolean;
  };
  ui: {
    searchQuery: string;
    isLoading: boolean;
    bulkMode: boolean;
    theme: 'neural' | 'classic' | 'dark';
  };
}

export interface FileExplorerProps {
  className?: string;
  onFileSelect?: (file: EnhancedFileNode) => void;
  onFileOpen?: (file: EnhancedFileNode) => void;
  onFileCreate?: (parentPath: string, name: string, type: 'file' | 'folder') => void;
  onFileDelete?: (file: EnhancedFileNode) => void;
  onFileRename?: (file: EnhancedFileNode, newName: string) => void;
  onFileMove?: (file: EnhancedFileNode, targetPath: string) => void;
  showToolbar?: boolean;
  showSearch?: boolean;
  theme?: 'neural' | 'classic' | 'dark';
}
