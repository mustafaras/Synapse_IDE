export type Semver = `${number}.${number}.${number}`;
export type VersionRange = 'latest' | `^${Semver}` | `~${Semver}` | Semver | string; // allow aliases like 'stable'

export interface PromptMeta {
  id: string;
  versions: Semver[]; // sorted ascending
  aliases?: Record<string, Semver>;
  description?: string;
}

export interface PromptRecord {
  meta: PromptMeta;
  files: Record<Semver, string>;
}

export interface Registry {
  records: PromptRecord[];
}
