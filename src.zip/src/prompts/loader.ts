import type { Registry, VersionRange } from './types';
import { resolveVersion } from './version';

type Params = Record<string, string | number | boolean>;
const varRx = /\{\{\s*([A-Z0-9_:.|-]+)\s*\}\}/gi;

// Support Vite raw imports for prompt files
const files = import.meta.glob('/src/prompts/**', { query: '?raw', import: 'default', eager: true }) as Record<string, string>;
const registry: Registry = (() => {
  const raw = files['/src/prompts/registry.json'];
  if (!raw) throw new Error('Prompt registry not found');
  try {
    return JSON.parse(raw) as Registry;
  } catch {
    throw new Error('Failed to parse /src/prompts/registry.json');
  }
})();

export function interpolate(input: string, params: Params): string {
  return input.replace(varRx, (match: string, key: string) => {
    const k = String(key);
    const v = params[k];
    // If missing, keep token intact so unresolved check can catch it
    if (v === undefined || v === null) return match;
    return String(v);
  });
}

function readPromptFile(rel: string): string {
  const p = `/src/prompts/${rel}`;
  if (files && files[p]) return files[p];
  throw new Error(`Prompt file not found: ${rel}`);
}

export function loadPrompt(id: string, range: VersionRange, params: Params) {
  const rec = registry.records.find(r => r.meta.id === id);
  if (!rec) throw new Error(`Prompt not found: ${id}`);
  const ver = resolveVersion(rec.meta, range);
  const rel = rec.files[ver];
  if (!rel) throw new Error(`File not found for ${id}@${ver}`);
  const body = readPromptFile(rel);
  const out = interpolate(body, params);
  if (/\{\{\s*[^}]+\s*\}\}/.test(out)) {
    throw new Error(`Unresolved template tokens remain in ${id}@${ver}`);
  }
  return { id, version: ver as string, text: out };
}
