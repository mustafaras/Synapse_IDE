import { loadPrompt } from './loader';
import type { VersionRange } from './types';

export function getPrompt(spec: string, params: Record<string, string | number | boolean>) {
  const [id, rangeRaw] = spec.split('@');
  const range = (rangeRaw ?? 'latest') as VersionRange;
  return loadPrompt(id, range, params);
}
