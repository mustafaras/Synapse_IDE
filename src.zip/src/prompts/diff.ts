export function diffLines(a: string, b: string) {
  const A = a.split('\n');
  const B = b.split('\n');
  const out: Array<{ type: '+' | '-' | ' '; text: string }> = [];
  const len = Math.max(A.length, B.length);
  for (let i = 0; i < len; i++) {
    const l = A[i] ?? '';
    const r = B[i] ?? '';
    if (l === r) out.push({ type: ' ', text: l });
    else {
      out.push({ type: '-', text: l });
      out.push({ type: '+', text: r });
    }
  }
  return out;
}
