import type { PromptMeta, Semver, VersionRange } from './types';

export function resolveVersion(meta: PromptMeta, range: VersionRange): Semver {
  const vs = [...meta.versions];
  if (!vs.length) throw new Error(`No versions for ${meta.id}`);
  // Ensure sorted ascending
  vs.sort((a,b)=>{
    const pa=a.split('.').map(Number); const pb=b.split('.').map(Number);
    return pa[0]-pb[0] || pa[1]-pb[1] || pa[2]-pb[2];
  });
  if (typeof range === 'string' && meta.aliases && meta.aliases[range as string]) {
    return meta.aliases[range as string] as Semver;
  }
  if (range === 'latest') return vs[vs.length-1] as Semver;
  const s = String(range);
  if (s.startsWith('^') || s.startsWith('~')) {
    const base = s.slice(1) as Semver;
    const [maj, min] = base.split('.').map(Number);
    if (s.startsWith('^')) {
      const candidates = vs.filter(v => Number(v.split('.')[0]) === maj);
      const last = candidates.length ? candidates[candidates.length - 1] : vs[vs.length - 1];
      return last as Semver;
    }
    const candidates = vs.filter(v => {
      const [M,m] = v.split('.').map(Number);
      return M === maj && m === min;
    });
    const last = candidates.length ? candidates[candidates.length - 1] : vs[vs.length - 1];
    return last as Semver;
  }
  if (!vs.includes(s as Semver)) throw new Error(`Version ${s} not in registry for ${meta.id}`);
  return s as Semver;
}
