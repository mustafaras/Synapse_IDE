// This file will serve as the entry point for all template definitions and content generators.

import { getTemplateContentByLanguage } from './templateContent';

export { getTemplateContentByLanguage };
