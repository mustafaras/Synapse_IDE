export const flags = {
  aiTrace: Boolean(
    // Enable via env, querystring, or localStorage for convenience
    (import.meta as any)?.env?.VITE_AI_TRACE ||
      (typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('trace') === '1') ||
      (typeof localStorage !== 'undefined' && localStorage.getItem('synapse.flags.aiTrace') === '1')
  ),
  // Enable short test timeouts and testing hooks
  e2e: (() => {
    try {
      // env (Vite), querystring, or localStorage
      const env = (import.meta as any)?.env?.VITE_E2E;
      if (env === '1' || env === true) return true;
      if (typeof window !== 'undefined') {
        const qs = new URLSearchParams(window.location.search).get('e2e');
        if (qs === '1') return true;
      }
      if (typeof localStorage !== 'undefined') {
        const v = localStorage.getItem('synapse.flags.e2e');
        if (v === '1') return true;
      }
    } catch {}
    return false;
  })(),
  a11yEnabled: (() => {
    try {
      if (typeof localStorage !== 'undefined') {
        const v = localStorage.getItem('synapse.flags.a11y');
        if (v === '0') return false;
        if (v === '1') return true;
      }
      if (typeof window !== 'undefined') {
        const qs = new URLSearchParams(window.location.search).get('a11y');
        if (qs === '0') return false;
        if (qs === '1') return true;
      }
    } catch {}
    return false; // default disabled
  })(), // a11y removed
} as const;
