import { flags } from './flags';

// Centralized client-side timeouts for chat lifecycle and SSE
// Values intentionally short under e2e to speed up tests.
const PROD = {
  idleMs: 25_000,     // no chunks idle timeout
  hardMs: 120_000,    // hard cap for a request
  retryBackoffMs: 800,
  sseOpenMs: 10_000,  // time to establish SSE connection
};

const E2E = {
  idleMs: 1_200,
  hardMs: 6_000,
  retryBackoffMs: 100,
  sseOpenMs: 1_000,
};

export const timeouts = flags.e2e ? E2E : PROD;
export type Timeouts = typeof timeouts;
