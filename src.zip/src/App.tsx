/* eslint-disable no-console, @typescript-eslint/no-explicit-any, react/jsx-no-bind */
import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { GlobalStyles } from './styles/GlobalStyles';
import { Button, Input } from './components/atoms';
import StatusBar from './components/StatusBar/StatusBar';
import { NewProjectModal } from './components/molecules';
import { ErrorBoundary, TestHarness } from './components/utilities';
import { AiAssistant } from './components/ai';
import SynapseHomepage from './components/templates/SynapseHomepage';
import { EnhancedIDE } from './components/ide/EnhancedIDE';
import { FileExplorer } from './components/file-explorer';
import { Bot, Code, FolderOpen, Monitor, Moon, Plus, Sun } from 'lucide-react';
import { storage } from './services';
import { initializeSampleData } from './utils/sampleData';
import { wireNetworkEvents } from './utils/resilience/netEvents';
import { flags } from './config/flags';

// DEV-only Observability HUD was previously mounted here. Hidden per request.

const ThemeToggle: React.FC = () => {
  const { themeName, toggleTheme } = useTheme();

  const getIcon = () => {
    switch (themeName) {
      case 'light':
        return <Sun size={16} />;
      case 'dark':
        return <Moon size={16} />;
      case 'neutral':
        return <Monitor size={16} />;
      default:
        return <Monitor size={16} />;
    }
  };

  return (
    <Button
      className="active-chip focus-ring"
      variant="ghost"
      size="sm"
      onClick={toggleTheme}
      icon={getIcon()}
      aria-label={`Switch to ${themeName === 'light' ? 'dark' : themeName === 'dark' ? 'neutral' : 'light'} theme`}
    >
      {themeName}
    </Button>
  );
};

const DemoPage: React.FC = () => {
  useEffect(() => { wireNetworkEvents(); }, []);
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);
  const [recentProjects, setRecentProjects] = useState(() => storage.getRecentProjects());

  const handleCreateProject = async (projectData: {
    name: string;
    template: string;
    description?: string;
  }) => {
    // Create new project
    const newProject = {
      id: Date.now().toString(),
      name: projectData.name,
      template: projectData.template,
      description: projectData.description,
      createdAt: new Date().toISOString(),
    };

    // Add to recent projects
    const updatedProjects = [newProject, ...recentProjects].slice(0, 10);
    setRecentProjects(updatedProjects);
    storage.setRecentProjects(updatedProjects);

    console.log('Project created:', newProject);
  };

  const handleOpenProject = (project: any) => {
    console.log('Opening project:', project);
    // TODO: Implement project opening logic
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        background: 'var(--color-background)',
        fontFamily: 'var(--font-family-primary)',
        transition: 'all 300ms var(--timing-function-global)',
      }}
    >
      <header
        className="glass-surface"
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 100,
          background: 'var(--glass-background)',
          backdropFilter: 'var(--blur-glass)',
          WebkitBackdropFilter: 'var(--blur-glass)',
          borderBottom: '1px solid var(--color-border)',
        }}
      >
        <div
          className="container"
          style={{
            maxWidth: '1440px',
            margin: '0 auto',
            paddingInline: 'clamp(1rem, 5vw, 4rem)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: 'var(--spacing-lg) clamp(1rem, 5vw, 4rem)',
            transition: 'all 300ms var(--timing-function-global)',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-md)' }}>
            <div
              style={{
                background: 'linear-gradient(135deg, var(--color-primary), var(--color-accent))',
                borderRadius: 'var(--border-radius-md)',
                padding: 'var(--spacing-sm)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Code size={24} color="white" />
            </div>
            <div>
              <h1
                className="glow-text"
                style={{
                  margin: 0,
                  fontSize: 'var(--font-size-xl)',
                  fontFamily: 'var(--font-family-brand)',
                  fontWeight: 'var(--font-weight-bold)',
                  lineHeight: 'var(--line-height-tight)',
                }}
              >
                SynapseIDE
              </h1>
              <p
                style={{
                  margin: 0,
                  fontSize: 'var(--font-size-xs)',
                  color: 'var(--color-text-secondary)',
                  fontFamily: 'var(--font-family-primary)',
                }}
              >
                Professional Development Environment
              </p>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-sm)' }}>
            <Button
              className="active-chip focus-ring"
              variant="ghost"
              size="sm"
              onClick={() => setIsAiAssistantOpen(true)}
              icon={<Bot size={16} />}
              aria-label="Open AI Assistant"
            >
              AI Assistant
            </Button>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Hero Section - Enhanced with scalable SVG logo and proper hierarchy */}
      <section
        style={{
          background: `linear-gradient(135deg, 
            var(--color-background) 0%, 
            var(--color-primary)05 50%, 
            var(--color-background) 100%)`,
          borderBottom: '1px solid var(--color-border)',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        <div
          className="container"
          style={{
            maxWidth: '1440px',
            margin: '0 auto',
            paddingInline: 'clamp(1rem, 5vw, 4rem)',
            padding: 'var(--spacing-xxl) clamp(1rem, 5vw, 4rem) var(--spacing-xl)',
            textAlign: 'center',
            position: 'relative',
          }}
        >
          {/* Enhanced SVG Logo with pulse-glow animation */}
          <div
            style={{
              display: 'flex',
              justifyContent: 'center',
              marginBottom: 'var(--spacing-lg)',
              animation: 'pulse-glow 3s ease-in-out infinite',
            }}
          >
            <svg
              width="80"
              height="80"
              viewBox="0 0 80 80"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              style={{
                minWidth: '80px',
                minHeight: '80px',
                filter: 'drop-shadow(0 0 20px currentColor)',
              }}
            >
              <defs>
                <linearGradient id="logo-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="var(--logo-color-primary)" />
                  <stop offset="100%" stopColor="var(--logo-color-secondary)" />
                </linearGradient>
              </defs>
              {/* Neural network inspired logo */}
              <circle
                cx="40"
                cy="40"
                r="38"
                stroke="url(#logo-gradient)"
                strokeWidth="2"
                fill="none"
                opacity="0.3"
              />
              <circle
                cx="40"
                cy="40"
                r="28"
                stroke="url(#logo-gradient)"
                strokeWidth="2"
                fill="none"
                opacity="0.5"
              />
              <circle
                cx="40"
                cy="40"
                r="18"
                stroke="url(#logo-gradient)"
                strokeWidth="2"
                fill="none"
                opacity="0.7"
              />
              <circle cx="40" cy="40" r="8" fill="url(#logo-gradient)" />
              {/* Neural connections */}
              <line
                x1="20"
                y1="20"
                x2="35"
                y2="35"
                stroke="url(#logo-gradient)"
                strokeWidth="1.5"
                opacity="0.6"
              />
              <line
                x1="60"
                y1="20"
                x2="45"
                y2="35"
                stroke="url(#logo-gradient)"
                strokeWidth="1.5"
                opacity="0.6"
              />
              <line
                x1="20"
                y1="60"
                x2="35"
                y2="45"
                stroke="url(#logo-gradient)"
                strokeWidth="1.5"
                opacity="0.6"
              />
              <line
                x1="60"
                y1="60"
                x2="45"
                y2="45"
                stroke="url(#logo-gradient)"
                strokeWidth="1.5"
                opacity="0.6"
              />
              {/* Corner nodes */}
              <circle cx="20" cy="20" r="3" fill="url(#logo-gradient)" opacity="0.8" />
              <circle cx="60" cy="20" r="3" fill="url(#logo-gradient)" opacity="0.8" />
              <circle cx="20" cy="60" r="3" fill="url(#logo-gradient)" opacity="0.8" />
              <circle cx="60" cy="60" r="3" fill="url(#logo-gradient)" opacity="0.8" />
            </svg>
          </div>

          {/* Welcome text with proper styling */}
          <p
            style={{
              fontSize: '0.875rem',
              fontWeight: '500',
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              color: 'var(--color-text-secondary)',
              margin: '0 0 var(--spacing-md) 0',
              fontFamily: 'var(--font-family-primary)',
            }}
          >
            Welcome To
          </p>

          {/* SynapseIDE with gradient and glow */}
          <h1
            style={{
              fontSize: 'clamp(3.5rem, 8vw, 5rem)',
              fontWeight: '800',
              lineHeight: '0.9',
              margin: '0 0 var(--spacing-lg) 0',
              background: 'linear-gradient(135deg, #3B82F6 0%, #9333EA 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              textShadow: '0 0 40px rgba(59, 130, 246, 0.5)',
              fontFamily: 'var(--font-family-brand)',
              letterSpacing: '-0.02em',
              filter: 'drop-shadow(0 0 20px rgba(59, 130, 246, 0.3))',
            }}
          >
            SynapseIDE
          </h1>

          {/* Tagline with small-caps and proper spacing */}
          <p
            style={{
              fontSize: '1.125rem',
              fontWeight: '600',
              fontVariant: 'small-caps',
              letterSpacing: '1rem',
              color: 'rgba(255, 255, 255, 0.6)',
              margin: '0 0 var(--spacing-xl) 0',
              fontFamily: 'var(--font-family-primary)',
              textShadow: '0 2px 4px rgba(0, 0, 0, 0.3)',
            }}
          >
            The Future of Development
          </p>

          {/* Feature badges */}
          <div
            style={{
              display: 'flex',
              justifyContent: 'center',
              gap: 'var(--spacing-md)',
              flexWrap: 'wrap',
            }}
          >
            <div className="active-chip" style={{ padding: 'var(--spacing-xs) var(--spacing-md)' }}>
              <span
                style={{
                  fontFamily: 'var(--font-family-primary)',
                  fontSize: 'var(--font-size-sm)',
                }}
              >
                ⚡ Inter Typography
              </span>
            </div>
            <div
              className="active-chip"
              style={{
                padding: 'var(--spacing-xs) var(--spacing-md)',
                display: 'flex',
                alignItems: 'center',
                gap: 'var(--spacing-xs)',
                background:
                  'linear-gradient(135deg, rgba(255, 215, 0, 0.1), rgba(255, 215, 0, 0.05))',
                border: '1px solid rgba(255, 215, 0, 0.3)',
                borderRadius: '6px',
                transition: 'all 0.3s ease',
              }}
            >
              <div
                style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  background: 'linear-gradient(45deg, #FFD700, #B8860B)',
                }}
              />
              <span
                style={{
                  fontFamily: 'var(--font-family-primary)',
                  fontSize: 'var(--font-size-sm)',
                  fontWeight: '600',
                  color: '#FFD700',
                  letterSpacing: '0.5px',
                }}
              >
                Glassmorphism
              </span>
            </div>
            <div
              className="active-chip"
              style={{
                padding: 'var(--spacing-xs) var(--spacing-md)',
                display: 'flex',
                alignItems: 'center',
                gap: 'var(--spacing-xs)',
                background:
                  'linear-gradient(135deg, rgba(255, 215, 0, 0.1), rgba(255, 215, 0, 0.05))',
                border: '1px solid rgba(255, 215, 0, 0.3)',
                borderRadius: '6px',
                transition: 'all 0.3s ease',
              }}
            >
              <div
                style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '2px',
                  background: 'linear-gradient(45deg, #FFD700, #B8860B)',
                }}
              />
              <span
                style={{
                  fontFamily: 'var(--font-family-primary)',
                  fontSize: 'var(--font-size-sm)',
                  fontWeight: '600',
                  color: '#FFD700',
                  letterSpacing: '0.5px',
                }}
              >
                12-Column Grid
              </span>
            </div>
            <div
              className="active-chip"
              style={{
                padding: 'var(--spacing-xs) var(--spacing-md)',
                display: 'flex',
                alignItems: 'center',
                gap: 'var(--spacing-xs)',
                background:
                  'linear-gradient(135deg, rgba(255, 215, 0, 0.1), rgba(255, 215, 0, 0.05))',
                border: '1px solid rgba(255, 215, 0, 0.3)',
                borderRadius: '6px',
                transition: 'all 0.3s ease',
              }}
            >
              <div
                style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  background: 'linear-gradient(45deg, #6A9955, #4CAF50)',
                }}
              />
              <span
                style={{
                  fontFamily: 'var(--font-family-primary)',
                  fontSize: 'var(--font-size-sm)',
                  fontWeight: '600',
                  color: '#6A9955',
                  letterSpacing: '0.5px',
                }}
              >
                Max Contrast
              </span>
            </div>
          </div>
        </div>
      </section>

      <main
        style={{
          flex: 1,
          background: 'var(--color-background)',
          transition: 'all 300ms var(--timing-function-global)',
          padding: 'var(--spacing-xl) 0',
        }}
      >
        <div
          className="container"
          style={{
            maxWidth: '1440px',
            margin: '0 auto',
            paddingInline: 'clamp(1rem, 5vw, 4rem)',
          }}
        >
          <div className="grid" style={{ gap: 'var(--spacing-lg)', alignItems: 'start' }}>
            {/* Welcome Card - Enhanced with better hierarchy */}
            <div className="col-12 col-md-6">
              <div
                className="glass-surface"
                style={{ padding: 'var(--spacing-xl)', height: '100%' }}
              >
                <div style={{ marginBottom: 'var(--spacing-lg)' }}>
                  <h2
                    className="glow-text"
                    style={{
                      marginBottom: 'var(--spacing-md)',
                      fontSize: 'var(--font-size-xxl)',
                      fontFamily: 'var(--font-family-brand)',
                      fontWeight: 'var(--font-weight-bold)',
                      lineHeight: 'var(--line-height-tight)',
                    }}
                  >
                    Welcome to SynapseIDE
                  </h2>
                  <p
                    style={{
                      color: 'var(--color-text-secondary)',
                      fontFamily: 'var(--font-family-primary)',
                      fontSize: 'var(--font-size-md)',
                      lineHeight: 'var(--line-height-relaxed)',
                      marginBottom: 'var(--spacing-lg)',
                    }}
                  >
                    A revolutionary IDE with advanced AI assistance, glassmorphism design, and
                    maximum contrast for accessibility. Built with modern web technologies and
                    Bauhaus design principles.
                  </p>
                </div>

                {/* Action buttons with improved spacing */}
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
                    gap: 'var(--spacing-md)',
                    marginBottom: 'var(--spacing-lg)',
                  }}
                >
                  <Button
                    className="focus-ring"
                    variant="primary"
                    icon={<Plus size={16} />}
                    onClick={() => setIsNewProjectModalOpen(true)}
                  >
                    New Project
                  </Button>
                  <Button
                    className="focus-ring"
                    variant="secondary"
                    icon={<FolderOpen size={16} />}
                  >
                    Open File
                  </Button>
                </div>

                {/* Enhanced search input */}
                <div className="focus-ring">
                  <Input
                    label="Quick Search"
                    placeholder="Search projects, files, or commands..."
                  />
                </div>
              </div>
            </div>

            {/* Recent Projects Card - Enhanced layout */}
            <div className="col-12 col-md-6">
              <div
                className="glass-surface"
                style={{ padding: 'var(--spacing-xl)', height: '100%' }}
              >
                <h3
                  className="glow-text"
                  style={{
                    marginBottom: 'var(--spacing-lg)',
                    fontSize: 'var(--font-size-xl)',
                    fontFamily: 'var(--font-family-brand)',
                    fontWeight: 'var(--font-weight-semibold)',
                    lineHeight: 'var(--line-height-tight)',
                  }}
                >
                  Recent Projects
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--spacing-sm)' }}>
                  {recentProjects.length > 0 ? (
                    recentProjects.slice(0, 5).map((project: any, index: number) => (
                      <div
                        key={project.id || index}
                        className="active-chip focus-ring"
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleOpenProject(project); } }}
                        onClick={() => handleOpenProject(project)}
                        style={{
                          padding: 'var(--spacing-md)',
                          cursor: 'pointer',
                          borderRadius: 'var(--border-radius-md)',
                          transition: 'all 300ms var(--timing-function-global)',
                        }}
                      >
                        <div
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                          }}
                        >
                          <div>
                            <div
                              style={{
                                color: 'var(--color-text)',
                                fontWeight: 'var(--font-weight-medium)',
                                fontFamily: 'var(--font-family-primary)',
                                fontSize: 'var(--font-size-md)',
                                marginBottom: 'var(--spacing-xs)',
                              }}
                            >
                              {project.name}
                            </div>
                            {project.template ? <div
                                style={{
                                  fontSize: 'var(--font-size-sm)',
                                  color: 'var(--color-text-secondary)',
                                  fontFamily: 'var(--font-family-primary)',
                                }}
                              >
                                {project.template}
                              </div> : null}
                          </div>
                          <Button variant="ghost" size="sm" className="focus-ring">
                            Open
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div
                      className="glass-surface"
                      style={{
                        padding: 'var(--spacing-xl)',
                        textAlign: 'center',
                        border: '2px dashed var(--color-border)',
                        borderRadius: 'var(--border-radius-lg)',
                      }}
                    >
                      <p
                        style={{
                          color: 'var(--color-text-secondary)',
                          fontStyle: 'italic',
                          fontFamily: 'var(--font-family-primary)',
                          fontSize: 'var(--font-size-md)',
                          margin: 0,
                        }}
                      >
                        No recent projects. Create your first project to get started!
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Features Card - Enhanced with better visual hierarchy */}
            <div className="col-12">
              <div className="glass-surface" style={{ padding: 'var(--spacing-xl)' }}>
                <div style={{ textAlign: 'center', marginBottom: 'var(--spacing-xl)' }}>
                  <h3
                    className="glow-text"
                    style={{
                      marginBottom: 'var(--spacing-md)',
                      fontSize: 'var(--font-size-xxl)',
                      fontFamily: 'var(--font-family-brand)',
                      fontWeight: 'var(--font-weight-bold)',
                      lineHeight: 'var(--line-height-tight)',
                    }}
                  >
                    Powerful IDE Features
                  </h3>
                  <p
                    style={{
                      color: 'var(--color-text-secondary)',
                      fontFamily: 'var(--font-family-primary)',
                      fontSize: 'var(--font-size-lg)',
                      lineHeight: 'var(--line-height-relaxed)',
                      maxWidth: '600px',
                      margin: '0 auto',
                    }}
                  >
                    Experience next-generation development tools designed for modern workflows
                  </p>
                </div>

                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                    gap: 'var(--spacing-lg)',
                    maxWidth: '1200px',
                    margin: '0 auto',
                  }}
                >
                  {[
                    {
                      name: 'Monaco Editor',
                      desc: 'Industry-standard code editor with advanced IntelliSense',
                      icon: '⚡',
                    },
                    {
                      name: 'AI Assistant',
                      desc: 'Intelligent code completion and AI-powered suggestions',
                      icon: '🤖',
                    },
                    {
                      name: 'Multi-Language',
                      desc: 'Support for 30+ programming languages and frameworks',
                      icon: '🌐',
                    },
                    {
                      name: 'Git Integration',
                      desc: 'Built-in version control with visual diff and merge tools',
                      icon: '🔄',
                    },
                    {
                      name: 'Live Collaboration',
                      desc: 'Real-time team coding with synchronized editing',
                      icon: '👥',
                    },
                    {
                      name: 'Plugin System',
                      desc: 'Extensible architecture with rich ecosystem support',
                      icon: '🔧',
                    },
                  ].map((feature, index) => (
                    <div
                      key={index}
                      className="active-chip focus-ring"
                      style={{
                        padding: 'var(--spacing-lg)',
                        textAlign: 'center',
                        background: 'var(--glass-background)',
                        border: '1px solid var(--glass-border)',
                        borderRadius: 'var(--border-radius-lg)',
                        transition: 'all 300ms var(--timing-function-global)',
                        cursor: 'pointer',
                      }}
                    >
                      <div
                        style={{
                          fontSize: '2rem',
                          marginBottom: 'var(--spacing-md)',
                          lineHeight: 1,
                        }}
                      >
                        {feature.icon}
                      </div>
                      <h4
                        style={{
                          margin: 0,
                          marginBottom: 'var(--spacing-sm)',
                          fontSize: 'var(--font-size-lg)',
                          fontWeight: 'var(--font-weight-semibold)',
                          color: 'var(--color-text)',
                          fontFamily: 'var(--font-family-brand)',
                          lineHeight: 'var(--line-height-tight)',
                        }}
                      >
                        {feature.name}
                      </h4>
                      <p
                        style={{
                          margin: 0,
                          fontSize: 'var(--font-size-sm)',
                          color: 'var(--color-text-secondary)',
                          lineHeight: 'var(--line-height-relaxed)',
                          fontFamily: 'var(--font-family-primary)',
                        }}
                      >
                        {feature.desc}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      {/* Developer-only test harness toggle via ?tests=1 */}
      {(() => {
        try {
          const sp = new URLSearchParams(window.location.search);
          if (sp.get('tests') === '1') {
            return <TestHarness />;
          }
        } catch {}
        return null;
      })()}

      <footer
        className="glass-surface"
        style={{
          marginTop: 'auto',
          background: 'var(--glass-background)',
          borderTop: '1px solid var(--color-border)',
          backdropFilter: 'var(--blur-glass)',
          WebkitBackdropFilter: 'var(--blur-glass)',
        }}
      >
        <div
          className="container"
          style={{
            maxWidth: '1440px',
            margin: '0 auto',
            paddingInline: 'clamp(1rem, 5vw, 4rem)',
            padding: 'var(--spacing-lg) clamp(1rem, 5vw, 4rem)',
            textAlign: 'center',
          }}
        >
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
              gap: 'var(--spacing-lg)',
              alignItems: 'center',
              marginBottom: 'var(--spacing-md)',
            }}
          >
            <div>
              <h4
                className="glow-text"
                style={{
                  margin: 0,
                  marginBottom: 'var(--spacing-xs)',
                  fontSize: 'var(--font-size-md)',
                  fontFamily: 'var(--font-family-brand)',
                  fontWeight: 'var(--font-weight-semibold)',
                }}
              >
                SynapseIDE
              </h4>
              <p
                style={{
                  margin: 0,
                  color: 'var(--color-text-secondary)',
                  fontSize: 'var(--font-size-sm)',
                  fontFamily: 'var(--font-family-primary)',
                }}
              >
                Next-generation development environment
              </p>
            </div>

            <div>
              <p
                style={{
                  margin: 0,
                  color: 'var(--color-text-secondary)',
                  fontSize: 'var(--font-size-sm)',
                  fontFamily: 'var(--font-family-primary)',
                  lineHeight: 'var(--line-height-relaxed)',
                }}
              >
                Built with ❤️ using React, TypeScript, and Bauhaus design principles.
                <br />
                <span className="glow-text" style={{ fontSize: 'var(--font-size-xs)' }}>
                  Experience the future of development
                </span>
              </p>
            </div>
          </div>

          <div
            style={{
              paddingTop: 'var(--spacing-md)',
              borderTop: '1px solid var(--color-border)',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              gap: 'var(--spacing-sm)',
            }}
          >
            <span
              style={{
                fontSize: 'var(--font-size-xs)',
                color: 'var(--color-text-secondary)',
                fontFamily: 'var(--font-family-primary)',
              }}
            >
              Design System: Glassmorphism • Typography: Inter/Poppins • Animation:
              cubic-bezier(0.4, 0, 0.2, 1)
            </span>
          </div>
        </div>
      </footer>

      {/* AI Assistant Modal */}
      {isAiAssistantOpen ? <AiAssistant onClose={() => setIsAiAssistantOpen(false)} /> : null}

      {/* New Project Modal */}
      {isNewProjectModalOpen ? <NewProjectModal
          isOpen={isNewProjectModalOpen}
          onClose={() => setIsNewProjectModalOpen(false)}
          onCreateProject={handleCreateProject}
        /> : null}
    </div>
  );
};

const MainApp: React.FC = () => {
  const [currentView, setCurrentView] = useState<'homepage' | 'demo' | 'ide' | 'fileexplorer'>(() => {
    // In E2E mode, start directly in IDE to simplify automation
    if (flags.e2e) return 'ide';
    try {
      const sp = new URLSearchParams(window.location.search);
      const v = sp.get('view');
      if (v === 'ide' || v === 'homepage' || v === 'demo' || v === 'fileexplorer') return v as any;
    } catch {}
    return 'homepage';
  }); // Homepage ile başla

  // Initialize sample data and listen for home navigation events from IDE
  useEffect(() => {
    // Initialize sample data for file explorer
    initializeSampleData();

    const handleNavigateToHome = (event: CustomEvent) => {
      console.log('🏠 Received home navigation event from:', event.detail?.source);
      setCurrentView('homepage');
    };

    window.addEventListener('navigateToHome', handleNavigateToHome as EventListener);

    // E2E helpers (no UI changes). This is safe and only used in tests.
    try {
      if (flags.e2e && typeof window !== 'undefined') {
        (window as any).e2e = (window as any).e2e || {};
        (window as any).e2e.setView = (v: 'homepage'|'demo'|'ide'|'fileexplorer') => setCurrentView(v);
      }
    } catch {}

  return () => {
      window.removeEventListener('navigateToHome', handleNavigateToHome as EventListener);
    };
  }, []);

  const handleLaunchWorkspace = () => {
    console.log('🚀 Launch workspace clicked');
    setCurrentView('ide');
  };

  const handleExploreFeatures = () => {
    console.log('🚀 Explore features clicked');
    setCurrentView('demo');
  };

  // const _handleFileExplorer = () => {
  //   console.log('📁 File Explorer clicked');
  //   setCurrentView('fileexplorer');
  // };

  const handleBackToHome = () => {
    console.log('🏠 Back to home clicked');
    setCurrentView('homepage');
  };

  // Show homepage, demo or IDE based on state
  return (
    <div style={{ minHeight: '100vh', paddingBottom: '22px' }}>
      {currentView === 'homepage' ? (
        <SynapseHomepage onLaunchIDE={handleLaunchWorkspace} onSettings={handleExploreFeatures} />
      ) : currentView === 'ide' ? (
        <div style={{ position: 'relative' }} data-testid="ide-root">
          <EnhancedIDE />
        </div>
      ) : currentView === 'fileexplorer' ? (
        // FileExplorer view
        <div style={{ position: 'relative', minHeight: '100vh' }}>
          {/* Back to home button */}
          <div
            style={{
              position: 'fixed',
              top: '20px',
              left: '20px',
              zIndex: 1000,
            }}
          >
            <Button icon={<FolderOpen />} onClick={handleBackToHome} className="glass-button" />
          </div>
          <div style={{ padding: '60px 20px 20px 20px' }}>
            <FileExplorer />
          </div>
        </div>
      ) : (
        // Demo view
        <div style={{ position: 'relative' }}>
          {/* Back to home button */}
          <div
            style={{
              position: 'fixed',
              top: 'var(--spacing-md)',
              left: 'var(--spacing-md)',
              zIndex: 1000,
            }}
          >
            <div
              className="glass-surface"
              style={{
                padding: 'var(--spacing-xs)',
              }}
            >
              <Button
                className="focus-ring"
                variant="ghost"
                size="sm"
                onClick={handleBackToHome}
                icon={<Code size={16} />}
              >
                Back to Home
              </Button>
            </div>
          </div>
          <DemoPage />
        </div>
      )}

      {/* Status Bar - Sadece IDE modunda göster */}
      {currentView === 'ide' && (
        <StatusBar
          language="javascript"
          content="// Welcome to Synapse IDE"
          cursorPosition={{ line: 1, column: 1 }}
          encoding="UTF-8"
          lineEnding="LF"
          tabSize={2}
          indentation="spaces"
          fontSize={14}
          errors={0}
          warnings={0}
          isLiveServer={false}
          gitBranch="main"
          isModified={false}
        />
      )}
    </div>
  );
};

function App() {
  console.log('🚀 App component rendering...');

  return (
    <ErrorBoundary>
      <ThemeProvider>
        <GlobalStyles />
        <Router>
          <MainApp />
        </Router>
        {/* Observability (DEV) HUD hidden */}
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
