import { useEffect, useRef, useState } from 'react';

/**
 * useLiveRegion
 * - Batches announcements into a single polite live region to reduce verbosity.
 * - Trims messages and enforces a max length per announce.
 * - Returns { node, announce, clear } where `node` should be rendered in the tree.
 */
export function useLiveRegion(options?: { maxLen?: number; flushMs?: number }) {
  const maxLen = options?.maxLen ?? 200;
  const flushMs = options?.flushMs ?? 400;
  const [text, setText] = useState('');
  const queueRef = useRef<string[]>([]);
  const timerRef = useRef<number | null>(null);

  const flush = () => {
    const q = queueRef.current;
    if (!q.length) return;
    const joined = q.join(' ').replace(/\s+/g, ' ').trim();
    queueRef.current = [];
    const out = joined.length > maxLen ? `${joined.slice(0, maxLen - 1)  }…` : joined;
    setText(out);
  };

  const schedule = () => {
    if (timerRef.current) return;
    timerRef.current = window.setTimeout(() => {
      timerRef.current = null;
      flush();
    }, flushMs);
  };

  const announce = (msg: string) => {
    if (!msg) return;
    queueRef.current.push(String(msg));
    schedule();
  };

  const clear = () => {
    queueRef.current = [];
    setText('');
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current); }, []);

  const node = (
    <div aria-live="polite" aria-atomic="true" className="sr-only">{text}</div>
  );

  return { node, announce, clear } as const;
}

export default useLiveRegion;
