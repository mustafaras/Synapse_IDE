// Re-export from .tsx to avoid JSX parse errors in .ts files
// a11y removed
