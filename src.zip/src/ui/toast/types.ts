export type ToastKind = 'success' | 'error' | 'warning' | 'info';

export interface ToastAction {
  label: string;
  onClick?: () => void;
}

export interface ToastItem {
  id: string;
  kind: ToastKind;
  message: string;
  title?: string | undefined;
  duration?: number; // ms; 0 or undefined means default; negative disables auto dismiss
  contextKey?: string | undefined; // used for dedupe/rate-limit
  action?: ToastAction | undefined;
  createdAt: number;
}

export interface ShowToastInput {
  kind: ToastKind;
  message: string;
  title?: string;
  duration?: number;
  contextKey?: string;
  action?: ToastAction;
}
