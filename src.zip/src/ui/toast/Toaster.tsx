import React from 'react';
import { createPortal } from 'react-dom';
import { useToastStore } from './store';
import './Toaster.css';

// Uses the existing .ai-toast styles for visual parity
export const Toaster: React.FC = () => {
  const items = useToastStore(s => s.items);
  const dismiss = useToastStore(s => s.dismiss);

  if (typeof document === 'undefined') return null;
  const container = document.body;

  const handleActionClick = (id: string, cb?: () => void) => () => {
    try { cb?.(); } finally { dismiss(id); }
  };
  const handleDismissClick = (id: string) => () => dismiss(id);

  return createPortal(
    <div className="ai-toaster-layer" data-testid="toaster">
      <div className="ai-toaster-stack">
        {items.map(t => (
          <div key={t.id} className={`ai-toast ai-toast--${t.kind}`} data-autofade={t.duration !== undefined && t.duration > 0 ? 'true' : 'false'} data-testid="toast" data-kind={t.kind}>
            <div className="ai-toast__content">
              {t.title ? <strong className="ai-toast__title">{t.title}</strong> : null}
              <span>{t.message}</span>
            </div>
            {t.action ? (
              <button className="ai-toast__action" onClick={handleActionClick(t.id, t.action.onClick)}>{t.action.label}</button>
            ) : null}
            {t.kind === 'error' ? (
              <button className="ai-toast__dismiss" onClick={handleDismissClick(t.id)}>Dismiss</button>
            ) : null}
          </div>
        ))}
      </div>
    </div>,
    container
  );
};

export default Toaster;
