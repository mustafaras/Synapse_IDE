export type KeyChord = string;

export interface KeyEventContext {
  isComposing: () => boolean;
  toChord: (e: KeyboardEvent) => KeyChord;
}

export interface KeyScope {
  id: string;
  /** Higher number wins. */
  priority: number;
  /** Whether this scope is currently active. Defaults to true. */
  when?: () => boolean;
  /** Return true to consume the event. */
  onKeyDown?: (e: KeyboardEvent, ctx: KeyEventContext) => boolean | void;
  /** Return true to consume the event. */
  onKeyUp?: (e: KeyboardEvent, ctx: KeyEventContext) => boolean | void;
}
