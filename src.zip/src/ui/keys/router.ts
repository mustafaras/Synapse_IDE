import type { KeyChord, KeyEventContext, KeyScope } from './types';
import { getActiveElement, isComposingIME, isTextInputLike } from './dom';

// Simple global router with priority ordering
class KeyRouter {
  private scopes: KeyScope[] = [];
  private attached = false;

  attach() {
    if (this.attached) return;
    this.attached = true;

    const ctx: KeyEventContext = {
      isComposing: () => this.isComposing,
      toChord: (e) => toChord(e),
    };

    window.addEventListener(
      'keydown',
      (ev) => this.dispatch('down', ev, ctx),
      { capture: true }
    );
    window.addEventListener(
      'keyup',
      (ev) => this.dispatch('up', ev, ctx),
      { capture: true }
    );
  }

  private composing = false;
  private get isComposing() {
    return this.composing;
  }

  register(scope: KeyScope) {
    this.scopes.push(scope);
    this.sortScopes();
    return () => this.unregister(scope.id);
  }

  unregister(id: string) {
    this.scopes = this.scopes.filter((s) => s.id !== id);
  }

  private sortScopes() {
    this.scopes.sort((a, b) => b.priority - a.priority);
  }

  private dispatch(phase: 'down' | 'up', e: KeyboardEvent, ctx: KeyEventContext) {
    // Track composition state
    this.composing = isComposingIME(e);

    // If composing, allow text inputs to handle without interference
    if (this.composing) return;

    // Don't interfere with native typing in inputs unless explicitly opted-in via data-chat-input
    const active = getActiveElement();
    if (active && isTextInputLike(active) && !active.hasAttribute('data-chat-input')) {
      return;
    }

    // Walk scopes by priority, first truthy consume wins
    for (const s of this.scopes) {
      if (s.when && !s.when()) continue;
      const handler = phase === 'down' ? s.onKeyDown : s.onKeyUp;
      if (!handler) continue;
      const consumed = !!handler(e, ctx);
      if (consumed) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
    }
  }
}

export const globalKeyRouter = new KeyRouter();

// Public API for registering scopes in React components
export const registerKeyScope = (scope: KeyScope): (() => void) => {
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore - extend global for a simple attach guard
  if (!globalThis.__KEY_ROUTER_ATTACHED__) {
    globalKeyRouter.attach();
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    globalThis.__KEY_ROUTER_ATTACHED__ = true;
  }
  return globalKeyRouter.register(scope);
};

// Utilities
export const toChord = (e: KeyboardEvent): KeyChord => {
  const mods: string[] = [];
  if (e.ctrlKey) mods.push('Ctrl');
  if (e.metaKey) mods.push('Meta');
  if (e.altKey) mods.push('Alt');
  if (e.shiftKey) mods.push('Shift');
  const key = e.key.length === 1 ? e.key.toUpperCase() : e.key;
  return [...mods, key].join('+');
};
