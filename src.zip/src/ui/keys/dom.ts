// Lightweight DOM helpers for focus and composition state

export const isComposingIME = (e: KeyboardEvent): boolean => {
  // Prefer native isComposing when available
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const anyE = e as any;
  if (typeof anyE.isComposing === 'boolean') return anyE.isComposing;
  // Fallback: treat legacy IME signals as composing
  // Note: keyCode is deprecated in standards but still present in browsers
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return e.key === 'Process' || (e as any).keyCode === 229;
};

export const isTextInputLike = (el: Element | null): el is HTMLElement => {
  if (!el || !(el instanceof HTMLElement)) return false;
  const tag = el.tagName.toLowerCase();
  const editable = (el as HTMLElement).isContentEditable;
  if (editable) return true;
  if (tag === 'textarea' || tag === 'input') return true;
  // Custom attribute we add to our chat input
  if (el.hasAttribute('data-chat-input')) return true;
  return false;
};

export const getActiveElement = (): HTMLElement | null => {
  const ae = document.activeElement as HTMLElement | null;
  return ae ?? null;
};
