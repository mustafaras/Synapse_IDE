export interface VirtualItem {
  index: number;
  key: string | number;
  top: number;        // px from start
  size: number;       // measured/estimated height
}

export interface VirtualConfig {
  count: number;
  getKey: (index: number) => string | number;
  estimateSize: (index: number) => number; // e.g., 80
  overscan?: number;  // default 6
}

export interface VirtualState {
  scrollTop: number;
  viewportHeight: number;
  totalSize: number;
  items: VirtualItem[]; // render window
}
