/* eslint-disable */
import * as React from 'react';
import type { VirtualConfig, VirtualItem, VirtualState } from './types';

function binLower(offsets: number[], value: number) {
  let lo = 0, hi = offsets.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (offsets[mid] < value) lo = mid + 1; else hi = mid;
  }
  return lo;
}

export function useVirtual(cfg: VirtualConfig, refScroll: React.RefObject<HTMLElement>) {
  const sizeCache = React.useRef(new Map<number, number>());
  const [state, setState] = React.useState<VirtualState>({
    scrollTop: 0,
    viewportHeight: 0,
    totalSize: 0,
    items: [],
  });

  const update = React.useCallback(() => {
    const sc = refScroll.current;
    if (!sc) return;
    const scrollTop = sc.scrollTop;
    const viewportHeight = sc.clientHeight;
    const count = cfg.count;

    let total = 0;
    const offsets: number[] = new Array(count);
    for (let i = 0; i < count; i++) {
      offsets[i] = total;
      total += sizeCache.current.get(i) ?? cfg.estimateSize(i);
    }

    const overscan = cfg.overscan ?? 6;
    const startIdx = Math.max(0, binLower(offsets, scrollTop) - overscan);
    const endIdx = Math.min(count - 1, binLower(offsets, scrollTop + viewportHeight) + overscan);

    const items: VirtualItem[] = [];
    for (let i = startIdx; i <= endIdx; i++) {
      const top = offsets[i];
      const size = sizeCache.current.get(i) ?? cfg.estimateSize(i);
      items.push({ index: i, key: cfg.getKey(i), top, size });
    }

    setState({ scrollTop, viewportHeight, totalSize: total, items });
  }, [cfg, refScroll]);

  React.useEffect(() => {
    const sc = refScroll.current;
    if (!sc) return;
    const onScroll: EventListener = () => { update(); };
    const ro = new ResizeObserver(() => update());
    sc.addEventListener('scroll', onScroll, { passive: true });
    try { ro.observe(sc); } catch {}
    update();
    function cleanup(): void {
      sc.removeEventListener('scroll', onScroll);
      ro.disconnect();
    }
    return cleanup;
  }, [update, refScroll]);

  const setMeasuredSize = React.useCallback((index: number, px: number) => {
    const prev = sizeCache.current.get(index);
    if (prev && Math.abs(prev - px) < 1) return;
    sizeCache.current.set(index, px);
    update();
  }, [update]);

  const clearCache = React.useCallback(() => {
    sizeCache.current.clear();
    update();
  }, [update]);

  return { state, setMeasuredSize, clearCache };
}
