import {
  buildSummaryRequestPayload,
  estimateTokens,
  selectRecentForBudget,
  type StoredMessage,
} from '@/components/ai/AiAssistantConfig';

function makeMsgs(n: number, prefix = 'msg'): StoredMessage[] {
  const out: StoredMessage[] = [];
  for (let i = 0; i < n; i++) {
    out.push({
      role: i % 2 === 0 ? 'user' : 'assistant',
      content: `${prefix}-${i} ${  'x'.repeat(50)}`,
      ts: Date.now() - (n - i) * 1000,
    });
  }
  return out;
}

export function runAiAssistantConfigTests() {
  // Test: buildSummaryRequestPayload keeps only tail after cutoff
  {
    const msgs = makeMsgs(25);
    const t = {
      projectId: 'p1',
      version: 1 as const,
      summary: '',
      messages: msgs,
      updatedAt: Date.now(),
    };
    const payload = buildSummaryRequestPayload(t);
    if (payload.keepTailFromIndex !== 15)
      throw new Error('keepTailFromIndex should be 15 for 25 messages');
    if (!payload.system.includes('compress prior conversation'))
      throw new Error('summary system text missing');
    if (!payload.user.includes('Summarize the following prior dialogue'))
      throw new Error('summary user header missing');
  }

  // Test: selectRecentForBudget respects budget and order
  {
    const msgs = makeMsgs(20);
    const baseTokens = 100; // assume system prompt cost
    const budget = 600; // small for test
    const margin = 100; // leave space
    const selected = selectRecentForBudget(msgs, baseTokens, budget, margin);
    const total = selected.reduce(
      (acc, m) => acc + estimateTokens(`[${m.role}] ${m.content}\n`),
      baseTokens
    );
    if (total > budget - margin) throw new Error('selected tokens exceed budget - margin');
    if (!selected.length || !selected[0].content.includes('msg-'))
      throw new Error('selected content malformed');
  }

  // eslint-disable-next-line no-console
  console.log('[TEST] aiAssistantConfig tests passed');
  return true;
}

if (typeof window !== 'undefined') {
  (window as any).__runAiAssistantConfigTests = runAiAssistantConfigTests;
}
