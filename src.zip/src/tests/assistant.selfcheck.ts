/* eslint-disable */
// Dev-only self-checks for AI Assistant wiring
export type SelfCheckResult = {
  name: string;
  pass: boolean;
  info?: string | undefined;
  error?: string | undefined;
};

export function runAiAssistantSelfChecks() {
  const results: SelfCheckResult[] = [];
  const safe = async (name: string, fn: () => any | Promise<any>, info?: string) => {
    try {
      const r = await fn();
      results.push({ name, pass: true, info: info ?? (typeof r === 'string' ? r : undefined) });
    } catch (e: any) {
      results.push({ name, pass: false, error: e?.message || String(e) });
    }
  };

  const start = Date.now();
  // localStorage R/W (non-destructive)
  safe('localStorage: write/read', () => {
    const k = 'synapse.ai.__selfcheck';
    const v = String(Math.random());
    localStorage.setItem(k, v);
    const got = localStorage.getItem(k);
    localStorage.removeItem(k);
    if (got !== v) throw new Error('value mismatch');
    return 'ok';
  });

  // telemetry exports
  safe('telemetry: estimateTokens()', async () => {
    const mod = await import('../services/telemetry');
    const t = mod.estimateTokens('function x(){return 1;}');
    if (typeof t !== 'number' || t < 1) throw new Error('invalid token estimate');
    return `tokens=${t}`;
  });

  // editorBridge exports presence
  safe('editorBridge: basic API presence', async () => {
    const eb = await import('../services/editorBridge');
    const ok = [
      'inferLanguageFromFence',
      'openNewTab',
      'insertIntoActive',
      'replaceSelection',
    ].every(k => typeof (eb as any)[k] === 'function');
    if (!ok) throw new Error('missing functions');
    return 'ok';
  });

  // previewBridge exports presence
  safe('previewBridge: runPreview presence', async () => {
    const pb = await import('../services/previewBridge');
    if (typeof (pb as any).runPreview !== 'function') throw new Error('runPreview missing');
    return 'ok';
  });

  // config presence
  safe('AiAssistantConfig: models/prompts presence', async () => {
    const cfg = await import('../components/ai/AiAssistantConfig');
    const hasModels = Array.isArray((cfg as any).aiModels) && (cfg as any).aiModels.length > 0;
    const hasPrompts =
      Array.isArray((cfg as any).quickPrompts) && (cfg as any).quickPrompts.length > 0;
    if (!hasModels || !hasPrompts) throw new Error('missing models/prompts');
    return `models=${(cfg as any).aiModels.length}, prompts=${(cfg as any).quickPrompts.length}`;
  });

  // Optional: Code block actions component load
  safe('CodeBlockWithActions import', async () => {
    const mod = await import('../components/ai/CodeBlockWithActions');
    if (!mod || typeof (mod as any).CodeBlockWithActions !== 'function')
      throw new Error('component missing');
    return 'ok';
  });

  const took = Date.now() - start;
   
  console.log('[AI_ASSISTANT_SELF_CHECK]', { tookMs: took, results });
  return results;
}

if (typeof window !== 'undefined') {
  (window as any).__runAiSelfCheck = runAiAssistantSelfChecks;
}
