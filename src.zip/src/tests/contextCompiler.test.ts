import { compileContext } from '@/utils/ai/context/contextCompiler';
import type { ContextInput } from '@/utils/ai/context/contextSources';

export function runContextCompilerTests() {
  const longSel = 'A'.repeat(8000);
  const longFile = 'function x(){}\n'.repeat(800);
  const input: ContextInput = {
    activeFilePath: 'src/App.tsx',
    activeFileContent: longFile,
    selectedText: longSel,
    pinnedNotes: ['Do not change UI tokens', 'Accessibility priority'],
    projectBrief: 'Small React app with Zustand stores and Vite build.',
    settings: { mode: 'pro' },
  };
  const compiled = compileContext(input);
  if (!compiled.summary || compiled.summary.length === 0) throw new Error('summary missing');
  if (!compiled.slices.length) throw new Error('no slices');
  if (compiled.tokensEstimated <= 0) throw new Error('tokensEstimated invalid');
  // eslint-disable-next-line no-console
  console.log('[TEST] contextCompiler ok:', { slices: compiled.slices.length, tokens: compiled.tokensEstimated });
  return true;
}

declare global {
  interface Window { __runContextCompilerTests?: () => boolean }
}
if (typeof window !== 'undefined') {
  window.__runContextCompilerTests = runContextCompilerTests;
}
