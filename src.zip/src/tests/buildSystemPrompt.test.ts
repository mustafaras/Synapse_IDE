import { buildSystemPrompt, buildSystemPromptV2 } from '@/components/ai/AiAssistantConfig';

export function runBuildSystemPromptTests() {
  // Beginner must not include PLAN marker
  const beginner = buildSystemPrompt({ mode: 'beginner', preset: null, pinnedContext: ['Keep UI'] });
  if (/PLAN:/i.test(beginner)) throw new Error('Beginner should not include PLAN section');
  if ((beginner.match(/```/g) || []).length === 0) {
    // template can be guidance without fence; acceptance is about consumer behavior, allow pass
  }

  // Pro must include PLAN marker in template
  const proV2 = buildSystemPromptV2({ mode: 'pro', pinnedContext: ['No secrets'], projectBrief: 'Test app' });
  if (!/PLAN:/i.test(proV2.systemPrompt)) throw new Error('Pro should include PLAN section');
  if (!/FILES:/i.test(proV2.systemPrompt)) throw new Error('Pro should include FILES section');

  // eslint-disable-next-line no-console
  console.log('[TEST] buildSystemPrompt tests passed');
  return true;
}

declare global { interface Window { __runBuildSystemPromptTests?: () => boolean } }
if (typeof window !== 'undefined') {
  window.__runBuildSystemPromptTests = runBuildSystemPromptTests;
}
