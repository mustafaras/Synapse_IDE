import { estimateTokens } from '@/services/telemetry';

// Minimal ad-hoc test (no framework) – export function to be invoked manually
export function runTelemetryHeuristicTests() {
  const cases: Array<{ input: string; expectedRange: [number, number] }> = [
    { input: '', expectedRange: [0, 0] },
    { input: 'hello', expectedRange: [1, 5] },
    { input: 'function add(a, b) { return a + b; }', expectedRange: [5, 40] },
    { input: ' '.repeat(40), expectedRange: [0, 5] },
    { input: 'const x = 10;\nconst y = x * 2;\nconsole.log(y);', expectedRange: [5, 60] },
  ];
  const results = cases.map(c => ({
    input: `${c.input.slice(0, 30)  }...`,
    tokens: estimateTokens(c.input),
    pass:
      estimateTokens(c.input) >= c.expectedRange[0] &&
      estimateTokens(c.input) <= c.expectedRange[1],
  }));
  // eslint-disable-next-line no-console
  console.log('[TEST] estimateTokens heuristic results:', results);
  return results.every(r => r.pass);
}

// Auto-run if executed directly in a browser/dev environment
if (typeof window !== 'undefined') {
  (window as any).__runTelemetryHeuristicTests = runTelemetryHeuristicTests;
}
