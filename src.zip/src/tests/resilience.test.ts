import { classifyProviderError, selectFallbackModel } from '@/components/ai/AiAssistantConfig';

const HTTP_TOO_MANY = 429;
const HTTP_SERVER_ERROR = 500;
const HTTP_UNAUTHORIZED = 401;

export function runResilienceTests() {
  // classifyProviderError: HTTP status parsing
  const e429 = classifyProviderError(new Error(`HTTP ${HTTP_TOO_MANY} Too Many Requests`));
  if (!(e429.retryable && e429.type === 'rate_limit' && e429.status === HTTP_TOO_MANY))
    throw new Error('429 should be retryable rate_limit');

  const e500 = classifyProviderError(new Error(`Server error ${HTTP_SERVER_ERROR}`));
  if (!(e500.retryable && e500.type === 'server' && e500.status === HTTP_SERVER_ERROR))
    throw new Error('500 should be retryable server');

  const e401 = classifyProviderError(new Error(`${HTTP_UNAUTHORIZED} Unauthorized`));
  if (!(e401.retryable === false && e401.type === 'auth' && e401.status === HTTP_UNAUTHORIZED))
    throw new Error('401 should be non-retryable auth');

  const enet = classifyProviderError(new Error('Failed to fetch'));
  if (!(enet.retryable && enet.type === 'network')) throw new Error('Network should be retryable');

  const abortLike: { name: string; message: string } = {
    name: 'AbortError',
    message: 'The operation was aborted',
  };
  const eabort = classifyProviderError(abortLike);
  if (!(eabort.retryable && eabort.type === 'network'))
    throw new Error('Abort should be retryable network');

  // selectFallbackModel: prefers same provider options
  const fbOpenAI = selectFallbackModel('chatgpt-4o-latest', 'openai');
  if (!fbOpenAI || fbOpenAI === 'chatgpt-4o-latest')
    throw new Error('Fallback for openai should differ from current');

  const fbAnthropic = selectFallbackModel('claude-3-opus-20240229', 'anthropic');
  if (!fbAnthropic || fbAnthropic === 'claude-3-opus-20240229')
    throw new Error('Fallback for anthropic should differ from current');

  // eslint-disable-next-line no-console
  console.log('[TEST] resilience tests passed');
  return true;
}

declare global {
  interface Window {
    __runResilienceTests: () => boolean;
  }
}

if (typeof window !== 'undefined') {
  window.__runResilienceTests = runResilienceTests;
}
