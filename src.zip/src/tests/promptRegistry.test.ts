import { describe, expect, it } from 'vitest';
import { loadPrompt } from '@/prompts/loader';

describe('Prompt Registry & Loader', () => {
  it('resolves caret range to highest matching version', () => {
    const { version, text } = loadPrompt('system.pro', '^1.0.0', {
      LANG_NAME: 'TypeScript',
      FENCE_LANG: 'ts',
      CONTEXT_SNIPPET: 'Summary here',
    });
    expect(version).toBe('1.2.0');
    expect(text).toContain('PLAN:');
    expect(text).toContain('FILES:');
  });

  it('throws when unresolved template tokens remain', () => {
    expect(() =>
      loadPrompt('system.beginner', '1.0.0', {
        LANG_NAME: 'JS',
        // FENCE_LANG missing on purpose
        CONTEXT_SNIPPET: 'X',
      } as unknown as Record<string, string>),
    ).toThrowError(/Unresolved template tokens/);
  });
});
