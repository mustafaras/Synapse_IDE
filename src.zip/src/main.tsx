import React from 'react';
import { createRoot } from 'react-dom/client';
// import { ErrorBoundary } from './components/utilities';
// import './tailwind.css';  // Commented out to avoid import issues
// import './index.css';      // Commented out to avoid import issues
import AppRoot from './app/AppRoot';
import { AppErrorBoundary, installGlobalRejectionHandler } from './app/ErrorBoundary';
import './services/tasksAdapter';

console.log('🚀 Starting App...');
console.log('React version:', React?.version || 'Unknown');

const rootElement = document.getElementById('root');
console.log('Root element:', rootElement);

if (!rootElement) {
  console.error('❌ ROOT ELEMENT NOT FOUND!');
  document.body.innerHTML =
    '<h1 style="color: red; font-size: 2rem; text-align: center; margin-top: 2rem;">ERROR: Root element not found!</h1>';
} else {
  console.log('✅ Root element found, creating React root...');
  try {
    installGlobalRejectionHandler();
    const root = createRoot(rootElement);
    console.log('✅ React root created, rendering App...');
    root.render(
      <React.StrictMode>
        <AppErrorBoundary>
          <AppRoot />
        </AppErrorBoundary>
      </React.StrictMode>
    );
    console.log('✅ APP RENDERED!');
  } catch (error) {
    console.error('❌ Error rendering app:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    const errorStack = error instanceof Error ? error.stack : String(error);
    document.body.innerHTML = `<h1 style="color: red; font-size: 1.5rem; text-align: center; margin: 2rem; padding: 2rem; border: 2px solid red;">ERROR: ${errorMessage}</h1>`;
    document.body.innerHTML += `<pre style="color: red; text-align: left; margin: 2rem; padding: 1rem; background: #f0f0f0;">${errorStack}</pre>`;
  }
}
