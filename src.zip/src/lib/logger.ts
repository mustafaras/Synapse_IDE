type Level = 'debug' | 'info' | 'warn' | 'error';
const PREFIX = '[AI-TRACE]';

function ts() {
  try {
    return performance.now().toFixed(2).padStart(8, ' ');
  } catch {
    return '--------';
  }
}

function log(level: Level, ...msg: any[]) {
  const line = [PREFIX, `[${ts()}]`, `[${level.toUpperCase()}]`, ...msg].join(' ');
  (console as any)[level === 'debug' ? 'log' : level](line);
}

export const logger = {
  debug: (...m: any[]) => log('debug', ...m),
  info: (...m: any[]) => log('info', ...m),
  warn: (...m: any[]) => log('warn', ...m),
  error: (...m: any[]) => log('error', ...m),
};
