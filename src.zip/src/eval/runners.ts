import { getAdapter } from '../services/ai/adapters';
import type { EvalRunOptions } from './types';
import { keyFor, readCassette, writeCassette } from './cassette';

export async function runCase(prompt: string, opts: EvalRunOptions) {
  const fingerprint = keyFor(prompt, opts);
  const dir = opts.cassetteDir ?? '.eval_cassettes';
  if (!opts.live) {
    const cached = readCassette(dir, fingerprint);
    if (cached !== undefined) return { text: cached, source: 'replay' as const, key: fingerprint };
    throw new Error(`Cassette miss for ${fingerprint}. Run scripts/eval/record.cjs to record.`);
  }
  const adapter = getAdapter(opts.provider);
  const { text } = await adapter.complete({
    options: { model: opts.model, temperature: 0, maxTokens: opts.maxTokens },
    messages: [{ role: 'user', content: prompt }],
    timeoutMs: opts.timeoutMs ?? 15000,
  });
  writeCassette(dir, fingerprint, text);
  return { text, source: 'live' as const, key: fingerprint };
}
