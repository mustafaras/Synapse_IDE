import type { EvalResult } from '../types';

export function junitXml(r: EvalResult) {
  const failures = r.total - r.passed;
  const body = r.cases
    .map((c) =>
      c.ok
        ? `<testcase name="${escapeXml(c.id)}" />`
        : `<testcase name="${escapeXml(c.id)}"><failure message="${escapeXml(c.reason || 'fail')}" /></testcase>`
    )
    .join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>
<testsuite name="eval:${escapeXml(r.datasetId)}" tests="${r.total}" failures="${failures}">
${body}
</testsuite>`;
}

function escapeXml(s: string) {
  const map: Record<string, string> = { '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' };
  return s.replace(/[<>&'"']/g, (c) => map[c]!);
}
