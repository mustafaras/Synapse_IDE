import type { EvalResult } from '../types';

export function mdSummary(r: EvalResult) {
  const pct = ((r.passed / r.total) * 100).toFixed(1);
  const fails = r.failIds.length ? `\n**Fails:** ${r.failIds.join(', ')}` : '';
  return `### Eval: ${r.datasetId}\n- Passed: ${r.passed}/${r.total} (${pct}%)${fails}\n`;
}
