import { load as yamlLoad } from 'js-yaml';
import type { Dataset } from './types';

export function loadYamlDataset(text: string): Dataset {
  const obj = yamlLoad(text) as unknown;
  const maybe = obj as { meta?: unknown; tasks?: unknown } | undefined;
  const tasks = (maybe && Array.isArray(maybe.tasks) ? maybe.tasks : []) as unknown[];
  if (!maybe || tasks.length === 0) throw new Error('Dataset missing tasks');
  return obj as Dataset;
}
