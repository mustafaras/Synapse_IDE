declare module 'js-yaml' {
  export function load(str: string, opts?: unknown): unknown;
}
