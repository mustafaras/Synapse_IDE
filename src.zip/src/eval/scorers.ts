export type ScoreFn = (out: string, args?: unknown) => { ok: boolean; reason?: string | undefined; score?: number };

function isRecord(v: unknown): v is Record<string, unknown> { return typeof v === 'object' && v !== null; }
function str(v: unknown, fb = ''): string { return v == null ? fb : String(v); }
function strArg(args: unknown, key: string, fb = ''): string { return isRecord(args) ? str(args[key], fb) : fb; }
function strArrArg(args: unknown, key: string): string[] {
  if (isRecord(args)) {
    const v = args[key];
    if (Array.isArray(v)) return v.map((x) => String(x));
  }
  return [];
}

export const scorers: Record<string, ScoreFn> = {
  exact: (out, args) => ({ ok: out.trim() === strArg(args, 'expected', '').trim(), reason: 'exact mismatch' }),
  contains: (out, args) => {
    const needles = strArrArg(args, 'needles');
    const misses = needles.filter((n) => !out.toLowerCase().includes(n.toLowerCase()));
    return { ok: misses.length === 0, reason: misses.length ? `missing: ${misses.join(',')}` : undefined };
  },
  not_contains: (out, args) => {
    const needles = strArrArg(args, 'needles');
    const bad = needles.filter((n) => out.toLowerCase().includes(n.toLowerCase()));
    return { ok: bad.length === 0, reason: bad.length ? `found disallowed: ${bad.join(',')}` : undefined };
  },
  regex: (out, args) => {
    const pattern = strArg(args, 'pattern', '');
    const flags = strArg(args, 'flags', 'i');
    const rx = new RegExp(pattern, flags);
    return { ok: rx.test(out), reason: 'regex failed' };
  },
  keywords: (out, args) => {
    const req = strArrArg(args, 'required');
    const forb = strArrArg(args, 'forbidden');
    const miss = req.filter((k) => !out.includes(k));
    const bad = forb.filter((k) => out.includes(k));
    const ok = miss.length === 0 && bad.length === 0;
    return { ok, reason: ok ? undefined : `miss:${miss.join(',')} bad:${bad.join(',')}` };
  },
  json: (out, args) => {
    try {
      const obj = JSON.parse(extractJson(out));
      const schema = isRecord(args) ? (args as Record<string, unknown>)['schema'] : undefined;
      const ok = validateJson(obj, schema);
      return { ok, reason: ok ? undefined : 'json schema fail' };
    } catch {
      return { ok: false, reason: 'invalid json' };
    }
  },
};

function extractJson(s: string) {
  const fence = s.match(/```json([\s\S]*?)```/i);
  if (fence) return fence[1];
  return s.trim();
}
type PropSchema = 'string' | 'number' | { type?: 'string' | 'number'; enum?: unknown[] };
type SimpleSchema = { type?: 'object'; required?: string[]; properties?: Record<string, PropSchema> };

function validateJson(obj: unknown, schema: unknown): boolean {
  if (!isRecord(schema)) return typeof obj === 'object' && obj !== null;
  const s = schema as SimpleSchema;
  if (s.type && s.type !== 'object') return false;
  const o = (obj ?? {}) as Record<string, unknown>;
  if (Array.isArray(s.required)) {
    for (const k of s.required) if (!(k in o)) return false;
  }
  if (s.properties && typeof s.properties === 'object' && s.properties) {
    for (const [k, p] of Object.entries(s.properties)) {
      if (o[k] === undefined) continue;
      if (p === 'string' || (typeof p === 'object' && p && (p as { type?: 'string' | 'number' }).type === 'string')) {
        if (typeof o[k] !== 'string') return false;
      }
      if (p === 'number' || (typeof p === 'object' && p && (p as { type?: 'string' | 'number' }).type === 'number')) {
        if (typeof o[k] !== 'number') return false;
      }
      if (typeof p === 'object' && p && Array.isArray((p as { enum?: unknown[] }).enum) && !(p as { enum?: unknown[] }).enum!.includes(o[k])) return false;
    }
  }
  return true;
}
