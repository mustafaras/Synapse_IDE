import { loadYamlDataset } from './loader';
import { scorers } from './scorers';
import { runCase } from './runners';
import { junitXml } from './reporters/junit';
import { mdSummary } from './reporters/markdown';
import type { EvalResult, EvalRunOptions } from './types';

export async function runDataset(yamlText: string, opts: EvalRunOptions): Promise<{ result: EvalResult; junit: string; md: string }> {
  const ds = loadYamlDataset(yamlText);
  let pass = 0;
  const cases: EvalResult['cases'] = [];
  for (const t of ds.tasks) {
    const p = interpolate(t.prompt, t.params || {});
    try {
      const out = await runCase(p, { ...ds.meta.default, ...opts, languageId: opts.languageId } as EvalRunOptions);
      const scorer = scorers[t.expect.scorer];
      const s = scorer ? scorer(out.text, t.expect.args) : { ok: false, reason: `unknown scorer: ${t.expect.scorer}` };
      if (s.ok) pass++;
      cases.push(s.reason ? { id: t.id, ok: s.ok, reason: s.reason } : { id: t.id, ok: s.ok });
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'error';
      cases.push({ id: t.id, ok: false, reason: msg });
    }
  }
  const result: EvalResult = {
    datasetId: ds.meta.id,
    passed: pass,
    total: ds.tasks.length,
    failIds: cases.filter((c) => !c.ok).map((c) => c.id),
    cases,
  };
  const junit = junitXml(result);
  const md = mdSummary(result);
  return { result, junit, md };
}

function interpolate(t: string, params: Record<string, unknown>) {
  return t.replace(/\{\{\s*([A-Za-z0-9_.-]+)\s*\}\}/g, (_, k: string) => {
    const v = Object.prototype.hasOwnProperty.call(params, k) ? (params as Record<string, unknown>)[k] : '';
    return String(v ?? '');
  });
}
