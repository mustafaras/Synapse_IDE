export type ProviderKey = 'openai' | 'anthropic' | 'gemini' | 'ollama';

export interface EvalMeta {
  id: string;
  version: number;
  description?: string;
  default?: Partial<EvalRunOptions>;
}

export interface Task {
  id: string;
  mode: 'beginner' | 'pro';
  prompt: string;
  params?: Record<string, unknown>;
  expect: {
    scorer: 'exact' | 'contains' | 'not_contains' | 'regex' | 'json' | 'keywords';
  args?: Record<string, unknown>;
  };
  notes?: string;
}

export interface Dataset {
  meta: EvalMeta;
  tasks: Task[];
}

export interface EvalRunOptions {
  provider: ProviderKey;
  model: string;
  temperature: number;
  maxTokens: number;
  languageId: string;
  live?: boolean;
  cassetteDir?: string;
  timeoutMs?: number;
}

export interface EvalResult {
  datasetId: string;
  passed: number;
  total: number;
  failIds: string[];
  cases: Array<{
    id: string;
    ok: boolean;
    score?: number;
    reason?: string;
  }>;
}
