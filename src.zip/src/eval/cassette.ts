import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type { EvalRunOptions } from './types';

export function keyFor(prompt: string, opts: EvalRunOptions) {
  const base = JSON.stringify({ p: prompt, model: opts.model, provider: opts.provider, temp: opts.temperature, max: opts.maxTokens });
  return crypto.createHash('sha256').update(base).digest('hex').slice(0, 16);
}

export function readCassette(dir: string, key: string): string | undefined {
  try {
    return fs.readFileSync(path.join(dir, `${key}.txt`), 'utf8');
  } catch {
    return undefined;
  }
}

export function writeCassette(dir: string, key: string, text: string) {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, `${key}.txt`), text, 'utf8');
}
